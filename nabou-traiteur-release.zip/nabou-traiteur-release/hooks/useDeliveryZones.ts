import { useState, useEffect } from 'react'
import { toast } from 'sonner'

// Types
export interface DeliveryZone {
  id: string
  name: string
  description?: string
  deliveryFee: number
  minOrderAmount?: number
  maxOrderAmount?: number
  estimatedTime?: string
  isActive: boolean
  sortOrder: number
  areas: string[]
  _count?: {
    orders: number
  }
  createdAt: string
  updatedAt: string
}

export interface DeliveryZonesResponse {
  data: DeliveryZone[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

export interface CreateDeliveryZoneData {
  name: string
  description?: string
  deliveryFee: number
  minOrderAmount?: number
  maxOrderAmount?: number
  estimatedTime?: string
  isActive?: boolean
  sortOrder?: number
  areas?: string[]
}

export interface UpdateDeliveryZoneData {
  name?: string
  description?: string
  deliveryFee?: number
  minOrderAmount?: number
  maxOrderAmount?: number
  estimatedTime?: string
  isActive?: boolean
  sortOrder?: number
  areas?: string[]
}

export interface UseDeliveryZonesParams {
  page?: number
  limit?: number
  search?: string
  isActive?: boolean
}

export function useDeliveryZones(params: UseDeliveryZonesParams = {}) {
  const [zones, setZones] = useState<DeliveryZone[]>([])
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 0
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchZones = async () => {
    try {
      setLoading(true)
      setError(null)

      const searchParams = new URLSearchParams()
      if (params.page) searchParams.set('page', params.page.toString())
      if (params.limit) searchParams.set('limit', params.limit.toString())
      if (params.search) searchParams.set('search', params.search)
      if (params.isActive !== undefined) searchParams.set('isActive', params.isActive.toString())

      const response = await fetch(`/api/delivery/zones?${searchParams.toString()}`, {
        headers: {
          'Content-Type': 'application/json',
        },
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || 'Erreur lors du chargement des zones')
      }

      const result = await response.json()
      // L'API retourne { success: true, data: { data: [...], pagination: {...} } }
      const data = result.data || result
      setZones(data.data || [])
      setPagination(data.pagination || { page: 1, limit: 10, total: 0, totalPages: 0 })
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erreur inconnue'
      setError(errorMessage)
      toast.error(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  const createZone = async (zoneData: CreateDeliveryZoneData): Promise<DeliveryZone | null> => {
    try {
      setLoading(true)
      setError(null)

      const response = await fetch('/api/delivery/zones', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(zoneData),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || 'Erreur lors de la création de la zone')
      }

      const result = await response.json()
      const newZone = result.data || result
      setZones(prev => [...prev, newZone])
      toast.success('Zone de livraison créée avec succès')
      return newZone
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erreur inconnue'
      setError(errorMessage)
      toast.error(errorMessage)
      return null
    } finally {
      setLoading(false)
    }
  }

  const updateZone = async (id: string, zoneData: UpdateDeliveryZoneData): Promise<DeliveryZone | null> => {
    try {
      setLoading(true)
      setError(null)

      const response = await fetch(`/api/delivery/zones/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(zoneData),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || 'Erreur lors de la modification de la zone')
      }

      const result = await response.json()
      const updatedZone = result.data || result
      setZones(prev => prev.map(zone => zone.id === id ? updatedZone : zone))
      toast.success('Zone de livraison modifiée avec succès')
      return updatedZone
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erreur inconnue'
      setError(errorMessage)
      toast.error(errorMessage)
      return null
    } finally {
      setLoading(false)
    }
  }

  const deleteZone = async (id: string): Promise<boolean> => {
    try {
      setLoading(true)
      setError(null)

      const response = await fetch(`/api/delivery/zones/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || 'Erreur lors de la suppression de la zone')
      }

      setZones(prev => prev.filter(zone => zone.id !== id))
      toast.success('Zone de livraison supprimée avec succès')
      return true
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erreur inconnue'
      setError(errorMessage)
      toast.error(errorMessage)
      return false
    } finally {
      setLoading(false)
    }
  }

  const toggleZoneStatus = async (id: string): Promise<boolean> => {
    const zone = zones.find(z => z.id === id)
    if (!zone) return false

    const result = await updateZone(id, { isActive: !zone.isActive })
    return result !== null
  }

  useEffect(() => {
    fetchZones()
  }, [params.page, params.limit, params.search, params.isActive])

  return {
    zones,
    pagination,
    loading,
    error,
    fetchZones,
    createZone,
    updateZone,
    deleteZone,
    toggleZoneStatus,
  }
}

export default useDeliveryZones