import { useState, useEffect } from "react";
import {
  WeeklyMenuItem,
  WeeklyMenuResponse,
  WeeklyMenuStats,
  UseWeeklyMenuReturn,
} from "@/types/weeklyMenuPublic";

export function useWeeklyMenu(): UseWeeklyMenuReturn {
  const [weeklyMenu, setWeeklyMenu] = useState<
    Record<string, WeeklyMenuItem[]>
  >({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<WeeklyMenuStats | null>(null);

  const fetchWeeklyMenu = async () => {
    try {
      setLoading(true);
      setError(null);

      // Get user from localstorage
      const state = JSON.parse(localStorage.getItem("auth-storage") || "{}");
      const user = state.state.user;
      const employeeId = user?.id;

      const response = await fetch(
        `/api/menu/public/weekly?current=true&includeDishes=true&employee=${employeeId}`
      );

      if (!response.ok) {
        throw new Error(`Erreur HTTP: ${response.status}`);
      }

      const data: WeeklyMenuResponse = await response.json();

      if (!data.success) {
        throw new Error("Erreur lors de la récupération du menu");
      }

      setWeeklyMenu(data.data.weeklyMenu);
      setStats(data.data.stats);
    } catch (err) {
      console.error("Erreur lors de la récupération du menu:", err);
      setError(err instanceof Error ? err.message : "Une erreur est survenue");
      // En cas d'erreur, on garde un menu vide plutôt que de planter l'app
      setWeeklyMenu({});
      setStats(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeeklyMenu();
  }, []);

  return {
    weeklyMenu,
    loading,
    error,
    stats,
    refetch: fetchWeeklyMenu,
  };
}
