import { useState, useEffect } from 'react';
import { useAuthStore } from '@/stores/authStore';
import { DashboardData } from '@/types/dashboard';

interface UseDashboardReturn {
  data: DashboardData | null;
  loading: boolean;
  error: string | null;
  refetch: () => void;
  fetchData: (startDate?: string, endDate?: string, companyIds?: string[]) => void;
}

export function useDashboard(): UseDashboardReturn {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { token } = useAuthStore();

  const fetchDashboardData = async (startDate?: string, endDate?: string, companyIds: string[] = []) => {
    if (!token) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const queryParams = new URLSearchParams();
      
      // Ajouter les dates personnalisées si fournies
      if (startDate) {
        queryParams.set('startDate', startDate);
      }
      if (endDate) {
        queryParams.set('endDate', endDate);
      }
      
      // Ajouter les compagnies si sélectionnées
      if (companyIds.length > 0) {
        queryParams.set('companyIds', companyIds.join(','));
      }
      
      const response = await fetch(`/api/analytics/dashboard?${queryParams.toString()}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Erreur lors de la récupération des données');
      }

      const result = await response.json();
      
      // L'API retourne les données dans un format { success: true, data: ... }
      if (result.success && result.data) {
        setData(result.data);
      } else {
        throw new Error(result.message || 'Format de réponse invalide');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur est survenue');
    } finally {
      setLoading(false);
    }
  };

  // Supprimer l'useEffect automatique
  // useEffect(() => {
  //   fetchDashboardData();
  // }, [startDate, endDate, companyIds, token]);

  const refetch = () => {
    // Pour la compatibilité, on peut garder cette fonction mais elle ne fera rien sans paramètres
  };

  const fetchData = (startDate?: string, endDate?: string, companyIds: string[] = []) => {
    fetchDashboardData(startDate, endDate, companyIds);
  };

  return {
    data,
    loading,
    error,
    refetch,
    fetchData,
  };
}