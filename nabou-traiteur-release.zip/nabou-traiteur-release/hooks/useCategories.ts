import { useEffect } from 'react';
import { usePublicCategoriesStore } from '../stores/publicCategoriesStore';
import { Category } from '../types/categories';

interface UseCategoriesReturn {
  categories: Category[];
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

/**
 * @deprecated This hook is deprecated. Use usePublicCategoriesStore directly instead.
 * This hook will be removed in a future version.
 * 
 * Migration example:
 * ```typescript
 * // Old way
 * const { categories, loading, error, refetch } = useCategories();
 * 
 * // New way
 * const { categories, loading, error, refetch } = usePublicCategoriesStore();
 * ```
 */
export function useCategories(): UseCategoriesReturn {
  // Show deprecation warning in development
  if (process.env.NODE_ENV === 'development') {
    console.warn(
      '⚠️ useCategories hook is deprecated. Please use usePublicCategoriesStore directly instead. ' +
      'This hook will be removed in a future version. ' +
      'See migration guide in the hook documentation.'
    );
  }

  const {
    categories,
    loading,
    error,
    fetchCategories,
    refetch,
    isDataFresh
  } = usePublicCategoriesStore();

  // Auto-fetch data if not fresh (maintains backward compatibility)
  useEffect(() => {
    if (!isDataFresh()) {
      fetchCategories();
    }
  }, [fetchCategories, isDataFresh]);

  return {
    categories,
    loading,
    error,
    refetch,
  };
}