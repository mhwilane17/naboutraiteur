import { useEffect } from "react";
import { DeliveryZone } from "@/services/deliveryService";
import { PaymentMethod } from "@/services/paymentService";
import { usePublicDeliveryZonesStore } from "../stores/publicDeliveryZonesStore";
import { usePublicPaymentMethodsStore } from "../stores/publicPaymentMethodsStore";

interface UseDeliveryAndPaymentReturn {
  deliveryZones: DeliveryZone[];
  paymentMethods: PaymentMethod[];
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

/**
 * @deprecated This hook is deprecated. Use usePublicDeliveryZonesStore and usePublicPaymentMethodsStore directly instead.
 * This hook will be removed in a future version.
 * 
 * Migration example:
 * ```typescript
 * // Old way
 * const { deliveryZones, paymentMethods, loading, error, refetch } = useDeliveryAndPayment();
 * 
 * // New way
 * const { 
 *   deliveryZones, 
 *   loading: deliveryLoading, 
 *   error: deliveryError, 
 *   fetchDeliveryZones,
 *   isDataFresh: isDeliveryDataFresh 
 * } = usePublicDeliveryZonesStore();
 * 
 * const { 
 *   paymentMethods, 
 *   loading: paymentLoading, 
 *   error: paymentError, 
 *   fetchPaymentMethods,
 *   isDataFresh: isPaymentDataFresh 
 * } = usePublicPaymentMethodsStore();
 * ```
 */
export function useDeliveryAndPayment(): UseDeliveryAndPaymentReturn {
  // Show deprecation warning in development
  if (process.env.NODE_ENV === 'development') {
    console.warn(
      '⚠️ useDeliveryAndPayment hook is deprecated. Please use usePublicDeliveryZonesStore and usePublicPaymentMethodsStore directly instead. ' +
      'This hook will be removed in a future version. ' +
      'See migration guide in the hook documentation.'
    );
  }

  const {
    deliveryZones,
    loading: deliveryLoading,
    error: deliveryError,
    fetchDeliveryZones,
    refetch: refetchDeliveryZones,
    isDataFresh: isDeliveryDataFresh
  } = usePublicDeliveryZonesStore();

  const {
    paymentMethods,
    loading: paymentLoading,
    error: paymentError,
    fetchPaymentMethods,
    refetch: refetchPaymentMethods,
    isDataFresh: isPaymentDataFresh
  } = usePublicPaymentMethodsStore();

  // Auto-fetch data if not fresh (maintains backward compatibility)
  useEffect(() => {
    if (!isDeliveryDataFresh()) {
      fetchDeliveryZones();
    }
    if (!isPaymentDataFresh()) {
      fetchPaymentMethods();
    }
  }, [fetchDeliveryZones, fetchPaymentMethods, isDeliveryDataFresh, isPaymentDataFresh]);

  // Combined loading state
  const loading = deliveryLoading || paymentLoading;
  
  // Combined error state (prioritize the first error encountered)
  const error = deliveryError || paymentError;

  // Combined refetch function
  const refetch = async () => {
    await Promise.all([
      refetchDeliveryZones(),
      refetchPaymentMethods()
    ]);
  };

  return {
    deliveryZones,
    paymentMethods,
    loading,
    error,
    refetch,
  };
}
