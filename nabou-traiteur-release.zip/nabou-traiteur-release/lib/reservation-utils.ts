export interface OrderFormData {
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  employeeId: string | undefined;
  deliveryZoneId: string;
  deliveryAddress: string;
  deliveryTime: string;
  customerNotes: string;
  paymentMethod: string;
  weeklyMenuId: string;
}

export interface ReservationStep {
  id: number;
  title: string;
  isValid: (data: any) => boolean;
}

export interface StepValidationResult {
  isValid: boolean;
  errors?: string[];
}

export interface ReservationMode {
  cartMode: boolean;
}

export interface PromoState {
  code: string;
  isValid: boolean;
  isValidating: boolean;
  message: string | null;
  discountAmount: number;
  isFreeDelivery: boolean;
}

export interface OrderCalculation {
  basePrice: number;
  itemPrice: number;
  deliveryPrice: number;
  discountedSubtotal: number;
  effectiveDeliveryFee: number;
  totalPrice: number;
}

export function calculateOrderPricing(
  quantity: number,
  basePrice: number,
  deliveryPrice: number,
  isPromoValid: boolean,
  promoDiscountAmount: number,
  promoIsFreeDelivery: boolean
): OrderCalculation {
  const itemPrice = basePrice * quantity;
  const discountedSubtotal = Math.max(
    0,
    Number(itemPrice) - (isPromoValid ? promoDiscountAmount : 0)
  );
  const effectiveDeliveryFee = promoIsFreeDelivery ? 0 : Number(deliveryPrice);
  const totalPrice = discountedSubtotal + effectiveDeliveryFee;

  return {
    basePrice,
    itemPrice,
    deliveryPrice,
    discountedSubtotal,
    effectiveDeliveryFee,
    totalPrice,
  };
}

// Gestion des étapes de réservation
export function getStepCount(): number {
  return 2; // Mode normal : infos + confirmation
}

export function getStepTitle(step: number,): string {

  // Mode normal
  switch (step) {
    case 1: return "Informations";
    case 2: return "Confirmation";
    default: return "";
  }
}

// Validation des étapes
export function validateCurrentStep(
  step: number,
  formData: OrderFormData,
  isEmployee?: boolean
): StepValidationResult {  

  // Mode normal
  if (step === 1) {
    const errors: string[] = [];
    
    if (isEmployee) {
      // Pour les employés, seule l'heure de livraison est obligatoire
      if (!formData.deliveryTime) errors.push("L'heure de livraison est requise");
    } else {
      // Pour les clients normaux, tous les champs sont obligatoires
      if (!formData.firstName.trim()) errors.push("Le prénom est requis");
      if (!formData.lastName.trim()) errors.push("Le nom est requis");
      if (!formData.phone.trim()) errors.push("Le téléphone est requis");
      if (!formData.deliveryZoneId) errors.push("La zone de livraison est requise");
      if (!formData.deliveryAddress.trim()) errors.push("L'adresse est requise");
      if (!formData.deliveryTime) errors.push("L'heure de livraison est requise");
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  return { isValid: true };
}

// Calculer les prix selon le mode
export function calculatePricing(
  cartSubtotal: number
) {

  let itemPrice = 0;
  let basePrice = 0;
  let selectedOption: any = null;

  itemPrice = cartSubtotal;


  return {
    itemPrice,
    basePrice,
    selectedOption
  };
}