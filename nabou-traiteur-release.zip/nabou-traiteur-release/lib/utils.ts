import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import bcrypt from 'bcryptjs'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Fonction pour vérifier si on peut bénéficier de la promo Rak Tak (8h-10h)
 * @returns {boolean} true si l'heure actuelle est entre 8h et 10h, false sinon
 */
export const isRakTakTime = (): boolean => {
  const now = new Date();
  const currentHour = now.getHours();
  return currentHour >= 8 && currentHour < 10;
};

/**
 * Génère un mot de passe fort aléatoirement
 * @returns Un mot de passe fort de 12 caractères
 */
export function generateStrongPassword(): string {
  const length = 12;
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
  let password = "";
  
  // S'assurer qu'on a au moins un caractère de chaque type
  password += "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[Math.floor(Math.random() * 26)]; // Majuscule
  password += "abcdefghijklmnopqrstuvwxyz"[Math.floor(Math.random() * 26)]; // Minuscule
  password += "0123456789"[Math.floor(Math.random() * 10)]; // Chiffre
  password += "!@#$%^&*"[Math.floor(Math.random() * 8)]; // Caractère spécial
  
  // Compléter avec des caractères aléatoaires
  for (let i = 4; i < length; i++) {
    password += charset[Math.floor(Math.random() * charset.length)];
  }
  
  // Mélanger les caractères
  return password.split('').sort(() => Math.random() - 0.5).join('');
}

/**
 * Hash un mot de passe avec bcrypt
 * @param password - Le mot de passe en clair
 * @returns Le hash du mot de passe
 */
export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
}
