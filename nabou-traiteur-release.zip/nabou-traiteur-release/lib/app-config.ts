import { prisma } from "@/lib/prisma";

/**
 * Cache pour les configurations d'application
 */
const configCache = new Map<string, { value: any; timestamp: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

/**
 * Récupère une configuration d'application par sa clé
 * @param key - Clé de la configuration
 * @param defaultValue - Valeur par défaut si la configuration n'existe pas
 * @returns La valeur de la configuration
 */
export async function getAppConfig<T = string>(
  key: string,
  defaultValue?: T
): Promise<T> {
  try {
    // Vérifier le cache
    const cached = configCache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      return cached.value;
    }

    // Récupérer depuis la base de données
    const config = await prisma.appConfiguration.findUnique({
      where: { key }
    });

    if (!config) {
      return defaultValue as T;
    }

    // Parser la valeur selon le type
    let parsedValue: any = config.value;

    switch (config.type) {
      case 'number':
        parsedValue = parseFloat(config.value);
        break;
      case 'boolean':
        parsedValue = config.value.toLowerCase() === 'true';
        break;
      case 'json':
        try {
          parsedValue = JSON.parse(config.value);
        } catch {
          parsedValue = config.value;
        }
        break;
      case 'time':
        // Retourner l'heure au format HH:MM
        parsedValue = config.value;
        break;
      default:
        parsedValue = config.value;
    }

    // Mettre en cache
    configCache.set(key, {
      value: parsedValue,
      timestamp: Date.now()
    });

    return parsedValue;
  } catch (error) {
    console.error(`Erreur lors de la récupération de la configuration ${key}:`, error);
    return defaultValue as T;
  }
}

/**
 * Récupère plusieurs configurations d'application
 * @param keys - Tableau des clés de configuration
 * @returns Objet avec les configurations
 */
export async function getAppConfigs(keys: string[]): Promise<Record<string, any>> {
  try {
    const configs = await prisma.appConfiguration.findMany({
      where: {
        key: {
          in: keys
        }
      }
    });

    const result: Record<string, any> = {};

    for (const config of configs) {
      let parsedValue: any = config.value;

      switch (config.type) {
        case 'number':
          parsedValue = parseFloat(config.value);
          break;
        case 'boolean':
          parsedValue = config.value.toLowerCase() === 'true';
          break;
        case 'json':
          try {
            parsedValue = JSON.parse(config.value);
          } catch {
            parsedValue = config.value;
          }
          break;
        case 'time':
          parsedValue = config.value;
          break;
        default:
          parsedValue = config.value;
      }

      result[config.key] = parsedValue;

      // Mettre en cache
      configCache.set(config.key, {
        value: parsedValue,
        timestamp: Date.now()
      });
    }

    return result;
  } catch (error) {
    console.error('Erreur lors de la récupération des configurations:', error);
    return {};
  }
}

/**
 * Vide le cache des configurations
 */
export function clearConfigCache(): void {
  configCache.clear();
}

/**
 * Récupère les heures d'ouverture et de fermeture pour les commandes
 * @returns Objet avec les heures d'ouverture et de fermeture
 */
export async function getOrderingHours(): Promise<{
  openingTime: string;
  closingTime: string;
}> {
  const configs = await getAppConfigs(['orders.opening_time', 'orders.closing_time']);

  return {
    openingTime: configs['orders.opening_time'] || '07:00',
    closingTime: configs['orders.closing_time'] || '16:00'
  };
}

/**
 * Vérifie si l'heure actuelle est dans la plage de commande
 * @returns true si les commandes sont acceptées, false sinon
 */
export async function isOrderingTimeActive(): Promise<boolean> {
  try {
    const { openingTime, closingTime } = await getOrderingHours();

    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const currentTime = currentHour * 60 + currentMinute; // Convertir en minutes

    // Parser les heures d'ouverture et de fermeture
    const [openHour, openMinute] = openingTime.split(':').map(Number);
    const [closeHour, closeMinute] = closingTime.split(':').map(Number);

    const openingMinutes = openHour * 60 + openMinute;
    const closingMinutes = closeHour * 60 + closeMinute;

    return currentTime >= openingMinutes && currentTime < closingMinutes;
  } catch (error) {
    console.error('Erreur lors de la vérification des heures de commande:', error);
    // Valeurs par défaut en cas d'erreur (7h-16h)
    const now = new Date();
    const currentHour = now.getHours();
    return currentHour >= 7 && currentHour < 16;
  }
}

/**
 * Récupère toutes les configurations de notifications
 * @returns Objet avec toutes les configurations de notifications
 */
export async function getNotificationConfigs(): Promise<{
  fromEmailPassword: string;
  fromEmail: string;
  smtpHost: string;
  smtpPort: number;
  smtpSecure: boolean;
  whatsappToken: string;
  whatsappPhone: string;
  whatsappPhoneNumberId: string;
}> {
  const configs = await getAppConfigs([
    'notifications.from_email_password',
    'notifications.from_email',
    'notifications.smtp_host',
    'notifications.smtp_port',
    'notifications.smtp_secure',
    'notifications.whatsapp_token',
    'notifications.whatsapp_phone',
    'notifications.whatsapp_phone_number_id'
  ]);

  return {
    fromEmailPassword: configs['notifications.from_email_password'] || process.env.FROM_EMAIL_PASSWORD || '',
    fromEmail: configs['notifications.from_email'] || process.env.FROM_EMAIL || '',
    smtpHost: configs['notifications.smtp_host'] || process.env.SMTP_HOST || 'smtp.gmail.com',
    smtpPort: configs['notifications.smtp_port'] || parseInt(process.env.SMTP_PORT || '587'),
    smtpSecure: configs['notifications.smtp_secure'] || (process.env.SMTP_SECURE === 'true'),
    whatsappToken: configs['notifications.whatsapp_token'] || process.env.WHATSAPP_TOKEN || '',
    whatsappPhone: configs['notifications.whatsapp_phone'] || process.env.WHATSAPP_RECIPIENT_PHONE_NUMBER || '',
    whatsappPhoneNumberId: configs['notifications.whatsapp_phone_number_id'] || process.env.WHATSAPP_PHONE_NUMBER_ID || ''
  };
}