import { RateLimiterMemory } from 'rate-limiter-flexible'
import { NextRequest } from 'next/server'
import { ApiError } from './api-response'
import { Logger } from './logger'

// Configuration des limiteurs de taux
const rateLimiters = {
  // Limites générales pour les API
  general: new RateLimiterMemory({
    points: 100, // Nombre de requêtes
    duration: 60, // Par minute
    blockDuration: 60, // Blocage pendant 1 minute
  }),

  // Limites strictes pour l'authentification
  auth: new RateLimiterMemory({
    points: 5, // 5 tentatives
    duration: 60, // Par minute
    blockDuration: 300, // Blocage pendant 5 minutes
  }),

  // Limites pour les commandes
  orders: new RateLimiterMemory({
    points: 10, // 10 commandes
    duration: 60, // Par minute
    blockDuration: 60, // Blocage pendant 1 minute
  }),

  // Limites pour les uploads
  upload: new RateLimiterMemory({
    points: 5, // 5 uploads
    duration: 60, // Par minute
    blockDuration: 120, // Blocage pendant 2 minutes
  })
}

/**
 * Types de limiteurs disponibles
 */
export type RateLimiterType = keyof typeof rateLimiters

/**
 * Obtient l'identifiant client pour le rate limiting
 */
function getClientId(request: NextRequest): string {
  // Priorité : IP réelle > IP forwarded > IP de connexion
  const forwarded = request.headers.get('x-forwarded-for')
  const realIp = request.headers.get('x-real-ip')
  
  return realIp || forwarded?.split(',')[0] || 'unknown'
}

/**
 * Middleware de rate limiting
 */
export async function rateLimit(
  request: NextRequest,
  type: RateLimiterType = 'general',
  customKey?: string
): Promise<void> {
  const limiter = rateLimiters[type]
  const clientId = customKey || getClientId(request)
  
  try {
    await limiter.consume(clientId)
    
    // Log des requêtes pour monitoring
    Logger.info(`Rate limit check passed for ${type}`, undefined, {
      clientId,
      type,
      userAgent: request.headers.get('user-agent')
    })
  } catch (rejRes: any) {
    // Rate limit dépassé
    const secs = Math.round(rejRes.msBeforeNext / 1000) || 1
    
    Logger.warn(`Rate limit exceeded for ${type}`, undefined, {
      clientId,
      type,
      remainingPoints: rejRes.remainingPoints,
      msBeforeNext: rejRes.msBeforeNext,
      userAgent: request.headers.get('user-agent')
    })
    
    throw ApiError.tooManyRequests(
      `Trop de requêtes. Réessayez dans ${secs} secondes.`
    )
  }
}

/**
 * Middleware spécialisé pour l'authentification
 */
export async function rateLimitAuth(request: NextRequest, email?: string): Promise<void> {
  const key = email || getClientId(request)
  await rateLimit(request, 'auth', key)
}

/**
 * Middleware spécialisé pour les commandes
 */
export async function rateLimitOrders(request: NextRequest, userId?: string): Promise<void> {
  const key = userId || getClientId(request)
  await rateLimit(request, 'orders', key)
}

/**
 * Middleware spécialisé pour les uploads
 */
export async function rateLimitUpload(request: NextRequest, userId?: string): Promise<void> {
  const key = userId || getClientId(request)
  await rateLimit(request, 'upload', key)
}

/**
 * Obtient les informations de rate limit pour un client
 */
export async function getRateLimitInfo(
  clientId: string,
  type: RateLimiterType = 'general'
): Promise<{
  remainingPoints: number
  msBeforeNext: number
}> {
  const limiter = rateLimiters[type]
  const res = await limiter.get(clientId)
  
  return {
    remainingPoints: res?.remainingPoints || limiter.points,
    msBeforeNext: res?.msBeforeNext || 0
  }
}

/**
 * Réinitialise le rate limit pour un client
 */
export async function resetRateLimit(
  clientId: string,
  type: RateLimiterType = 'general'
): Promise<void> {
  const limiter = rateLimiters[type]
  await limiter.delete(clientId)
  
  Logger.info(`Rate limit reset for ${type}`, undefined, {
    clientId,
    type
  })
}

/**
 * Fonction helper pour créer des headers de rate limit
 */
export function createRateLimitHeaders(
  remainingPoints: number,
  msBeforeNext: number,
  totalPoints: number
): Record<string, string> {
  return {
    'X-RateLimit-Limit': totalPoints.toString(),
    'X-RateLimit-Remaining': Math.max(0, remainingPoints).toString(),
    'X-RateLimit-Reset': new Date(Date.now() + msBeforeNext).toISOString()
  }
}