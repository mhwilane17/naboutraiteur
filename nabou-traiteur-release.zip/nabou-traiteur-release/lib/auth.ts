import { PrismaClient } from "@prisma/client";
import { compare, hash } from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";
import { NextRequest } from "next/server";
import { ApiError } from "./api-response";
import { Logger } from "./logger";
import { AuthenticatedUser, UserTokenPayload, GuestTokenPayload } from "../types/api";

const prisma = new PrismaClient();

// Configuration JWT
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "your-secret-key");
const JWT_REFRESH_SECRET = new TextEncoder().encode(
  process.env.JWT_REFRESH_SECRET || "your-refresh-secret-key"
);
const JWT_GUEST_SECRET = new TextEncoder().encode(
  process.env.JWT_GUEST_SECRET || "your-guest-secret-key"
);

const JWT_EXPIRES_IN = "15m"; // Token principal
const JWT_REFRESH_EXPIRES_IN = "7d"; // Token de rafraîchissement
const JWT_GUEST_EXPIRES_IN = "24h"; // Token invité

// ============================================================================
// UTILITAIRES DE HACHAGE
// ============================================================================

/**
 * Hache un mot de passe
 */
export async function hashPassword(password: string): Promise<string> {
  return hash(password, 12);
}

/**
 * Vérifie un mot de passe
 */
export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return compare(password, hashedPassword);
}

// ============================================================================
// GESTION DES TOKENS JWT
// ============================================================================

/**
 * Génère un token JWT pour un utilisateur
 */
export async function generateUserToken(user: AuthenticatedUser): Promise<string> {
  const payload: UserTokenPayload = {
    userId: user.id,
    email: user.email,
    roles: user.roles,
    permissions: user.permissions,
    type: "user",
  };

  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(JWT_EXPIRES_IN)
    .sign(JWT_SECRET);
}

/**
 * Génère un token de rafraîchissement
 */
export async function generateRefreshToken(userId: string): Promise<string> {
  const payload = {
    userId,
    type: "refresh",
  };

  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(JWT_REFRESH_EXPIRES_IN)
    .sign(JWT_REFRESH_SECRET);
}

/**
 * Génère un token pour un invité
 */
export async function generateGuestToken(sessionId: string): Promise<string> {
  const payload: GuestTokenPayload = {
    sessionId,
    type: "guest",
  };

  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(JWT_GUEST_EXPIRES_IN)
    .sign(JWT_GUEST_SECRET);
}

/**
 * Vérifie un token JWT utilisateur
 */
export async function verifyUserToken(token: string): Promise<UserTokenPayload> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as UserTokenPayload;
  } catch (error: any) {
    Logger.auth("Token verification failed", "", false, { error: error.message });
    throw ApiError.unauthorized("Token invalide");
  }
}

/**
 * Vérifie un token de rafraîchissement
 */
export async function verifyRefreshToken(token: string): Promise<{ userId: string }> {
  try {
    const { payload } = await jwtVerify(token, JWT_REFRESH_SECRET);
    return payload as { userId: string };
  } catch (error: any) {
    Logger.auth("Refresh token verification failed", "", false, { error: error.message });
    throw ApiError.unauthorized("Token de rafraîchissement invalide");
  }
}

/**
 * Vérifie un token invité
 */
export async function verifyGuestToken(token: string): Promise<GuestTokenPayload> {
  try {
    const { payload } = await jwtVerify(token, JWT_GUEST_SECRET);
    return payload as GuestTokenPayload;
  } catch (error: any) {
    Logger.auth("Guest token verification failed", "", false, { error: error.message });
    throw ApiError.unauthorized("Token invité invalide");
  }
}

// ============================================================================
// GESTION DES UTILISATEURS ET PERMISSIONS
// ============================================================================

/**
 * Récupère un utilisateur avec ses rôles et permissions
 */
export async function getUserWithPermissions(userId: string): Promise<AuthenticatedUser | null> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId, isActive: true },
      include: {
        roles: {
          include: {
            role: {
              include: {
                permissions: {
                  include: {
                    permission: true,
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!user) return null;

    // Collecter tous les rôles et permissions
    const roles = user.roles.map((ur: any) => ur.role.id) as string[];
    const permissions = user.roles.flatMap((ur: any) =>
      ur.role.permissions.map((rp: any) => rp.permission.id)
    ) as string[];
    // Supprimer les doublons
    const uniquePermissions = [...new Set(permissions)];

    return {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      roles,
      permissions: uniquePermissions,
      companyId: (user as any).companyId,
    };
  } catch (error: any) {
    Logger.database("Failed to get user with permissions", "", { userId, error: error.message });
    throw ApiError.internalError("Erreur lors de la récupération de l'utilisateur");
  }
}

/**
 * Vérifie si un utilisateur a une permission spécifique
 */
export function hasPermission(user: AuthenticatedUser, permission: string): boolean {
  return user.permissions.includes(permission);
}

/**
 * Vérifie si un utilisateur a un rôle spécifique
 */
export function hasRole(user: AuthenticatedUser, role: string): boolean {
  return user.roles.includes(role);
}

/**
 * Authentifie un utilisateur avec email/mot de passe
 * Note: Le champ password doit être ajouté au modèle User
 */
export async function authenticateUser(
  email: string,
  password: string
): Promise<AuthenticatedUser> {
  try {
    const user = await prisma.user.findUnique({
      where: { email, isActive: true },
      include: {
        roles: {
          include: {
            role: {
              include: {
                permissions: {
                  include: {
                    permission: true,
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!user) {
      Logger.auth("Authentication failed - user not found", "", false, { email });
      throw ApiError.unauthorized("Identifiants invalides");
    }

    const isValidPassword = await verifyPassword(password, user.passwordHash);
    if (!isValidPassword) {
      Logger.auth("Authentication failed - invalid password", "", false, { email });
      throw ApiError.unauthorized("Identifiants invalides");
    }

    // Mettre à jour la dernière connexion
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLogin: new Date() },
    });

    // Collecter tous les rôles et permissions
    const roles = user.roles.map((ur: any) => ur.role.id) as string[];
    const permissions = user.roles.flatMap((ur: any) =>
      ur.role.permissions.map((rp: any) => rp.permission.id)
    ) as string[];
    const uniquePermissions = [...new Set(permissions)];

    Logger.auth("User authenticated successfully", user.id, true, { email });

    return {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      roles,
      permissions: uniquePermissions,
      companyId: (user as any).companyId,
    };
  } catch (error: any) {
    if (error instanceof ApiError) throw error;
    Logger.auth("Authentication error", "", false, { email, error: error.message });
    throw ApiError.internalError("Erreur lors de l'authentification");
  }
}

// ============================================================================
// MIDDLEWARES D'AUTHENTIFICATION
// ============================================================================

/**
 * Middleware pour vérifier l'authentification
 */
export async function requireAuth(request: NextRequest): Promise<AuthenticatedUser> {
  const authHeader = request.headers.get("authorization");

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    throw ApiError.unauthorized("Token d'authentification requis");
  }

  const token = authHeader.substring(7);
  const payload = await verifyUserToken(token);

  // Récupérer les informations utilisateur à jour
  const user = await getUserWithPermissions(payload.userId);
  if (!user) {
    throw ApiError.unauthorized("Utilisateur non trouvé");
  }

  return user;
}

/**
 * Middleware pour vérifier les permissions
 */
export function requirePermission(permission: string) {
  return async (request: NextRequest): Promise<AuthenticatedUser> => {
    const user = await requireAuth(request);

    if (!hasPermission(user, permission)) {
      Logger.auth("Permission denied", user.id, false, {
        requiredPermission: permission,
        userPermissions: user.permissions,
      });
      throw ApiError.forbidden("Permission insuffisante");
    }

    return user;
  };
}

/**
 * Middleware pour vérifier les rôles
 */
export function requireRole(role: string) {
  return async (request: NextRequest): Promise<AuthenticatedUser> => {
    const user = await requireAuth(request);

    if (!hasRole(user, role)) {
      Logger.auth("Role check failed", user.id, false, {
        requiredRole: role,
        userRoles: user.roles,
      });
      throw ApiError.forbidden("Rôle insuffisant");
    }

    return user;
  };
}

/**
 * Extrait le token de la requête
 */
export function extractToken(request: NextRequest): string | null {
  const authHeader = request.headers.get("authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return null;
  }
  return authHeader.substring(7);
}

/**
 * Authentifie un invité avec un token
 */
export async function authenticateGuest(request: NextRequest): Promise<GuestTokenPayload | null> {
  try {
    const token = extractToken(request);
    if (!token) {
      return null;
    }

    return await verifyGuestToken(token);
  } catch (error: any) {
    Logger.warn("Guest authentication failed", undefined, { error: error.message });
    return null;
  }
}
