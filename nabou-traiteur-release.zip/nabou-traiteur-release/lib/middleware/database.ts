import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

/**
 * Middleware pour gérer les connexions à la base de données
 * Assure la fermeture propre des connexions après chaque requête
 */
export function withDatabaseMiddleware(
  handler: (request: NextRequest, ...args: any[]) => Promise<NextResponse>
) {
  return async (request: NextRequest, ...args: any[]): Promise<NextResponse> => {
    try {
      // Exécuter le handler
      const response = await handler(request, ...args)
      return response
    } catch (error) {
      console.error('Database middleware error:', error)
      throw error
    } finally {
      // Nettoyer les connexions inactives (optionnel)
      // Note: Prisma gère automatiquement le pool de connexions
      // Cette étape est principalement pour le logging et le monitoring
      try {
        // On peut ajouter ici des métriques ou du logging
        // await prisma.$disconnect() // Ne pas faire ça, cela fermerait toutes les connexions
      } catch (cleanupError) {
        console.warn('Database cleanup warning:', cleanupError)
      }
    }
  }
}

/**
 * Utilitaire pour vérifier l'état des connexions
 */
export async function getDatabaseConnectionInfo() {
  try {
    // Exécuter une requête simple pour tester la connexion
    await prisma.$queryRaw`SELECT 1 as test`
    return {
      status: 'connected',
      timestamp: new Date().toISOString()
    }
  } catch (error) {
    return {
      status: 'error',
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }
  }
}

/**
 * Vérification simple de la santé de la base de données
 */
export async function checkDatabaseHealth(): Promise<boolean> {
  try {
    await prisma.$queryRaw`SELECT 1`
    return true
  } catch (error) {
    console.error('Database health check failed:', error)
    return false
  }
}