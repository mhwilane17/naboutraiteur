import { NextRequest } from "next/server";
import { LogContext } from "../types/api";

/**
 * Niveaux de log
 */
export enum LogLevel {
  DEBUG = "debug",
  INFO = "info",
  WARN = "warn",
  ERROR = "error",
}

/**
 * Interface pour les entrées de log
 */
interface LogEntry {
  level: LogLevel;
  message: string;
  timestamp: string;
  context?: Partial<LogContext>;
  data?: any;
  error?: {
    name: string;
    message: string;
    stack?: string;
  };
}

/**
 * Classe Logger pour la gestion centralisée des logs
 */
export class Logger {
  /**
   * Log de niveau DEBUG
   */
  static debug(message: string, context?: Partial<LogContext>, data?: any) {
    if (process.env.NODE_ENV === "development") {
      this.log(LogLevel.DEBUG, message, context, data);
    }
  }

  /**
   * Log de niveau INFO
   */
  static info(message: string, context?: Partial<LogContext>, data?: any) {
    this.log(LogLevel.INFO, message, context, data);
  }

  /**
   * Log de niveau WARN
   */
  static warn(message: string, context?: Partial<LogContext>, data?: any) {
    this.log(LogLevel.WARN, message, context, data);
  }

  /**
   * Log de niveau ERROR
   */
  static error(message: string, error?: Error, context?: Partial<LogContext>) {
    const logEntry: LogEntry = {
      level: LogLevel.ERROR,
      message,
      timestamp: new Date().toISOString(),
      context,
      error: error
        ? {
            name: error.name,
            message: error.message,
            stack: error.stack,
          }
        : undefined,
    };

    console.error(JSON.stringify(logEntry, null, 2));
  }

  /**
   * Méthode privée pour logger
   */
  private static log(
    level: LogLevel,
    message: string,
    context?: Partial<LogContext>,
    data?: any
  ) {
    const logEntry: LogEntry = {
      level,
      message,
      timestamp: new Date().toISOString(),
      context,
      data,
    };

    // En développement, on affiche les logs de manière lisible
    if (process.env.NODE_ENV === "development") {
      console.log(JSON.stringify(logEntry, null, 2));
    } else {
      // En production, on affiche les logs en une ligne pour les outils de monitoring
      console.log(JSON.stringify(logEntry));
    }
  }

  /**
   * Crée un contexte de log à partir d'une requête
   */
  static createContext(request: NextRequest, userId?: string): LogContext {
    return {
      userId,
      requestId: crypto.randomUUID(),
      method: request.method,
      url: request.url,
      userAgent: request.headers.get("user-agent") || undefined,
      ip:
        request.headers.get("x-forwarded-for") ||
        request.headers.get("x-real-ip") ||
        undefined,
    };
  }

  /**
   * Log spécialisé pour les requêtes API
   */
  static apiRequest(
    method: string,
    path: string,
    context: LogContext,
    duration?: number
  ) {
    this.info(`${method} ${path}`, context, {
      duration: duration ? `${duration}ms` : undefined,
    });
  }

  /**
   * Log spécialisé pour les erreurs API
   */
  static apiError(
    method: string,
    path: string,
    error: Error,
    context: LogContext,
    statusCode?: number
  ) {
    this.error(
      `${method} ${path} - ${error.message}`,
      error,
      {
        ...context,
        statusCode,
      }
    );
  }

  /**
   * Log spécialisé pour l'authentification
   */
  static auth(action: string, userId?: string, success: boolean = true, details?: any) {
    const level = success ? LogLevel.INFO : LogLevel.WARN;
    const message = `Auth ${action}: ${success ? "SUCCESS" : "FAILED"}`;
    
    this.log(level, message, { userId }, details);
  }

  /**
   * Log spécialisé pour les opérations de base de données
   */
  static database(
    operation: string,
    table: string,
    context?: Partial<LogContext>,
    duration?: number
  ) {
    this.debug(`DB ${operation} on ${table}`, context, {
      duration: duration ? `${duration}ms` : undefined,
    });
  }

  /**
   * Log spécialisé pour les opérations business
   */
  static business(
    action: string,
    entity: string,
    entityId?: string,
    context?: Partial<LogContext>,
    data?: any
  ) {
    this.info(`Business: ${action} ${entity}`, {
      ...context,
      entityId,
    }, data);
  }

  /**
   * Log spécialisé pour les paiements
   */
  static payment(
    action: string,
    orderId: string,
    amount?: number,
    provider?: string,
    context?: Partial<LogContext>
  ) {
    this.info(`Payment: ${action}`, context, {
      orderId,
      amount,
      provider,
    });
  }

  /**
   * Log spécialisé pour les performances
   */
  static performance(
    operation: string,
    duration: number,
    context?: Partial<LogContext>,
    threshold: number = 1000
  ) {
    const level = duration > threshold ? LogLevel.WARN : LogLevel.DEBUG;
    const message = `Performance: ${operation} took ${duration}ms`;
    
    this.log(level, message, context, { duration, threshold });
  }
}

/**
 * Décorateur pour logger automatiquement les appels de méthodes
 */
export function LogMethod(target: any, propertyName: string, descriptor: PropertyDescriptor) {
  const method = descriptor.value;

  descriptor.value = async function (...args: any[]) {
    const start = Date.now();
    const className = target.constructor.name;
    const methodName = `${className}.${propertyName}`;

    Logger.debug(`Calling ${methodName}`, undefined, { args });

    try {
      const result = await method.apply(this, args);
      const duration = Date.now() - start;
      
      Logger.debug(`${methodName} completed`, undefined, { duration });
      return result;
    } catch (error) {
      const duration = Date.now() - start;
      
      Logger.error(
        `${methodName} failed`,
        error as Error,
        { duration }
      );
      throw error;
    }
  };

  return descriptor;
}