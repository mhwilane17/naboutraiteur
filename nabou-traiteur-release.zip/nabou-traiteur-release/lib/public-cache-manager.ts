/**
 * Public Cache Manager
 * Centralized management for all public data caches
 */

import { 
  GlobalCacheManager, 
  CacheMonitor, 
  CacheDebugger, 
  CachePerformanceMonitor,
  createCacheEvent,
  CACHE_CONFIG
} from './cache-utils';

// Store references (will be populated when stores are initialized)
let publicCategoriesStore: any = null;
let publicDeliveryZonesStore: any = null;
let publicPaymentMethodsStore: any = null;

/**
 * Public cache manager class
 */
export class PublicCacheManager {
  private static initialized = false;
  
  /**
   * Initialize the cache manager with store references
   */
  static initialize(stores: {
    categories?: any;
    deliveryZones?: any;
    paymentMethods?: any;
  }): void {
    if (this.initialized) return;
    
    // Register stores
    if (stores.categories) {
      publicCategoriesStore = stores.categories;
      GlobalCacheManager.registerStore('publicCategories', stores.categories);
    }
    
    if (stores.deliveryZones) {
      publicDeliveryZonesStore = stores.deliveryZones;
      GlobalCacheManager.registerStore('publicDeliveryZones', stores.deliveryZones);
    }
    
    if (stores.paymentMethods) {
      publicPaymentMethodsStore = stores.paymentMethods;
      GlobalCacheManager.registerStore('publicPaymentMethods', stores.paymentMethods);
    }
    
    this.initialized = true;
    
    if (CACHE_CONFIG.DEBUG_MODE) {
      console.log('[Public Cache Manager] Initialized with stores:', Object.keys(stores));
    }
  }
  
  /**
   * Preload all public data
   */
  static async preloadAll(): Promise<void> {
    const measurement = CachePerformanceMonitor.startMeasurement('preloadAll');
    
    try {
      CacheMonitor.emit(createCacheEvent(
        CacheMonitor.Events.FETCH_START,
        'all',
        null,
        undefined,
        { operation: 'preloadAll' }
      ));
      
      const promises = [];
      
      if (publicCategoriesStore) {
        promises.push(this.loadCategories());
      }
      
      if (publicDeliveryZonesStore) {
        promises.push(this.loadDeliveryZones());
      }
      
      if (publicPaymentMethodsStore) {
        promises.push(this.loadPaymentMethods());
      }
      
      await Promise.allSettled(promises);
      
      measurement.end(true);
      
      CacheMonitor.emit(createCacheEvent(
        CacheMonitor.Events.FETCH_SUCCESS,
        'all',
        null,
        undefined,
        { operation: 'preloadAll' }
      ));
      
    } catch (error) {
      measurement.end(false);
      
      CacheMonitor.emit(createCacheEvent(
        CacheMonitor.Events.FETCH_ERROR,
        'all',
        null,
        error instanceof Error ? error.message : 'Unknown error',
        { operation: 'preloadAll' }
      ));
      
      throw error;
    }
  }
  
  /**
   * Load categories with monitoring
   */
  static async loadCategories(): Promise<void> {
    if (!publicCategoriesStore) return;
    
    const measurement = CachePerformanceMonitor.startMeasurement('loadCategories');
    
    try {
      const state = publicCategoriesStore.getState();
      
      if (state.isDataFresh()) {
        CacheDebugger.recordHit('publicCategories');
        CacheMonitor.emit(createCacheEvent(
          CacheMonitor.Events.CACHE_HIT,
          'publicCategories'
        ));
        measurement.end(true, state.categories?.length);
        return;
      }
      
      CacheDebugger.recordMiss('publicCategories');
      CacheMonitor.emit(createCacheEvent(
        CacheMonitor.Events.CACHE_MISS,
        'publicCategories'
      ));
      
      await state.fetchCategories();
      
      const newState = publicCategoriesStore.getState();
      CacheDebugger.registerEntry('publicCategories', newState.categories, {
        lastFetch: newState.lastFetch,
        cacheExpiry: newState.cacheExpiry,
        isLoading: newState.loading,
        error: newState.error
      });
      
      measurement.end(true, newState.categories?.length);
      
    } catch (error) {
      measurement.end(false);
      throw error;
    }
  }
  
  /**
   * Load delivery zones with monitoring
   */
  static async loadDeliveryZones(): Promise<void> {
    if (!publicDeliveryZonesStore) return;
    
    const measurement = CachePerformanceMonitor.startMeasurement('loadDeliveryZones');
    
    try {
      const state = publicDeliveryZonesStore.getState();
      
      if (state.isDataFresh()) {
        CacheDebugger.recordHit('publicDeliveryZones');
        CacheMonitor.emit(createCacheEvent(
          CacheMonitor.Events.CACHE_HIT,
          'publicDeliveryZones'
        ));
        measurement.end(true, state.deliveryZones?.length);
        return;
      }
      
      CacheDebugger.recordMiss('publicDeliveryZones');
      CacheMonitor.emit(createCacheEvent(
        CacheMonitor.Events.CACHE_MISS,
        'publicDeliveryZones'
      ));
      
      await state.fetchDeliveryZones();
      
      const newState = publicDeliveryZonesStore.getState();
      CacheDebugger.registerEntry('publicDeliveryZones', newState.deliveryZones, {
        lastFetch: newState.lastFetch,
        cacheExpiry: newState.cacheExpiry,
        isLoading: newState.loading,
        error: newState.error
      });
      
      measurement.end(true, newState.deliveryZones?.length);
      
    } catch (error) {
      measurement.end(false);
      throw error;
    }
  }
  
  /**
   * Load payment methods with monitoring
   */
  static async loadPaymentMethods(): Promise<void> {
    if (!publicPaymentMethodsStore) return;
    
    const measurement = CachePerformanceMonitor.startMeasurement('loadPaymentMethods');
    
    try {
      const state = publicPaymentMethodsStore.getState();
      
      if (state.isDataFresh()) {
        CacheDebugger.recordHit('publicPaymentMethods');
        CacheMonitor.emit(createCacheEvent(
          CacheMonitor.Events.CACHE_HIT,
          'publicPaymentMethods'
        ));
        measurement.end(true, state.paymentMethods?.length);
        return;
      }
      
      CacheDebugger.recordMiss('publicPaymentMethods');
      CacheMonitor.emit(createCacheEvent(
        CacheMonitor.Events.CACHE_MISS,
        'publicPaymentMethods'
      ));
      
      await state.fetchPaymentMethods();
      
      const newState = publicPaymentMethodsStore.getState();
      CacheDebugger.registerEntry('publicPaymentMethods', newState.paymentMethods, {
        lastFetch: newState.lastFetch,
        cacheExpiry: newState.cacheExpiry,
        isLoading: newState.loading,
        error: newState.error
      });
      
      measurement.end(true, newState.paymentMethods?.length);
      
    } catch (error) {
      measurement.end(false);
      throw error;
    }
  }
  
  /**
   * Refresh all public data
   */
  static async refreshAll(): Promise<void> {
    const measurement = CachePerformanceMonitor.startMeasurement('refreshAll');
    
    try {
      CacheMonitor.emit(createCacheEvent(
        CacheMonitor.Events.FETCH_START,
        'all',
        null,
        undefined,
        { operation: 'refreshAll' }
      ));
      
      const promises = [];
      
      if (publicCategoriesStore) {
        promises.push(publicCategoriesStore.getState().refetch());
      }
      
      if (publicDeliveryZonesStore) {
        promises.push(publicDeliveryZonesStore.getState().refetch());
      }
      
      if (publicPaymentMethodsStore) {
        promises.push(publicPaymentMethodsStore.getState().refetch());
      }
      
      await Promise.allSettled(promises);
      
      measurement.end(true);
      
      CacheMonitor.emit(createCacheEvent(
        CacheMonitor.Events.FETCH_SUCCESS,
        'all',
        null,
        undefined,
        { operation: 'refreshAll' }
      ));
      
    } catch (error) {
      measurement.end(false);
      
      CacheMonitor.emit(createCacheEvent(
        CacheMonitor.Events.FETCH_ERROR,
        'all',
        null,
        error instanceof Error ? error.message : 'Unknown error',
        { operation: 'refreshAll' }
      ));
      
      throw error;
    }
  }
  
  /**
   * Clear all public data caches
   */
  static clearAll(): void {
    CacheMonitor.emit(createCacheEvent(
      CacheMonitor.Events.CACHE_INVALIDATE,
      'all',
      null,
      undefined,
      { operation: 'clearAll' }
    ));
    
    if (publicCategoriesStore) {
      publicCategoriesStore.getState().clearCache();
      CacheDebugger.clearEntry('publicCategories');
    }
    
    if (publicDeliveryZonesStore) {
      publicDeliveryZonesStore.getState().clearCache();
      CacheDebugger.clearEntry('publicDeliveryZones');
    }
    
    if (publicPaymentMethodsStore) {
      publicPaymentMethodsStore.getState().clearCache();
      CacheDebugger.clearEntry('publicPaymentMethods');
    }
    
    if (CACHE_CONFIG.DEBUG_MODE) {
      console.log('[Public Cache Manager] Cleared all caches');
    }
  }
  
  /**
   * Get cache status for all public stores
   */
  static getCacheStatus(): PublicCacheStatus {
    return {
      categories: this.getStoreCacheStatus(publicCategoriesStore, 'categories'),
      deliveryZones: this.getStoreCacheStatus(publicDeliveryZonesStore, 'deliveryZones'),
      paymentMethods: this.getStoreCacheStatus(publicPaymentMethodsStore, 'paymentMethods'),
      overall: this.getOverallStatus()
    };
  }
  
  /**
   * Get cache status for a specific store
   */
  private static getStoreCacheStatus(store: any, dataKey: string): StoreCacheStatus {
    if (!store) {
      return {
        available: false,
        hasData: false,
        isLoading: false,
        hasError: false,
        lastFetch: null,
        cacheAge: 'N/A',
        isDataFresh: false,
        dataCount: 0
      };
    }
    
    const state = store.getState();
    const data = state[dataKey] || [];
    
    return {
      available: true,
      hasData: Array.isArray(data) ? data.length > 0 : !!data,
      isLoading: state.loading || false,
      hasError: !!state.error,
      error: state.error,
      lastFetch: state.lastFetch,
      cacheAge: this.formatCacheAge(state.lastFetch),
      isDataFresh: typeof state.isDataFresh === 'function' ? state.isDataFresh() : false,
      dataCount: Array.isArray(data) ? data.length : (data ? 1 : 0)
    };
  }
  
  /**
   * Get overall cache status
   */
  private static getOverallStatus(): OverallCacheStatus {
    const statuses = [
      this.getStoreCacheStatus(publicCategoriesStore, 'categories'),
      this.getStoreCacheStatus(publicDeliveryZonesStore, 'deliveryZones'),
      this.getStoreCacheStatus(publicPaymentMethodsStore, 'paymentMethods')
    ].filter(status => status.available);
    
    const totalStores = statuses.length;
    const storesWithData = statuses.filter(s => s.hasData).length;
    const storesLoading = statuses.filter(s => s.isLoading).length;
    const storesWithErrors = statuses.filter(s => s.hasError).length;
    const storesWithFreshData = statuses.filter(s => s.isDataFresh).length;
    
    return {
      totalStores,
      storesWithData,
      storesLoading,
      storesWithErrors,
      storesWithFreshData,
      allDataLoaded: storesWithData === totalStores,
      anyLoading: storesLoading > 0,
      anyErrors: storesWithErrors > 0,
      allDataFresh: storesWithFreshData === totalStores
    };
  }
  
  /**
   * Format cache age for display
   */
  private static formatCacheAge(lastFetch: number | null): string {
    if (!lastFetch) return 'Never';
    
    const age = Date.now() - lastFetch;
    const seconds = Math.floor(age / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    if (hours > 0) return `${hours}h ${minutes % 60}m ago`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s ago`;
    return `${seconds}s ago`;
  }
  
  /**
   * Get performance statistics
   */
  static getPerformanceStats(): Record<string, any> {
    return {
      preloadAll: CachePerformanceMonitor.getStats('preloadAll'),
      refreshAll: CachePerformanceMonitor.getStats('refreshAll'),
      loadCategories: CachePerformanceMonitor.getStats('loadCategories'),
      loadDeliveryZones: CachePerformanceMonitor.getStats('loadDeliveryZones'),
      loadPaymentMethods: CachePerformanceMonitor.getStats('loadPaymentMethods')
    };
  }
  
  /**
   * Print debug information
   */
  static printDebugInfo(): void {
    if (!CACHE_CONFIG.DEBUG_MODE) {
      console.log('Debug mode is disabled. Set NODE_ENV=development to enable.');
      return;
    }
    
    console.group('[Public Cache Manager] Debug Information');
    
    // Cache status
    console.log('Cache Status:', this.getCacheStatus());
    
    // Performance stats
    console.log('Performance Stats:', this.getPerformanceStats());
    
    // Cache debugger stats
    CacheDebugger.printStats();
    
    console.groupEnd();
  }
}

// Type definitions
export interface StoreCacheStatus {
  available: boolean;
  hasData: boolean;
  isLoading: boolean;
  hasError: boolean;
  error?: string | null;
  lastFetch: number | null;
  cacheAge: string;
  isDataFresh: boolean;
  dataCount: number;
}

export interface OverallCacheStatus {
  totalStores: number;
  storesWithData: number;
  storesLoading: number;
  storesWithErrors: number;
  storesWithFreshData: number;
  allDataLoaded: boolean;
  anyLoading: boolean;
  anyErrors: boolean;
  allDataFresh: boolean;
}

export interface PublicCacheStatus {
  categories: StoreCacheStatus;
  deliveryZones: StoreCacheStatus;
  paymentMethods: StoreCacheStatus;
  overall: OverallCacheStatus;
}

// Export utilities for direct use
export {
  CacheMonitor,
  CacheDebugger,
  CachePerformanceMonitor,
  GlobalCacheManager
} from './cache-utils';