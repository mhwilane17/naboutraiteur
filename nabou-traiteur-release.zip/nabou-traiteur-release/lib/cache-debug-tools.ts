/**
 * Cache Debug Tools
 * Advanced debugging and monitoring utilities for cache system
 */

import { 
  CacheDebugger, 
  CacheMonitor, 
  CachePerformanceMonitor,
  CACHE_CONFIG 
} from './cache-utils';
import { PublicCacheManager } from './public-cache-manager';
import { CacheInvalidationManager } from './cache-invalidation';

/**
 * Cache debug console - provides a console interface for cache debugging
 */
export class CacheDebugConsole {
  private static commands = new Map<string, (args: string[]) => void>();
  
  static {
    this.registerCommands();
  }
  
  /**
   * Execute a debug command
   */
  static execute(command: string): void {
    const [cmd, ...args] = command.trim().split(' ');
    const handler = this.commands.get(cmd.toLowerCase());
    
    if (handler) {
      try {
        handler(args);
      } catch (error) {
        console.error(`[Cache Debug] Error executing command '${cmd}':`, error);
      }
    } else {
      console.error(`[Cache Debug] Unknown command: ${cmd}`);
      this.showHelp();
    }
  }
  
  /**
   * Register debug commands
   */
  private static registerCommands(): void {
    this.commands.set('help', () => this.showHelp());
    this.commands.set('status', () => this.showStatus());
    this.commands.set('stats', () => this.showStats());
    this.commands.set('performance', () => this.showPerformance());
    this.commands.set('clear', (args) => this.clearCache(args));
    this.commands.set('refresh', (args) => this.refreshCache(args));
    this.commands.set('invalidate', (args) => this.invalidateCache(args));
    this.commands.set('monitor', (args) => this.toggleMonitoring(args));
    this.commands.set('export', () => this.exportDebugData());
    this.commands.set('simulate', (args) => this.simulateScenario(args));
  }
  
  /**
   * Show help information
   */
  private static showHelp(): void {
    console.group('[Cache Debug] Available Commands');
    console.log('help                    - Show this help message');
    console.log('status                  - Show cache status for all stores');
    console.log('stats                   - Show cache statistics and metrics');
    console.log('performance             - Show performance statistics');
    console.log('clear [store]           - Clear cache (all stores or specific store)');
    console.log('refresh [store]         - Refresh cache (all stores or specific store)');
    console.log('invalidate [store]      - Invalidate cache with default strategy');
    console.log('monitor [on|off]        - Toggle cache monitoring');
    console.log('export                  - Export debug data to console');
    console.log('simulate [scenario]     - Simulate cache scenarios (error, slow, etc.)');
    console.groupEnd();
  }
  
  /**
   * Show cache status
   */
  private static showStatus(): void {
    const status = PublicCacheManager.getCacheStatus();
    
    console.group('[Cache Debug] Cache Status');
    console.table({
      'Categories': {
        'Has Data': status.categories.hasData,
        'Loading': status.categories.isLoading,
        'Error': status.categories.hasError,
        'Fresh': status.categories.isDataFresh,
        'Count': status.categories.dataCount,
        'Age': status.categories.cacheAge
      },
      'Delivery Zones': {
        'Has Data': status.deliveryZones.hasData,
        'Loading': status.deliveryZones.isLoading,
        'Error': status.deliveryZones.hasError,
        'Fresh': status.deliveryZones.isDataFresh,
        'Count': status.deliveryZones.dataCount,
        'Age': status.deliveryZones.cacheAge
      },
      'Payment Methods': {
        'Has Data': status.paymentMethods.hasData,
        'Loading': status.paymentMethods.isLoading,
        'Error': status.paymentMethods.hasError,
        'Fresh': status.paymentMethods.isDataFresh,
        'Count': status.paymentMethods.dataCount,
        'Age': status.paymentMethods.cacheAge
      }
    });
    
    console.log('Overall Status:', status.overall);
    console.groupEnd();
  }
  
  /**
   * Show cache statistics
   */
  private static showStats(): void {
    console.group('[Cache Debug] Cache Statistics');
    CacheDebugger.printStats();
    
    const entries = CacheDebugger.getAllEntries();
    if (entries.length > 0) {
      console.table(entries.map(entry => ({
        'Store': entry.key,
        'Size (KB)': (entry.size / 1024).toFixed(2),
        'Hits': entry.hitCount,
        'Misses': entry.missCount,
        'Hit Rate': entry.hitCount + entry.missCount > 0 
          ? `${((entry.hitCount / (entry.hitCount + entry.missCount)) * 100).toFixed(1)}%`
          : 'N/A'
      })));
    }
    console.groupEnd();
  }
  
  /**
   * Show performance statistics
   */
  private static showPerformance(): void {
    const stats = PublicCacheManager.getPerformanceStats();
    
    console.group('[Cache Debug] Performance Statistics');
    Object.entries(stats).forEach(([operation, stat]) => {
      if (stat) {
        console.log(`${operation}:`, {
          'Avg Duration': `${stat.averageDuration.toFixed(2)}ms`,
          'Min Duration': `${stat.minDuration.toFixed(2)}ms`,
          'Max Duration': `${stat.maxDuration.toFixed(2)}ms`,
          'Success Rate': `${stat.successRate.toFixed(1)}%`,
          'Total Measurements': stat.totalMeasurements
        });
      }
    });
    console.groupEnd();
  }
  
  /**
   * Clear cache
   */
  private static clearCache(args: string[]): void {
    const store = args[0];
    
    if (!store || store === 'all') {
      PublicCacheManager.clearAll();
      console.log('[Cache Debug] Cleared all caches');
    } else {
      // Individual store clearing would be implemented here
      console.log(`[Cache Debug] Clearing individual stores not yet implemented. Cleared all caches.`);
      PublicCacheManager.clearAll();
    }
  }
  
  /**
   * Refresh cache
   */
  private static refreshCache(args: string[]): void {
    const store = args[0];
    
    if (!store || store === 'all') {
      PublicCacheManager.refreshAll()
        .then(() => console.log('[Cache Debug] Refreshed all caches'))
        .catch(error => console.error('[Cache Debug] Failed to refresh caches:', error));
    } else {
      // Individual store refresh would be implemented here
      console.log(`[Cache Debug] Refreshing individual stores not yet implemented. Refreshing all caches.`);
      PublicCacheManager.refreshAll()
        .then(() => console.log('[Cache Debug] Refreshed all caches'))
        .catch(error => console.error('[Cache Debug] Failed to refresh caches:', error));
    }
  }
  
  /**
   * Invalidate cache
   */
  private static invalidateCache(args: string[]): void {
    const store = args[0] || 'all';
    
    CacheInvalidationManager.invalidate(store, {
      strategy: 'immediate' as any
    });
    
    console.log(`[Cache Debug] Invalidated cache for ${store}`);
  }
  
  /**
   * Toggle monitoring
   */
  private static toggleMonitoring(args: string[]): void {
    const action = args[0]?.toLowerCase();
    
    if (action === 'on') {
      this.enableMonitoring();
      console.log('[Cache Debug] Monitoring enabled');
    } else if (action === 'off') {
      this.disableMonitoring();
      console.log('[Cache Debug] Monitoring disabled');
    } else {
      console.log('[Cache Debug] Usage: monitor [on|off]');
    }
  }
  
  /**
   * Export debug data
   */
  private static exportDebugData(): void {
    const debugData = {
      timestamp: new Date().toISOString(),
      cacheStatus: PublicCacheManager.getCacheStatus(),
      cacheStats: CacheDebugger.getStats(),
      performanceStats: PublicCacheManager.getPerformanceStats(),
      activeInvalidations: CacheInvalidationManager.getActiveInvalidations(),
      entries: CacheDebugger.getAllEntries()
    };
    
    console.log('[Cache Debug] Debug Data Export:');
    console.log(JSON.stringify(debugData, null, 2));
    
    // Also copy to clipboard if available
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(JSON.stringify(debugData, null, 2))
        .then(() => console.log('[Cache Debug] Debug data copied to clipboard'))
        .catch(() => console.log('[Cache Debug] Failed to copy to clipboard'));
    }
  }
  
  /**
   * Simulate cache scenarios
   */
  private static simulateScenario(args: string[]): void {
    const scenario = args[0]?.toLowerCase();
    
    switch (scenario) {
      case 'error':
        this.simulateError();
        break;
      case 'slow':
        this.simulateSlowResponse();
        break;
      case 'offline':
        this.simulateOffline();
        break;
      case 'load':
        this.simulateHighLoad();
        break;
      default:
        console.log('[Cache Debug] Available scenarios: error, slow, offline, load');
    }
  }
  
  /**
   * Enable cache monitoring
   */
  private static enableMonitoring(): void {
    const eventTypes = [
      CacheMonitor.Events.FETCH_START,
      CacheMonitor.Events.FETCH_SUCCESS,
      CacheMonitor.Events.FETCH_ERROR,
      CacheMonitor.Events.CACHE_HIT,
      CacheMonitor.Events.CACHE_MISS,
      CacheMonitor.Events.CACHE_INVALIDATE
    ];
    
    eventTypes.forEach(eventType => {
      CacheMonitor.addEventListener(eventType, (event) => {
        console.log(`[Cache Monitor] ${event.type}:`, event);
      });
    });
  }
  
  /**
   * Disable cache monitoring
   */
  private static disableMonitoring(): void {
    // This would require keeping track of listeners to remove them
    // For now, we'll just log that monitoring is disabled
    console.log('[Cache Debug] Monitoring disabled (restart required to fully disable)');
  }
  
  /**
   * Simulate error scenario
   */
  private static simulateError(): void {
    console.log('[Cache Debug] Simulating error scenario...');
    // This would involve mocking fetch to return errors
    console.log('[Cache Debug] Error simulation not fully implemented');
  }
  
  /**
   * Simulate slow response
   */
  private static simulateSlowResponse(): void {
    console.log('[Cache Debug] Simulating slow response scenario...');
    // This would involve adding delays to fetch responses
    console.log('[Cache Debug] Slow response simulation not fully implemented');
  }
  
  /**
   * Simulate offline scenario
   */
  private static simulateOffline(): void {
    console.log('[Cache Debug] Simulating offline scenario...');
    // This would involve mocking network offline state
    console.log('[Cache Debug] Offline simulation not fully implemented');
  }
  
  /**
   * Simulate high load scenario
   */
  private static simulateHighLoad(): void {
    console.log('[Cache Debug] Simulating high load scenario...');
    // This would involve making multiple concurrent requests
    const promises = Array.from({ length: 10 }, () => 
      PublicCacheManager.preloadAll()
    );
    
    Promise.allSettled(promises)
      .then(() => console.log('[Cache Debug] High load simulation completed'))
      .catch(error => console.error('[Cache Debug] High load simulation failed:', error));
  }
}

/**
 * Cache health checker
 */
export class CacheHealthChecker {
  /**
   * Perform comprehensive health check
   */
  static async performHealthCheck(): Promise<CacheHealthReport> {
    const startTime = performance.now();
    const report: CacheHealthReport = {
      timestamp: new Date().toISOString(),
      overall: 'healthy',
      checks: [],
      recommendations: [],
      duration: 0
    };
    
    try {
      // Check cache status
      const statusCheck = this.checkCacheStatus();
      report.checks.push(statusCheck);
      
      // Check performance
      const performanceCheck = this.checkPerformance();
      report.checks.push(performanceCheck);
      
      // Check memory usage
      const memoryCheck = this.checkMemoryUsage();
      report.checks.push(memoryCheck);
      
      // Check error rates
      const errorCheck = this.checkErrorRates();
      report.checks.push(errorCheck);
      
      // Determine overall health
      const failedChecks = report.checks.filter(check => check.status === 'failed');
      const warningChecks = report.checks.filter(check => check.status === 'warning');
      
      if (failedChecks.length > 0) {
        report.overall = 'unhealthy';
      } else if (warningChecks.length > 0) {
        report.overall = 'degraded';
      }
      
      // Generate recommendations
      report.recommendations = this.generateRecommendations(report.checks);
      
    } catch (error) {
      report.overall = 'unhealthy';
      report.checks.push({
        name: 'Health Check Execution',
        status: 'failed',
        message: `Health check failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        details: { error }
      });
    }
    
    report.duration = performance.now() - startTime;
    return report;
  }
  
  /**
   * Check cache status
   */
  private static checkCacheStatus(): HealthCheck {
    try {
      const status = PublicCacheManager.getCacheStatus();
      
      if (status.overall.anyErrors) {
        return {
          name: 'Cache Status',
          status: 'failed',
          message: `${status.overall.storesWithErrors} stores have errors`,
          details: { status }
        };
      }
      
      if (!status.overall.allDataLoaded) {
        return {
          name: 'Cache Status',
          status: 'warning',
          message: `Only ${status.overall.storesWithData}/${status.overall.totalStores} stores have data`,
          details: { status }
        };
      }
      
      return {
        name: 'Cache Status',
        status: 'passed',
        message: 'All caches are healthy',
        details: { status }
      };
      
    } catch (error) {
      return {
        name: 'Cache Status',
        status: 'failed',
        message: 'Failed to check cache status',
        details: { error }
      };
    }
  }
  
  /**
   * Check performance metrics
   */
  private static checkPerformance(): HealthCheck {
    try {
      const stats = PublicCacheManager.getPerformanceStats();
      const issues: string[] = [];
      
      Object.entries(stats).forEach(([operation, stat]) => {
        if (stat) {
          if (stat.averageDuration > 5000) { // 5 seconds
            issues.push(`${operation} average duration is high: ${stat.averageDuration.toFixed(2)}ms`);
          }
          
          if (stat.successRate < 95) {
            issues.push(`${operation} success rate is low: ${stat.successRate.toFixed(1)}%`);
          }
        }
      });
      
      if (issues.length > 0) {
        return {
          name: 'Performance',
          status: 'warning',
          message: `Performance issues detected: ${issues.join(', ')}`,
          details: { stats, issues }
        };
      }
      
      return {
        name: 'Performance',
        status: 'passed',
        message: 'Performance metrics are within acceptable ranges',
        details: { stats }
      };
      
    } catch (error) {
      return {
        name: 'Performance',
        status: 'failed',
        message: 'Failed to check performance metrics',
        details: { error }
      };
    }
  }
  
  /**
   * Check memory usage
   */
  private static checkMemoryUsage(): HealthCheck {
    try {
      const cacheStats = CacheDebugger.getStats();
      const totalSizeKB = cacheStats.totalSize / 1024;
      
      if (totalSizeKB > 1024) { // 1MB
        return {
          name: 'Memory Usage',
          status: 'warning',
          message: `Cache size is large: ${totalSizeKB.toFixed(2)} KB`,
          details: { cacheStats }
        };
      }
      
      return {
        name: 'Memory Usage',
        status: 'passed',
        message: `Cache size is acceptable: ${totalSizeKB.toFixed(2)} KB`,
        details: { cacheStats }
      };
      
    } catch (error) {
      return {
        name: 'Memory Usage',
        status: 'failed',
        message: 'Failed to check memory usage',
        details: { error }
      };
    }
  }
  
  /**
   * Check error rates
   */
  private static checkErrorRates(): HealthCheck {
    try {
      const cacheStats = CacheDebugger.getStats();
      
      if (cacheStats.missRate > 50) {
        return {
          name: 'Error Rates',
          status: 'warning',
          message: `High cache miss rate: ${cacheStats.missRate.toFixed(1)}%`,
          details: { cacheStats }
        };
      }
      
      return {
        name: 'Error Rates',
        status: 'passed',
        message: `Cache hit rate is good: ${cacheStats.hitRate.toFixed(1)}%`,
        details: { cacheStats }
      };
      
    } catch (error) {
      return {
        name: 'Error Rates',
        status: 'failed',
        message: 'Failed to check error rates',
        details: { error }
      };
    }
  }
  
  /**
   * Generate recommendations based on health checks
   */
  private static generateRecommendations(checks: HealthCheck[]): string[] {
    const recommendations: string[] = [];
    
    checks.forEach(check => {
      switch (check.name) {
        case 'Cache Status':
          if (check.status === 'failed') {
            recommendations.push('Clear and refresh all caches to resolve errors');
          } else if (check.status === 'warning') {
            recommendations.push('Preload missing cache data');
          }
          break;
          
        case 'Performance':
          if (check.status === 'warning') {
            recommendations.push('Consider increasing cache duration or optimizing API responses');
          }
          break;
          
        case 'Memory Usage':
          if (check.status === 'warning') {
            recommendations.push('Consider reducing cache size or implementing cache cleanup');
          }
          break;
          
        case 'Error Rates':
          if (check.status === 'warning') {
            recommendations.push('Investigate cache miss causes and optimize cache strategy');
          }
          break;
      }
    });
    
    return recommendations;
  }
}

// Type definitions
export interface HealthCheck {
  name: string;
  status: 'passed' | 'warning' | 'failed';
  message: string;
  details?: any;
}

export interface CacheHealthReport {
  timestamp: string;
  overall: 'healthy' | 'degraded' | 'unhealthy';
  checks: HealthCheck[];
  recommendations: string[];
  duration: number;
}

/**
 * Global debug interface - attach to window for browser debugging
 */
export const attachDebugInterface = (): void => {
  if (typeof window !== 'undefined' && CACHE_CONFIG.DEBUG_MODE) {
    (window as any).cacheDebug = {
      console: CacheDebugConsole,
      health: CacheHealthChecker,
      manager: PublicCacheManager,
      invalidation: CacheInvalidationManager,
      
      // Quick access methods
      status: () => CacheDebugConsole.execute('status'),
      stats: () => CacheDebugConsole.execute('stats'),
      clear: () => CacheDebugConsole.execute('clear all'),
      refresh: () => CacheDebugConsole.execute('refresh all'),
      help: () => CacheDebugConsole.execute('help'),
      
      // Health check
      healthCheck: () => CacheHealthChecker.performHealthCheck()
        .then(report => {
          console.log('[Cache Health]', report);
          return report;
        })
    };
    
    console.log('[Cache Debug] Debug interface attached to window.cacheDebug');
    console.log('[Cache Debug] Try: cacheDebug.help() or cacheDebug.status()');
  }
};