import { prisma } from "@/lib/prisma";

interface PromoValidationParams {
  code: string;
  orderAmount: number;
  items: Array<{
    menuItemId: string;
    quantity: number;
    unitPrice: number;
  }>;
  userId?: string;
}

interface PromoValidationResult {
  isValid: boolean;
  discount: {
    amount: number;
    type: string;
    isFreeDelivery: boolean;
    appliedToItems?: Array<{
      menuItemId: string;
      discountAmount: number;
    }>;
  };
  promotion?: {
    id: string;
    name: string;
    description?: string;
    code: string;
    type: string;
    value: number;
  };
  error?: string;
}

/**
 * Valide un code promo et calcule la réduction applicable
 * Gère l'applicabilité aux plats spécifiques et la livraison gratuite
 */
export async function validateAndCalculatePromoDiscount(
  params: PromoValidationParams
): Promise<PromoValidationResult> {
  const { code, orderAmount, items, userId } = params;

  try {
    // Recherche de la promotion par code
    const promotion = await prisma.promotion.findFirst({
      where: {
        code: {
          equals: code,
          mode: "insensitive",
        },
        isActive: true,
        startDate: {
          lte: new Date(),
        },
        endDate: {
          gte: new Date(),
        },
      },
      include: {
        usage: {
          where: userId
            ? {
                userId: userId,
              }
            : undefined,
        },
        _count: {
          select: {
            usage: true,
          },
        },
      },
    });

    if (!promotion) {
      return {
        isValid: false,
        discount: { amount: 0, type: "", isFreeDelivery: false },
        error: "Code promo invalide ou expiré",
      };
    }

    // Vérification de la fenêtre horaire si définie
    if (promotion.activeStartTime && promotion.activeEndTime) {
      const now = new Date();
      const currentHHMM = now.toTimeString().slice(0, 5); // HH:mm
      if (!(currentHHMM >= promotion.activeStartTime && currentHHMM <= promotion.activeEndTime)) {
        return {
          isValid: false,
          discount: { amount: 0, type: "", isFreeDelivery: false },
          error: "Cette promotion n'est pas active à cette heure",
        };
      }
    }

    // Vérification de la limite d'utilisation globale
    if (promotion.usageLimit && promotion._count.usage >= promotion.usageLimit) {
      return {
        isValid: false,
        discount: { amount: 0, type: "", isFreeDelivery: false },
        error: "Ce code promo a atteint sa limite d'utilisation",
      };
    }

    // Vérification de la limite d'utilisation par utilisateur
    if (userId && promotion.usagePerUser && promotion.usage.length >= promotion.usagePerUser) {
      return {
        isValid: false,
        discount: { amount: 0, type: "", isFreeDelivery: false },
        error: "Vous avez déjà utilisé ce code promo le nombre maximum de fois autorisé",
      };
    }

    // Vérification du montant minimum de commande
    if (promotion.minOrderAmount && orderAmount < Number(promotion.minOrderAmount)) {
      return {
        isValid: false,
        discount: { amount: 0, type: "", isFreeDelivery: false },
        error: `Montant minimum de commande non atteint. Minimum requis: ${promotion.minOrderAmount}€`,
      };
    }

    // Vérification du nombre minimum d'articles
    if (promotion.minOrderItem) {
      const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
      if (totalItems < promotion.minOrderItem) {
        return {
          isValid: false,
          discount: { amount: 0, type: "", isFreeDelivery: false },
          error: `Nombre minimum d'articles non atteint. Minimum requis: ${promotion.minOrderItem} article(s)`,
        };
      }
    }

    // Calcul de la réduction en fonction de l'applicabilité aux plats
    let discountAmount = 0;
    let appliedToItems: Array<{ menuItemId: string; discountAmount: number }> = [];

    // Si applicableMenuItems contient des IDs, appliquer la réduction uniquement sur ces plats
    if (promotion.applicableMenuItems.length > 0) {
      const applicableItems = items.filter((item) =>
        promotion.applicableMenuItems.includes(item.menuItemId)
      );

      if (applicableItems.length === 0) {
        return {
          isValid: false,
          discount: { amount: 0, type: "", isFreeDelivery: false },
          error: "Ce code promo n'est pas applicable aux articles de votre commande",
        };
      }

      // Calculer la réduction sur les plats applicables uniquement
      const applicableAmount = applicableItems.reduce(
        (sum, item) => sum + item.unitPrice * item.quantity,
        0
      );

      switch (promotion.type) {
        case "percentage":
          discountAmount = (applicableAmount * Number(promotion.value)) / 100;
          break;
        case "fixed_amount":
          discountAmount = Number(promotion.value);
          break;
        case "free_delivery":
          // Pour la livraison gratuite, pas de réduction sur les items
          discountAmount = 0;
          break;
        default:
          return {
            isValid: false,
            discount: { amount: 0, type: "", isFreeDelivery: false },
            error: "Type de promotion non supporté",
          };
      }

      // Répartir la réduction proportionnellement sur les plats applicables
      if (discountAmount > 0 && promotion.type !== "free_delivery") {
        const totalApplicableAmount = applicableItems.reduce(
          (sum, item) => sum + item.unitPrice * item.quantity,
          0
        );

        appliedToItems = applicableItems.map((item) => {
          const itemAmount = item.unitPrice * item.quantity;
          const itemDiscountAmount = (itemAmount / totalApplicableAmount) * discountAmount;
          return {
            menuItemId: item.menuItemId,
            discountAmount: itemDiscountAmount,
          };
        });
      }
    } else {
      // Si applicableMenuItems est vide, appliquer la réduction sur le prix total des items
      switch (promotion.type) {
        case "percentage":
          discountAmount = (orderAmount * Number(promotion.value)) / 100;
          break;
        case "fixed_amount":
          discountAmount = Number(promotion.value);
          break;
        case "free_delivery":
          // Pour la livraison gratuite, pas de réduction sur les items
          discountAmount = 0;
          break;
        default:
          return {
            isValid: false,
            discount: { amount: 0, type: "", isFreeDelivery: false },
            error: "Type de promotion non supporté",
          };
      }
    }

    // Application de la limite de réduction maximale
    if (promotion.maxDiscountAmount && discountAmount > Number(promotion.maxDiscountAmount)) {
      discountAmount = Number(promotion.maxDiscountAmount);
    }

    // S'assurer que la réduction ne dépasse pas le montant applicable
    const maxApplicableAmount =
      promotion.applicableMenuItems.length > 0
        ? items
            .filter((item) => promotion.applicableMenuItems.includes(item.menuItemId))
            .reduce((sum, item) => sum + item.unitPrice * item.quantity, 0)
        : orderAmount;

    if (discountAmount > maxApplicableAmount) {
      discountAmount = maxApplicableAmount;
    }

    const result: PromoValidationResult = {
      isValid: true,
      discount: {
        amount: discountAmount,
        type: promotion.type,
        isFreeDelivery: promotion.type === "free_delivery",
        appliedToItems: appliedToItems.length > 0 ? appliedToItems : undefined,
      },
      promotion: {
        id: promotion.id,
        name: promotion.name,
        description: promotion.description || undefined,
        code: promotion.code,
        type: promotion.type,
        value: Number(promotion.value),
      },
    };

    return result;
  } catch (error) {
    console.error("Erreur lors de la validation du code promo:", error);
    return {
      isValid: false,
      discount: { amount: 0, type: "", isFreeDelivery: false },
      error: "Erreur lors de la validation du code promo",
    };
  }
}
