import { prisma } from "./prisma-client";

// Graceful shutdown handlers
const gracefulShutdown = async () => {
  console.log("Shutting down Prisma client...");
  await prisma.$disconnect();
  process.exit(0);
};

process.on("SIGINT", gracefulShutdown);
process.on("SIGTERM", gracefulShutdown);
process.on("beforeExit", async () => {
  await prisma.$disconnect();
});

export { prisma };