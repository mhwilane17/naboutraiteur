/**
 * Cache utilities and helpers for public data stores
 * Provides common cache operations, invalidation mechanisms, and debugging utilities
 */

// Cache configuration constants
export const CACHE_CONFIG = {
  DEFAULT_DURATION: 5 * 60 * 1000, // 5 minutes
  MAX_RETRY_ATTEMPTS: 3,
  RETRY_DELAY_BASE: 1000, // 1 second base delay
  DEBUG_MODE: process.env.NODE_ENV === 'development'
} as const;

// Cache metadata interface
export interface CacheMetadata {
  lastFetch: number | null;
  cacheExpiry: number;
  isLoading: boolean;
  error: string | null;
  retryCount?: number;
}

// Cache entry interface for debugging
export interface CacheEntry<T = any> {
  key: string;
  data: T;
  metadata: CacheMetadata;
  size: number;
  hitCount: number;
  missCount: number;
}

// Cache statistics interface
export interface CacheStats {
  totalEntries: number;
  totalSize: number;
  hitRate: number;
  missRate: number;
  oldestEntry: string | null;
  newestEntry: string | null;
}

/**
 * Check if cached data is still fresh
 */
export const isDataFresh = (lastFetch: number | null, cacheExpiry: number): boolean => {
  if (!lastFetch) return false;
  return Date.now() - lastFetch < cacheExpiry;
};

/**
 * Calculate cache age in milliseconds
 */
export const getCacheAge = (lastFetch: number | null): number => {
  if (!lastFetch) return Infinity;
  return Date.now() - lastFetch;
};

/**
 * Calculate time until cache expires
 */
export const getTimeUntilExpiry = (lastFetch: number | null, cacheExpiry: number): number => {
  if (!lastFetch) return 0;
  const age = getCacheAge(lastFetch);
  return Math.max(0, cacheExpiry - age);
};

/**
 * Format cache age for human-readable display
 */
export const formatCacheAge = (lastFetch: number | null): string => {
  if (!lastFetch) return 'Never fetched';
  
  const age = getCacheAge(lastFetch);
  const seconds = Math.floor(age / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  
  if (hours > 0) return `${hours}h ${minutes % 60}m ago`;
  if (minutes > 0) return `${minutes}m ${seconds % 60}s ago`;
  return `${seconds}s ago`;
};

/**
 * Calculate exponential backoff delay for retries
 */
export const calculateRetryDelay = (retryCount: number): number => {
  return CACHE_CONFIG.RETRY_DELAY_BASE * Math.pow(2, retryCount);
};

/**
 * Check if retry should be attempted
 */
export const shouldRetry = (retryCount: number = 0): boolean => {
  return retryCount < CACHE_CONFIG.MAX_RETRY_ATTEMPTS;
};

/**
 * Create a cache invalidation function
 */
export const createCacheInvalidator = <T>(
  storeName: string,
  clearCacheFunction: () => void
) => {
  return {
    invalidate: () => {
      if (CACHE_CONFIG.DEBUG_MODE) {
        console.log(`[Cache] Invalidating cache for ${storeName}`);
      }
      clearCacheFunction();
    },
    
    invalidateAfter: (delay: number) => {
      setTimeout(() => {
        if (CACHE_CONFIG.DEBUG_MODE) {
          console.log(`[Cache] Auto-invalidating cache for ${storeName} after ${delay}ms`);
        }
        clearCacheFunction();
      }, delay);
    }
  };
};

/**
 * Cache debugging utilities
 */
export class CacheDebugger {
  private static entries = new Map<string, CacheEntry>();
  
  /**
   * Register a cache entry for debugging
   */
  static registerEntry<T>(
    key: string,
    data: T,
    metadata: CacheMetadata
  ): void {
    const existing = this.entries.get(key);
    const entry: CacheEntry<T> = {
      key,
      data,
      metadata,
      size: this.calculateSize(data),
      hitCount: existing?.hitCount || 0,
      missCount: existing?.missCount || 0
    };
    
    this.entries.set(key, entry);
    
    if (CACHE_CONFIG.DEBUG_MODE) {
      console.log(`[Cache Debug] Registered entry: ${key}`, entry);
    }
  }
  
  /**
   * Record a cache hit
   */
  static recordHit(key: string): void {
    const entry = this.entries.get(key);
    if (entry) {
      entry.hitCount++;
      if (CACHE_CONFIG.DEBUG_MODE) {
        console.log(`[Cache Debug] Cache HIT for ${key} (hits: ${entry.hitCount})`);
      }
    }
  }
  
  /**
   * Record a cache miss
   */
  static recordMiss(key: string): void {
    const entry = this.entries.get(key);
    if (entry) {
      entry.missCount++;
      if (CACHE_CONFIG.DEBUG_MODE) {
        console.log(`[Cache Debug] Cache MISS for ${key} (misses: ${entry.missCount})`);
      }
    }
  }
  
  /**
   * Get cache statistics
   */
  static getStats(): CacheStats {
    const entries = Array.from(this.entries.values());
    const totalHits = entries.reduce((sum, entry) => sum + entry.hitCount, 0);
    const totalMisses = entries.reduce((sum, entry) => sum + entry.missCount, 0);
    const totalRequests = totalHits + totalMisses;
    
    const oldestEntry = entries
      .filter(e => e.metadata.lastFetch)
      .sort((a, b) => (a.metadata.lastFetch || 0) - (b.metadata.lastFetch || 0))[0];
    
    const newestEntry = entries
      .filter(e => e.metadata.lastFetch)
      .sort((a, b) => (b.metadata.lastFetch || 0) - (a.metadata.lastFetch || 0))[0];
    
    return {
      totalEntries: entries.length,
      totalSize: entries.reduce((sum, entry) => sum + entry.size, 0),
      hitRate: totalRequests > 0 ? (totalHits / totalRequests) * 100 : 0,
      missRate: totalRequests > 0 ? (totalMisses / totalRequests) * 100 : 0,
      oldestEntry: oldestEntry?.key || null,
      newestEntry: newestEntry?.key || null
    };
  }
  
  /**
   * Get detailed information about a specific cache entry
   */
  static getEntryInfo(key: string): CacheEntry | null {
    return this.entries.get(key) || null;
  }
  
  /**
   * Get all cache entries
   */
  static getAllEntries(): CacheEntry[] {
    return Array.from(this.entries.values());
  }
  
  /**
   * Clear debug information for a specific entry
   */
  static clearEntry(key: string): void {
    this.entries.delete(key);
    if (CACHE_CONFIG.DEBUG_MODE) {
      console.log(`[Cache Debug] Cleared debug info for ${key}`);
    }
  }
  
  /**
   * Clear all debug information
   */
  static clearAll(): void {
    this.entries.clear();
    if (CACHE_CONFIG.DEBUG_MODE) {
      console.log('[Cache Debug] Cleared all debug information');
    }
  }
  
  /**
   * Print cache statistics to console
   */
  static printStats(): void {
    if (!CACHE_CONFIG.DEBUG_MODE) return;
    
    const stats = this.getStats();
    console.group('[Cache Debug] Statistics');
    console.log('Total Entries:', stats.totalEntries);
    console.log('Total Size:', `${(stats.totalSize / 1024).toFixed(2)} KB`);
    console.log('Hit Rate:', `${stats.hitRate.toFixed(2)}%`);
    console.log('Miss Rate:', `${stats.missRate.toFixed(2)}%`);
    console.log('Oldest Entry:', stats.oldestEntry);
    console.log('Newest Entry:', stats.newestEntry);
    console.groupEnd();
  }
  
  /**
   * Calculate approximate size of data in bytes
   */
  private static calculateSize(data: any): number {
    try {
      return new Blob([JSON.stringify(data)]).size;
    } catch {
      return 0;
    }
  }
}

/**
 * Cache monitoring utilities
 */
export class CacheMonitor {
  private static listeners = new Map<string, Array<(event: CacheEvent) => void>>();
  
  /**
   * Cache event types
   */
  static readonly Events = {
    FETCH_START: 'fetch_start',
    FETCH_SUCCESS: 'fetch_success',
    FETCH_ERROR: 'fetch_error',
    CACHE_HIT: 'cache_hit',
    CACHE_MISS: 'cache_miss',
    CACHE_INVALIDATE: 'cache_invalidate'
  } as const;
  
  /**
   * Add event listener
   */
  static addEventListener(
    event: string,
    listener: (event: CacheEvent) => void
  ): void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event)!.push(listener);
  }
  
  /**
   * Remove event listener
   */
  static removeEventListener(
    event: string,
    listener: (event: CacheEvent) => void
  ): void {
    const listeners = this.listeners.get(event);
    if (listeners) {
      const index = listeners.indexOf(listener);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    }
  }
  
  /**
   * Emit cache event
   */
  static emit(event: CacheEvent): void {
    const listeners = this.listeners.get(event.type);
    if (listeners) {
      listeners.forEach(listener => {
        try {
          listener(event);
        } catch (error) {
          console.error('[Cache Monitor] Error in event listener:', error);
        }
      });
    }
    
    if (CACHE_CONFIG.DEBUG_MODE) {
      console.log(`[Cache Monitor] ${event.type}:`, event);
    }
  }
}

/**
 * Cache event interface
 */
export interface CacheEvent {
  type: string;
  storeName: string;
  timestamp: number;
  data?: any;
  error?: string;
  metadata?: any;
}

/**
 * Create cache event
 */
export const createCacheEvent = (
  type: string,
  storeName: string,
  data?: any,
  error?: string,
  metadata?: any
): CacheEvent => ({
  type,
  storeName,
  timestamp: Date.now(),
  data,
  error,
  metadata
});

/**
 * Global cache management utilities
 */
export class GlobalCacheManager {
  private static stores = new Map<string, any>();
  
  /**
   * Register a store for global management
   */
  static registerStore(name: string, store: any): void {
    this.stores.set(name, store);
    if (CACHE_CONFIG.DEBUG_MODE) {
      console.log(`[Global Cache] Registered store: ${name}`);
    }
  }
  
  /**
   * Unregister a store
   */
  static unregisterStore(name: string): void {
    this.stores.delete(name);
    if (CACHE_CONFIG.DEBUG_MODE) {
      console.log(`[Global Cache] Unregistered store: ${name}`);
    }
  }
  
  /**
   * Clear all caches
   */
  static clearAllCaches(): void {
    this.stores.forEach((store, name) => {
      if (typeof store.clearCache === 'function') {
        store.clearCache();
        if (CACHE_CONFIG.DEBUG_MODE) {
          console.log(`[Global Cache] Cleared cache for ${name}`);
        }
      }
    });
  }
  
  /**
   * Refresh all caches
   */
  static async refreshAllCaches(): Promise<void> {
    const promises = Array.from(this.stores.entries()).map(async ([name, store]) => {
      if (typeof store.refetch === 'function') {
        try {
          await store.refetch();
          if (CACHE_CONFIG.DEBUG_MODE) {
            console.log(`[Global Cache] Refreshed cache for ${name}`);
          }
        } catch (error) {
          console.error(`[Global Cache] Failed to refresh ${name}:`, error);
        }
      }
    });
    
    await Promise.allSettled(promises);
  }
  
  /**
   * Get cache status for all stores
   */
  static getCacheStatus(): Record<string, any> {
    const status: Record<string, any> = {};
    
    this.stores.forEach((store, name) => {
      const state = store.getState ? store.getState() : store;
      status[name] = {
        hasData: Array.isArray(state.data) ? state.data.length > 0 : !!state.data,
        isLoading: state.loading || false,
        hasError: !!state.error,
        lastFetch: state.lastFetch,
        cacheAge: formatCacheAge(state.lastFetch),
        isDataFresh: typeof state.isDataFresh === 'function' ? state.isDataFresh() : false
      };
    });
    
    return status;
  }
}

/**
 * Performance monitoring utilities
 */
export class CachePerformanceMonitor {
  private static metrics = new Map<string, PerformanceMetric[]>();
  
  /**
   * Start performance measurement
   */
  static startMeasurement(key: string): PerformanceMeasurement {
    const startTime = performance.now();
    
    return {
      end: (success: boolean = true, dataSize?: number) => {
        const endTime = performance.now();
        const duration = endTime - startTime;
        
        this.recordMetric(key, {
          duration,
          success,
          dataSize,
          timestamp: Date.now()
        });
        
        return duration;
      }
    };
  }
  
  /**
   * Record performance metric
   */
  private static recordMetric(key: string, metric: PerformanceMetric): void {
    if (!this.metrics.has(key)) {
      this.metrics.set(key, []);
    }
    
    const metrics = this.metrics.get(key)!;
    metrics.push(metric);
    
    // Keep only last 100 measurements
    if (metrics.length > 100) {
      metrics.shift();
    }
    
    if (CACHE_CONFIG.DEBUG_MODE) {
      console.log(`[Performance] ${key}: ${metric.duration.toFixed(2)}ms`);
    }
  }
  
  /**
   * Get performance statistics
   */
  static getStats(key: string): PerformanceStats | null {
    const metrics = this.metrics.get(key);
    if (!metrics || metrics.length === 0) return null;
    
    const durations = metrics.map(m => m.duration);
    const successfulMetrics = metrics.filter(m => m.success);
    
    return {
      totalMeasurements: metrics.length,
      successRate: (successfulMetrics.length / metrics.length) * 100,
      averageDuration: durations.reduce((sum, d) => sum + d, 0) / durations.length,
      minDuration: Math.min(...durations),
      maxDuration: Math.max(...durations),
      medianDuration: this.calculateMedian(durations)
    };
  }
  
  /**
   * Calculate median value
   */
  private static calculateMedian(values: number[]): number {
    const sorted = [...values].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 === 0
      ? (sorted[mid - 1] + sorted[mid]) / 2
      : sorted[mid];
  }
}

// Performance interfaces
interface PerformanceMeasurement {
  end: (success?: boolean, dataSize?: number) => number;
}

interface PerformanceMetric {
  duration: number;
  success: boolean;
  dataSize?: number;
  timestamp: number;
}

interface PerformanceStats {
  totalMeasurements: number;
  successRate: number;
  averageDuration: number;
  minDuration: number;
  maxDuration: number;
  medianDuration: number;
}