/**
 * Fonctions de notification pour l'application Nabou Traiteur
 */

import { getNotificationConfigs } from "@/lib/app-config";
import { Logger } from "./logger";
import nodemailer from "nodemailer";

/**
 * Envoie les informations de connexion d'un nouvel utilisateur par email via NodeMailer
 * @param firstName - Prénom de l'utilisateur
 * @param lastName - Nom de l'utilisateur
 * @param email - Email de l'utilisateur
 * @param password - Mot de passe temporaire généré
 * @returns Résultat de l'envoi de l'email
 */
export async function sendUserCredentialsEmail(
  firstName: string,
  lastName: string,
  email: string,
  password: string
) {
  try {
    // Récupérer les configurations depuis la BDD avec fallback sur les variables d'environnement
    const { fromEmailPassword, fromEmail, smtpHost, smtpPort, smtpSecure } = await getNotificationConfigs();

    // Créer le transporteur NodeMailer
    const transporter = nodemailer.createTransport({
      host: smtpHost,
      port: smtpPort,
      secure: smtpSecure, // true pour 465, false pour autres ports
      auth: {
        user: fromEmail,
        pass: fromEmailPassword,
      },
    });

    // Template HTML pour l'email - Design simple et mobile-friendly
    const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bienvenue chez Nabou Traiteur</title>
        <style>
            /* Reset et base */
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; 
                line-height: 1.5; 
                color: #333; 
                background-color: #f5f5f5;
                padding: 10px;
            }
            
            /* Container principal */
            .email-container { 
                max-width: 100%; 
                width: 100%; 
                margin: 0 auto; 
                background: white;
                border-radius: 8px;
                overflow: hidden;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            
            /* Header */
            .header { 
                background: #667eea; 
                color: white; 
                padding: 20px 15px; 
                text-align: center; 
            }
            .header h1 { 
                font-size: 20px; 
                margin-bottom: 5px; 
                font-weight: 600;
            }
            .header p { 
                font-size: 14px; 
                opacity: 0.9; 
            }
            
            /* Contenu */
            .content { 
                padding: 20px 15px; 
            }
            .greeting { 
                font-size: 16px; 
                margin-bottom: 15px; 
                font-weight: 500;
            }
            .intro { 
                font-size: 14px; 
                margin-bottom: 20px; 
                color: #555; 
            }
            
            /* Bloc des identifiants */
            .credentials { 
                background: #f8f9ff; 
                border: 1px solid #e1e5f2; 
                border-radius: 6px; 
                padding: 15px; 
                margin: 20px 0; 
            }
            .credentials h3 { 
                font-size: 14px; 
                margin-bottom: 10px; 
                color: #667eea; 
                font-weight: 600;
            }
            .credential-item { 
                margin-bottom: 8px; 
                font-size: 14px; 
            }
            .credential-label { 
                font-weight: 500; 
                color: #333; 
            }
            .password-code { 
                background: #e8ecf7; 
                padding: 6px 10px; 
                border-radius: 4px; 
                font-family: 'Courier New', monospace; 
                font-size: 14px; 
                color: #667eea; 
                font-weight: 600;
                display: inline-block;
                margin-top: 5px;
            }
            
            /* Avertissement */
            .warning { 
                background: #fff8e1; 
                border: 1px solid #ffcc02; 
                border-radius: 6px; 
                padding: 15px; 
                margin: 20px 0; 
            }
            .warning h4 { 
                font-size: 14px; 
                margin-bottom: 8px; 
                color: #f57c00; 
                font-weight: 600;
            }
            .warning p { 
                font-size: 13px; 
                color: #e65100; 
            }
            
            /* Footer */
            .footer { 
                text-align: center; 
                margin-top: 25px; 
                padding-top: 20px; 
                border-top: 1px solid #eee; 
            }
            .footer p { 
                font-size: 13px; 
                color: #666; 
                margin-bottom: 5px; 
            }
            
            /* Responsive */
            @media only screen and (min-width: 480px) {
                body { padding: 20px; }
                .email-container { max-width: 500px; }
                .header { padding: 25px 20px; }
                .header h1 { font-size: 22px; }
                .content { padding: 25px 20px; }
                .greeting { font-size: 17px; }
                .intro { font-size: 15px; }
            }
            
            @media only screen and (min-width: 600px) {
                .email-container { max-width: 600px; }
                .header { padding: 30px 25px; }
                .content { padding: 30px 25px; }
            }
        </style>
    </head>
    <body>
        <div class="email-container">
            <div class="header">
                <h1>🎉 Bienvenue chez Nabou Traiteur !</h1>
                <p>Votre compte a été créé avec succès</p>
            </div>
            
            <div class="content">
                <div class="greeting">Bonjour ${firstName} ${lastName},</div>
                
                <div class="intro">
                    Nous sommes ravis de vous accueillir dans la famille Nabou Traiteur ! Votre compte a été créé et vous pouvez maintenant accéder à notre plateforme.
                </div>
                
                <div class="credentials">
                    <h3>📧 Vos informations de connexion</h3>
                    <div class="credential-item">
                        <span class="credential-label">Email :</span> ${email}
                    </div>
                    <div class="credential-item">
                        <span class="credential-label">Mot de passe temporaire :</span>
                        <div class="password-code">${password}</div>
                    </div>
                </div>
                
                <div class="warning">
                    <h4>⚠️ Important - Sécurité</h4>
                    <p>Pour des raisons de sécurité, nous vous recommandons fortement de <strong>changer votre mot de passe</strong> lors de votre première connexion.</p>
                </div>
                
                <div class="footer">
                    <p>Merci de faire confiance à Nabou Traiteur ! 🍽️</p>
                    <p><em>Si vous avez des questions, n'hésitez pas à nous contacter.</em></p>
                </div>
            </div>
        </div>
    </body>
    </html>`;

    // Préparer les options de l'email
    const mailOptions = {
      from: fromEmail,
      to: email,
      subject: "🎉 Bienvenue chez Nabou Traiteur - Vos informations de connexion",
      html: htmlContent
    };

    // Envoyer l'email avec NodeMailer
    const result = await transporter.sendMail(mailOptions);
    console.log("Email envoyé avec succès:", result.messageId);
    
    return { success: true, data: { messageId: result.messageId } };

  } catch (error) {
    console.error("Erreur lors de l'envoi de l'email de connexion:", error);
    return { success: false, error: error };
  }
}

/**
 * Envoie une notification WhatsApp au manager pour une nouvelle commande
 * @param orderNumber - Numéro de la commande
 * @param customerName - Nom complet du client
 * @param totalAmount - Montant total de la commande
 * @param customerPhone - Numéro de téléphone du client
 * @param deliveryZone - Zone de livraison (ou null si retrait sur place)
 * @param orderItems - Articles commandés avec leurs quantités
 * @returns Résultat de l'envoi de la notification
 */
export async function sendWhatsAppNotification(
  orderNumber: string,
  customerName: string,
  totalAmount: number,
  customerPhone: string,
  deliveryZone: string | null,
  orderItems: any[]
) {
  try {
    // Récupérer les configurations WhatsApp depuis la BDD avec fallback sur les variables d'environnement
    const { whatsappToken, whatsappPhone: recipientPhoneNumber, whatsappPhoneNumberId: phoneNumberId } = await getNotificationConfigs();

    if (!whatsappToken || !recipientPhoneNumber || !phoneNumberId) {
      console.error("Une ou plusieurs variables d'environnement WhatsApp ne sont pas définies");
      return;
    }

    // Formater les articles commandés
    const itemsText = orderItems
      .map((item) => {
        return `(${item.quantity}x) ${item.menuItemName || "Article"}`;
      })
      .join(" - ");

    // Préparer les en-têtes
    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Authorization", `Bearer ${whatsappToken}`);

    // Préparer le corps de la requête
    // phoneNumber est le numéro du manager qui recevra la notification
    const raw = JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: recipientPhoneNumber, // Numéro du manager, pas celui du client
      type: "template",
      template: {
        name: "nabou_new_order_receved",
        language: {
          code: "fr",
        },
        components: [
          {
            type: "body",
            parameters: [
              {
                type: "text",
                text: orderNumber,
              },
              {
                type: "text",
                text: customerName,
              },
              {
                type: "text",
                text: customerPhone,
              },
              {
                type: "text",
                text: deliveryZone || "Retrait sur place",
              },
              {
                type: "text",
                text: itemsText,
              },
              {
                type: "text",
                text: totalAmount.toString(),
              },
            ],
          },

          // {
          //   type: "button",
          //   sub_type: "url",
          //   index: "0",
          //   parameters: [
          //     {
          //       type: "text",
          //       text: orderNumber,
          //     },
          //   ],
          // },
        ],
      },
    });

    // Options de la requête
    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: raw,
    };

    // Envoyer la notification
    const response = await fetch(
      `https://graph.facebook.com/v21.0/${phoneNumberId}/messages`,
      requestOptions
    );
    const result = await response.text();

    console.log(raw);

    Logger.info("[sendWhatsAppNotification]: Notification WhatsApp envoyée:", undefined, result);
    return result;
  } catch (error) {
    console.error(error);
    Logger.error("[sendWhatsAppNotification]: Erreur lors de l'envoi de la notification WhatsApp:", undefined);
  }
}

/**
 * Envoie une notification WhatsApp au client pour confirmer sa commande
 * @param orderNumber - Numéro de la commande
 * @param orderTotal - Montant total de la commande
 * @param orderArticles - Articles commandés avec leurs quantités
 * @param clientPhoneNumber - Numéro de téléphone du client
 * @returns Résultat de l'envoi de la notification
 */
interface NotificationClient {
  orderNumber: string;
  orderTotal: string;
  orderArticles: string;
  clientPhoneNumber: string;
  deliveryFees: string;
  deliveryAdress: string;
  deliveryZone: string;
  deliveryTime: string;
  customerName: string;
  totalArticles: string;
  discountAmount: string;
}
export async function sendClientWhatsAppNotification({
  orderNumber,
  orderTotal,
  orderArticles,
  clientPhoneNumber,
  deliveryFees,
  deliveryAdress,
  deliveryZone,
  deliveryTime,
  customerName,
  totalArticles,
  discountAmount,
}: NotificationClient) {
  try {
    // Récupérer les configurations WhatsApp depuis la BDD avec fallback sur les variables d'environnement
    const { whatsappToken, whatsappPhoneNumberId: phoneNumberId } = await getNotificationConfigs();
    const paymentLink = process.env.WAVE_PAYMENT_LINK; // Cette valeur reste en variable d'environnement

    if (!whatsappToken || !phoneNumberId) {
      console.error("Une ou plusieurs variables d'environnement WhatsApp ne sont pas définies");
      return;
    }

    // Préparer les en-têtes
    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Authorization", `Bearer ${whatsappToken}`);

    // Préparer le corps de la requête
    const raw = JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: clientPhoneNumber,
      type: "template",
      template: {
        name: "nabou_client_order_confirmation",
        language: {
          code: "fr",
        },
        components: [
          {
            type: "body",
            parameters: [
              {
                type: "text",
                text: customerName,
              },
              {
                type: "text",
                text: orderNumber,
              },
              {
                type: "text",
                text: totalArticles,
              },
              {
                type: "text",
                text: orderArticles,
              },
              {
                type: "text",
                text: discountAmount,
              },
              {
                type: "text",
                text: deliveryFees,
              },
              {
                type: "text",
                text: orderTotal,
              },
              {
                type: "text",
                text: deliveryAdress,
              },
              {
                type: "text",
                text: deliveryZone,
              },
              {
                type: "text",
                text: deliveryTime,
              },
              {
                type: "text",
                text: paymentLink,
              },
              // {
              //   type: "text",
              //   text: recipientPhoneNumber,
              // },
            ],
          },
        ],
      },
    });

    // Options de la requête
    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: raw,
      redirect: "follow" as RequestRedirect,
    };

    // Envoyer la notification
    const response = await fetch(
      `https://graph.facebook.com/v21.0/${phoneNumberId}/messages`,
      requestOptions
    );
    const result = await response.text();

    console.log("Notification WhatsApp client envoyée:", result);
    return result;
  } catch (error) {
    console.error("Erreur lors de l'envoi de la notification WhatsApp client:", error);
  }
}
