/**
 * Cache Utilities Index
 * Central export point for all cache-related utilities and helpers
 */

import { attachDebugInterface } from '../cache-debug-tools';
import { setupDefaultInvalidations } from '../cache-invalidation';
import { CACHE_CONFIG } from '../cache-utils';
import { PublicCacheManager } from '../public-cache-manager';

// Core cache utilities
export {
  CACHE_CONFIG,
  isDataFresh,
  getCacheAge,
  getTimeUntilExpiry,
  formatCacheAge,
  calculateRetryDelay,
  shouldRetry,
  createCacheInvalidator,
  CacheDebugger,
  CacheMonitor,
  CachePerformanceMonitor,
  GlobalCacheManager,
  createCacheEvent
} from '../cache-utils';

export type {
  CacheMetadata,
  CacheEntry,
  CacheStats,
  CacheEvent
} from '../cache-utils';

// Public cache manager
export {
  PublicCacheManager
} from '../public-cache-manager';

export type {
  StoreCacheStatus,
  OverallCacheStatus,
  PublicCacheStatus
} from '../public-cache-manager';

// Cache invalidation
export {
  CacheInvalidationManager,
  InvalidationStrategy,
  InvalidationConfigs,
  setupDefaultInvalidations,
  cleanupInvalidations
} from '../cache-invalidation';

export type {
  InvalidationConfig
} from '../cache-invalidation';

// Debug tools
export {
  CacheDebugConsole,
  CacheHealthChecker,
  attachDebugInterface
} from '../cache-debug-tools';

export type {
  HealthCheck,
  CacheHealthReport
} from '../cache-debug-tools';

/**
 * Initialize cache system with default configuration
 */
export const initializeCacheSystem = (stores?: {
  categories?: any;
  deliveryZones?: any;
  paymentMethods?: any;
}) => {
  // Initialize public cache manager
  if (stores) {
    PublicCacheManager.initialize(stores);
  }
  
  // Setup default invalidation strategies
  setupDefaultInvalidations();
  
  // Attach debug interface in development
  attachDebugInterface();
  
  console.log('[Cache System] Initialized with utilities and monitoring');
};

/**
 * Quick access to common cache operations
 */
export const CacheUtils = {
  // Status and monitoring
  // getStatus: () => PublicCacheManager.getCacheStatus(),
  // getPerformanceStats: () => PublicCacheManager.getPerformanceStats(),
  
  // // Data operations
  // preloadAll: () => PublicCacheManager.preloadAll(),
  // refreshAll: () => PublicCacheManager.refreshAll(),
  // clearAll: () => PublicCacheManager.clearAll(),
  
  // // Health check
  // healthCheck: () => CacheHealthChecker.performHealthCheck(),
  
  // // Debug
  // printDebugInfo: () => PublicCacheManager.printDebugInfo(),
  
  // // Invalidation
  // setupInvalidations: setupDefaultInvalidations,
  // cleanupInvalidations: cleanupInvalidations
};

/**
 * Cache system configuration
 */
export const CacheSystemConfig = {
  // Default cache duration (5 minutes)
  DEFAULT_CACHE_DURATION: CACHE_CONFIG.DEFAULT_DURATION,
  
  // Performance thresholds
  PERFORMANCE_THRESHOLDS: {
    MAX_RESPONSE_TIME: 5000, // 5 seconds
    MIN_SUCCESS_RATE: 95, // 95%
    MAX_CACHE_SIZE: 1024 * 1024, // 1MB
    MAX_MISS_RATE: 50 // 50%
  },
  
  // Retry configuration
  RETRY_CONFIG: {
    MAX_ATTEMPTS: CACHE_CONFIG.MAX_RETRY_ATTEMPTS,
    BASE_DELAY: CACHE_CONFIG.RETRY_DELAY_BASE
  }
};