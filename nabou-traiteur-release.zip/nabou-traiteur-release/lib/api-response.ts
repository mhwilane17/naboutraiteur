import { NextResponse } from "next/server";
import { z } from "zod";
import { ApiSuccessResponse, ApiErrorResponse } from "@/types/api";
import { ERROR_CODES, ERROR_MESSAGES, ErrorCode } from "@/lib/error-codes";

/**
 * Classe pour gérer les réponses de succès de l'API
 */
export class ApiResponse {
  static success<T>(
    data: T,
    message?: string,
    pagination?: {
      page: number;
      limit: number;
      total: number;
      totalPages: number;
    }
  ): NextResponse<ApiSuccessResponse<T>> {
    const response: ApiSuccessResponse<T> = {
      success: true,
      data,
      message,
      pagination,
    };

    return NextResponse.json(response);
  }

  static created<T>(data: T, message?: string): NextResponse<ApiSuccessResponse<T>> {
    const response: ApiSuccessResponse<T> = {
      success: true,
      data,
      message: message || "Ressource créée avec succès",
    };

    return NextResponse.json(response, { status: 201 });
  }

  static updated<T>(data: T, message?: string): NextResponse<ApiSuccessResponse<T>> {
    const response: ApiSuccessResponse<T> = {
      success: true,
      data,
      message: message || "Ressource mise à jour avec succès",
    };

    return NextResponse.json(response);
  }

  static deleted(message?: string): NextResponse<ApiSuccessResponse<null>> {
    const response: ApiSuccessResponse<null> = {
      success: true,
      data: null,
      message: message || "Ressource supprimée avec succès",
    };

    return NextResponse.json(response);
  }
}

/**
 * Classe pour gérer les erreurs de l'API
 */
export class ApiError extends Error {
  public code: ErrorCode;
  public statusCode: number;
  public details?: any;

  constructor(code: ErrorCode, message?: string, statusCode: number = 500, details?: any) {
    super(message || ERROR_MESSAGES[code]);
    this.code = code;
    this.statusCode = statusCode;
    this.details = details;
    this.name = "ApiError";
  }

  // Méthodes statiques pour les erreurs courantes
  static badRequest(
    message?: string,
    code: ErrorCode = ERROR_CODES.VALIDATION_INVALID_FORMAT,
    details?: any
  ): NextResponse<ApiErrorResponse> {
    return this.createErrorResponse(code, message, 400, details);
  }

  static unauthorized(
    message?: string,
    code: ErrorCode = ERROR_CODES.AUTH_INVALID_TOKEN
  ): NextResponse<ApiErrorResponse> {
    return this.createErrorResponse(code, message, 401);
  }

  static forbidden(
    message?: string,
    code: ErrorCode = ERROR_CODES.AUTH_INSUFFICIENT_PERMISSIONS
  ): NextResponse<ApiErrorResponse> {
    return this.createErrorResponse(code, message, 403);
  }

  static notFound(
    message?: string,
    code: ErrorCode = ERROR_CODES.RESOURCE_NOT_FOUND
  ): NextResponse<ApiErrorResponse> {
    return this.createErrorResponse(code, message, 404);
  }

  static conflict(
    message?: string,
    code: ErrorCode = ERROR_CODES.RESOURCE_CONFLICT
  ): NextResponse<ApiErrorResponse> {
    return this.createErrorResponse(code, message, 409);
  }

  static tooManyRequests(
    message?: string,
    code: ErrorCode = ERROR_CODES.SYSTEM_RATE_LIMIT_EXCEEDED
  ): NextResponse<ApiErrorResponse> {
    return this.createErrorResponse(code, message, 429);
  }

  static internalError(
    message?: string,
    code: ErrorCode = ERROR_CODES.SYSTEM_INTERNAL_ERROR
  ): NextResponse<ApiErrorResponse> {
    return this.createErrorResponse(code, message, 500);
  }

  // Méthode pour créer une réponse d'erreur
  private static createErrorResponse(
    code: ErrorCode,
    message?: string,
    statusCode: number = 500,
    details?: any
  ): NextResponse<ApiErrorResponse> {
    const response: ApiErrorResponse = {
      success: false,
      error: {
        code,
        message: message || ERROR_MESSAGES[code],
        details,
      },
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { status: statusCode });
  }

  // Gestionnaire global d'erreurs
  static handle(error: unknown): NextResponse<ApiErrorResponse> {
    console.error("API Error:", error);

    // Erreur de validation Zod
    if (error instanceof z.ZodError) {
      return this.badRequest(
        "Données de validation invalides",
        ERROR_CODES.VALIDATION_INVALID_FORMAT,
        error.errors
      );
    }

    // Erreur API personnalisée
    if (error instanceof ApiError) {
      return this.createErrorResponse(
        error.code,
        error.message,
        error.statusCode,
        error.details
      );
    }

    // Erreur Prisma
    if (error && typeof error === "object" && "code" in error) {
      const prismaError = error as any;
      
      // Violation de contrainte unique
      if (prismaError.code === "P2002") {
        return this.conflict(
          "Cette ressource existe déjà",
          ERROR_CODES.RESOURCE_ALREADY_EXISTS
        );
      }
      
      // Enregistrement non trouvé
      if (prismaError.code === "P2025") {
        return this.notFound(
          "Ressource introuvable",
          ERROR_CODES.RESOURCE_NOT_FOUND
        );
      }
      
      // Autres erreurs Prisma
      return this.internalError(
        "Erreur de base de données",
        ERROR_CODES.SYSTEM_DATABASE_ERROR
      );
    }

    // Erreur générique
    return this.internalError(
      "Une erreur inattendue s'est produite",
      ERROR_CODES.SYSTEM_INTERNAL_ERROR
    );
  }
}