import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

// Configuration optimisée pour éviter "Too many database connections"
export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"],
    datasources: {
      db: {
        url: process.env.DATABASE_URL,
      },
    },
    // Configuration du pool de connexions pour éviter les erreurs de connexion
    // Ces paramètres sont intégrés dans l'URL de connexion PostgreSQL
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}