/**
 * Cache Invalidation Mechanisms
 * Provides various strategies for cache invalidation and refresh
 */

import { PublicCacheManager } from './public-cache-manager';
import { CacheMonitor, createCacheEvent, CACHE_CONFIG } from './cache-utils';

/**
 * Cache invalidation strategies
 */
export enum InvalidationStrategy {
  IMMEDIATE = 'immediate',
  DELAYED = 'delayed',
  SCHEDULED = 'scheduled',
  ON_ERROR = 'on_error',
  ON_VISIBILITY_CHANGE = 'on_visibility_change',
  ON_NETWORK_RECONNECT = 'on_network_reconnect'
}

/**
 * Cache invalidation configuration
 */
export interface InvalidationConfig {
  strategy: InvalidationStrategy;
  delay?: number;
  scheduleTime?: string; // HH:MM format
  maxRetries?: number;
  retryDelay?: number;
}

/**
 * Cache invalidation manager
 */
export class CacheInvalidationManager {
  private static timers = new Map<string, NodeJS.Timeout>();
  private static intervals = new Map<string, NodeJS.Timeout>();
  private static listeners = new Map<string, () => void>();
  
  /**
   * Invalidate cache using specified strategy
   */
  static invalidate(
    storeName: string | 'all',
    config: InvalidationConfig
  ): void {
    const key = `${storeName}_${config.strategy}`;
    
    // Clear existing timer/interval for this key
    this.clearInvalidation(key);
    
    switch (config.strategy) {
      case InvalidationStrategy.IMMEDIATE:
        this.invalidateImmediate(storeName);
        break;
        
      case InvalidationStrategy.DELAYED:
        this.invalidateDelayed(storeName, config.delay || 1000, key);
        break;
        
      case InvalidationStrategy.SCHEDULED:
        this.invalidateScheduled(storeName, config.scheduleTime || '00:00', key);
        break;
        
      case InvalidationStrategy.ON_ERROR:
        this.invalidateOnError(storeName, config, key);
        break;
        
      case InvalidationStrategy.ON_VISIBILITY_CHANGE:
        this.invalidateOnVisibilityChange(storeName, key);
        break;
        
      case InvalidationStrategy.ON_NETWORK_RECONNECT:
        this.invalidateOnNetworkReconnect(storeName, key);
        break;
    }
    
    if (CACHE_CONFIG.DEBUG_MODE) {
      console.log(`[Cache Invalidation] Set up ${config.strategy} invalidation for ${storeName}`);
    }
  }
  
  /**
   * Immediate invalidation
   */
  private static invalidateImmediate(storeName: string | 'all'): void {
    if (storeName === 'all') {
      PublicCacheManager.clearAll();
    } else {
      this.invalidateSpecificStore(storeName);
    }
    
    CacheMonitor.emit(createCacheEvent(
      CacheMonitor.Events.CACHE_INVALIDATE,
      storeName,
      null,
      undefined,
      { strategy: InvalidationStrategy.IMMEDIATE }
    ));
  }
  
  /**
   * Delayed invalidation
   */
  private static invalidateDelayed(
    storeName: string | 'all',
    delay: number,
    key: string
  ): void {
    const timer = setTimeout(() => {
      this.invalidateImmediate(storeName);
      this.timers.delete(key);
    }, delay);
    
    this.timers.set(key, timer);
  }
  
  /**
   * Scheduled invalidation (daily at specified time)
   */
  private static invalidateScheduled(
    storeName: string | 'all',
    scheduleTime: string,
    key: string
  ): void {
    const [hours, minutes] = scheduleTime.split(':').map(Number);
    
    const scheduleInvalidation = () => {
      const now = new Date();
      const scheduledTime = new Date();
      scheduledTime.setHours(hours, minutes, 0, 0);
      
      // If scheduled time has passed today, schedule for tomorrow
      if (scheduledTime <= now) {
        scheduledTime.setDate(scheduledTime.getDate() + 1);
      }
      
      const delay = scheduledTime.getTime() - now.getTime();
      
      const timer = setTimeout(() => {
        this.invalidateImmediate(storeName);
        // Schedule next invalidation
        scheduleInvalidation();
      }, delay);
      
      this.timers.set(key, timer);
    };
    
    scheduleInvalidation();
  }
  
  /**
   * Invalidation on error with retry logic
   */
  private static invalidateOnError(
    storeName: string | 'all',
    config: InvalidationConfig,
    key: string
  ): void {
    let retryCount = 0;
    const maxRetries = config.maxRetries || 3;
    const retryDelay = config.retryDelay || 5000;
    
    const errorListener = (event: any) => {
      if (event.type === CacheMonitor.Events.FETCH_ERROR) {
        if (storeName === 'all' || event.storeName === storeName) {
          if (retryCount < maxRetries) {
            retryCount++;
            
            const timer = setTimeout(() => {
              if (storeName === 'all') {
                PublicCacheManager.refreshAll().catch(() => {
                  // Error will be handled by the error listener again
                });
              } else {
                this.refreshSpecificStore(storeName).catch(() => {
                  // Error will be handled by the error listener again
                });
              }
            }, retryDelay * retryCount); // Exponential backoff
            
            this.timers.set(`${key}_retry_${retryCount}`, timer);
            
            if (CACHE_CONFIG.DEBUG_MODE) {
              console.log(`[Cache Invalidation] Retry ${retryCount}/${maxRetries} for ${storeName} in ${retryDelay * retryCount}ms`);
            }
          } else {
            if (CACHE_CONFIG.DEBUG_MODE) {
              console.log(`[Cache Invalidation] Max retries reached for ${storeName}`);
            }
          }
        }
      } else if (event.type === CacheMonitor.Events.FETCH_SUCCESS) {
        // Reset retry count on success
        if (storeName === 'all' || event.storeName === storeName) {
          retryCount = 0;
        }
      }
    };
    
    CacheMonitor.addEventListener(CacheMonitor.Events.FETCH_ERROR, errorListener);
    CacheMonitor.addEventListener(CacheMonitor.Events.FETCH_SUCCESS, errorListener);
    
    this.listeners.set(key, () => {
      CacheMonitor.removeEventListener(CacheMonitor.Events.FETCH_ERROR, errorListener);
      CacheMonitor.removeEventListener(CacheMonitor.Events.FETCH_SUCCESS, errorListener);
    });
  }
  
  /**
   * Invalidation on visibility change (when user returns to tab)
   */
  private static invalidateOnVisibilityChange(
    storeName: string | 'all',
    key: string
  ): void {
    if (typeof document === 'undefined') return; // Server-side check
    
    const visibilityListener = () => {
      if (!document.hidden) {
        // User returned to tab, refresh cache if data is stale
        if (storeName === 'all') {
          PublicCacheManager.preloadAll().catch(error => {
            console.error('[Cache Invalidation] Failed to refresh on visibility change:', error);
          });
        } else {
          this.refreshSpecificStore(storeName).catch(error => {
            console.error(`[Cache Invalidation] Failed to refresh ${storeName} on visibility change:`, error);
          });
        }
      }
    };
    
    document.addEventListener('visibilitychange', visibilityListener);
    
    this.listeners.set(key, () => {
      document.removeEventListener('visibilitychange', visibilityListener);
    });
  }
  
  /**
   * Invalidation on network reconnect
   */
  private static invalidateOnNetworkReconnect(
    storeName: string | 'all',
    key: string
  ): void {
    if (typeof window === 'undefined') return; // Server-side check
    
    const onlineListener = () => {
      // Network reconnected, refresh cache
      if (storeName === 'all') {
        PublicCacheManager.refreshAll().catch(error => {
          console.error('[Cache Invalidation] Failed to refresh on network reconnect:', error);
        });
      } else {
        this.refreshSpecificStore(storeName).catch(error => {
          console.error(`[Cache Invalidation] Failed to refresh ${storeName} on network reconnect:`, error);
        });
      }
    };
    
    window.addEventListener('online', onlineListener);
    
    this.listeners.set(key, () => {
      window.removeEventListener('online', onlineListener);
    });
  }
  
  /**
   * Invalidate specific store
   */
  private static invalidateSpecificStore(storeName: string): void {
    // This would need to be implemented based on the specific store
    // For now, we'll use the global cache manager approach
    switch (storeName) {
      case 'publicCategories':
      case 'publicDeliveryZones':
      case 'publicPaymentMethods':
        // Individual store invalidation would be implemented here
        // For now, we'll clear all as a fallback
        PublicCacheManager.clearAll();
        break;
      default:
        console.warn(`[Cache Invalidation] Unknown store: ${storeName}`);
    }
  }
  
  /**
   * Refresh specific store
   */
  private static async refreshSpecificStore(storeName: string): Promise<void> {
    switch (storeName) {
      case 'publicCategories':
        await PublicCacheManager.loadCategories();
        break;
      case 'publicDeliveryZones':
        await PublicCacheManager.loadDeliveryZones();
        break;
      case 'publicPaymentMethods':
        await PublicCacheManager.loadPaymentMethods();
        break;
      default:
        throw new Error(`Unknown store: ${storeName}`);
    }
  }
  
  /**
   * Clear specific invalidation
   */
  static clearInvalidation(key: string): void {
    // Clear timer
    const timer = this.timers.get(key);
    if (timer) {
      clearTimeout(timer);
      this.timers.delete(key);
    }
    
    // Clear interval
    const interval = this.intervals.get(key);
    if (interval) {
      clearInterval(interval);
      this.intervals.delete(key);
    }
    
    // Remove listener
    const removeListener = this.listeners.get(key);
    if (removeListener) {
      removeListener();
      this.listeners.delete(key);
    }
  }
  
  /**
   * Clear all invalidations
   */
  static clearAllInvalidations(): void {
    // Clear all timers
    this.timers.forEach(timer => clearTimeout(timer));
    this.timers.clear();
    
    // Clear all intervals
    this.intervals.forEach(interval => clearInterval(interval));
    this.intervals.clear();
    
    // Remove all listeners
    this.listeners.forEach(removeListener => removeListener());
    this.listeners.clear();
    
    if (CACHE_CONFIG.DEBUG_MODE) {
      console.log('[Cache Invalidation] Cleared all invalidations');
    }
  }
  
  /**
   * Get active invalidations
   */
  static getActiveInvalidations(): string[] {
    const active = [
      ...Array.from(this.timers.keys()),
      ...Array.from(this.intervals.keys()),
      ...Array.from(this.listeners.keys())
    ];
    
    return [...new Set(active)]; // Remove duplicates
  }
}

/**
 * Predefined invalidation configurations
 */
export const InvalidationConfigs = {
  /**
   * Refresh cache every 5 minutes
   */
  AUTO_REFRESH: {
    strategy: InvalidationStrategy.SCHEDULED,
    scheduleTime: '00:00' // Will be overridden by interval
  } as InvalidationConfig,
  
  /**
   * Refresh on network errors with retry
   */
  ERROR_RECOVERY: {
    strategy: InvalidationStrategy.ON_ERROR,
    maxRetries: 3,
    retryDelay: 2000
  } as InvalidationConfig,
  
  /**
   * Refresh when user returns to tab
   */
  VISIBILITY_REFRESH: {
    strategy: InvalidationStrategy.ON_VISIBILITY_CHANGE
  } as InvalidationConfig,
  
  /**
   * Refresh when network reconnects
   */
  NETWORK_RECOVERY: {
    strategy: InvalidationStrategy.ON_NETWORK_RECONNECT
  } as InvalidationConfig,
  
  /**
   * Daily cache refresh at midnight
   */
  DAILY_REFRESH: {
    strategy: InvalidationStrategy.SCHEDULED,
    scheduleTime: '00:00'
  } as InvalidationConfig
};

/**
 * Setup default invalidation strategies for public caches
 */
export const setupDefaultInvalidations = (): void => {
  // Setup error recovery for all stores
  CacheInvalidationManager.invalidate('all', InvalidationConfigs.ERROR_RECOVERY);
  
  // Setup visibility change refresh
  CacheInvalidationManager.invalidate('all', InvalidationConfigs.VISIBILITY_REFRESH);
  
  // Setup network recovery
  CacheInvalidationManager.invalidate('all', InvalidationConfigs.NETWORK_RECOVERY);
  
  if (CACHE_CONFIG.DEBUG_MODE) {
    console.log('[Cache Invalidation] Default invalidation strategies set up');
  }
};

/**
 * Cleanup function to call when component unmounts or app closes
 */
export const cleanupInvalidations = (): void => {
  CacheInvalidationManager.clearAllInvalidations();
};