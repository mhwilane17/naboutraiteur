import { prisma } from './prisma'

/**
 * Utility pour exécuter des requêtes avec gestion automatique des connexions
 * Évite les erreurs "Too many database connections"
 */
export async function withDatabase<T>(
  operation: (client: typeof prisma) => Promise<T>
): Promise<T> {
  try {
    const result = await operation(prisma)
    return result
  } catch (error) {
    console.error('Database operation failed:', error)
    throw error
  }
}

/**
 * Utility pour exécuter des transactions avec gestion automatique des connexions
 */
export async function withTransaction<T>(
  operation: (tx: Parameters<Parameters<typeof prisma.$transaction>[0]>[0]) => Promise<T>
): Promise<T> {
  try {
    const result = await prisma.$transaction(operation, {
      maxWait: 5000, // 5 secondes max d'attente
      timeout: 10000, // 10 secondes max d'exécution
    })
    return result
  } catch (error) {
    console.error('Database transaction failed:', error)
    throw error
  }
}

/**
 * Vérifie la santé de la connexion à la base de données
 */
export async function checkDatabaseHealth(): Promise<boolean> {
  try {
    await prisma.$queryRaw`SELECT 1`
    return true
  } catch (error) {
    console.error('Database health check failed:', error)
    return false
  }
}

/**
 * Force la déconnexion et reconnexion à la base de données
 * Utile en cas de problèmes de connexion
 */
export async function reconnectDatabase(): Promise<void> {
  try {
    await prisma.$disconnect()
    await prisma.$connect()
  } catch (error) {
    console.error('Database reconnection failed:', error)
    throw error
  }
}