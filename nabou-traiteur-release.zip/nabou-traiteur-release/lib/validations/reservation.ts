import { z } from "zod";

// Schéma pour les informations client
export const customerInfoSchema = z.object({
  firstName: z.string().min(1, "Le prénom est requis"),
  lastName: z.string().min(1, "Le nom est requis"),
  phone: z.string().min(10, "Le numéro de téléphone doit contenir au moins 10 caractères"),
  email: z.string().email("Email invalide").optional().or(z.literal("")),
  employeeId: z.string().optional(),
});

// Schéma pour les informations de livraison
export const deliveryInfoSchema = z.object({
  deliveryZoneId: z.string().min(1, "La zone de livraison est requise"),
  deliveryAddress: z.string().min(1, "L'adresse de livraison est requise"),
  deliveryTime: z.string().min(1, "L'heure de livraison est requise"),
});

// Schéma pour les options de menu
export const menuOptionsSchema = z.object({
  menuSize: z.string().min(1, "Veuillez sélectionner une option"),
  quantity: z.number().min(1, "La quantité doit être d'au moins 1"),
});

// Schéma pour le code promo
export const promoCodeSchema = z.object({
  code: z.string().min(1, "Le code promo ne peut pas être vide"),
});

// Schéma complet pour le formulaire de réservation
export const reservationFormSchema = z.object({
  customerInfo: customerInfoSchema,
  deliveryInfo: deliveryInfoSchema,
  menuOptions: menuOptionsSchema,
  customerNotes: z.string().optional(),
  paymentMethod: z.string().min(1, "Le mode de paiement est requis"),
  weeklyMenuId: z.string().min(1, "L'ID du menu hebdomadaire est requis"),
  promoCode: z.string().optional(),
});

// Types dérivés des schémas
export type CustomerInfo = z.infer<typeof customerInfoSchema>;
export type DeliveryInfo = z.infer<typeof deliveryInfoSchema>;
export type MenuOptions = z.infer<typeof menuOptionsSchema>;
export type PromoCode = z.infer<typeof promoCodeSchema>;
export type ReservationForm = z.infer<typeof reservationFormSchema>;

// Fonctions de validation utilitaires
export const validateCustomerInfo = (data: unknown) => {
  return customerInfoSchema.safeParse(data);
};

export const validateDeliveryInfo = (data: unknown) => {
  return deliveryInfoSchema.safeParse(data);
};

export const validateMenuOptions = (data: unknown) => {
  return menuOptionsSchema.safeParse(data);
};

export const validatePromoCode = (data: unknown) => {
  return promoCodeSchema.safeParse(data);
};

export const validateReservationForm = (data: unknown) => {
  return reservationFormSchema.safeParse(data);
};

// Validation par étape
export const validateStep = (step: number, data: any, isLoggedIn: boolean = false) => {
  switch (step) {
    case 1:
      // Étape quantité/options
      return validateMenuOptions({
        menuSize: data.menuSize,
        quantity: data.quantity,
      });
    
    case 2:
      // Étape informations (seulement pour les utilisateurs non connectés)
      if (isLoggedIn) return { success: true };
      return validateCustomerInfo(data.customerInfo) && validateDeliveryInfo(data.deliveryInfo);
    
    case 3:
      // Étape confirmation/paiement
      return data.paymentMethod && data.paymentMethod.trim() !== "";
    
    default:
      return { success: false, error: { message: "Étape invalide" } };
  }
};

// Validation des options obligatoires pour le mode panier
export const validateCartModeOptions = (menuSize: string) => {
  if (!menuSize || menuSize.trim() === "") {
    return {
      success: false,
      error: { message: "Veuillez sélectionner une option avant d'ajouter au panier" }
    };
  }
  return { success: true };
};

// Validation de l'existence d'une option sélectionnée
export const validateSelectedOption = (options: any[], selectedSize: string) => {
  const selectedOption = options.find(opt => opt.name === selectedSize);
  if (!selectedOption) {
    return {
      success: false,
      error: { message: "Option sélectionnée invalide" }
    };
  }
  return { success: true, data: selectedOption };
};