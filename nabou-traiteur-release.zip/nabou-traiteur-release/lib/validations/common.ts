import { z } from "zod";

// Schéma pour la pagination
export const PaginationSchema = z.object({
  page: z
    .string()
    .optional()
    .default("1")
    .transform((val) => parseInt(val, 10))
    .refine((val) => val >= 1, "La page doit être supérieure ou égale à 1"),
  limit: z
    .string()
    .optional()
    .default("10")
    .transform((val) => parseInt(val, 10))
    .refine(
      (val) => val >= 1 && val <= 100,
      "La limite doit être entre 1 et 100"
    ),
  search: z
    .string()
    .optional()
    .transform((val) => val?.trim() || undefined),
});

// Schéma pour les paramètres d'ID
export const IdParamSchema = z.object({
  id: z
    .string()
    .min(1, "L'ID est requis")
    .regex(/^[a-zA-Z0-9_-]+$/, "Format d'ID invalide"),
});

// Schéma pour les paramètres UUID
export const UuidParamSchema = z.object({
  id: z
    .string()
    .uuid("Format UUID invalide"),
});

// Schéma pour les filtres de date
export const DateRangeSchema = z.object({
  startDate: z
    .string()
    .optional()
    .refine(
      (val) => !val || !isNaN(Date.parse(val)),
      "Format de date invalide"
    )
    .transform((val) => val ? new Date(val) : undefined),
  endDate: z
    .string()
    .optional()
    .refine(
      (val) => !val || !isNaN(Date.parse(val)),
      "Format de date invalide"
    )
    .transform((val) => val ? new Date(val) : undefined),
}).refine(
  (data) => {
    if (data.startDate && data.endDate) {
      return data.startDate <= data.endDate;
    }
    return true;
  },
  {
    message: "La date de début doit être antérieure à la date de fin",
    path: ["startDate"],
  }
);

// Schéma pour les filtres de statut
export const StatusFilterSchema = z.object({
  status: z
    .string()
    .optional()
    .transform((val) => val?.trim() || undefined),
});

// Schéma pour les filtres booléens
export const BooleanFilterSchema = z.object({
  isActive: z
    .string()
    .optional()
    .transform((val) => {
      if (!val) return undefined;
      return val.toLowerCase() === "true";
    }),
});

// Schéma pour le tri
export const SortSchema = z.object({
  sortBy: z
    .string()
    .optional()
    .default("createdAt")
    .transform((val) => val.trim()),
  sortOrder: z
    .enum(["asc", "desc"])
    .optional()
    .default("desc"),
});

// Schéma combiné pour les requêtes de liste
export const ListQuerySchema = PaginationSchema.merge(SortSchema).merge(
  z.object({
    search: z
      .string()
      .optional()
      .transform((val) => val?.trim() || undefined),
  })
);

// Schéma pour les coordonnées géographiques
export const CoordinatesSchema = z.object({
  latitude: z
    .number()
    .min(-90, "La latitude doit être entre -90 et 90")
    .max(90, "La latitude doit être entre -90 et 90"),
  longitude: z
    .number()
    .min(-180, "La longitude doit être entre -180 et 180")
    .max(180, "La longitude doit être entre -180 et 180"),
});

// Schéma pour les adresses
export const AddressSchema = z.object({
  street: z
    .string()
    .min(1, "La rue est requise")
    .max(200, "La rue ne peut pas dépasser 200 caractères"),
  city: z
    .string()
    .min(1, "La ville est requise")
    .max(100, "La ville ne peut pas dépasser 100 caractères"),
  postalCode: z
    .string()
    .optional()
    .transform((val) => val?.trim() || undefined),
  country: z
    .string()
    .min(1, "Le pays est requis")
    .max(100, "Le pays ne peut pas dépasser 100 caractères")
    .default("Sénégal"),
  coordinates: CoordinatesSchema.optional(),
});

// Types inférés
export type PaginationQuery = z.infer<typeof PaginationSchema>;
export type IdParam = z.infer<typeof IdParamSchema>;
export type UuidParam = z.infer<typeof UuidParamSchema>;
export type DateRangeFilter = z.infer<typeof DateRangeSchema>;
export type StatusFilter = z.infer<typeof StatusFilterSchema>;
export type BooleanFilter = z.infer<typeof BooleanFilterSchema>;
export type SortQuery = z.infer<typeof SortSchema>;
export type ListQuery = z.infer<typeof ListQuerySchema>;
export type Coordinates = z.infer<typeof CoordinatesSchema>;
export type Address = z.infer<typeof AddressSchema>;