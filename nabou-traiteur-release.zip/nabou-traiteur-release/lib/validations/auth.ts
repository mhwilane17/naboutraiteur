import { z } from "zod";

// Fonction utilitaire pour nettoyer les chaînes
const sanitizeString = (str: string) => {
  return str.trim().replace(/[<>"'&]/g, "");
};

// Schéma pour la connexion
export const LoginSchema = z.object({
  email: z
    .string()
    .min(1, "L'email est requis")
    .email("Format d'email invalide")
    .toLowerCase()
    .transform(sanitizeString),
  password: z
    .string()
    .min(1, "Le mot de passe est requis")
    .min(6, "Le mot de passe doit contenir au moins 6 caractères"),
  rememberMe: z.boolean().optional().default(false)
});

// Schéma pour l'inscription
export const RegisterSchema = z.object({
  name: z
    .string()
    .min(2, "Le nom doit contenir au moins 2 caractères")
    .max(100, "Le nom ne peut pas dépasser 100 caractères")
    .transform(sanitizeString),
  email: z
    .string()
    .min(1, "L'email est requis")
    .email("Format d'email invalide")
    .toLowerCase()
    .transform(sanitizeString),
  password: z
    .string()
    .min(8, "Le mot de passe doit contenir au moins 8 caractères")
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
      "Le mot de passe doit contenir au moins une minuscule, une majuscule et un chiffre"
    ),
  phone: z
    .string()
    .regex(/^[+]?[0-9\s\-()]+$/, "Format de téléphone invalide")
    .optional()
    .transform((val) => val ? sanitizeString(val) : undefined),
});

// Schéma pour la mise à jour du profil
export const UpdateProfileSchema = z.object({
  name: z
    .string()
    .min(2, "Le nom doit contenir au moins 2 caractères")
    .max(100, "Le nom ne peut pas dépasser 100 caractères")
    .transform(sanitizeString)
    .optional(),
  phone: z
    .string()
    .regex(/^[+]?[0-9\s\-()]+$/, "Format de téléphone invalide")
    .optional()
    .transform((val) => val ? sanitizeString(val) : undefined),
  currentPassword: z
    .string()
    .min(1, "Le mot de passe actuel est requis")
    .optional(),
  newPassword: z
    .string()
    .min(8, "Le nouveau mot de passe doit contenir au moins 8 caractères")
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
      "Le mot de passe doit contenir au moins une minuscule, une majuscule et un chiffre"
    )
    .optional(),
}).refine(
  (data) => {
    // Si un nouveau mot de passe est fourni, l'ancien est requis
    if (data.newPassword && !data.currentPassword) {
      return false;
    }
    return true;
  },
  {
    message: "Le mot de passe actuel est requis pour changer le mot de passe",
    path: ["currentPassword"],
  }
);

// Schéma pour la réinitialisation de mot de passe
export const ResetPasswordSchema = z.object({
  email: z
    .string()
    .min(1, "L'email est requis")
    .email("Format d'email invalide")
    .toLowerCase()
    .transform(sanitizeString),
});

// Schéma pour confirmer la réinitialisation de mot de passe
export const ConfirmResetPasswordSchema = z.object({
  token: z.string().min(1, "Le token est requis"),
  password: z
    .string()
    .min(8, "Le mot de passe doit contenir au moins 8 caractères")
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
      "Le mot de passe doit contenir au moins une minuscule, une majuscule et un chiffre"
    ),
});

// Types inférés des schémas
export type LoginRequest = z.infer<typeof LoginSchema>;
export type RegisterRequest = z.infer<typeof RegisterSchema>;
export type UpdateProfileRequest = z.infer<typeof UpdateProfileSchema>;
export type ResetPasswordRequest = z.infer<typeof ResetPasswordSchema>;
export type ConfirmResetPasswordRequest = z.infer<typeof ConfirmResetPasswordSchema>;