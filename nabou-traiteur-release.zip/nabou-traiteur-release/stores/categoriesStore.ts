import { create } from 'zustand';
import { Category, CategoryFormData, ApiResponse, ApiError } from '@/types/categories';

interface CategoriesState {
  // État des catégories
  categories: Category[];
  loading: boolean;
  error: string | null;
  
  // État des dialogs
  isAddDialogOpen: boolean;
  isEditDialogOpen: boolean;
  isViewDialogOpen: boolean;
  isDeleteDialogOpen: boolean;
  
  // Catégorie sélectionnée
  selectedCategory: Category | null;
  
  // Données du formulaire
  formData: CategoryFormData;
  
  // Actions pour les catégories (API)
  fetchCategories: () => Promise<void>;
  fetchCategory: (id: string) => Promise<Category | null>;
  createCategory: (categoryData: CategoryFormData) => Promise<boolean>;
  updateCategory: (id: string, updates: Partial<CategoryFormData>) => Promise<boolean>;
  deleteCategory: (id: string) => Promise<boolean>;
  
  // Actions pour les dialogs
  openAddDialog: () => void;
  openEditDialog: (category: Category) => void;
  openViewDialog: (category: Category) => void;
  openDeleteDialog: (category: Category) => void;
  closeAllDialogs: () => void;
  
  // Actions pour le formulaire
  setFormData: (data: Partial<CategoryFormData>) => void;
  resetForm: () => void;
  
  // Actions utilitaires
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
}

const initialFormData: CategoryFormData = {
  name: '',
  description: '',
  color: 'blue',
  icon: 'utensils',
  isActive: true,
  sortOrder: 0,
};

export const useCategoriesStore = create<CategoriesState>((set, get) => ({
  // État initial
  categories: [],
  loading: false,
  error: null,
  isAddDialogOpen: false,
  isEditDialogOpen: false,
  isViewDialogOpen: false,
  isDeleteDialogOpen: false,
  selectedCategory: null,
  formData: initialFormData,

  // Actions utilitaires
  setLoading: (loading: boolean) => set({ loading }),
  setError: (error: string | null) => set({ error }),

  // Actions API pour les catégories
  fetchCategories: async () => {
    set({ loading: true, error: null });
    try {
      const response = await fetch('/api/menu/categories');
      const result: ApiResponse<Category[]> = await response.json();
      
      if (result.success) {
        set({ categories: result.data, loading: false });
      } else {
        set({ error: 'Erreur lors du chargement des catégories', loading: false });
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
    }
  },

  fetchCategory: async (id: string): Promise<Category | null> => {
    set({ loading: true, error: null });
    try {
      const response = await fetch(`/api/menu/categories/${id}`);
      const result: ApiResponse<Category> = await response.json();
      
      if (result.success) {
        set({ loading: false });
        return result.data;
      } else {
        set({ error: 'Catégorie non trouvée', loading: false });
        return null;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      return null;
    }
  },

  createCategory: async (categoryData: CategoryFormData): Promise<boolean> => {
    set({ loading: true, error: null });
    try {
      const response = await fetch('/api/menu/categories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(categoryData),
      });
      
      const result: ApiResponse<Category> = await response.json();
      
      if (result.success) {
        // Recharger les catégories après création
        await get().fetchCategories();
        set({ loading: false });
        return true;
      } else {
        set({ error: result.message || 'Erreur lors de la création', loading: false });
        return false;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      return false;
    }
  },

  updateCategory: async (id: string, updates: Partial<CategoryFormData>): Promise<boolean> => {
    set({ loading: true, error: null });
    try {
      const response = await fetch(`/api/menu/categories/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updates),
      });
      
      const result: ApiResponse<Category> = await response.json();
      
      if (result.success) {
        // Recharger les catégories après mise à jour
        await get().fetchCategories();
        set({ loading: false });
        return true;
      } else {
        set({ error: result.message || 'Erreur lors de la mise à jour', loading: false });
        return false;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      return false;
    }
  },

  deleteCategory: async (id: string): Promise<boolean> => {
    set({ loading: true, error: null });
    try {
      const response = await fetch(`/api/menu/categories/${id}`, {
        method: 'DELETE',
      });
      
      const result: ApiResponse<{ message: string }> = await response.json();
      
      if (result.success) {
        // Recharger les catégories après suppression
        await get().fetchCategories();
        set({ loading: false });
        return true;
      } else {
        set({ error: result.message || 'Erreur lors de la suppression', loading: false });
        return false;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      return false;
    }
  },

  // Actions pour les dialogs
  openAddDialog: () => {
    set({
      isAddDialogOpen: true,
      formData: initialFormData,
    });
  },

  openEditDialog: (category: Category) => {
    set({
      isEditDialogOpen: true,
      selectedCategory: category,
      formData: {
        id: category.id,
        name: category.name,
        description: category.description || '',
        color: category.color,
        icon: category.icon,
        isActive: category.isActive,
        sortOrder: category.sortOrder,
      },
    });
  },

  openViewDialog: (category: Category) => {
    set({
      isViewDialogOpen: true,
      selectedCategory: category,
    });
  },

  openDeleteDialog: (category: Category) => {
    set({
      isDeleteDialogOpen: true,
      selectedCategory: category,
    });
  },

  closeAllDialogs: () => {
    set({
      isAddDialogOpen: false,
      isEditDialogOpen: false,
      isViewDialogOpen: false,
      isDeleteDialogOpen: false,
      selectedCategory: null,
    });
  },

  // Actions pour le formulaire
  setFormData: (data: Partial<CategoryFormData>) => {
    set((state) => ({ formData: { ...state.formData, ...data } }));
  },

  resetForm: () => {
    set({ formData: initialFormData });
  },
}));