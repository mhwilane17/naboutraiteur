import { create } from "zustand";
import { toast } from "sonner";
import {
  WeeklyMenu,
  WeeklyMenuDish,
  CreateWeeklyMenuData,
  UpdateWeeklyMenuData,
  WeeklyMenuState,
  WeeklyMenuActions,
  WeeklyMenuStore,
} from "@/types/weeklyMenu";

export const useWeeklyMenuStore = create<WeeklyMenuStore>((set, get) => ({
  // État initial
  weeklyMenus: [],
  loading: false,
  error: null,
  pagination: null,

  // Actions
  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),
  setWeeklyMenus: (weeklyMenus) => set({ weeklyMenus }),
  setPagination: (pagination) => set({ pagination }),

  fetchWeeklyMenus: async (params = {}) => {
    try {
      set({ loading: true, error: null });

      const searchParams = new URLSearchParams();

      if (params.page) searchParams.append("page", params.page.toString());
      if (params.limit) searchParams.append("limit", params.limit.toString());
      if (params.search) searchParams.append("search", params.search);
      if (params.isActive !== undefined)
        searchParams.append("isActive", params.isActive.toString());
      if (params.isPublished !== undefined)
        searchParams.append("isPublished", params.isPublished.toString());
      if (params.startDate) searchParams.append("startDate", params.startDate);
      if (params.endDate) searchParams.append("endDate", params.endDate);
      if (params.sortBy) searchParams.append("sortBy", params.sortBy);
      if (params.sortOrder) searchParams.append("sortOrder", params.sortOrder);
      if (params.includeDishes !== undefined)
        searchParams.append("includeDishes", params.includeDishes.toString());
      if (params.includeStats !== undefined)
        searchParams.append("includeStats", params.includeStats.toString());

      const response = await fetch(`/api/menu/weekly?${searchParams.toString()}`);

      const responseData = await response.json();

      if (!response.ok || !responseData.success) {
        // Extraction du message d'erreur spécifique
        let errorMessage = "Erreur lors de la récupération des menus hebdomadaires";

        if (responseData.error) {
          if (typeof responseData.error === "string") {
            errorMessage = responseData.error;
          } else if (responseData.error.message) {
            errorMessage = responseData.error.message;
          }
        } else if (responseData.message) {
          errorMessage = responseData.message;
        }

        throw new Error(errorMessage);
      }

      set({
        weeklyMenus: responseData.data.weeklyMenus,
        pagination: responseData.data.pagination,
      });
      return responseData.data;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Une erreur est survenue";
      set({ error: errorMessage });
      // Suppression du toast d'erreur pour laisser le composant gérer l'affichage
      return Promise.reject(error);
    } finally {
      set({ loading: false });
    }
  },

  createWeeklyMenu: async (data) => {
    try {
      set({ loading: true, error: null });

      const response = await fetch("/api/menu/weekly", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      const responseData = await response.json();

      if (!response.ok || !responseData.success) {
        // Extraction du message d'erreur spécifique
        let errorMessage = "Erreur lors de la création du menu hebdomadaire";

        if (responseData.error) {
          if (typeof responseData.error === "string") {
            errorMessage = responseData.error;
          } else if (responseData.error.message) {
            errorMessage = responseData.error.message;
          }
        } else if (responseData.message) {
          errorMessage = responseData.message;
        }

        throw new Error(errorMessage);
      }

      const newWeeklyMenu = responseData.data;

      // Ajouter le nouveau menu à la liste
      set((state) => ({
        weeklyMenus: [newWeeklyMenu, ...state.weeklyMenus],
      }));

      return newWeeklyMenu;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Une erreur est survenue";
      set({ error: errorMessage });
      // Suppression du toast d'erreur pour laisser le composant gérer l'affichage
      return Promise.reject(error);
    } finally {
      set({ loading: false });
    }
  },

  updateWeeklyMenu: async (data) => {
    try {
      set({ loading: true, error: null });

      const { id, ...updateData } = data;

      const response = await fetch(`/api/menu/weekly/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updateData),
      });

      const responseData = await response.json();

      if (!response.ok || !responseData.success) {
        // Extraction du message d'erreur spécifique
        let errorMessage = "Erreur lors de la mise à jour du menu hebdomadaire";

        if (responseData.error) {
          if (typeof responseData.error === "string") {
            errorMessage = responseData.error;
          } else if (responseData.error.message) {
            errorMessage = responseData.error.message;
          }
        } else if (responseData.message) {
          errorMessage = responseData.message;
        }

        throw new Error(errorMessage);
      }

      const updatedWeeklyMenu = responseData.data;

      // Mettre à jour le menu dans la liste
      set((state) => ({
        weeklyMenus: state.weeklyMenus.map((menu) => (menu.id === id ? updatedWeeklyMenu : menu)),
      }));

      return updatedWeeklyMenu;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Une erreur est survenue";
      set({ error: errorMessage });
      // Suppression du toast d'erreur pour laisser le composant gérer l'affichage
      return Promise.reject(error);
    } finally {
      set({ loading: false });
    }
  },

  deleteWeeklyMenu: async (id) => {
    try {
      set({ loading: true, error: null });

      const response = await fetch(`/api/menu/weekly/${id}`, {
        method: "DELETE",
      });

      const responseData = await response.json();

      if (!response.ok || !responseData.success) {
        // Extraction du message d'erreur spécifique
        let errorMessage = "Erreur lors de la suppression du menu hebdomadaire";

        if (responseData.error) {
          if (typeof responseData.error === "string") {
            errorMessage = responseData.error;
          } else if (responseData.error.message) {
            errorMessage = responseData.error.message;
          }
        } else if (responseData.message) {
          errorMessage = responseData.message;
        }

        throw new Error(errorMessage);
      }

      // Supprimer le menu de la liste
      set((state) => ({
        weeklyMenus: state.weeklyMenus.filter((menu) => menu.id !== id),
      }));

      return true;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Une erreur est survenue";
      set({ error: errorMessage });
      // Suppression du toast d'erreur pour laisser le composant gérer l'affichage
      return Promise.reject(error);
    } finally {
      set({ loading: false });
    }
  },

  refreshWeeklyMenus: async () => {
    const { fetchWeeklyMenus } = get();
    await fetchWeeklyMenus();
  },
}));
