import { create } from 'zustand';
import { 
  User, 
  Role, 
  UserFormData, 
  UserFilters, 
  UserStats, 
  CreateUserRequest, 
  UpdateUserRequest,
  UsersApiResponse,
  RolesApiResponse,
  UserStatus,
  UserErrorMessages
} from '@/types/users';
import { UserService } from '@/services/userService';

interface UsersState {
  // État des données
  users: User[];
  roles: Role[];
  loading: boolean;
  error: string | null;
  
  // États de chargement granulaires
  operationLoading: {
    create: boolean;
    update: boolean;
    delete: boolean;
    suspend: boolean;
    reactivate: boolean;
    fetchUsers: boolean;
    fetchRoles: boolean;
    fetchStats: boolean;
  };
  
  // État des statistiques
  stats: UserStats;
  statsLoading: boolean;
  
  // État de pagination
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
  
  // État des filtres
  filters: UserFilters;
  
  // État des dialogs
  isAddDialogOpen: boolean;
  isEditDialogOpen: boolean;
  isViewDialogOpen: boolean;
  isDeleteDialogOpen: boolean;
  
  // Utilisateur sélectionné
  selectedUser: User | null;
  
  // Données du formulaire
  formData: UserFormData;
  
  // Debouncing state
  searchTimeout: NodeJS.Timeout | null;
  
  // Cleanup method
  cleanup: () => void;
  
  // Actions API
  fetchUsers: (page?: number, limit?: number) => Promise<void>;
  fetchRoles: () => Promise<void>;
  fetchStats: () => Promise<void>;
  createUser: (userData: CreateUserRequest) => Promise<boolean>;
  updateUser: (id: string, updates: UpdateUserRequest) => Promise<boolean>;
  deleteUser: (id: string) => Promise<boolean>;
  suspendUser: (id: string) => Promise<boolean>;
  reactivateUser: (id: string) => Promise<boolean>;
  
  // Pagination actions
  goToPage: (page: number) => Promise<void>;
  goToNextPage: () => Promise<void>;
  goToPreviousPage: () => Promise<void>;
  goToFirstPage: () => Promise<void>;
  goToLastPage: () => Promise<void>;
  setPageSize: (limit: number) => Promise<void>;
  
  // Actions UI
  openAddDialog: () => void;
  openEditDialog: (user: User) => void;
  openViewDialog: (user: User) => void;
  openDeleteDialog: (user: User) => void;
  closeAllDialogs: () => void;
  
  // Actions de filtrage
  setFilters: (filters: Partial<UserFilters>) => void;
  setSearchFilter: (search: string) => void;
  setImmediateFilter: (filters: Partial<UserFilters>) => void;
  clearFilters: () => void;
  
  // Actions utilitaires
  setFormData: (data: Partial<UserFormData>) => void;
  resetForm: () => void;
  getStats: () => UserStats;
  getFilteredUsers: () => User[];
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  setStatsLoading: (loading: boolean) => void;
  setOperationLoading: (operation: keyof UsersState['operationLoading'], loading: boolean) => void;
}

const initialFormData: UserFormData = {
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  address: '',
  city: '',
  postalCode: '',
  isActive: true,
  roleIds: ['CUSTOMER'],
};

const initialFilters: UserFilters = {
  search: '',
  role: '',
  status: UserStatus.ALL,
};

const initialPagination = {
  page: 1,
  limit: 10,
  total: 0,
  totalPages: 0,
};

const initialStats: UserStats = {
  total: 0,
  active: 0,
  admins: 0,
  suspended: 0,
};

const initialOperationLoading = {
  create: false,
  update: false,
  delete: false,
  suspend: false,
  reactivate: false,
  fetchUsers: false,
  fetchRoles: false,
  fetchStats: false,
};

export const useUsersStore = create<UsersState>((set, get) => ({
  // État initial
  users: [],
  roles: [],
  loading: false,
  error: null,
  operationLoading: initialOperationLoading,
  stats: initialStats,
  statsLoading: false,
  pagination: initialPagination,
  filters: initialFilters,
  isAddDialogOpen: false,
  isEditDialogOpen: false,
  isViewDialogOpen: false,
  isDeleteDialogOpen: false,
  selectedUser: null,
  formData: initialFormData,
  searchTimeout: null,

  // Cleanup method
  cleanup: () => {
    const state = get();
    if (state.searchTimeout) {
      clearTimeout(state.searchTimeout);
      set({ searchTimeout: null });
    }
  },

  // Actions utilitaires
  setLoading: (loading: boolean) => set({ loading }),
  setError: (error: string | null) => set({ error }),
  setStatsLoading: (loading: boolean) => set({ statsLoading: loading }),
  setOperationLoading: (operation: keyof UsersState['operationLoading'], loading: boolean) => {
    set((state) => ({
      operationLoading: {
        ...state.operationLoading,
        [operation]: loading,
      },
    }));
  },

  // Actions API
  fetchUsers: async (page = 1, limit = 100) => {
    get().setOperationLoading('fetchUsers', true);
    set({ loading: true, error: null });
    try {
      const { filters } = get();
      const params = {
        page,
        limit,
        search: filters.search || undefined,
        role: filters.role || undefined,
        status: filters.status !== UserStatus.ALL ? filters.status : undefined,
      };

      const response = await UserService.getUsers(params);
      
      if (UserService.isErrorResponse(response)) {
        const errorMessage = UserErrorMessages[response.error.code as keyof typeof UserErrorMessages] 
          || response.error.message 
          || 'Erreur lors du chargement des utilisateurs';
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('fetchUsers', false);
      } else {
        const usersResponse = response as UsersApiResponse;
        set({ 
          users: usersResponse.data, 
          pagination: usersResponse.pagination,
          loading: false 
        });
        get().setOperationLoading('fetchUsers', false);
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('fetchUsers', false);
    }
  },

  fetchRoles: async () => {
    // Don't set loading to true if roles are already loaded to avoid UI flicker
    const currentState = get();
    get().setOperationLoading('fetchRoles', true);
    if (currentState.roles.length === 0) {
      set({ loading: true, error: null });
    }
    
    try {
      const response = await UserService.getRoles();
      
      if (UserService.isErrorResponse(response)) {
        const errorMessage = response.error.message || 'Erreur lors du chargement des rôles';
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('fetchRoles', false);
      } else {
        const rolesResponse = response as RolesApiResponse;
        set({ roles: rolesResponse.data, loading: false });
        get().setOperationLoading('fetchRoles', false);
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('fetchRoles', false);
    }
  },

  fetchStats: async () => {
    get().setOperationLoading('fetchStats', true);
    set({ statsLoading: true, error: null });
    try {
      const response = await UserService.getUserStats();
      
      if (UserService.isErrorResponse(response)) {
        const errorMessage = response.error.message || 'Erreur lors du chargement des statistiques';
        set({ error: errorMessage, statsLoading: false });
        get().setOperationLoading('fetchStats', false);
      } else {
        set({ stats: response.data, statsLoading: false });
        get().setOperationLoading('fetchStats', false);
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', statsLoading: false });
      get().setOperationLoading('fetchStats', false);
    }
  },

  createUser: async (userData: CreateUserRequest): Promise<boolean> => {
    get().setOperationLoading('create', true);
    set({ loading: true, error: null });
    try {
      // Ensure roles are loaded to find default client role
      const state = get();
      if (state.roles.length === 0) {
        await get().fetchRoles();
      }

      // If no roles specified, assign default "client" role
      let finalUserData = { ...userData };
      if (!userData.roleIds || userData.roleIds.length === 0) {
        const updatedState = get();
        const clientRole = updatedState.roles.find(role => 
          role.name.toLowerCase() === 'client' || role.id === 'client'
        );
        if (clientRole) {
          finalUserData.roleIds = [clientRole.id];
        }
      }

      const response = await UserService.createUser(finalUserData);
      
      if (UserService.isErrorResponse(response)) {
        const errorMessage = UserErrorMessages[response.error.code as keyof typeof UserErrorMessages] 
          || response.error.message 
          || 'Erreur lors de la création de l\'utilisateur';
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('create', false);
        return false;
      } else {
        // Recharger les utilisateurs et les statistiques après création
        // Reset to first page to show the new user
        await Promise.all([
          get().fetchUsers(1, get().pagination.limit),
          get().fetchStats()
        ]);
        set({ loading: false });
        get().setOperationLoading('create', false);
        return true;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('create', false);
      return false;
    }
  },

  updateUser: async (id: string, updates: UpdateUserRequest): Promise<boolean> => {
    get().setOperationLoading('update', true);
    set({ loading: true, error: null });
    try {
      const response = await UserService.updateUser(id, updates);
      
      if (UserService.isErrorResponse(response)) {
        const errorMessage = UserErrorMessages[response.error.code as keyof typeof UserErrorMessages] 
          || response.error.message 
          || 'Erreur lors de la mise à jour de l\'utilisateur';
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('update', false);
        return false;
      } else {
        // Recharger les utilisateurs et les statistiques après mise à jour
        await Promise.all([
          get().fetchUsers(get().pagination.page, get().pagination.limit),
          get().fetchStats()
        ]);
        set({ loading: false });
        get().setOperationLoading('update', false);
        return true;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('update', false);
      return false;
    }
  },

  deleteUser: async (id: string): Promise<boolean> => {
    get().setOperationLoading('delete', true);
    set({ loading: true, error: null });
    try {
      const response = await UserService.deleteUser(id);
      
      if (UserService.isErrorResponse(response)) {
        const errorMessage = UserErrorMessages[response.error.code as keyof typeof UserErrorMessages] 
          || response.error.message 
          || 'Erreur lors de la suppression de l\'utilisateur';
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('delete', false);
        return false;
      } else {
        // Recharger les utilisateurs et les statistiques après suppression
        const currentPagination = get().pagination;
        let targetPage = currentPagination.page;
        
        // If we're on the last page and it might become empty, go to previous page
        if (currentPagination.page > 1 && 
            currentPagination.total > 0 && 
            (currentPagination.total - 1) <= (currentPagination.page - 1) * currentPagination.limit) {
          targetPage = currentPagination.page - 1;
        }
        
        await Promise.all([
          get().fetchUsers(targetPage, currentPagination.limit),
          get().fetchStats()
        ]);
        set({ loading: false });
        get().setOperationLoading('delete', false);
        return true;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('delete', false);
      return false;
    }
  },

  suspendUser: async (id: string): Promise<boolean> => {
    get().setOperationLoading('suspend', true);
    set({ loading: true, error: null });
    try {
      const response = await UserService.suspendUser(id);
      
      if (UserService.isErrorResponse(response)) {
        const errorMessage = UserErrorMessages[response.error.code as keyof typeof UserErrorMessages] 
          || response.error.message 
          || 'Erreur lors de la suspension de l\'utilisateur';
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('suspend', false);
        return false;
      } else {
        // Recharger les utilisateurs et les statistiques après suspension
        await Promise.all([
          get().fetchUsers(get().pagination.page, get().pagination.limit),
          get().fetchStats()
        ]);
        set({ loading: false });
        get().setOperationLoading('suspend', false);
        return true;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('suspend', false);
      return false;
    }
  },

  reactivateUser: async (id: string): Promise<boolean> => {
    get().setOperationLoading('reactivate', true);
    set({ loading: true, error: null });
    try {
      const response = await UserService.reactivateUser(id);
      
      if (UserService.isErrorResponse(response)) {
        const errorMessage = UserErrorMessages[response.error.code as keyof typeof UserErrorMessages] 
          || response.error.message 
          || 'Erreur lors de la réactivation de l\'utilisateur';
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('reactivate', false);
        return false;
      } else {
        // Recharger les utilisateurs et les statistiques après réactivation
        await Promise.all([
          get().fetchUsers(get().pagination.page, get().pagination.limit),
          get().fetchStats()
        ]);
        set({ loading: false });
        get().setOperationLoading('reactivate', false);
        return true;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('reactivate', false);
      return false;
    }
  },

  // Actions pour les dialogs
  openAddDialog: () => {
    set({
      isAddDialogOpen: true,
      formData: initialFormData,
    });
    
    // Ensure roles are loaded when opening add dialog
    const state = get();
    if (state.roles.length === 0) {
      get().fetchRoles();
    }
  },

  openEditDialog: (user: User) => {
    set({
      isEditDialogOpen: true,
      selectedUser: user,
      formData: {
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        phone: user.phone || '',
        address: user.address || '',
        city: user.city || '',
        postalCode: user.postalCode || '',
        isActive: user.isActive,
        roleIds: user.roles.map(role => role.id),
      },
    });
  },

  openViewDialog: (user: User) => {
    set({
      isViewDialogOpen: true,
      selectedUser: user,
    });
  },

  openDeleteDialog: (user: User) => {
    set({
      isDeleteDialogOpen: true,
      selectedUser: user,
    });
  },

  closeAllDialogs: () => {
    set({
      isAddDialogOpen: false,
      isEditDialogOpen: false,
      isViewDialogOpen: false,
      isDeleteDialogOpen: false,
      selectedUser: null,
    });
  },

  // Actions de filtrage
  setFilters: (newFilters: Partial<UserFilters>) => {
    const state = get();
    
    // Clear existing search timeout if setting search filter
    if (newFilters.search !== undefined && state.searchTimeout) {
      clearTimeout(state.searchTimeout);
    }
    
    set((state) => ({ 
      filters: { ...state.filters, ...newFilters },
      pagination: { ...state.pagination, page: 1 }, // Reset to first page when filtering
      searchTimeout: null
    }));
    
    // If search filter is being set, use debouncing
    if (newFilters.search !== undefined) {
      const timeout = setTimeout(() => {
        get().fetchUsers(1, get().pagination.limit);
      }, 300); // 300ms debounce delay
      
      set({ searchTimeout: timeout });
    } else {
      // For non-search filters, fetch immediately
      get().fetchUsers(1, get().pagination.limit);
    }
  },

  setSearchFilter: (search: string) => {
    const state = get();
    
    // Clear existing timeout
    if (state.searchTimeout) {
      clearTimeout(state.searchTimeout);
    }
    
    // Update search filter immediately for UI responsiveness
    set((state) => ({ 
      filters: { ...state.filters, search },
      pagination: { ...state.pagination, page: 1 }
    }));
    
    // Debounce the API call
    const timeout = setTimeout(() => {
      get().fetchUsers(1, get().pagination.limit);
      set({ searchTimeout: null });
    }, 300); // 300ms debounce delay
    
    set({ searchTimeout: timeout });
  },

  setImmediateFilter: (newFilters: Partial<UserFilters>) => {
    const state = get();
    
    // Clear existing search timeout
    if (state.searchTimeout) {
      clearTimeout(state.searchTimeout);
    }
    
    set((state) => ({ 
      filters: { ...state.filters, ...newFilters },
      pagination: { ...state.pagination, page: 1 },
      searchTimeout: null
    }));
    
    // Fetch immediately without debouncing
    get().fetchUsers(1, get().pagination.limit);
  },

  clearFilters: () => {
    const state = get();
    
    // Clear any pending search timeout
    if (state.searchTimeout) {
      clearTimeout(state.searchTimeout);
    }
    
    set({ 
      filters: initialFilters,
      pagination: { ...get().pagination, page: 1 },
      searchTimeout: null
    });
    
    // Recharger les utilisateurs sans filtres
    get().fetchUsers(1, get().pagination.limit);
  },

  // Actions pour le formulaire
  setFormData: (data: Partial<UserFormData>) => {
    set((state) => ({ formData: { ...state.formData, ...data } }));
  },

  resetForm: () => {
    set({ formData: initialFormData });
  },

  // Pagination actions
  goToPage: async (page: number) => {
    const { pagination } = get();
    if (page >= 1 && page <= pagination.totalPages && page !== pagination.page) {
      await get().fetchUsers(page, pagination.limit);
    }
  },

  goToNextPage: async () => {
    const { pagination } = get();
    if (pagination.page < pagination.totalPages) {
      await get().fetchUsers(pagination.page + 1, pagination.limit);
    }
  },

  goToPreviousPage: async () => {
    const { pagination } = get();
    if (pagination.page > 1) {
      await get().fetchUsers(pagination.page - 1, pagination.limit);
    }
  },

  goToFirstPage: async () => {
    const { pagination } = get();
    if (pagination.page !== 1) {
      await get().fetchUsers(1, pagination.limit);
    }
  },

  goToLastPage: async () => {
    const { pagination } = get();
    if (pagination.page !== pagination.totalPages && pagination.totalPages > 0) {
      await get().fetchUsers(pagination.totalPages, pagination.limit);
    }
  },

  setPageSize: async (limit: number) => {
    const { pagination } = get();
    if (limit !== pagination.limit && limit > 0) {
      // Reset to first page when changing page size
      await get().fetchUsers(1, limit);
    }
  },

  // Actions utilitaires
  getStats: (): UserStats => {
    const { stats } = get();
    return stats;
  },

  getFilteredUsers: (): User[] => {
    const { users, filters } = get();
    
    if (!users.length) return [];
    
    return users.filter(user => {
      // Filtre de recherche (nom, prénom, email, téléphone)
      if (filters.search && filters.search.trim()) {
        const searchTerm = filters.search.toLowerCase().trim();
        const matchesSearch = 
          user.firstName.toLowerCase().includes(searchTerm) ||
          user.lastName.toLowerCase().includes(searchTerm) ||
          user.email.toLowerCase().includes(searchTerm) ||
          (user.phone && user.phone.toLowerCase().includes(searchTerm));
        if (!matchesSearch) return false;
      }
      
      // Filtre par rôle
      if (filters.role && filters.role.trim()) {
        const hasRole = user.roles.some(role => role.id === filters.role);
        if (!hasRole) return false;
      }
      
      // Filtre par statut
      if (filters.status && filters.status !== UserStatus.ALL) {
        if (filters.status === UserStatus.ACTIVE && !user.isActive) return false;
        if (filters.status === UserStatus.SUSPENDED && user.isActive) return false;
      }
      
      return true;
    });
  },
}));