import { create } from "zustand";

// Types
export interface Promo {
  id: string;
  name: string;
  description?: string;
  code: string;
  type: "percentage" | "fixed_amount" | "free_delivery";
  value: number;
  minOrderAmount?: number;
  minOrderItem?: number;
  maxDiscountAmount?: number;
  usageLimit?: number;
  usagePerUser?: number;
  startDate: string;
  endDate: string;
  isActive: boolean;
  activeStartTime?: string; // HH:mm
  activeEndTime?: string; // HH:mm
  applicableCategories: string[];
  applicableMenuItems: string[];
  createdAt: string;
  updatedAt: string;
}

export interface PromoFormData extends Partial<Promo> {}

// Types de promotion disponibles
export const promoTypes = [
  { value: "percentage", label: "Pourcentage (%)" },
  { value: "fixed_amount", label: "Montant fixe (FCFA)" },
  { value: "free_delivery", label: "Livraison gratuite" },
];

interface PromotionsState {
  promos: Promo[];
  searchTerm: string;
  selectedStatus: string;
  selectedType: string;
  isAddDialogOpen: boolean;
  isEditDialogOpen: boolean;
  isViewDialogOpen: boolean;
  isDeleteDialogOpen: boolean;
  selectedPromo: Promo | null;
  formData: PromoFormData;
  isLoading: boolean;
  error: string | null;

  // Actions
  setSearchTerm: (term: string) => void;
  setSelectedStatus: (status: string) => void;
  setSelectedType: (type: string) => void;
  setIsAddDialogOpen: (isOpen: boolean) => void;
  setIsEditDialogOpen: (isOpen: boolean) => void;
  setIsViewDialogOpen: (isOpen: boolean) => void;
  setIsDeleteDialogOpen: (isOpen: boolean) => void;
  setSelectedPromo: (promo: Promo | null) => void;
  setFormData: (data: PromoFormData) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;

  // API calls
  fetchPromos: () => Promise<void>;
  createPromo: () => Promise<void>;
  updatePromo: () => Promise<void>;
  deletePromoById: (id: string) => Promise<void>;

  // Business logic
  addPromo: () => void;
  editPromo: () => void;
  deletePromo: () => void;
  togglePromoStatus: (promoId: string) => void;
  openAddDialog: () => void;
  openEditDialog: (promo: Promo) => void;
  openViewDialog: (promo: Promo) => void;
  openDeleteDialog: (promo: Promo) => void;
  resetForm: () => void;
  formatValue: (promo: Promo) => string;
  isExpired: (endDate: string) => boolean;
  getFilteredPromos: () => Promo[];
  getStats: () => { total: number; active: number; expired: number };
}

export const usePromotionsStore = create<PromotionsState>((set, get) => ({
  promos: [],
  searchTerm: "",
  selectedStatus: "all",
  selectedType: "all",
  isAddDialogOpen: false,
  isEditDialogOpen: false,
  isViewDialogOpen: false,
  isDeleteDialogOpen: false,
  selectedPromo: null,
  isLoading: false,
  error: null,
  formData: {
    name: "",
    description: "",
    code: "",
    type: "percentage" as "percentage" | "fixed_amount" | "free_delivery",
    value: 0,
    minOrderAmount: 0,
    minOrderItem: 0,
    maxDiscountAmount: undefined,
    usageLimit: undefined,
    usagePerUser: undefined,
    startDate: new Date().toISOString().split("T")[0],
    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    isActive: true,
    activeStartTime: undefined,
    activeEndTime: undefined,
    applicableCategories: [],
    applicableMenuItems: [],
  },

  // Setters
  setSearchTerm: (term) => set({ searchTerm: term }),
  setSelectedStatus: (status) => set({ selectedStatus: status }),
  setSelectedType: (type) => set({ selectedType: type }),
  setIsAddDialogOpen: (isOpen) => set({ isAddDialogOpen: isOpen }),
  setIsEditDialogOpen: (isOpen) => set({ isEditDialogOpen: isOpen }),
  setIsViewDialogOpen: (isOpen) => set({ isViewDialogOpen: isOpen }),
  setIsDeleteDialogOpen: (isOpen) => set({ isDeleteDialogOpen: isOpen }),
  setSelectedPromo: (promo) => set({ selectedPromo: promo }),
  setFormData: (data) => set((state) => ({ formData: { ...state.formData, ...data } })),
  setLoading: (loading) => set({ isLoading: loading }),
  setError: (error) => set({ error }),

  // API calls
  fetchPromos: async () => {
    const { setLoading, setError } = get();
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/promotions");
      if (!response.ok) {
        throw new Error("Erreur lors de la récupération des promotions");
      }

      const result = await response.json();
      set({ promos: result.data.data || [] });
    } catch (error) {
      setError(error instanceof Error ? error.message : "Une erreur est survenue");
    } finally {
      setLoading(false);
    }
  },

  createPromo: async () => {
    const { formData, setLoading, setError, fetchPromos } = get();
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/promotions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          startDate: new Date(formData.startDate || "").toISOString(),
          endDate: new Date(formData.endDate || "").toISOString(),
          activeStartTime: formData.activeStartTime || undefined,
          activeEndTime: formData.activeEndTime || undefined,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur lors de la création de la promotion");
      }

      await fetchPromos();
      set({ isAddDialogOpen: false });
      get().resetForm();
    } catch (error) {
      setError(error instanceof Error ? error.message : "Une erreur est survenue");
    } finally {
      setLoading(false);
    }
  },

  updatePromo: async () => {
    const { selectedPromo, formData, setLoading, setError, fetchPromos } = get();
    if (!selectedPromo) return;

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/promotions/${selectedPromo.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          applicableCategories: [], // a definir
          applicableMenuItems: [], // a definir
          startDate: formData.startDate ? new Date(formData.startDate).toISOString() : undefined,
          endDate: formData.endDate ? new Date(formData.endDate).toISOString() : undefined,
          activeStartTime: formData.activeStartTime || undefined,
          activeEndTime: formData.activeEndTime || undefined,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur lors de la mise à jour de la promotion");
      }

      await fetchPromos();
      set({ isEditDialogOpen: false });
      get().resetForm();
    } catch (error) {
      setError(error instanceof Error ? error.message : "Une erreur est survenue");
    } finally {
      setLoading(false);
    }
  },

  deletePromoById: async (id: string) => {
    const { setLoading, setError, fetchPromos } = get();
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/promotions/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Erreur lors de la suppression de la promotion");
      }

      await fetchPromos();
      set({ isDeleteDialogOpen: false, selectedPromo: null });
    } catch (error) {
      setError(error instanceof Error ? error.message : "Une erreur est survenue");
    } finally {
      setLoading(false);
    }
  },

  // Business logic
  addPromo: () => {
    get().createPromo();
  },

  editPromo: () => {
    get().updatePromo();
  },

  deletePromo: () => {
    const { selectedPromo } = get();
    if (!selectedPromo) return;

    get().deletePromoById(selectedPromo.id);
  },

  togglePromoStatus: (promoId) => {
    const { promos } = get();

    const updatedPromos = promos.map((promo) =>
      promo.id === promoId
        ? { ...promo, isActive: !promo.isActive, updatedAt: new Date().toISOString() }
        : promo
    );

    set({ promos: updatedPromos });
  },

  openAddDialog: () => {
    get().resetForm();
    set({ isAddDialogOpen: true });
  },

  openEditDialog: (promo) => {
    set({
      selectedPromo: promo,
      formData: {
        name: promo.name,
        description: promo.description,
        code: promo.code,
        type: promo.type,
        value: Number(promo.value),
        minOrderAmount: Number(promo.minOrderAmount),
        minOrderItem: Number(promo.minOrderItem),
        maxDiscountAmount: Number(promo.maxDiscountAmount),
        usageLimit: Number(promo.usageLimit),
        usagePerUser: Number(promo.usagePerUser),
        startDate: promo.startDate ? new Date(promo.startDate).toISOString().split("T")[0] : "",
        endDate: promo.endDate ? new Date(promo.endDate).toISOString().split("T")[0] : "",
        isActive: promo.isActive,
        activeStartTime: promo.activeStartTime,
        activeEndTime: promo.activeEndTime,
        applicableCategories: promo.applicableCategories,
        applicableMenuItems: promo.applicableMenuItems,
      },
      isEditDialogOpen: true,
    });
  },

  openViewDialog: (promo) => {
    set({ selectedPromo: promo, isViewDialogOpen: true });
  },

  openDeleteDialog: (promo) => {
    set({ selectedPromo: promo, isDeleteDialogOpen: true });
  },

  resetForm: () => {
    set({
      formData: {
        name: "",
        description: "",
        code: "",
        type: "percentage",
        value: 0,
        minOrderAmount: 0,
        minOrderItem: 0,
        usageLimit: undefined,
        usagePerUser: undefined,
        startDate: new Date().toISOString().split("T")[0],
        endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        isActive: true,
        activeStartTime: undefined,
        activeEndTime: undefined,
        applicableCategories: [],
        applicableMenuItems: [],
      },
      selectedPromo: null,
    });
  },

  formatValue: (promo) => {
    if (promo.type === "percentage") {
      return `${promo.value}%`;
    } else if (promo.type === "fixed_amount") {
      return `${promo.value} FCFA`;
    } else if (promo.type === "free_delivery") {
      return "Livraison gratuite";
    }
    return `${promo.value}`;
  },

  isExpired: (endDate) => {
    return new Date(endDate) < new Date();
  },

  getFilteredPromos: () => {
    const { promos, searchTerm, selectedStatus, selectedType } = get();

    return promos.filter((promo) => {
      const matchesSearch =
        promo.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        promo.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (promo.description?.toLowerCase().includes(searchTerm.toLowerCase()) ?? false);

      const matchesStatus =
        selectedStatus === "all" ||
        (selectedStatus === "active" && promo.isActive) ||
        (selectedStatus === "inactive" && !promo.isActive) ||
        (selectedStatus === "expired" && new Date(promo.endDate) < new Date());

      const matchesType = selectedType === "all" || promo.type === selectedType;

      return matchesSearch && matchesStatus && matchesType;
    });
  },

  getStats: () => {
    const { promos } = get();

    return {
      total: promos.length,
      active: promos.filter((p) => p.isActive && new Date(p.endDate) >= new Date()).length,
      expired: promos.filter((p) => new Date(p.endDate) < new Date()).length,
    };
  },
}));
