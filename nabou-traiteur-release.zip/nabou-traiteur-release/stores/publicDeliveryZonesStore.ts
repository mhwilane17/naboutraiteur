import { create } from 'zustand';
import { DeliveryZone } from '../services/deliveryService';
import { ApiSuccessResponse } from '../types/api';

interface PublicDeliveryZonesStore {
  deliveryZones: DeliveryZone[];
  loading: boolean;
  error: string | null;
  lastFetch: number | null;
  cacheExpiry: number;
  
  fetchDeliveryZones: () => Promise<void>;
  refetch: () => Promise<void>;
  clearCache: () => void;
  isDataFresh: () => boolean;
}

// Cache duration: 5 minutes (300000ms)
const CACHE_DURATION = 5 * 60 * 1000;

// Fallback delivery zones in case of API failure
const fallbackDeliveryZones: DeliveryZone[] = [
  {
    id: 'zone-1',
    name: 'Centre-ville',
    description: 'Livraison dans le centre-ville',
    deliveryFee: 2.50,
    minimumOrderAmount: 15.00,
    maximumOrderAmount: 100.00,
    estimatedTime: '30-45 min',
    isActive: true,
    areas: ['Centre', 'Plateau', 'Medina']
  },
  {
    id: 'zone-2',
    name: 'Banlieue proche',
    description: 'Livraison en banlieue proche',
    deliveryFee: 3.50,
    minimumOrderAmount: 20.00,
    maximumOrderAmount: 150.00,
    estimatedTime: '45-60 min',
    isActive: true,
    areas: ['Parcelles Assainies', 'Guediawaye', 'Pikine']
  }
];

export const usePublicDeliveryZonesStore = create<PublicDeliveryZonesStore>((set, get) => ({
  deliveryZones: [],
  loading: false,
  error: null,
  lastFetch: null,
  cacheExpiry: CACHE_DURATION,

  isDataFresh: () => {
    const { lastFetch, cacheExpiry } = get();
    if (!lastFetch) return false;
    return Date.now() - lastFetch < cacheExpiry;
  },

  fetchDeliveryZones: async () => {
    const { isDataFresh, loading } = get();
    
    // If data is fresh or already loading, don't fetch again
    if (isDataFresh() || loading) {
      return;
    }

    set({ loading: true, error: null });
    
    try {
      const response = await fetch('/api/delivery/zones/public');
      
      if (!response.ok) {
        throw new Error(`HTTP Error: ${response.status}`);
      }
      
      const result: ApiSuccessResponse<DeliveryZone[]> = await response.json();
      
      if (!result.success) {
        throw new Error('Failed to fetch delivery zones from API');
      }
      
      set({
        deliveryZones: result.data,
        loading: false,
        error: null,
        lastFetch: Date.now()
      });
      
    } catch (error) {
      console.error('Error fetching public delivery zones:', error);
      
      // Use fallback delivery zones if we don't have any cached data
      const currentDeliveryZones = get().deliveryZones;
      const deliveryZonesToUse = currentDeliveryZones.length > 0 ? currentDeliveryZones : fallbackDeliveryZones;
      
      set({
        deliveryZones: deliveryZonesToUse,
        loading: false,
        error: error instanceof Error ? error.message : 'Failed to fetch delivery zones',
        // Don't update lastFetch on error to allow retry
      });
    }
  },

  refetch: async () => {
    // Force refetch by clearing cache timestamp
    set({ lastFetch: null });
    await get().fetchDeliveryZones();
  },

  clearCache: () => {
    set({
      deliveryZones: [],
      lastFetch: null,
      error: null
    });
  }
}));