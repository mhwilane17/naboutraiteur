import { create } from 'zustand';
import { Category, ApiResponse } from '../types/categories';

interface PublicCategoriesStore {
  categories: Category[];
  loading: boolean;
  error: string | null;
  lastFetch: number | null;
  cacheExpiry: number;
  
  fetchCategories: () => Promise<void>;
  refetch: () => Promise<void>;
  clearCache: () => void;
  isDataFresh: () => boolean;
}

// Cache duration: 5 minutes (300000ms)
const CACHE_DURATION = 5 * 60 * 1000;

// Fallback categories in case of API failure
const fallbackCategories: Category[] = [
  {
    id: 'plat',
    name: 'Plats',
    description: 'Plats principaux traditionnels',
    color: 'orange',
    icon: 'utensils',
    isActive: true,
    sortOrder: 1,
    createdAt: '',
    updatedAt: ''
  },
  {
    id: 'diet',
    name: 'Diet',
    description: 'Plats équilibrés et healthy',
    color: 'green',
    icon: 'carrot',
    isActive: true,
    sortOrder: 2,
    createdAt: '',
    updatedAt: ''
  },
  {
    id: 'salade',
    name: 'Salades',
    description: 'Salades fraîches et variées',
    color: 'green',
    icon: 'carrot',
    isActive: true,
    sortOrder: 3,
    createdAt: '',
    updatedAt: ''
  },
  {
    id: 'fast-food',
    name: 'Fast Food',
    description: 'Restauration rapide',
    color: 'red',
    icon: 'pizza',
    isActive: true,
    sortOrder: 4,
    createdAt: '',
    updatedAt: ''
  },
  {
    id: 'dessert',
    name: 'Desserts',
    description: 'Douceurs et desserts',
    color: 'pink',
    icon: 'cake',
    isActive: true,
    sortOrder: 5,
    createdAt: '',
    updatedAt: ''
  },
  {
    id: 'boisson',
    name: 'Boissons',
    description: 'Boissons traditionnelles et modernes',
    color: 'blue',
    icon: 'wine',
    isActive: true,
    sortOrder: 6,
    createdAt: '',
    updatedAt: ''
  }
];

export const usePublicCategoriesStore = create<PublicCategoriesStore>((set, get) => ({
  categories: [],
  loading: false,
  error: null,
  lastFetch: null,
  cacheExpiry: CACHE_DURATION,

  isDataFresh: () => {
    const { lastFetch, cacheExpiry } = get();
    if (!lastFetch) return false;
    return Date.now() - lastFetch < cacheExpiry;
  },

  fetchCategories: async () => {
    const { isDataFresh, loading } = get();
    
    // If data is fresh or already loading, don't fetch again
    if (isDataFresh() || loading) {
      return;
    }

    set({ loading: true, error: null });
    
    try {
      const response = await fetch('/api/menu/categories/public');
      
      if (!response.ok) {
        throw new Error(`HTTP Error: ${response.status}`);
      }
      
      const result: ApiResponse<Category[]> = await response.json();
      
      if (!result.success) {
        throw new Error('Failed to fetch categories from API');
      }
      
      set({
        categories: result.data,
        loading: false,
        error: null,
        lastFetch: Date.now()
      });
      
    } catch (error) {
      console.error('Error fetching public categories:', error);
      
      // Use fallback categories if we don't have any cached data
      const currentCategories = get().categories;
      const categoriesToUse = currentCategories.length > 0 ? currentCategories : fallbackCategories;
      
      set({
        categories: categoriesToUse,
        loading: false,
        error: error instanceof Error ? error.message : 'Failed to fetch categories',
        // Don't update lastFetch on error to allow retry
      });
    }
  },

  refetch: async () => {
    // Force refetch by clearing cache timestamp
    set({ lastFetch: null });
    await get().fetchCategories();
  },

  clearCache: () => {
    set({
      categories: [],
      lastFetch: null,
      error: null
    });
  }
}));