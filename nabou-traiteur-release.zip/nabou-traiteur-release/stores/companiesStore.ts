import { create } from 'zustand';
import { CompanyWithRelations, CompanyFormData, CompanyFilters } from '@/types/company';
import { CompanyService } from '@/services/companyService';

interface CompaniesState {
  companies: CompanyWithRelations[];
  loading: boolean;
  error: string | null;

  operationLoading: {
    fetchCompanies: boolean;
    create: boolean;
    update: boolean;
    delete: boolean;
    updateLimits: boolean;
  };

  pagination: { page: number; limit: number; total: number; totalPages: number };
  filters: CompanyFilters;

  isAddDialogOpen: boolean;
  isEditDialogOpen: boolean;
  isViewDialogOpen: boolean;
  isDeleteDialogOpen: boolean;

  selectedCompany: CompanyWithRelations | null;
  formData: CompanyFormData;

  searchTimeout: NodeJS.Timeout | null;

  cleanup: () => void;

  fetchCompanies: (page?: number, limit?: number) => Promise<void>;
  createCompany: (payload: Partial<CompanyFormData>) => Promise<boolean>;
  updateCompany: (id: string, payload: Partial<CompanyFormData>) => Promise<boolean>;
  deleteCompany: (id: string) => Promise<boolean>;
  updateLimits: (id: string, limits: CompanyFormData['limits']) => Promise<boolean>;

  openAddDialog: () => void;
  openEditDialog: (company: CompanyWithRelations) => void;
  openViewDialog: (company: CompanyWithRelations) => void;
  openDeleteDialog: (company: CompanyWithRelations) => void;
  closeDialogs: () => void;

  setFilters: (filters: Partial<CompanyFilters>) => void;
  setSearchFilter: (search: string) => void;

  goToPage: (page: number) => void;
  goToNextPage: () => void;
  goToPrevPage: () => void;
}

const initialFormData: CompanyFormData = { name: '', contactEmail: undefined, isActive: true, limits: [] };
const initialFilters: CompanyFilters = { search: '', isActive: 'all' };

export const useCompaniesStore = create<CompaniesState>((set, get) => ({
  companies: [],
  loading: false,
  error: null,

  operationLoading: { fetchCompanies: false, create: false, update: false, delete: false, updateLimits: false },

  pagination: { page: 1, limit: 10, total: 0, totalPages: 0 },
  filters: initialFilters,

  isAddDialogOpen: false,
  isEditDialogOpen: false,
  isViewDialogOpen: false,
  isDeleteDialogOpen: false,

  selectedCompany: null,
  formData: initialFormData,

  searchTimeout: null,

  cleanup: () => {
    set({
      companies: [],
      loading: false,
      error: null,
      operationLoading: { fetchCompanies: false, create: false, update: false, delete: false, updateLimits: false },
      pagination: { page: 1, limit: 10, total: 0, totalPages: 0 },
      filters: initialFilters,
      isAddDialogOpen: false,
      isEditDialogOpen: false,
      isViewDialogOpen: false,
      isDeleteDialogOpen: false,
      selectedCompany: null,
      formData: initialFormData,
      searchTimeout: null,
    });
  },

  // Actions API
  fetchCompanies: async (page?: number, limit?: number) => {
    set((state) => ({ operationLoading: { ...state.operationLoading, fetchCompanies: true }, loading: true, error: null }));
    try {
      const currentPage = page ?? get().pagination.page;
      const currentLimit = limit ?? get().pagination.limit;
      const { filters } = get();

      const params: any = { page: currentPage, limit: currentLimit };
      if (filters.search) params.search = filters.search;
      if (filters.isActive !== 'all') params.isActive = filters.isActive;

      const response = await CompanyService.getCompanies(params);
      if (CompanyService.isErrorResponse(response)) {
        set({ error: response.error.message, loading: false });
      } else {
        set({ companies: response.data, pagination: response.pagination, loading: false });
      }
    } catch (e) {
      set({ error: 'Erreur de connexion', loading: false });
    } finally {
      set((state) => ({ operationLoading: { ...state.operationLoading, fetchCompanies: false } }));
    }
  },

  createCompany: async (payload) => {
    set((state) => ({ operationLoading: { ...state.operationLoading, create: true }, loading: true, error: null }));
    try {
      const response = await CompanyService.createCompany(payload);
      if (CompanyService.isErrorResponse(response)) {
        set({ error: response.error.message, loading: false });
        return false;
      }
      await get().fetchCompanies(1, get().pagination.limit);
      set({ loading: false });
      return true;
    } catch (e) {
      set({ error: 'Erreur de connexion', loading: false });
      return false;
    } finally {
      set((state) => ({ operationLoading: { ...state.operationLoading, create: false } }));
    }
  },

  updateCompany: async (id, payload) => {
    set((state) => ({ operationLoading: { ...state.operationLoading, update: true }, loading: true, error: null }));
    try {
      const response = await CompanyService.updateCompany(id, payload);
      if (CompanyService.isErrorResponse(response)) {
        set({ error: response.error.message, loading: false });
        return false;
      }
      await get().fetchCompanies(get().pagination.page, get().pagination.limit);
      set({ loading: false });
      return true;
    } catch (e) {
      set({ error: 'Erreur de connexion', loading: false });
      return false;
    } finally {
      set((state) => ({ operationLoading: { ...state.operationLoading, update: false } }));
    }
  },

  deleteCompany: async (id) => {
    set((state) => ({ operationLoading: { ...state.operationLoading, delete: true }, loading: true, error: null }));
    try {
      const response = await CompanyService.deleteCompany(id);
      if (CompanyService.isErrorResponse(response)) {
        set({ error: response.error.message, loading: false });
        return false;
      }
      // Si on supprime la dernière de la page courante, ajuster page
      const { page, limit, total } = get().pagination;
      const newTotal = total - 1;
      const newTotalPages = Math.max(1, Math.ceil(newTotal / limit));
      const nextPage = Math.min(page, newTotalPages);
      await get().fetchCompanies(nextPage, limit);
      set({ loading: false });
      return true;
    } catch (e) {
      set({ error: 'Erreur de connexion', loading: false });
      return false;
    } finally {
      set((state) => ({ operationLoading: { ...state.operationLoading, delete: false } }));
    }
  },

  updateLimits: async (id, limits) => {
    set((state) => ({ operationLoading: { ...state.operationLoading, updateLimits: true }, loading: true, error: null }));
    try {
      const response = await CompanyService.updateLimits(id, limits);
      if (CompanyService.isErrorResponse(response)) {
        set({ error: response.error.message, loading: false });
        return false;
      }
      await get().fetchCompanies(get().pagination.page, get().pagination.limit);
      set({ loading: false });
      return true;
    } catch (e) {
      set({ error: 'Erreur de connexion', loading: false });
      return false;
    } finally {
      set((state) => ({ operationLoading: { ...state.operationLoading, updateLimits: false } }));
    }
  },

  // Dialogs
  openAddDialog: () => set({ isAddDialogOpen: true, formData: initialFormData }),
  openEditDialog: (company) => set({ isEditDialogOpen: true, selectedCompany: company, formData: {
    name: company.name,
    contactEmail: company.contactEmail ?? undefined,
    isActive: company.isActive,
    limits: company.limits.map(l => ({ categoryId: l.categoryId, maxPerOrder: l.maxPerOrder }))
  } }),
  openViewDialog: (company) => set({ isViewDialogOpen: true, selectedCompany: company }),
  openDeleteDialog: (company) => set({ isDeleteDialogOpen: true, selectedCompany: company }),
  closeDialogs: () => set({ isAddDialogOpen: false, isEditDialogOpen: false, isViewDialogOpen: false, isDeleteDialogOpen: false, selectedCompany: null, formData: initialFormData }),

  // Filtres
  setFilters: (filters) => {
    set((state) => ({ filters: { ...state.filters, ...filters } }));
    // Rechargement si changement immédiat autre que search (search est débouncé)
    if (filters.isActive !== undefined) {
      get().fetchCompanies(1, get().pagination.limit);
    }
  },
  setSearchFilter: (search) => {
    const currentTimeout = get().searchTimeout;
    if (currentTimeout) {
      clearTimeout(currentTimeout);
    }
    const timeout = setTimeout(() => {
      set((state) => ({ filters: { ...state.filters, search } }));
      get().fetchCompanies(1, get().pagination.limit);
    }, 400);
    set({ searchTimeout: timeout as unknown as NodeJS.Timeout });
  },

  // Pagination
  goToPage: (page) => { set((state) => ({ pagination: { ...state.pagination, page } })); get().fetchCompanies(page, get().pagination.limit); },
  goToNextPage: () => {
    const { page, totalPages, limit } = get().pagination;
    if (page < totalPages) {
      const next = page + 1;
      set((state) => ({ pagination: { ...state.pagination, page: next } }));
      get().fetchCompanies(next, limit);
    }
  },
  goToPrevPage: () => {
    const { page, limit } = get().pagination;
    if (page > 1) {
      const prev = page - 1;
      set((state) => ({ pagination: { ...state.pagination, page: prev } }));
      get().fetchCompanies(prev, limit);
    }
  },
}));