import { create } from "zustand";
import { persist } from "zustand/middleware";
import { WeeklyMenuItem } from "@/types/weeklyMenuPublic";
import { OrderItem } from "@/types/orders";
import { ExtendedCartStore, CartItem, ExtendedCartStorage } from "@/types/cart";
import { DeliveryZone } from "@/services/deliveryService";
import {
  OrderFormData,
  validateCurrentStep,
  getStepCount,
  getStepTitle,
} from "@/lib/reservation-utils";
import {
  validatePromoCode,
  validatePromoCodeFormat,
} from "@/services/promoService";
import { useAuthStore } from "@/stores/authStore";
import { unifiedOrderService } from "@/services/unifiedOrderService";

/**
 * Génère un identifiant unique pour un article du panier basé sur l'ID du menu et les options
 * Garantit que le même plat avec des options différentes aura des IDs différents
 */
const generateCartItemId = (menuItemId: string, options: any): string => {
  // Trier les clés pour assurer la cohérence du hash
  const optionsString = JSON.stringify(options, Object.keys(options).sort());
  const hash = btoa(optionsString).slice(0, 8);
  return `${menuItemId}-${hash}`;
};

/**
 * Trouve l'option sélectionnée et retourne son prix
 */
const getOptionPrice = (item: WeeklyMenuItem, selectedSize: string): number => {
  const selectedOption = item.options.find(
    (option) => option.name === selectedSize
  );
  return selectedOption?.price || 0;
};

/**
 * Store Zustand unifié pour la gestion du panier et des commandes
 */
export const useCartStore = create<ExtendedCartStore>()(
  persist(
    (set, get) => ({
      items: [],
      totalItems: 0,
      subtotal: 0,
      deliveryFee: 0,
      promoDiscount: 0,
      isFreeDelivery: false,
      total: 0,
      selectedDeliveryZone: null,
      appliedPromoCode: null,
      isOpen: false,

      // Nouveaux états pour la gestion des commandes
      orderState: {
        isLoading: false,
        isSubmitting: false,
        error: null,
        submissionError: null,
        currentOrder: null,
      },

      // États du modal de commande
      modalState: {
        isOpen: false,
        step: 1,
      },

      // Données du formulaire
      formData: {
        firstName: "",
        lastName: "",
        phone: "",
        email: "",
        employeeId: "",
        deliveryZoneId: "",
        deliveryAddress: "",
        deliveryTime: "",
        customerNotes: "",
        paymentMethod: "",
        weeklyMenuId: "",
      },

      // État des codes promo
      promoState: {
        code: "",
        isValid: false,
        isValidating: false,
        message: null,
        discountAmount: 0,
        isFreeDelivery: false,
      },

      // Configuration
      configState: {
        deliveryZones: [],
        paymentMethods: [],
        deliveryTimes: [],
      },

      generateCartItemId,

      calculateTotals: async () => {
        const { items, deliveryFee, promoDiscount, isFreeDelivery } = get();
        const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
        const subtotal = items.reduce((sum, item) => sum + item.totalPrice, 0);

        // Calculer le total avec frais de livraison et réductions
        const effectiveDeliveryFee = isFreeDelivery ? 0 : +deliveryFee;
        const discountedSubtotal = Math.max(0, +subtotal - +promoDiscount);
        const total = Number(discountedSubtotal) + effectiveDeliveryFee;

        set({ totalItems, subtotal, total });
      },

      setDeliveryZone: (zone: DeliveryZone | null) => {
        set({
          selectedDeliveryZone: zone,
          deliveryFee: zone ? zone.deliveryFee : 0,
        });
        get().calculateTotals();
      },

      applyPromoCode: (
        code: string,
        discount: number,
        isFreeDelivery: boolean = false
      ) => {
        set({
          appliedPromoCode: code,
          promoDiscount: discount,
          isFreeDelivery,
        });
        get().calculateTotals();
      },

      removePromoCode: () => {
        set({
          appliedPromoCode: null,
          promoDiscount: 0,
          isFreeDelivery: false,
        });
        get().calculateTotals();
      },

      addItem: async (
        item: WeeklyMenuItem,
        quantity: number,
        selectedSize: string
      ) => {
        const unitPrice = getOptionPrice(item, selectedSize);
        const options = { size: selectedSize };
        const itemId = generateCartItemId(item.menuItemId, selectedSize);

        if (item.rakTakPromoCode) {
          get().promo.setPromoCode(item.rakTakPromoCode);
        }

        set((state) => {
          const existingItemIndex = state.items.findIndex(
            (cartItem) => cartItem.id === itemId
          );

          let newItems: CartItem[];

          if (existingItemIndex >= 0) {
            // Article existant avec les mêmes options - augmenter la quantité
            newItems = state.items.map((cartItem, index) => {
              if (index === existingItemIndex) {
                const newQuantity = cartItem.quantity + quantity;
                return {
                  ...cartItem,
                  quantity: newQuantity,
                  totalPrice: unitPrice * newQuantity,
                };
              }
              return cartItem;
            });
          } else {
            // Nouvel article ou article avec options différentes
            const newCartItem: CartItem = {
              id: itemId,
              menuItemId: item.menuItemId,
              name: item.name,
              image: item.image,
              quantity,
              unitPrice,
              totalPrice: unitPrice * quantity,
              options,
              weeklyMenuId: item.weeklyMenuId,
              category: item.category,
              day: item.day,
              dayOfWeek: item.dayOfWeek || 0,
              mealType: item.mealType || "lunch",
              rakTakPromoCode: item.rakTakPromoCode || null,
            };

            newItems = [...state.items, newCartItem];
          }

          return { items: newItems };
        });

        // Recalculer les totaux
        await get().calculateTotals();
      },

      removeItem: (itemId: string) => {
        set((state) => ({
          items: state.items.filter((item) => item.id !== itemId),
        }));

        // Recalculer les totaux
        get().calculateTotals();
      },

      updateQuantity: (itemId: string, quantity: number) => {
        if (quantity <= 0) {
          // Si la quantité est 0 ou négative, supprimer l'article
          get().removeItem(itemId);
          return;
        }

        set((state) => ({
          items: state.items.map((item) => {
            if (item.id === itemId) {
              return {
                ...item,
                quantity,
                totalPrice: item.unitPrice * quantity,
              };
            }
            return item;
          }),
        }));

        // Recalculer les totaux
        get().calculateTotals();
      },

      clearCart: () => {
        set({
          items: [],
          totalItems: 0,
          subtotal: 0,
          deliveryFee: 0,
          promoDiscount: 0,
          isFreeDelivery: false,
          total: 0,
          selectedDeliveryZone: null,
          appliedPromoCode: null,
          isOpen: false,
        });
      },

      clearCartAfterOrder: () => {
        const { items } = get();
        const itemCount = items.length;

        set({
          items: [],
          totalItems: 0,
          subtotal: 0,
          deliveryFee: 0,
          promoDiscount: 0,
          isFreeDelivery: false,
          total: 0,
          selectedDeliveryZone: null,
          appliedPromoCode: null,
          // isOpen: false,
        });

        return itemCount;
      },

      openCart: () => {
        set({ isOpen: true });
      },

      closeCart: () => {
        set({ isOpen: false });
      },

      getCartForOrder: (): OrderItem[] => {
        const { items } = get();

        return items.map((cartItem) => ({
          id: cartItem.menuItemId, // Utiliser l'ID du menu item pour l'API
          quantity: cartItem.quantity,
          unitPrice: cartItem.unitPrice,
          totalPrice: cartItem.totalPrice,
          options: cartItem.options,
          menuItem: {
            id: cartItem.menuItemId,
            name: cartItem.name,
            price: cartItem.unitPrice,
            imageUrl: cartItem.image,
          },
        }));
      },

      getCartForGuestOrder: () => {
        const { items } = get();

        return items.map((cartItem) => ({
          menuItemId: cartItem.menuItemId,
          quantity: cartItem.quantity,
          options: cartItem.options,
        }));
      },

      // Actions de gestion des commandes
      order: {
        createOrder: async (orderData) => {
          set((state) => ({
            orderState: { ...state.orderState, isLoading: true, error: null },
          }));

          try {
            const { unifiedOrderService } = await import(
              "@/services/unifiedOrderService"
            );
            const response = await unifiedOrderService.createGuestOrder(
              orderData
            );

            if (response.success) {
              set((state) => ({
                orderState: {
                  ...state.orderState,
                  isLoading: false,
                  currentOrder: response.data,
                  error: null,
                },
              }));
              return response.data;
            } else {
              set((state) => ({
                orderState: {
                  ...state.orderState,
                  isLoading: false,
                  error: response.error.message,
                },
              }));
              return null;
            }
          } catch (error) {
            const errorMessage =
              error instanceof Error ? error.message : "Erreur inconnue";
            set((state) => ({
              orderState: {
                ...state.orderState,
                isLoading: false,
                error: errorMessage,
              },
            }));
            return null;
          }
        },

        getOrder: async (orderId) => {
          set((state) => ({
            orderState: { ...state.orderState, isLoading: true, error: null },
          }));

          try {
            const { unifiedOrderService } = await import(
              "@/services/unifiedOrderService"
            );
            const response = await unifiedOrderService.getOrderById(orderId);

            if (response.success) {
              set((state) => ({
                orderState: {
                  ...state.orderState,
                  isLoading: false,
                  currentOrder: response.data,
                  error: null,
                },
              }));
              return response.data;
            } else {
              set((state) => ({
                orderState: {
                  ...state.orderState,
                  isLoading: false,
                  error: response.error.message,
                },
              }));
              return null;
            }
          } catch (error) {
            const errorMessage =
              error instanceof Error ? error.message : "Erreur inconnue";
            set((state) => ({
              orderState: {
                ...state.orderState,
                isLoading: false,
                error: errorMessage,
              },
            }));
            return null;
          }
        },

        getOrderByNumber: async (orderNumber) => {
          set((state) => ({
            orderState: { ...state.orderState, isLoading: true, error: null },
          }));

          try {
            const { unifiedOrderService } = await import(
              "@/services/unifiedOrderService"
            );
            const response = await unifiedOrderService.getOrderByNumber(
              orderNumber
            );

            if (response.success) {
              set((state) => ({
                orderState: {
                  ...state.orderState,
                  isLoading: false,
                  currentOrder: response.data,
                  error: null,
                },
              }));
              return response.data;
            } else {
              set((state) => ({
                orderState: {
                  ...state.orderState,
                  isLoading: false,
                  error: response.error.message,
                },
              }));
              return null;
            }
          } catch (error) {
            const errorMessage =
              error instanceof Error ? error.message : "Erreur inconnue";
            set((state) => ({
              orderState: {
                ...state.orderState,
                isLoading: false,
                error: errorMessage,
              },
            }));
            return null;
          }
        },

        submitDirectOrder: async (item, data) => {
          set((state) => ({
            orderState: {
              ...state.orderState,
              isSubmitting: true,
              submissionError: null,
            },
          }));

          try {
            const { unifiedOrderService } = await import(
              "@/services/unifiedOrderService"
            );
            const response = await unifiedOrderService.createDirectOrder(
              item,
              data
            );

            if (response.success) {
              set((state) => ({
                orderState: {
                  ...state.orderState,
                  isSubmitting: false,
                  currentOrder: response.data,
                  submissionError: null,
                },
              }));
              return response.data;
            } else {
              set((state) => ({
                orderState: {
                  ...state.orderState,
                  isSubmitting: false,
                  submissionError: response.error.message,
                },
              }));
              return null;
            }
          } catch (error) {
            const errorMessage =
              error instanceof Error
                ? error.message
                : "Erreur lors de la soumission";
            set((state) => ({
              orderState: {
                ...state.orderState,
                isSubmitting: false,
                submissionError: errorMessage,
              },
            }));
            return null;
          }
        },

        submitCartOrder: async (formData, promoCode) => {
          const { items } = get();

          if (items.length === 0) {
            set((state) => ({
              orderState: {
                ...state.orderState,
                submissionError: "Le panier est vide",
              },
            }));
            return null;
          }

          set((state) => ({
            orderState: {
              ...state.orderState,
              isSubmitting: true,
              submissionError: null,
            },
          }));

          try {
            const response = await unifiedOrderService.createCartOrder(
              items,
              formData,
              promoCode
            );

            if (response.success) {
              // Ne pas vider le panier ici: laisser le modal gérer le vidage
              // pour éviter la fermeture prématurée et permettre l'affichage
              // des modals de sélection/QR.

              set((state) => ({
                orderState: {
                  ...state.orderState,
                  isSubmitting: false,
                  currentOrder: response.data,
                  submissionError: null,
                },
              }));

              return response.data;
            } else {
              set((state) => ({
                orderState: {
                  ...state.orderState,
                  isSubmitting: false,
                  submissionError: response.error.message,
                },
              }));
              return null;
            }
          } catch (error) {
            const errorMessage =
              error instanceof Error
                ? error.message
                : "Erreur lors de la soumission";
            set((state) => ({
              orderState: {
                ...state.orderState,
                isSubmitting: false,
                submissionError: errorMessage,
              },
            }));
            return null;
          }
        },

        clearOrderError: () => {
          set((state) => ({
            orderState: {
              ...state.orderState,
              error: null,
              submissionError: null,
            },
          }));
        },

        resetOrderState: () => {
          set((state) => ({
            orderState: {
              isLoading: false,
              isSubmitting: false,
              error: null,
              submissionError: null,
              currentOrder: null,
            },
          }));
        },
      },

      // Actions du modal
      modal: {
        openModal: () => {
          set((state) => ({
            modalState: {
              ...state.modalState,
              isOpen: true,
              step: 1,
            },
          }));
        },
        closeModal: () => {
          set((state) => ({
            modalState: { ...state.modalState, isOpen: false },
          }));
        },
        setStep: (step) => {
          const maxSteps = getStepCount();

          // Valider que l'étape est dans les limites
          const validStep = Math.max(1, Math.min(step, maxSteps));

          set((state) => ({
            modalState: { ...state.modalState, step: validStep },
          }));
        },
        nextStep: () => {
          const { modalState } = get();
          const maxSteps = getStepCount();

          if (modalState.step < maxSteps) {
            set((state) => ({
              modalState: {
                ...state.modalState,
                step: state.modalState.step + 1,
              },
            }));
          }
        },
        previousStep: () => {
          set((state) => ({
            modalState: {
              ...state.modalState,
              step: Math.max(1, state.modalState.step - 1),
            },
          }));
        },
        resetModal: () => {
          set((state) => ({
            modalState: {
              isOpen: false,
              step: 1,
            },
          }));

          // Réinitialiser aussi les données du formulaire et promo
          get().form.resetFormData();
          get().promo.resetPromoState();
        },
        getStepCount: () => {
          return getStepCount();
        },
        getStepTitle: (step) => {
          const { modalState } = get();

          const currentStep = step !== undefined ? step : modalState.step;
          return getStepTitle(currentStep);
        },
        canGoNext: () => {
          const { modalState } = get();

          const maxSteps = getStepCount();
          return modalState.step < maxSteps;
        },
        canGoPrevious: () => {
          const { modalState } = get();
          return modalState.step > 1;
        },
      },

      // Actions du formulaire
      form: {
        updateFormData: (field, value) => {
          set((state) => ({
            formData: { ...state.formData, [field]: value },
          }));

          // Validation en temps réel après mise à jour
          setTimeout(() => {
            get().form.validateCurrentStep();
          }, 0);
        },
        setFormData: (data) => {
          set((state) => ({
            formData: { ...state.formData, ...data },
          }));

          // Validation en temps réel après mise à jour
          setTimeout(() => {
            get().form.validateCurrentStep();
          }, 0);
        },
        resetFormData: () => {
          set({
            formData: {
              firstName: "",
              lastName: "",
              phone: "",
              email: "",
              employeeId: "",
              deliveryZoneId: "",
              deliveryAddress: "",
              deliveryTime: "",
              customerNotes: "",
              paymentMethod: "",
              weeklyMenuId: "",
            },
          });
        },
        validateCurrentStep: () => {
          const { modalState, formData } = get();
          const { user } = useAuthStore.getState();
          const isEmployee = !!user?.companyId;

          // Valider l'étape actuelle
          const result = validateCurrentStep(
            modalState.step,
            formData,
            isEmployee
          );

          return result;
        },
        validateField: (field, value) => {
          const errors: string[] = [];

          switch (field) {
            case "firstName":
              if (!value || !value.trim()) {
                errors.push("Le prénom est requis");
              } else if (value.trim().length < 2) {
                errors.push("Le prénom doit contenir au moins 2 caractères");
              }
              break;

            case "lastName":
              if (!value || !value.trim()) {
                errors.push("Le nom est requis");
              } else if (value.trim().length < 2) {
                errors.push("Le nom doit contenir au moins 2 caractères");
              }
              break;

            case "phone":
              if (!value || !value.trim()) {
                errors.push("Le téléphone est requis");
              } else if (!/^[\d\s\-\+\(\)]{8,}$/.test(value.trim())) {
                errors.push("Format de téléphone invalide");
              }
              break;

            case "email":
              if (
                value &&
                value.trim() &&
                !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim())
              ) {
                errors.push("Format d'email invalide");
              }
              break;

            case "deliveryZoneId":
              if (!value || !value.trim()) {
                errors.push("La zone de livraison est requise");
              }
              break;

            case "deliveryAddress":
              if (!value || !value.trim()) {
                errors.push("L'adresse de livraison est requise");
              } else if (value.trim().length < 5) {
                errors.push("L'adresse doit contenir au moins 5 caractères");
              }
              break;

            case "deliveryTime":
              if (!value || !value.trim()) {
                errors.push("L'heure de livraison est requise");
              }
              break;

            case "paymentMethod":
              if (!value || !value.trim()) {
                errors.push("La méthode de paiement est requise");
              }
              break;
          }

          return {
            isValid: errors.length === 0,
            errors,
          };
        },
        validateAllFields: () => {
          const { formData, modalState } = get();
          const allErrors: { [key: string]: string[] } = {};
          let hasErrors = false;

          // Déterminer quels champs valider selon le mode et l'étape
          const fieldsToValidate = get().form.getRequiredFields();

          fieldsToValidate.forEach((field) => {
            const fieldValue = formData[field as keyof OrderFormData];
            const validation = get().form.validateField(field, fieldValue);

            if (!validation.isValid) {
              allErrors[field] = validation.errors || [];
              hasErrors = true;
            }
          });

          return {
            isValid: !hasErrors,
            errors: allErrors,
          };
        },
        getRequiredFields: () => {
          const { modalState } = get();
          const { step } = modalState;

          // Champs de base toujours requis
          const baseFields = ["firstName", "lastName", "phone"];
          const deliveryFields = [
            "deliveryZoneId",
            "deliveryAddress",
            "deliveryTime",
          ];
          const paymentFields = ["paymentMethod"];

          // Mode normal - tous les utilisateurs doivent remplir le formulaire
          if (step === 1) {
            return [...baseFields, ...deliveryFields, ...paymentFields];
          }

          return [];
        },
        isStepValid: (step?: number) => {
          const currentStep = step !== undefined ? step : get().modalState.step;
          const validation = get().form.validateCurrentStep();
          return validation.isValid;
        },
        getStepErrors: (step?: number) => {
          const currentStep = step !== undefined ? step : get().modalState.step;
          const validation = get().form.validateCurrentStep();
          return validation.errors || [];
        },
      },

      // Actions des codes promo
      promo: {
        setPromoCode: (code) => {
          set((state) => ({
            promoState: { ...state.promoState, code },
          }));
        },
        validatePromoCode: async () => {
          const { promoState, items, subtotal } = get();
          const { code } = promoState;

          // Validation côté client du format
          const formatValidation = validatePromoCodeFormat(code);

          if (!formatValidation.isValid) {
            set((state) => ({
              promoState: {
                ...state.promoState,
                isValid: false,
                isValidating: false,
                message: formatValidation.message || "Format de code invalide",
                discountAmount: 0,
                isFreeDelivery: false,
              },
            }));
            return;
          }

          // Démarrer la validation
          set((state) => ({
            promoState: {
              ...state.promoState,
              isValidating: true,
              message: "Validation en cours...",
              isValid: false,
              discountAmount: 0,
              isFreeDelivery: false,
            },
          }));

          try {
            // Préparer les données des articles pour la validation
            const itemsForValidation = items.map((item) => ({
              menuItemId: item.menuItemId,
              quantity: item.quantity,
              unitPrice: item.unitPrice,
            }));

            // Valider le code promo via le service unifié
            const validationResult = await validatePromoCode(
              code,
              subtotal,
              itemsForValidation
            );

            if (validationResult.success && validationResult.data?.discount) {
              const { discount } = validationResult.data;
              const discountAmount = discount.amount || 0;
              const isFreeDelivery = discount.isFreeDelivery || false;

              // Appliquer le code promo validé
              set((state) => ({
                promoState: {
                  ...state.promoState,
                  isValid: true,
                  isValidating: false,
                  message:
                    validationResult.message ||
                    "Code promo appliqué avec succès",
                  discountAmount,
                  isFreeDelivery,
                },
              }));

              // Mettre à jour aussi l'état du panier pour la compatibilité
              get().applyPromoCode(code, discountAmount, isFreeDelivery);
            } else {
              // Code promo invalide
              const errorMessage =
                validationResult.error?.message ||
                validationResult.message ||
                "Code promo invalide";

              set((state) => ({
                promoState: {
                  ...state.promoState,
                  isValid: false,
                  isValidating: false,
                  message: errorMessage,
                  discountAmount: 0,
                  isFreeDelivery: false,
                },
              }));
            }
          } catch (error) {
            // Erreur réseau ou autre
            const errorMessage =
              error instanceof Error ? error.message : "Erreur de validation";

            set((state) => ({
              promoState: {
                ...state.promoState,
                isValid: false,
                isValidating: false,
                message: errorMessage,
                discountAmount: 0,
                isFreeDelivery: false,
              },
            }));
          }
        },
        applyPromoCode: (code, discount, isFreeDelivery = false) => {
          set((state) => ({
            promoState: {
              ...state.promoState,
              code,
              isValid: true,
              discountAmount: discount,
              isFreeDelivery,
              message: null,
            },
          }));
          // Also update the existing cart promo state for compatibility
          // get().applyPromoCode(code, discount, isFreeDelivery);
        },
        removePromoCode: () => {
          set((state) => ({
            promoState: {
              code: "",
              isValid: false,
              isValidating: false,
              message: null,
              discountAmount: 0,
              isFreeDelivery: false,
            },
          }));
          // Also update the existing cart promo state for compatibility
          get().removePromoCode();
        },
        resetPromoState: () => {
          set((state) => ({
            promoState: {
              code: "",
              isValid: false,
              isValidating: false,
              message: null,
              discountAmount: 0,
              isFreeDelivery: false,
            },
          }));
        },
        clearPromoMessage: () => {
          set((state) => ({
            promoState: { ...state.promoState, message: null },
          }));
        },
        isValidating: () => {
          const { promoState } = get();
          return promoState.isValidating;
        },
        hasValidPromo: () => {
          const { promoState } = get();
          return promoState.isValid && promoState.code.length > 0;
        },
        getPromoSummary: () => {
          const { promoState } = get();
          if (!promoState.isValid || !promoState.code) {
            return null;
          }

          return {
            code: promoState.code,
            discountAmount: promoState.discountAmount,
            isFreeDelivery: promoState.isFreeDelivery,
            message: promoState.message,
          };
        },
      },

      // Actions de configuration
      config: {
        setDeliveryZones: (zones) => {
          set((state) => ({
            configState: { ...state.configState, deliveryZones: zones },
          }));
        },
        setPaymentMethods: (methods) => {
          set((state) => ({
            configState: { ...state.configState, paymentMethods: methods },
          }));
        },
        setDeliveryTimes: (times) => {
          set((state) => ({
            configState: { ...state.configState, deliveryTimes: times },
          }));
        },
        updateConfig: (configUpdate) => {
          set((state) => ({
            configState: { ...state.configState, ...configUpdate },
          }));
        },
        getDeliveryZones: () => {
          const { configState } = get();
          return configState.deliveryZones;
        },
        getPaymentMethods: () => {
          const { configState } = get();
          return configState.paymentMethods;
        },
        getDeliveryTimes: () => {
          const { configState } = get();
          return configState.deliveryTimes;
        },
        getDeliveryZoneById: (zoneId) => {
          const { configState } = get();
          return (
            configState.deliveryZones.find((zone) => zone.id === zoneId) || null
          );
        },
        getPaymentMethodById: (methodId) => {
          const { configState } = get();
          return (
            configState.paymentMethods.find(
              (method) => method.id === methodId
            ) || null
          );
        },
        isDeliveryZoneAvailable: (zoneId) => {
          const { configState } = get();
          const zone = configState.deliveryZones.find(
            (zone) => zone.id === zoneId
          );
          return zone ? zone.isActive : false;
        },
        isPaymentMethodAvailable: (methodId) => {
          const { configState } = get();
          const method = configState.paymentMethods.find(
            (method) => method.id === methodId
          );
          return method ? method.isActive : false;
        },
        refreshConfiguration: async () => {
          try {
            // Charger les zones de livraison
            const { deliveryService } = await import(
              "@/services/deliveryService"
            );
            const deliveryZonesResponse =
              await deliveryService.getDeliveryZones();

            // Charger les méthodes de paiement
            const { paymentService } = await import(
              "@/services/paymentService"
            );
            const paymentMethodsResponse =
              await paymentService.getPaymentMethods();

            if (
              deliveryZonesResponse.success &&
              paymentMethodsResponse.success
            ) {
              set((state) => ({
                configState: {
                  ...state.configState,
                  deliveryZones: deliveryZonesResponse.data || [],
                  paymentMethods: paymentMethodsResponse.data || [],
                },
              }));

              return true;
            } else {
              console.error("Failed to refresh configuration:", {
                deliveryZones: deliveryZonesResponse.error,
                paymentMethods: paymentMethodsResponse.error,
              });
              return false;
            }
          } catch (error) {
            console.error("Error refreshing configuration:", error);
            return false;
          }
        },
        resetConfiguration: () => {
          set((state) => ({
            configState: {
              deliveryZones: [],
              paymentMethods: [],
              deliveryTimes: [],
            },
          }));
        },
      },
    }),
    {
      name: "cart-storage",
      version: 2,
      partialize: (state): ExtendedCartStorage => ({
        items: state.items,
        timestamp: Date.now(),
        version: "2.0.0",
        formData: state.formData,
        selectedDeliveryZone: state.selectedDeliveryZone,
        appliedPromoCode: state.appliedPromoCode || undefined,
        modalState: {
          lastStep: state.modalState.step,
        },
      }),
      onRehydrateStorage: () => (state) => {
        if (state) {
          // Recalculer les totaux après la réhydratation
          state.calculateTotals();

          // Restaurer les données du formulaire si elles existent
          const storage = localStorage.getItem("cart-storage");
          if (storage) {
            try {
              const parsed = JSON.parse(storage);
              if (parsed.state) {
                const { formData, modalState } = parsed.state;
                if (formData) {
                  state.form.setFormData(formData);
                }
                if (modalState?.lastItem) {
                  // Optionally restore modal state - this could be configurable
                  // state.modal.openModal(modalState.lastItem);
                }
              }
            } catch (error) {
              console.warn("Failed to restore extended cart data:", error);
            }
          }
        }
      },
    }
  )
);
