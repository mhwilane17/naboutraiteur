import { create } from 'zustand';
import { 
  AppConfiguration, 
  ConfigurationUpdate, 
  ConfigurationsBySection,
  ConfigurationService,
  ConfigurationErrorCodes,
  ConfigurationErrorMessages
} from '@/services/configurationService';

interface ConfigurationsState {
  // État des données
  configurations: AppConfiguration[];
  values: Record<string, string>;
  originalValues: Record<string, string>;
  loading: boolean;
  error: string | null;
  
  // États de chargement granulaires
  operationLoading: {
    fetch: boolean;
    save: boolean;
  };
  
  // État de validation
  validationErrors: Record<string, string>;
  
  // Actions API
  fetchConfigurations: () => Promise<void>;
  updateValue: (key: string, value: string) => void;
  saveChanges: () => Promise<boolean>;
  resetChanges: () => void;
  
  // Actions de validation
  validateField: (key: string, value: string) => string | null;
  validateAllFields: () => boolean;
  clearValidationErrors: () => void;
  
  // Actions utilitaires
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  setOperationLoading: (operation: keyof ConfigurationsState['operationLoading'], loading: boolean) => void;
  
  // Computed properties (getters)
  hasChanges: () => boolean;
  getConfigurationsBySection: (section: string) => AppConfiguration[];
  getAllSections: () => string[];
  getConfigurationByKey: (key: string) => AppConfiguration | undefined;
  getCurrentValue: (key: string) => string;
  hasValidationErrors: () => boolean;
}

const initialOperationLoading = {
  fetch: false,
  save: false,
};

export const useConfigurationsStore = create<ConfigurationsState>((set, get) => ({
  // État initial
  configurations: [],
  values: {},
  originalValues: {},
  loading: false,
  error: null,
  operationLoading: initialOperationLoading,
  validationErrors: {},

  // Actions utilitaires
  setLoading: (loading: boolean) => set({ loading }),
  setError: (error: string | null) => set({ error }),
  setOperationLoading: (operation: keyof ConfigurationsState['operationLoading'], loading: boolean) => {
    set((state) => ({
      operationLoading: {
        ...state.operationLoading,
        [operation]: loading,
      },
    }));
  },

  // Actions API
  fetchConfigurations: async () => {
    get().setOperationLoading('fetch', true);
    set({ loading: true, error: null });
    
    try {
      const response = await ConfigurationService.getAllConfigurations();
      
      if (ConfigurationService.isErrorResponse(response)) {
        const errorMessage = ConfigurationErrorMessages[response.error.code as keyof typeof ConfigurationErrorMessages] 
          || response.error.message 
          || 'Erreur lors du chargement des configurations';
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('fetch', false);
      } else {
        // Construire les objets values et originalValues
        const values: Record<string, string> = {};
        const originalValues: Record<string, string> = {};
        
        response.data.forEach(config => {
          values[config.key] = config.value;
          originalValues[config.key] = config.value;
        });
        
        set({ 
          configurations: response.data,
          values,
          originalValues,
          loading: false,
          validationErrors: {} // Clear validation errors on successful fetch
        });
        get().setOperationLoading('fetch', false);
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('fetch', false);
    }
  },

  updateValue: (key: string, value: string) => {
    set((state) => ({
      values: {
        ...state.values,
        [key]: value
      }
    }));
    
    // Validation en temps réel
    const config = get().getConfigurationByKey(key);
    if (config) {
      const validationError = get().validateField(key, value);
      set((state) => ({
        validationErrors: validationError 
          ? { ...state.validationErrors, [key]: validationError }
          : Object.fromEntries(Object.entries(state.validationErrors).filter(([k]) => k !== key))
      }));
    }
  },

  saveChanges: async (): Promise<boolean> => {
    // Valider tous les champs avant sauvegarde
    if (!get().validateAllFields()) {
      return false;
    }
    
    get().setOperationLoading('save', true);
    set({ loading: true, error: null });
    
    try {
      const { values, originalValues } = get();
      
      // Identifier les changements
      const updates: ConfigurationUpdate[] = [];
      Object.keys(values).forEach(key => {
        if (values[key] !== originalValues[key]) {
          updates.push({ key, value: values[key] });
        }
      });
      
      if (updates.length === 0) {
        set({ loading: false });
        get().setOperationLoading('save', false);
        return true; // Aucun changement à sauvegarder
      }
      
      const response = await ConfigurationService.updateConfigurations(updates);
      
      if (ConfigurationService.isErrorResponse(response)) {
        // Gérer les erreurs de validation spécifiques
        if (response.error.code === ConfigurationErrorCodes.VALIDATION_ERROR && response.error.details) {
          set({ 
            validationErrors: response.error.details as Record<string, string>,
            loading: false 
          });
        } else {
          const errorMessage = ConfigurationErrorMessages[response.error.code as keyof typeof ConfigurationErrorMessages] 
            || response.error.message 
            || 'Erreur lors de la sauvegarde des configurations';
          set({ error: errorMessage, loading: false });
        }
        get().setOperationLoading('save', false);
        return false;
      } else {
        // Mise à jour réussie - synchroniser les valeurs originales
        const { values } = get();
        set({ 
          originalValues: { ...values },
          loading: false,
          validationErrors: {} // Clear validation errors on successful save
        });
        
        // Optionnel: recharger les configurations pour s'assurer de la cohérence
        // await get().fetchConfigurations();
        
        get().setOperationLoading('save', false);
        return true;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('save', false);
      return false;
    }
  },

  resetChanges: () => {
    const { originalValues } = get();
    set({ 
      values: { ...originalValues },
      validationErrors: {}
    });
  },

  // Actions de validation
  validateField: (key: string, value: string): string | null => {
    const config = get().getConfigurationByKey(key);
    if (!config) {
      return 'Configuration introuvable';
    }
    
    return ConfigurationService.validateConfigurationValue(config, value);
  },

  validateAllFields: (): boolean => {
    const { values, configurations } = get();
    const errors: Record<string, string> = {};
    
    configurations.forEach(config => {
      const value = values[config.key] || '';
      const error = ConfigurationService.validateConfigurationValue(config, value);
      if (error) {
        errors[config.key] = error;
      }
    });
    
    // Validation spéciale pour les heures d'ouverture
    const openingTime = values['orders.opening_time'];
    const closingTime = values['orders.closing_time'];
    
    if (openingTime && closingTime) {
      const updates: ConfigurationUpdate[] = [
        { key: 'orders.opening_time', value: openingTime },
        { key: 'orders.closing_time', value: closingTime }
      ];
      
      const timeErrors = ConfigurationService.validateOrderingHours(updates);
      if (timeErrors) {
        Object.assign(errors, timeErrors);
      }
    }
    
    set({ validationErrors: errors });
    return Object.keys(errors).length === 0;
  },

  clearValidationErrors: () => {
    set({ validationErrors: {} });
  },

  // Computed properties (getters)
  hasChanges: (): boolean => {
    const { values, originalValues } = get();
    return Object.keys(values).some(key => values[key] !== originalValues[key]);
  },

  getConfigurationsBySection: (section: string): AppConfiguration[] => {
    const { configurations } = get();
    return configurations.filter(config => config.section === section);
  },

  getAllSections: (): string[] => {
    const { configurations } = get();
    const sections = new Set(configurations.map(config => config.section));
    return Array.from(sections).sort();
  },

  getConfigurationByKey: (key: string): AppConfiguration | undefined => {
    const { configurations } = get();
    return configurations.find(config => config.key === key);
  },

  getCurrentValue: (key: string): string => {
    const { values } = get();
    return values[key] || '';
  },

  hasValidationErrors: (): boolean => {
    const { validationErrors } = get();
    return Object.keys(validationErrors).length > 0;
  },
}));