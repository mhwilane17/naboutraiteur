import { create } from "zustand";
import type { Order, OrderFilters } from "@/types/orders";
import OrdersAdminService from "@/services/ordersAdminService";

interface PaginationState {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

interface OrdersPageFilters {
  searchTerm: string;
  selectedStatus: string; // 'all' | Order['status']
  selectedPaymentStatus: string; // 'all' | Order['paymentStatus']
  selectedStartDate: string; // yyyy-mm-dd
  selectedEndDate: string; // yyyy-mm-dd
}

interface OrdersState extends OrdersPageFilters {
  // Data
  orders: Order[];
  loading: boolean;
  error: string | null;
  pagination: PaginationState;

  // UI State
  isViewDialogOpen: boolean;
  selectedOrder: Order | null;
  isUpdating: string | null; // orderId
  isInitialized: boolean;
  isViewLoading: boolean; // Chargement des détails de commande

  // Actions - filters
  setSearchTerm: (value: string) => Promise<void>;
  setSelectedStatus: (value: string) => Promise<void>;
  setSelectedPaymentStatus: (value: string) => Promise<void>;
  setSelectedStartDate: (value: string) => Promise<void>;
  setSelectedEndDate: (value: string) => Promise<void>;

  // Actions - data
  fetchOrders: (extraFilters?: Partial<OrderFilters>) => Promise<void>;
  refetch: () => Promise<void>;
  getOrderById: (id: string) => Promise<Order | null>;
  updateOrderStatus: (
    id: string,
    status: Order["status"],
    adminNotes?: string
  ) => Promise<Order | null>;
  updateOrder: (id: string, updates: Partial<Order>) => Promise<Order | null>;

  // Actions - UI
  openViewDialog: (order: Order) => Promise<void>;
  closeViewDialog: () => void;
  initialize: () => Promise<void>;
}

const today = new Date().toISOString().split("T")[0];

export const useOrdersStore = create<OrdersState>((set, get) => ({
  // Filters
  searchTerm: "",
  selectedStatus: "all",
  selectedPaymentStatus: "all",
  selectedStartDate: today,
  selectedEndDate: today,

  // Data
  orders: [],
  loading: false,
  error: null,
  pagination: { page: 1, limit: 10, total: 0, totalPages: 0 },

  // UI
  isViewDialogOpen: false,
  selectedOrder: null,
  isUpdating: null,
  isInitialized: false,
  isViewLoading: false,

  // Utils
  initialize: async () => {
    set({ isInitialized: true });
    await get().fetchOrders();
  },

  // Filter setters with auto fetch
  setSearchTerm: async (value) => {
    set({ searchTerm: value });
    if (get().isInitialized) await get().fetchOrders();
  },
  setSelectedStatus: async (value) => {
    set({ selectedStatus: value });
    if (get().isInitialized) await get().fetchOrders();
  },
  setSelectedPaymentStatus: async (value) => {
    set({ selectedPaymentStatus: value });
    if (get().isInitialized) await get().fetchOrders();
  },
  setSelectedStartDate: async (value) => {
    set({ selectedStartDate: value });
    if (get().isInitialized) await get().fetchOrders();
  },
  setSelectedEndDate: async (value) => {
    set({ selectedEndDate: value });
    if (get().isInitialized) await get().fetchOrders();
  },

  // Data actions
  fetchOrders: async (extraFilters = {}) => {
    const state = get();
    set({ loading: true, error: null });
    try {
      const apiFilters: OrderFilters = {};

      // Map local filters to API filters
      if (state.searchTerm) apiFilters.search = state.searchTerm;
      if (state.selectedStatus !== "all") apiFilters.status = state.selectedStatus;
      if (state.selectedPaymentStatus !== "all") apiFilters.paymentStatus = state.selectedPaymentStatus as any;
      if (state.selectedStartDate) {
        apiFilters.startDate = state.selectedStartDate;
      }
      if (state.selectedEndDate) {
        apiFilters.endDate = state.selectedEndDate;
      }

      const mergedFilters = { ...apiFilters, ...extraFilters };
      const resp = await OrdersAdminService.getOrders(mergedFilters);

      if (resp.success) {
        set({ orders: resp.data.orders, pagination: resp.data.pagination });
      } else {
        set({ error: resp.error.message || "Erreur lors du chargement des commandes" });
      }
    } catch (e) {
      set({ error: e instanceof Error ? e.message : "Erreur inconnue" });
    } finally {
      set({ loading: false });
    }
  },

  refetch: async () => {
    await get().fetchOrders();
  },

  getOrderById: async (id) => {
    const resp = await OrdersAdminService.getOrderById(id);
    if (resp.success) {
      return resp.data;
    } else {
      set({ error: resp.error.message || "Erreur lors du chargement de la commande" });
      return null;
    }
  },

  updateOrderStatus: async (id, status, adminNotes) => {
    try {
      set({ isUpdating: id });
      const resp = await OrdersAdminService.updateOrderStatus(id, status, adminNotes);
      if (resp.success) {
        const updated = resp.data;
        set((prev) => ({
          orders: prev.orders.map((o) => (o.id === id ? { ...o, ...updated } : o)),
          selectedOrder: prev.selectedOrder?.id === id ? { ...prev.selectedOrder, ...updated } : prev.selectedOrder,
        }));
        return updated;
      } else {
        set({ error: resp.error.message || "Erreur lors de la mise à jour" });
        return null;
      }
    } finally {
      set({ isUpdating: null });
    }
  },

  updateOrder: async (id, updates) => {
    const resp = await OrdersAdminService.updateOrder(id, updates);
    if (resp.success) {
      const updated = resp.data;
      set((prev) => ({
        orders: prev.orders.map((o) => (o.id === id ? { ...o, ...updated } : o)),
        selectedOrder: prev.selectedOrder?.id === id ? { ...prev.selectedOrder, ...updated } : prev.selectedOrder,
      }));
      return updated;
    } else {
      set({ error: resp.error.message || "Erreur lors de la mise à jour de la commande" });
      return null;
    }
  },

  // UI actions
  openViewDialog: async (order) => {
    // Afficher le dialogue immédiatement avec l'indicateur de chargement
    set({ isViewDialogOpen: true, isViewLoading: true });

    // Charger les détails complets
    const full = await get().getOrderById(order.id);
    if (full) {
      set({ selectedOrder: full, isViewLoading: false });
    } else {
      // En cas d'erreur, fermer le dialogue
      set({ isViewDialogOpen: false, isViewLoading: false });
    }
  },
  closeViewDialog: () => {
    set({ isViewDialogOpen: false, selectedOrder: null });
  },
}));