import { create } from "zustand";
import { CreateMenuItemData, MenuItem, MenuItemsState, UpdateMenuItemData } from "@/types/menu";

interface MenuItemsActions {
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  setMenuItems: (menuItems: MenuItem[]) => void;
  setPagination: (pagination: MenuItemsState["pagination"]) => void;
  fetchMenuItems: (options?: {
    page?: number;
    limit?: number;
    search?: string;
    categoryId?: string;
    isAvailable?: boolean;
    isActive?: boolean;
  }) => Promise<void>;
  createMenuItem: (data: CreateMenuItemData) => Promise<MenuItem>;
  updateMenuItem: (data: UpdateMenuItemData) => Promise<MenuItem>;
  deleteMenuItem: (id: string) => Promise<void>;
  refreshMenuItems: () => Promise<void>;
}

type MenuItemsStore = MenuItemsState & MenuItemsActions;

export const useMenuItemsStore = create<MenuItemsStore>((set, get) => ({
  // State
  menuItems: [],
  loading: false,
  error: null,
  pagination: null,

  // Actions
  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),
  setMenuItems: (menuItems) => set({ menuItems }),
  setPagination: (pagination) => set({ pagination }),

  fetchMenuItems: async (options = {}) => {
    try {
      set({ loading: true, error: null });

      const params = new URLSearchParams();
      if (options.page) params.append("page", options.page.toString());
      if (options.limit) params.append("limit", options.limit.toString());
      if (options.search) params.append("search", options.search);
      if (options.categoryId) params.append("categoryId", options.categoryId);
      if (options.isAvailable !== undefined)
        params.append("isAvailable", options.isAvailable.toString());
      if (options.isActive !== undefined) params.append("isActive", options.isActive.toString());

      const response = await fetch(`/api/menu/items?page=1&limit=100`);

      if (!response.ok) {
        throw new Error(`Erreur HTTP: ${response.status}`);
      }

      const data: { data: any; success: boolean } = await response.json();

      if (!data.success) {
        throw new Error("Erreur lors de la récupération des plats");
      }

      // Transform API data to match admin types
      const transformedItems: MenuItem[] = data.data.data.map((item: any) => ({
        id: item.id,
        name: item.name,
        description: item.description || "",
        category: item.category,
        image: item.image || "/placeholder.svg",
        isAvailable: item.isAvailable,
        hasRakTakPromo: false, // This would need to be added to the API response
        options: item.options || [],
        createdAt: item.createdAt,
        updatedAt: item.updatedAt,
      }));

      set({
        menuItems: transformedItems,
        pagination: data.data.pagination,
        loading: false,
      });
    } catch (err) {
      console.error("Erreur lors de la récupération des plats:", err);
      const errorMessage = err instanceof Error ? err.message : "Une erreur est survenue";
      set({
        error: errorMessage,
        menuItems: [],
        pagination: null,
        loading: false,
      });
    }
  },

  createMenuItem: async (data: CreateMenuItemData): Promise<MenuItem> => {
    try {
      const response = await fetch("/api/menu/items", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || "Erreur lors de la création du plat");
      }

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.error?.message || "Erreur lors de la création du plat");
      }

      // Transform API response to admin type
      const newItem: MenuItem = {
        id: result.data.id,
        name: result.data.name,
        description: result.data.description || "",
        category: result.data.category,
        image: result.data.image || "/placeholder.svg",
        isAvailable: result.data.isAvailable,
        // hasRakTakPromo: false,
        options: result.data.options || [],
        createdAt: result.data.createdAt,
        updatedAt: result.data.updatedAt,
      };

      // Update local state
      const { menuItems } = get();
      set({ menuItems: [...menuItems, newItem] });

      return newItem;
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Erreur lors de la création du plat";
      set({ error: errorMessage });
      throw new Error(errorMessage);
    }
  },

  updateMenuItem: async (data: UpdateMenuItemData): Promise<MenuItem> => {
    try {
      const { id, ...updateData } = data;

      const response = await fetch(`/api/menu/items/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updateData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || "Erreur lors de la modification du plat");
      }

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.error?.message || "Erreur lors de la modification du plat");
      }

      // Transform API response to admin type
      const updatedItem: MenuItem = {
        id: result.data.id,
        name: result.data.name,
        description: result.data.description || "",
        category: result.data.category,
        image: result.data.image || "/placeholder.svg",
        isAvailable: result.data.isAvailable,
        // hasRakTakPromo: false,
        options: result.data.options || [],
        createdAt: result.data.createdAt,
        updatedAt: result.data.updatedAt,
      };

      // Update local state
      const { menuItems } = get();
      set({
        menuItems: menuItems.map((item) => (item.id === id ? updatedItem : item)),
      });

      return updatedItem;
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Erreur lors de la modification du plat";
      set({ error: errorMessage });
      throw new Error(errorMessage);
    }
  },

  deleteMenuItem: async (id: string): Promise<void> => {
    try {
      const response = await fetch(`/api/menu/items/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || "Erreur lors de la suppression du plat");
      }

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.error?.message || "Erreur lors de la suppression du plat");
      }

      // Update local state
      const { menuItems } = get();
      set({ menuItems: menuItems.filter((item) => item.id !== id) });
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Erreur lors de la suppression du plat";
      set({ error: errorMessage });
      throw new Error(errorMessage);
    }
  },

  refreshMenuItems: async () => {
    await get().fetchMenuItems();
  },
}));
