import { create } from 'zustand';
import { 
  Role, 
  Permission, 
  RoleFormData, 
  RoleFilters, 
  CreateRoleRequest, 
  UpdateRoleRequest,
  RolesApiResponse,
  PermissionsApiResponse
} from '@/types/roles';
import { rolesService } from '@/services/rolesService';

interface RolesState {
  // Data State
  roles: Role[];
  permissions: Permission[];
  loading: boolean;
  error: string | null;
  
  // Granular Loading States
  operationLoading: {
    create: boolean;
    update: boolean;
    delete: boolean;
    fetchRoles: boolean;
    fetchPermissions: boolean;
    toggleStatus: boolean;
  };
  
  // Pagination State
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
  
  // Filter State
  filters: RoleFilters;
  
  // Dialog State
  isAddDialogOpen: boolean;
  isEditDialogOpen: boolean;
  isViewDialogOpen: boolean;
  isDeleteDialogOpen: boolean;
  selectedRole: Role | null;
  formData: RoleFormData;
  
  // Debouncing state
  searchTimeout: NodeJS.Timeout | null;
  
  // Cleanup method
  cleanup: () => void;
  
  // API Actions
  fetchRoles: (page?: number, limit?: number) => Promise<void>;
  fetchPermissions: () => Promise<void>;
  createRole: (roleData: CreateRoleRequest) => Promise<boolean>;
  updateRole: (id: string, updates: UpdateRoleRequest) => Promise<boolean>;
  deleteRole: (id: string) => Promise<boolean>;
  toggleRoleStatus: (id: string) => Promise<boolean>;
  
  // Pagination actions
  goToPage: (page: number) => Promise<void>;
  goToNextPage: () => Promise<void>;
  goToPreviousPage: () => Promise<void>;
  goToFirstPage: () => Promise<void>;
  goToLastPage: () => Promise<void>;
  setPageSize: (limit: number) => Promise<void>;
  
  // UI Actions
  openAddDialog: () => void;
  openEditDialog: (role: Role) => void;
  openViewDialog: (role: Role) => void;
  openDeleteDialog: (role: Role) => void;
  closeAllDialogs: () => void;
  
  // Filter Actions
  setFilters: (filters: Partial<RoleFilters>) => void;
  setSearchFilter: (search: string) => void;
  setImmediateFilter: (filters: Partial<RoleFilters>) => void;
  clearFilters: () => void;
  
  // Utility Actions
  setFormData: (data: Partial<RoleFormData>) => void;
  resetForm: () => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  clearError: () => void;
  setOperationLoading: (operation: keyof RolesState['operationLoading'], loading: boolean) => void;
  getFilteredRoles: () => Role[];
}

const initialFormData: RoleFormData = {
  name: '',
  description: '',
  permissions: [],
  isActive: true,
};

const initialFilters: RoleFilters = {
  search: '',
  status: 'all',
};

const initialPagination = {
  page: 1,
  limit: 10,
  total: 0,
  totalPages: 0,
};

const initialOperationLoading = {
  create: false,
  update: false,
  delete: false,
  fetchRoles: false,
  fetchPermissions: false,
  toggleStatus: false,
};

export const useRolesStore = create<RolesState>((set, get) => ({
  // Initial State
  roles: [],
  permissions: [],
  loading: false,
  error: null,
  operationLoading: initialOperationLoading,
  pagination: initialPagination,
  filters: initialFilters,
  isAddDialogOpen: false,
  isEditDialogOpen: false,
  isViewDialogOpen: false,
  isDeleteDialogOpen: false,
  selectedRole: null,
  formData: initialFormData,
  searchTimeout: null,

  // Cleanup method
  cleanup: () => {
    const state = get();
    if (state.searchTimeout) {
      clearTimeout(state.searchTimeout);
      set({ searchTimeout: null });
    }
  },

  // Utility Actions
  setLoading: (loading: boolean) => set({ loading }),
  setError: (error: string | null) => set({ error }),
  clearError: () => set({ error: null }),
  setOperationLoading: (operation: keyof RolesState['operationLoading'], loading: boolean) => {
    set((state) => ({
      operationLoading: {
        ...state.operationLoading,
        [operation]: loading,
      },
    }));
  },

  // API Actions
  fetchRoles: async (page = 1, limit = 10) => {
    get().setOperationLoading('fetchRoles', true);
    set({ loading: true, error: null });
    
    try {
      const { filters } = get();
      const params = {
        page,
        limit,
        search: filters.search || undefined,
        status: filters.status !== 'all' ? filters.status : undefined,
      };

      const response = await rolesService.getRoles(params);
      
      if (rolesService.isErrorResponse(response)) {
        const errorMessage = rolesService.getErrorMessage(response);
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('fetchRoles', false);
      } else {
        const rolesResponse = response as RolesApiResponse;
        set({ 
          roles: rolesResponse.data, 
          pagination: rolesResponse.pagination,
          loading: false 
        });
        get().setOperationLoading('fetchRoles', false);
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('fetchRoles', false);
    }
  },

  fetchPermissions: async () => {
    // Don't set loading to true if permissions are already loaded to avoid UI flicker
    const currentState = get();
    get().setOperationLoading('fetchPermissions', true);
    if (currentState.permissions.length === 0) {
      set({ loading: true, error: null });
    }
    
    try {
      const response = await rolesService.getPermissions();
      
      if (rolesService.isErrorResponse(response)) {
        const errorMessage = rolesService.getErrorMessage(response);
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('fetchPermissions', false);
      } else {
        const permissionsResponse = response as PermissionsApiResponse;
        set({ permissions: permissionsResponse.data, loading: false });
        get().setOperationLoading('fetchPermissions', false);
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('fetchPermissions', false);
    }
  },

  createRole: async (roleData: CreateRoleRequest): Promise<boolean> => {
    get().setOperationLoading('create', true);
    set({ loading: true, error: null });
    
    try {
      // Validate data before sending
      const validation = rolesService.validateRoleData(roleData);
      if (!validation.isValid) {
        set({ error: validation.errors.join(', '), loading: false });
        get().setOperationLoading('create', false);
        return false;
      }

      const transformedData = rolesService.transformRoleForSubmission(roleData);
      const response = await rolesService.createRole(transformedData as CreateRoleRequest);
      
      if (rolesService.isErrorResponse(response)) {
        const errorMessage = rolesService.getErrorMessage(response);
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('create', false);
        return false;
      } else {
        // Reload roles after creation - reset to first page to show the new role
        await get().fetchRoles(1, get().pagination.limit);
        set({ loading: false });
        get().setOperationLoading('create', false);
        return true;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('create', false);
      return false;
    }
  },

  updateRole: async (id: string, updates: UpdateRoleRequest): Promise<boolean> => {
    get().setOperationLoading('update', true);
    set({ loading: true, error: null });
    
    try {
      // Validate data before sending
      const validation = rolesService.validateRoleData(updates);
      if (!validation.isValid) {
        set({ error: validation.errors.join(', '), loading: false });
        get().setOperationLoading('update', false);
        return false;
      }

      const transformedData = rolesService.transformRoleForSubmission(updates);
      const response = await rolesService.updateRole(id, transformedData as UpdateRoleRequest);
      
      if (rolesService.isErrorResponse(response)) {
        const errorMessage = rolesService.getErrorMessage(response);
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('update', false);
        return false;
      } else {
        // Reload roles after update
        await get().fetchRoles(get().pagination.page, get().pagination.limit);
        set({ loading: false });
        get().setOperationLoading('update', false);
        return true;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('update', false);
      return false;
    }
  },

  deleteRole: async (id: string): Promise<boolean> => {
    get().setOperationLoading('delete', true);
    set({ loading: true, error: null });
    
    try {
      const response = await rolesService.deleteRole(id);
      
      if (rolesService.isErrorResponse(response)) {
        const errorMessage = rolesService.getErrorMessage(response);
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('delete', false);
        return false;
      } else {
        // Reload roles after deletion
        const currentPagination = get().pagination;
        let targetPage = currentPagination.page;
        
        // If we're on the last page and it might become empty, go to previous page
        if (currentPagination.page > 1 && 
            currentPagination.total > 0 && 
            (currentPagination.total - 1) <= (currentPagination.page - 1) * currentPagination.limit) {
          targetPage = currentPagination.page - 1;
        }
        
        await get().fetchRoles(targetPage, currentPagination.limit);
        set({ loading: false });
        get().setOperationLoading('delete', false);
        return true;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('delete', false);
      return false;
    }
  },

  toggleRoleStatus: async (id: string): Promise<boolean> => {
    get().setOperationLoading('toggleStatus', true);
    set({ loading: true, error: null });
    
    try {
      // Find the current role to get its current status
      const currentRole = get().roles.find(role => role.id === id);
      if (!currentRole) {
        set({ error: 'Rôle introuvable', loading: false });
        get().setOperationLoading('toggleStatus', false);
        return false;
      }

      const response = await rolesService.toggleRoleStatus(id, !currentRole.isActive);
      
      if (rolesService.isErrorResponse(response)) {
        const errorMessage = rolesService.getErrorMessage(response);
        set({ error: errorMessage, loading: false });
        get().setOperationLoading('toggleStatus', false);
        return false;
      } else {
        // Reload roles after status change
        await get().fetchRoles(get().pagination.page, get().pagination.limit);
        set({ loading: false });
        get().setOperationLoading('toggleStatus', false);
        return true;
      }
    } catch (error) {
      set({ error: 'Erreur de connexion', loading: false });
      get().setOperationLoading('toggleStatus', false);
      return false;
    }
  },

  // Pagination Actions
  goToPage: async (page: number) => {
    const { pagination } = get();
    if (page >= 1 && page <= pagination.totalPages && page !== pagination.page) {
      await get().fetchRoles(page, pagination.limit);
    }
  },

  goToNextPage: async () => {
    const { pagination } = get();
    if (pagination.page < pagination.totalPages) {
      await get().fetchRoles(pagination.page + 1, pagination.limit);
    }
  },

  goToPreviousPage: async () => {
    const { pagination } = get();
    if (pagination.page > 1) {
      await get().fetchRoles(pagination.page - 1, pagination.limit);
    }
  },

  goToFirstPage: async () => {
    const { pagination } = get();
    if (pagination.page !== 1) {
      await get().fetchRoles(1, pagination.limit);
    }
  },

  goToLastPage: async () => {
    const { pagination } = get();
    if (pagination.page !== pagination.totalPages && pagination.totalPages > 0) {
      await get().fetchRoles(pagination.totalPages, pagination.limit);
    }
  },

  setPageSize: async (limit: number) => {
    const { pagination } = get();
    if (limit !== pagination.limit && limit > 0) {
      // Reset to first page when changing page size
      await get().fetchRoles(1, limit);
    }
  },

  // Dialog Actions
  openAddDialog: () => {
    set({
      isAddDialogOpen: true,
      formData: initialFormData,
    });
    
    // Ensure permissions are loaded when opening add dialog
    const state = get();
    if (state.permissions.length === 0) {
      get().fetchPermissions();
    }
  },

  openEditDialog: (role: Role) => {
    set({
      isEditDialogOpen: true,
      selectedRole: role,
      formData: {
        name: role.name,
        description: role.description || '',
        permissions: role.permissions.map(permission => permission.id),
        isActive: role.isActive,
      },
    });
    
    // Ensure permissions are loaded when opening edit dialog
    const state = get();
    if (state.permissions.length === 0) {
      get().fetchPermissions();
    }
  },

  openViewDialog: (role: Role) => {
    set({
      isViewDialogOpen: true,
      selectedRole: role,
    });
  },

  openDeleteDialog: (role: Role) => {
    set({
      isDeleteDialogOpen: true,
      selectedRole: role,
    });
  },

  closeAllDialogs: () => {
    set({
      isAddDialogOpen: false,
      isEditDialogOpen: false,
      isViewDialogOpen: false,
      isDeleteDialogOpen: false,
      selectedRole: null,
    });
  },

  // Filter Actions with Search Debouncing
  setFilters: (newFilters: Partial<RoleFilters>) => {
    const state = get();
    
    // Clear existing search timeout if setting search filter
    if (newFilters.search !== undefined && state.searchTimeout) {
      clearTimeout(state.searchTimeout);
    }
    
    set((state) => ({ 
      filters: { ...state.filters, ...newFilters },
      pagination: { ...state.pagination, page: 1 }, // Reset to first page when filtering
      searchTimeout: null
    }));
    
    // If search filter is being set, use debouncing
    if (newFilters.search !== undefined) {
      const timeout = setTimeout(() => {
        get().fetchRoles(1, get().pagination.limit);
      }, 300); // 300ms debounce delay
      
      set({ searchTimeout: timeout });
    } else {
      // For non-search filters, fetch immediately
      get().fetchRoles(1, get().pagination.limit);
    }
  },

  setSearchFilter: (search: string) => {
    const state = get();
    
    // Clear existing timeout
    if (state.searchTimeout) {
      clearTimeout(state.searchTimeout);
    }
    
    // Update search filter immediately for UI responsiveness
    set((state) => ({ 
      filters: { ...state.filters, search },
      pagination: { ...state.pagination, page: 1 }
    }));
    
    // Debounce the API call
    const timeout = setTimeout(() => {
      get().fetchRoles(1, get().pagination.limit);
      set({ searchTimeout: null });
    }, 300); // 300ms debounce delay
    
    set({ searchTimeout: timeout });
  },

  setImmediateFilter: (newFilters: Partial<RoleFilters>) => {
    const state = get();
    
    // Clear existing search timeout
    if (state.searchTimeout) {
      clearTimeout(state.searchTimeout);
    }
    
    set((state) => ({ 
      filters: { ...state.filters, ...newFilters },
      pagination: { ...state.pagination, page: 1 },
      searchTimeout: null
    }));
    
    // Fetch immediately without debouncing
    get().fetchRoles(1, get().pagination.limit);
  },

  clearFilters: () => {
    const state = get();
    
    // Clear any pending search timeout
    if (state.searchTimeout) {
      clearTimeout(state.searchTimeout);
    }
    
    set({ 
      filters: initialFilters,
      pagination: { ...get().pagination, page: 1 },
      searchTimeout: null
    });
    
    // Reload roles without filters
    get().fetchRoles(1, get().pagination.limit);
  },

  // Form Actions
  setFormData: (data: Partial<RoleFormData>) => {
    set((state) => ({ formData: { ...state.formData, ...data } }));
  },

  resetForm: () => {
    set({ formData: initialFormData });
  },

  // Utility Actions
  getFilteredRoles: (): Role[] => {
    const { roles, filters } = get();
    
    if (!roles.length) return [];
    
    return roles.filter(role => {
      // Search filter (name, description)
      if (filters.search && filters.search.trim()) {
        const searchTerm = filters.search.toLowerCase().trim();
        const matchesSearch = 
          role.name.toLowerCase().includes(searchTerm) ||
          (role.description && role.description.toLowerCase().includes(searchTerm));
        if (!matchesSearch) return false;
      }
      
      // Status filter
      if (filters.status && filters.status !== 'all') {
        if (filters.status === 'active' && !role.isActive) return false;
        if (filters.status === 'inactive' && role.isActive) return false;
      }
      
      return true;
    });
  },
}));