import { create } from 'zustand';
import { PaymentMethod } from '../services/paymentService';
import { ApiSuccessResponse } from '../types/api';

interface PublicPaymentMethodsStore {
  paymentMethods: PaymentMethod[];
  loading: boolean;
  error: string | null;
  lastFetch: number | null;
  cacheExpiry: number;
  
  fetchPaymentMethods: () => Promise<void>;
  refetch: () => Promise<void>;
  clearCache: () => void;
  isDataFresh: () => boolean;
}

// Cache duration: 5 minutes (300000ms)
const CACHE_DURATION = 5 * 60 * 1000;

// Fallback payment methods in case of API failure
const fallbackPaymentMethods: PaymentMethod[] = [
  {
    id: 'cash',
    name: 'Espèces',
    description: 'Paiement en espèces à la livraison',
    type: 'CASH',
    processingTime: 'Immédiat',
    isActive: true,
    isDefault: true
  },
  {
    id: 'mobile-money',
    name: 'Mobile Money',
    description: 'Paiement par téléphone mobile',
    type: 'MOBILE_MONEY',
    provider: 'Orange Money / Wave',
    processingTime: '1-2 minutes',
    isActive: true
  },
  {
    id: 'bank-transfer',
    name: 'Virement bancaire',
    description: 'Paiement par virement bancaire',
    type: 'BANK_TRANSFER',
    processingTime: '24-48 heures',
    isActive: true
  }
];

export const usePublicPaymentMethodsStore = create<PublicPaymentMethodsStore>((set, get) => ({
  paymentMethods: [],
  loading: false,
  error: null,
  lastFetch: null,
  cacheExpiry: CACHE_DURATION,

  isDataFresh: () => {
    const { lastFetch, cacheExpiry } = get();
    if (!lastFetch) return false;
    return Date.now() - lastFetch < cacheExpiry;
  },

  fetchPaymentMethods: async () => {
    const { isDataFresh, loading } = get();
    
    // If data is fresh or already loading, don't fetch again
    if (isDataFresh() || loading) {
      return;
    }

    set({ loading: true, error: null });
    
    try {
      const response = await fetch('/api/payments/methods/public');
      
      if (!response.ok) {
        throw new Error(`HTTP Error: ${response.status}`);
      }
      
      const result: ApiSuccessResponse<{ methods: PaymentMethod[]; meta: any }> = await response.json();
      
      if (!result.success) {
        throw new Error('Failed to fetch payment methods from API');
      }
      
      // Extract methods from the nested structure
      const methods = result.data.methods || [];
      
      set({
        paymentMethods: methods,
        loading: false,
        error: null,
        lastFetch: Date.now()
      });
      
    } catch (error) {
      console.error('Error fetching public payment methods:', error);
      
      // Use fallback payment methods if we don't have any cached data
      const currentPaymentMethods = get().paymentMethods;
      const paymentMethodsToUse = currentPaymentMethods.length > 0 ? currentPaymentMethods : fallbackPaymentMethods;
      
      set({
        paymentMethods: paymentMethodsToUse,
        loading: false,
        error: error instanceof Error ? error.message : 'Failed to fetch payment methods',
        // Don't update lastFetch on error to allow retry
      });
    }
  },

  refetch: async () => {
    // Force refetch by clearing cache timestamp
    set({ lastFetch: null });
    await get().fetchPaymentMethods();
  },

  clearCache: () => {
    set({
      paymentMethods: [],
      lastFetch: null,
      error: null
    });
  }
}));