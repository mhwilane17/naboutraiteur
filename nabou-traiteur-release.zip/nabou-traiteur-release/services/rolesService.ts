import {
  Role,
  Permission,
  CreateRoleRequest,
  UpdateRoleRequest,
  RolesApiResponse,
  PermissionsApiResponse,
  RoleErrorCodes,
  RoleErrorMessages,
  RoleSearchParams,
  PermissionSearchParams,
} from "@/types/roles";
import { ApiSuccessResponse, ApiErrorResponse } from "@/types/api";

/**
 * Service for managing roles and permissions through API calls
 * Handles all CRUD operations for roles and permission retrieval
 */
export class RolesService {
  private baseUrl = "/api";

  /**
   * Fetch roles with optional pagination and filtering
   */
  async getRoles(
    params?: RoleSearchParams
  ): Promise<RolesApiResponse | ApiErrorResponse> {
    try {
      const searchParams = new URLSearchParams();

      if (params?.page) searchParams.set("page", params.page.toString());
      if (params?.limit) searchParams.set("limit", params.limit.toString());
      if (params?.search) searchParams.set("search", params.search);
      if (params?.status && params.status !== "all") {
        searchParams.set("isActive", (params.status === "active").toString());
      }

      const url = `${this.baseUrl}/roles${
        searchParams.toString() ? `?${searchParams.toString()}` : ""
      }`;
      const response = await fetch(url, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (!response.ok) {
        return this.handleErrorResponse(data, response.status);
      }

      return data.data as RolesApiResponse;
    } catch (error) {
      return this.createNetworkError(error);
    }
  }

  /**
   * Fetch a single role by ID
   */
  async getRole(
    id: string
  ): Promise<ApiSuccessResponse<Role> | ApiErrorResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/roles/${id}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (!response.ok) {
        return this.handleErrorResponse(data, response.status);
      }

      return data as ApiSuccessResponse<Role>;
    } catch (error) {
      return this.createNetworkError(error);
    }
  }

  /**
   * Create a new role
   */
  async createRole(
    roleData: CreateRoleRequest
  ): Promise<ApiSuccessResponse<Role> | ApiErrorResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/roles`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(roleData),
      });

      const data = await response.json();

      if (!response.ok) {
        return this.handleErrorResponse(data, response.status);
      }

      return data as ApiSuccessResponse<Role>;
    } catch (error) {
      return this.createNetworkError(error);
    }
  }

  /**
   * Update an existing role
   */
  async updateRole(
    id: string,
    updates: UpdateRoleRequest
  ): Promise<ApiSuccessResponse<Role> | ApiErrorResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/roles/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updates),
      });

      const data = await response.json();

      if (!response.ok) {
        return this.handleErrorResponse(data, response.status);
      }

      return data as ApiSuccessResponse<Role>;
    } catch (error) {
      return this.createNetworkError(error);
    }
  }

  /**
   * Delete a role by ID
   */
  async deleteRole(
    id: string
  ): Promise<ApiSuccessResponse<{ message: string }> | ApiErrorResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/roles/${id}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (!response.ok) {
        return this.handleErrorResponse(data, response.status);
      }

      return data as ApiSuccessResponse<{ message: string }>;
    } catch (error) {
      return this.createNetworkError(error);
    }
  }

  /**
   * Toggle role status (activate/deactivate)
   */
  async toggleRoleStatus(
    id: string,
    isActive: boolean
  ): Promise<ApiSuccessResponse<Role> | ApiErrorResponse> {
    return this.updateRole(id, { isActive });
  }

  /**
   * Fetch all permissions with optional filtering
   */
  async getPermissions(
    params?: PermissionSearchParams
  ): Promise<PermissionsApiResponse | ApiErrorResponse> {
    try {
      const searchParams = new URLSearchParams();

      if (params?.page) searchParams.set("page", params.page.toString());
      if (params?.limit) searchParams.set("limit", params.limit.toString());
      if (params?.search) searchParams.set("search", params.search);
      if (params?.module) searchParams.set("module", params.module);
      if (params?.action) searchParams.set("action", params.action);

      const url = `${this.baseUrl}/permissions${
        searchParams.toString() ? `?${searchParams.toString()}` : ""
      }`;
      const response = await fetch(url, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (!response.ok) {
        return this.handleErrorResponse(data, response.status);
      }

      return data.data as PermissionsApiResponse;
    } catch (error) {
      return this.createNetworkError(error);
    }
  }

  /**
   * Check if a response is an error response
   */
  isErrorResponse(response: any): response is ApiErrorResponse {
    return response && response.success === false && response.error;
  }

  /**
   * Extract error message from API error response
   */
  getErrorMessage(response: ApiErrorResponse): string {
    if (response.error?.message) {
      return response.error.message;
    }

    // Try to map error codes to user-friendly messages
    const errorCode = response.error?.code as RoleErrorCodes;
    if (errorCode && RoleErrorMessages[errorCode]) {
      return RoleErrorMessages[errorCode];
    }

    return "Une erreur inattendue s'est produite";
  }

  /**
   * Get error code from API error response
   */
  getErrorCode(response: ApiErrorResponse): string {
    return response.error?.code || "UNKNOWN_ERROR";
  }

  /**
   * Check if error is a validation error
   */
  isValidationError(response: ApiErrorResponse): boolean {
    return this.getErrorCode(response) === RoleErrorCodes.VALIDATION_ERROR;
  }

  /**
   * Check if error is a conflict error (duplicate name, etc.)
   */
  isConflictError(response: ApiErrorResponse): boolean {
    const code = this.getErrorCode(response);
    return (
      code === RoleErrorCodes.ROLE_NAME_EXISTS ||
      code === RoleErrorCodes.ROLE_ID_EXISTS ||
      code === RoleErrorCodes.CANNOT_DELETE_ROLE_WITH_USERS ||
      code === RoleErrorCodes.CANNOT_DELETE_SYSTEM_ROLE
    );
  }

  /**
   * Check if error is a not found error
   */
  isNotFoundError(response: ApiErrorResponse): boolean {
    return this.getErrorCode(response) === RoleErrorCodes.ROLE_NOT_FOUND;
  }

  /**
   * Check if error is a permissions error
   */
  isPermissionsError(response: ApiErrorResponse): boolean {
    const code = this.getErrorCode(response);
    return (
      code === RoleErrorCodes.INVALID_PERMISSIONS ||
      code === RoleErrorCodes.INSUFFICIENT_PERMISSIONS
    );
  }

  /**
   * Validate role data before sending to API
   */
  validateRoleData(data: CreateRoleRequest | UpdateRoleRequest): {
    isValid: boolean;
    errors: string[];
  } {
    const errors: string[] = [];

    // Validate name
    if ("name" in data && data.name !== undefined) {
      if (!data.name || data.name.trim().length < 2) {
        errors.push("Le nom du rôle doit contenir au moins 2 caractères");
      }
      if (data.name.length > 100) {
        errors.push("Le nom du rôle ne peut pas dépasser 100 caractères");
      }
    }

    // Validate ID for creation
    if ("id" in data && data.id !== undefined) {
      if (!data.id || data.id.trim().length < 2) {
        errors.push(
          "L'identifiant du rôle doit contenir au moins 2 caractères"
        );
      }
      if (data.id.length > 50) {
        errors.push("L'identifiant du rôle ne peut pas dépasser 50 caractères");
      }
    }

    // Validate description
    if (
      data.description !== undefined &&
      data.description !== null &&
      data.description.length > 500
    ) {
      errors.push("La description ne peut pas dépasser 500 caractères");
    }

    // Validate permissions
    if (data.permissionIds !== undefined) {
      if (!Array.isArray(data.permissionIds)) {
        errors.push("Les permissions doivent être un tableau d'identifiants");
      } else {
        for (const permissionId of data.permissionIds) {
          if (typeof permissionId !== "string" || !permissionId.trim()) {
            errors.push(
              "Tous les identifiants de permissions doivent être des chaînes non vides"
            );
            break;
          }
        }
      }
    }

    return {
      isValid: errors.length === 0,
      errors,
    };
  }

  /**
   * Transform role data for API submission
   */
  transformRoleForSubmission(data: any): CreateRoleRequest | UpdateRoleRequest {
    const transformed: any = {};

    if (data.id !== undefined) transformed.id = data.id.trim();
    if (data.name !== undefined) transformed.name = data.name.trim();
    if (data.description !== undefined) {
      transformed.description = data.description
        ? data.description.trim()
        : undefined;
    }
    if (data.isActive !== undefined)
      transformed.isActive = Boolean(data.isActive);
    if (data.permissionIds !== undefined) {
      transformed.permissionIds = Array.isArray(data.permissionIds)
        ? data.permissionIds
        : [];
    }

    return transformed;
  }

  /**
   * Handle API error responses and map to standardized format
   */
  private handleErrorResponse(data: any, status: number): ApiErrorResponse {
    // If already in correct format, return as is
    if (data && data.success === false && data.error) {
      return data as ApiErrorResponse;
    }

    // Map HTTP status codes to error responses
    let errorCode = "UNKNOWN_ERROR";
    let errorMessage = "Une erreur inattendue s'est produite";

    switch (status) {
      case 400:
        errorCode = RoleErrorCodes.VALIDATION_ERROR;
        errorMessage = data?.message || "Données invalides";
        break;
      case 401:
        errorCode = RoleErrorCodes.INSUFFICIENT_PERMISSIONS;
        errorMessage = "Authentification requise";
        break;
      case 403:
        errorCode = RoleErrorCodes.INSUFFICIENT_PERMISSIONS;
        errorMessage = "Permissions insuffisantes";
        break;
      case 404:
        errorCode = RoleErrorCodes.ROLE_NOT_FOUND;
        errorMessage = "Rôle introuvable";
        break;
      case 409:
        errorCode = RoleErrorCodes.ROLE_NAME_EXISTS;
        errorMessage = data?.message || "Conflit de données";
        break;
      case 500:
        errorMessage = "Erreur interne du serveur";
        break;
    }

    return {
      success: false,
      error: {
        code: errorCode,
        message: errorMessage,
        details: data,
      },
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Create error response for network/fetch errors
   */
  private createNetworkError(error: any): ApiErrorResponse {
    return {
      success: false,
      error: {
        code: "NETWORK_ERROR",
        message: "Erreur de connexion au serveur",
        details: error instanceof Error ? error.message : String(error),
      },
      timestamp: new Date().toISOString(),
    };
  }
}

// Export singleton instance
export const rolesService = new RolesService();
export default rolesService;
