import { GuestOrderData } from "./orderService";
import { OrderFormData, ReservationMode } from "@/lib/reservation-utils";
import { WeeklyMenuItem } from "@/types/weeklyMenuPublic";

export interface ReservationSubmissionData {
  formData: OrderFormData;
  quantity: number;
  menuSize: string;
  promoCode?: string;
  isPromoValid: boolean;
}

export interface CartOrderData {
  items: any[];
  weeklyMenuId: string;
  promoCode?: string;
}

export class ReservationService {
  /**
   * Prépare les données de commande pour un article unique
   */
  static prepareDirectOrderData(
    item: WeeklyMenuItem,
    data: ReservationSubmissionData
  ): GuestOrderData {
    const { formData, quantity, menuSize, promoCode, isPromoValid } = data;

    const orderItems = [
      {
        menuItemId: item.menuItemId,
        quantity: quantity,
        options: {
          size: menuSize,
        },
      },
    ];

    const promotionCode = item.hasRakTakPromo
      ? item.rakTakPromoCode || undefined
      : isPromoValid && promoCode
        ? promoCode.toUpperCase()
        : undefined;

    return {
      items: orderItems,
      customerInfo: {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        email: formData.email || undefined,
        company: formData.company || undefined,
        employeeId: formData.employeeId || undefined,
      },
      deliveryInfo: {
        deliveryZoneId: formData.deliveryZoneId,
        deliveryAddress: formData.deliveryAddress,
        deliveryTime: formData.deliveryTime,
        type: "delivery",
      },
      customerNotes: formData.customerNotes || undefined,
      paymentMethod: formData.paymentMethod,
      weeklyMenuId: item.weeklyMenuId,
      promotionCode,
    };
  }

  /**
   * Prépare les données de commande depuis le panier
   */
  static prepareCartOrderData(
    cartData: CartOrderData,
    formData: OrderFormData,
    promoCode?: string,
    isPromoValid?: boolean
  ): GuestOrderData {
    const promotionCode = isPromoValid && promoCode
      ? promoCode.toUpperCase()
      : undefined;

    return {
      items: cartData.items,
      customerInfo: {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        email: formData.email || undefined,
        company: formData.company || undefined,
        employeeId: formData.employeeId || undefined,
      },
      deliveryInfo: {
        deliveryZoneId: formData.deliveryZoneId,
        deliveryAddress: formData.deliveryAddress,
        deliveryTime: formData.deliveryTime,
        type: "delivery",
      },
      customerNotes: formData.customerNotes || undefined,
      paymentMethod: formData.paymentMethod,
      weeklyMenuId: cartData.weeklyMenuId,
      promotionCode,
    };
  }

  /**
   * Valide les données avant soumission
   */
  static validateSubmissionData(
    mode: ReservationMode,
    item?: WeeklyMenuItem,
    cartItems?: any[]
  ): { isValid: boolean; error?: string } {
    const { orderFromCart } = mode;

    if (orderFromCart) {
      if (!cartItems || cartItems.length === 0) {
        return {
          isValid: false,
          error: "Panier vide"
        };
      }
    } else {
      if (!item?.menuItemId) {
        return {
          isValid: false,
          error: "menuItemId manquant"
        };
      }
    }

    return { isValid: true };
  }

  /**
   * Valide les options obligatoires pour le mode panier
   */
  static validateCartModeOptions(
    item: WeeklyMenuItem,
    menuSize: string
  ): { isValid: boolean; error?: string } {
    // Vérifier qu'une taille/option est sélectionnée
    if (!menuSize || menuSize.trim() === "") {
      return {
        isValid: false,
        error: "Veuillez sélectionner une option avant d'ajouter au panier"
      };
    }

    // Vérifier que l'option sélectionnée existe
    const selectedOption = item?.options.find(opt => opt.name === menuSize);
    if (!selectedOption) {
      return {
        isValid: false,
        error: "Option sélectionnée invalide"
      };
    }

    return { isValid: true };
  }

  /**
   * Prépare les données pour l'ajout au panier
   */
  static prepareCartItemData(
    item: WeeklyMenuItem,
    quantity: number,
    menuSize: string
  ) {
    return {
      item,
      quantity,
      menuSize
    };
  }

  /**
   * Génère un message de succès selon le type d'action
   */
  static getSuccessMessage(
    actionType: string,
    mode: ReservationMode,
    itemName?: string,
    quantity?: number
  ): string {
    const { cartMode } = mode;

    if (cartMode && itemName && quantity) {
      return `${itemName} ajouté au panier (${quantity}x)`;
    }

    return `${actionType.charAt(0).toUpperCase() + actionType.slice(1)} créée avec succès !`;
  }

  /**
   * Génère un message de succès pour la commande depuis le panier
   */
  static getCartOrderSuccessMessage(clearedItemsCount: number): string {
    return `Commande confirmée ! ${clearedItemsCount} article${clearedItemsCount > 1 ? 's ont été supprimés' : ' a été supprimé'} de votre panier.`;
  }
}