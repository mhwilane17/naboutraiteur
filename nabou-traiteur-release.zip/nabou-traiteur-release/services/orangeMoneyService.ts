import { prisma } from "@/lib/prisma";
import { Logger } from "@/lib/logger";
import { ERROR_CODES } from "@/lib/error-codes";

// ============================================================================
// TYPES AND INTERFACES
// ============================================================================

interface OrangeMoneyConfig {
  client_id: string;
  client_secret: string;
  grant_type: string;
  currency: string;
  merchant_code: string;
  merchant_name: string;
  validity: number;
  auth_url: string;
  checkout_url: string;
  encrypted_pin_code: string;
  customer_msisdn: string;
  partner_msisdn: string;
  public_key: string;
}

interface OAuthTokenResponse {
  access_token: string;
  expires_in: number;
  token_type: string;
}

interface BalanceResponse {
  value: number;
  unit: string;
}

interface CashInRequest {
  partner: {
    idType: "MSISDN";
    encryptedPinCode: string;
    id: string;
  };
  customer: {
    idType: "MSISDN";
    id: string;
  };
  amount: {
    value: number;
    unit: string;
  };
  reference: string;
  receiveNotification: boolean;
}

interface CashInResponse {
  reference: string;
  transactionId: string;
  requestId: string;
  status: string;
  description: string;
}

// ============================================================================
// ORANGE MONEY SERVICE
// ============================================================================

class OrangeMoneyService {
  private config: OrangeMoneyConfig | null = null;
  private accessToken: string | null = null;
  private tokenExpiry: number = 0;

  /**
   * Retrieves Orange Money configuration from the PaymentMethod table
   * Validates: Requirements 3.4
   */
  async getConfig(): Promise<OrangeMoneyConfig> {
    try {
      // Check if config is already cached
      if (this.config) {
        return this.config;
      }

      // Retrieve configuration from database
      const paymentMethod = await prisma.paymentMethod.findFirst({
        where: {
          provider: "Sonatel",
          //   isActive: true,
        },
      });

      if (!paymentMethod) {
        Logger.error(
          "Orange Money configuration not found in database",
          undefined,
          {
            provider: "Sonatel",
          }
        );
        throw new Error(ERROR_CODES.SYSTEM_EXTERNAL_SERVICE_ERROR);
      }

      if (!paymentMethod.config) {
        Logger.error("Orange Money config field is empty", undefined, {
          paymentMethodId: paymentMethod.id,
        });
        throw new Error(ERROR_CODES.SYSTEM_EXTERNAL_SERVICE_ERROR);
      }

      // Parse and validate configuration
      const config = paymentMethod.config as unknown as OrangeMoneyConfig;

      // Validate required fields
      const requiredFields = [
        "client_id",
        "client_secret",
        "grant_type",
        "currency",
        "auth_url",
        "checkout_url",
        "encrypted_pin_code",
        "partner_msisdn",
      ];

      for (const field of requiredFields) {
        if (!config[field as keyof OrangeMoneyConfig]) {
          Logger.error(
            `Missing required Orange Money config field: ${field}`,
            undefined,
            {
              paymentMethodId: paymentMethod.id,
            }
          );
          throw new Error(ERROR_CODES.SYSTEM_EXTERNAL_SERVICE_ERROR);
        }
      }

      // Cache the configuration
      this.config = config;

      Logger.info("Orange Money configuration loaded successfully", undefined, {
        paymentMethodId: paymentMethod.id,
      });

      return config;
    } catch (error: any) {
      Logger.error("Failed to retrieve Orange Money configuration", undefined, {
        error: error.message,
      });
      throw error;
    }
  }

  /**
   * Authenticates with Orange Money API using OAuth
   * Implements token caching to avoid repeated auth calls
   * Validates: Requirements 3.1, 3.2
   */
  async authenticate(): Promise<string> {
    try {
      // Check if we have a valid cached token
      const now = Date.now();
      if (this.accessToken && this.tokenExpiry > now) {
        Logger.info("Using cached Orange Money OAuth token", undefined, {
          expiresIn: Math.floor((this.tokenExpiry - now) / 1000),
        });
        return this.accessToken;
      }

      // Get configuration
      const config = await this.getConfig();

      Logger.info("Requesting new Orange Money OAuth token", undefined, {
        auth_url: config.auth_url,
      });

      // Prepare OAuth request
      const authPayload = new URLSearchParams({
        client_id: config.client_id,
        client_secret: config.client_secret,
        grant_type: config.grant_type,
      });

      // Make OAuth request
      const response = await fetch(config.auth_url, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: authPayload,
      });

      if (!response.ok) {
        const errorText = await response.text();
        Logger.error("Orange Money OAuth authentication failed", undefined, {
          status: response.status,
          statusText: response.statusText,
          error: errorText,
        });
        throw new Error(ERROR_CODES.SYSTEM_EXTERNAL_SERVICE_ERROR);
      }

      const tokenResponse: OAuthTokenResponse = await response.json();

      // Cache the token with expiry (subtract 60 seconds for safety margin)
      this.accessToken = tokenResponse.access_token;
      this.tokenExpiry = Date.now() + (tokenResponse.expires_in - 60) * 1000;

      Logger.info("Orange Money OAuth token obtained successfully", undefined, {
        expires_in: tokenResponse.expires_in,
        token_type: tokenResponse.token_type,
      });

      return this.accessToken;
    } catch (error: any) {
      Logger.error("Failed to authenticate with Orange Money", undefined, {
        error: error.message,
      });
      throw error;
    }
  }

  /**
   * Retrieves the current balance from Orange Money
   * Validates: Requirements 1.1, 1.2
   */
  async getBalance(): Promise<BalanceResponse> {
    try {
      // Authenticate first
      const token = await this.authenticate();
      const config = await this.getConfig();

      Logger.info("Requesting Orange Money balance", undefined, {
        partner_msisdn: config.partner_msisdn,
      });

      // Prepare balance request
      const balanceUrl = `https://api.orange-sonatel.com/api/eWallet/v1/account/retailer/balance`;

      const payload = {
        idType: "MSISDN",
        id: config.partner_msisdn,
        encryptedPinCode: config.encrypted_pin_code,
        wallet: "PRINCIPAL",
      };

      const response = await fetch(balanceUrl, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorText = await response.text();
        Logger.error("Orange Money balance request failed", undefined, {
          status: response.status,
          statusText: response.statusText,
          error: errorText,
        });
        throw new Error(ERROR_CODES.SYSTEM_EXTERNAL_SERVICE_ERROR);
      }

      const balanceData = await response.json();

      Logger.info("Orange Money balance retrieved successfully", undefined, {
        value: balanceData.value,
        unit: balanceData.unit,
      });

      return {
        value: balanceData.value,
        unit: balanceData.unit || config.currency,
      };
    } catch (error: any) {
      Logger.error("Failed to retrieve Orange Money balance", undefined, {
        error: error.message,
      });
      throw error;
    }
  }

  /**
   * Performs a cash-in operation
   * Validates: Requirements 2.3, 2.4
   */
  async cashIn(amount: number, reference?: string): Promise<CashInResponse> {
    try {
      // Authenticate first
      const token = await this.authenticate();
      const config = await this.getConfig();

      Logger.info("Initiating Orange Money cash-in", undefined, {
        amount,
        reference,
      });

      // Generate reference if not provided
      const txReference = reference || `CASHIN-${Date.now()}`;

      // Prepare cash-in request
      const cashInPayload: CashInRequest = {
        partner: {
          idType: "MSISDN",
          encryptedPinCode: config.encrypted_pin_code,
          id: config.partner_msisdn,
        },
        customer: {
          idType: "MSISDN",
          id: config.customer_msisdn,
        },
        amount: {
          value: amount,
          unit: config.currency,
        },
        reference: txReference,
        receiveNotification: true,
      };

      const cashInUrl = `https://api.orange-sonatel.com/api/eWallet/v1/cashins`;

      const response = await fetch(cashInUrl, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(cashInPayload),
      });

      if (!response.ok) {
        const errorText = await response.text();
        Logger.error("Orange Money cash-in request failed", undefined, {
          status: response.status,
          statusText: response.statusText,
          error: errorText,
          amount,
        });
        throw new Error(ERROR_CODES.SYSTEM_EXTERNAL_SERVICE_ERROR);
      }

      const cashInData = await response.json();

      Logger.info("Orange Money cash-in completed successfully", undefined, {
        transactionId: cashInData.transactionId,
        reference: cashInData.reference,
        status: cashInData.status,
      });

      return {
        reference: cashInData.reference,
        transactionId: cashInData.transactionId,
        requestId: cashInData.requestId,
        status: cashInData.status,
        description: cashInData.description,
      };
    } catch (error: any) {
      Logger.error("Failed to perform Orange Money cash-in", undefined, {
        error: error.message,
        amount,
      });
      throw error;
    }
  }

  /**
   * Clears the cached token (useful for testing or forcing re-authentication)
   */
  clearTokenCache(): void {
    this.accessToken = null;
    this.tokenExpiry = 0;
    Logger.info("Orange Money token cache cleared", undefined);
  }

  /**
   * Clears the cached configuration (useful for testing)
   */
  clearConfigCache(): void {
    this.config = null;
    Logger.info("Orange Money config cache cleared", undefined);
  }
}

// Export singleton instance
export const orangeMoneyService = new OrangeMoneyService();
