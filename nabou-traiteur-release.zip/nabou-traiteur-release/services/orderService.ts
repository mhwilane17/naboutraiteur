import { ApiSuccessResponse, ApiErrorResponse } from "@/types/api";

type ApiResponse<T> = ApiSuccessResponse<T> | ApiErrorResponse;

export interface OrderItem {
  menuItemId: string;
  quantity: number;
  options?: {
    size?: string;
    [key: string]: any;
  };
}

export interface GuestOrderData {
  items: OrderItem[];
  customerInfo: {
    firstName: string;
    lastName: string;
    phone: string;
    email?: string;
  };
  deliveryInfo: {
    // deliveryZone: string;
    deliveryTime: string;
    deliveryZoneId: string;
    deliveryAddress: string;
    type: "delivery" | "pickup";
  };
  customerNotes?: string;
  paymentMethod: string;
  promotionCode?: string;
  weeklyMenuId?: string;
  employeeId?: string; // Move employeeId to root level
}

export interface Order {
  id: string;
  orderNumber: string;
  status: string;
  totalAmount: string;
  deliveryFee: string;
  discountAmount: string;
  finalAmount: string;
  paymentStatus: string;
  deliveryDate: string | null;
  deliveryTime: string | null;
  createdAt: string;
  // Optionnel: informations d'initialisation de paiement (Orange/WAVE)
  paymentInit?: {
    qrCode: string;
    payment_link?: Record<string, string>;
  };
}

class OrderService {
  private baseUrl = "/api/orders";

  async createGuestOrder(
    orderData: GuestOrderData
  ): Promise<ApiResponse<Order>> {
    try {
      const response = await fetch(`${this.baseUrl}/guest`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(orderData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Erreur lors de la création de la commande"
        );
      }

      return {
        success: true,
        data: data.data.order,
        message: data.message || "Commande créée avec succès",
      } as ApiSuccessResponse<Order>;
    } catch (error) {
      console.error("Erreur lors de la création de la commande:", error);
      return {
        success: false,
        error: {
          code: "ORDER_CREATE_ERROR",
          message: error instanceof Error ? error.message : "Erreur inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  async getOrderById(orderId: string): Promise<ApiResponse<Order>> {
    try {
      const response = await fetch(`${this.baseUrl}/${orderId}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Erreur lors de la récupération de la commande"
        );
      }

      return {
        success: true,
        data: data.data,
      } as ApiSuccessResponse<Order>;
    } catch (error) {
      console.error("Erreur lors de la récupération de la commande:", error);
      return {
        success: false,
        error: {
          code: "ORDER_FETCH_ERROR",
          message: error instanceof Error ? error.message : "Erreur inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  async getOrderByNumber(orderNumber: string): Promise<ApiResponse<Order>> {
    try {
      const response = await fetch(`${this.baseUrl}/number/${orderNumber}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Erreur lors de la récupération de la commande"
        );
      }

      return {
        success: true,
        data: data.data,
      } as ApiSuccessResponse<Order>;
    } catch (error) {
      console.error("Erreur lors de la récupération de la commande:", error);
      return {
        success: false,
        error: {
          code: "ORDER_FETCH_ERROR",
          message: error instanceof Error ? error.message : "Erreur inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }
}

export const orderService = new OrderService();
export default orderService;
