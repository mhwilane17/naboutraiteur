import { prisma } from "@/lib/prisma";

export const RAKTAK_PROMO_ID = "cmdm6dysg0041i4yqts3j3iie";

export interface RakTakPromoStatus {
  isActiveNow: boolean;
  code: string | null;
}

export interface RakTakPromoDetails extends RakTakPromoStatus {
  type?: "percentage" | "fixed_amount" | "free_delivery";
  value?: number;
  maxDiscountAmount?: number | null;
}

// Vérifie si une heure HH:mm est dans une plage horaire [start, end]
// Gère aussi les plages qui chevauchent minuit (ex: 22:00 -> 02:00)
function isTimeWithinRange(currentHHMM: string, startHHMM: string, endHHMM: string): boolean {
  if (startHHMM <= endHHMM) {
    return currentHHMM >= startHHMM && currentHHMM <= endHHMM;
  }
  // Chevauchement minuit
  return currentHHMM >= startHHMM || currentHHMM <= endHHMM;
}

/**
 * Récupère les détails complets de la promo RakTak si elle est active maintenant.
 */
export async function getRakTakPromoDetails(
  now: Date = new Date()
): Promise<RakTakPromoDetails | null> {
  const promo = await prisma.promotion.findUnique({
    where: { id: RAKTAK_PROMO_ID },
    select: {
      code: true,
      isActive: true,
      startDate: true,
      endDate: true,
      activeStartTime: true,
      activeEndTime: true,
      type: true,
      value: true,
      maxDiscountAmount: true,
    },
  });

  if (!promo || !promo.isActive || !promo.startDate || !promo.endDate) {
    return null;
  }

  const withinDates = new Date(promo.startDate) <= now && new Date(promo.endDate) >= now;
  if (!withinDates) {
    return null;
  }

  const currentHHMM = now.toTimeString().slice(0, 5);
  let withinTime = true;
  if (promo.activeStartTime && promo.activeEndTime) {
    withinTime = isTimeWithinRange(currentHHMM, promo.activeStartTime, promo.activeEndTime);
  } else if (promo.activeStartTime && !promo.activeEndTime) {
    withinTime = currentHHMM >= promo.activeStartTime;
  } else if (!promo.activeStartTime && promo.activeEndTime) {
    withinTime = currentHHMM <= promo.activeEndTime;
  }

  if (!withinTime) {
    return null;
  }

  return {
    isActiveNow: true,
    code: promo.code,
    type: promo.type as "percentage" | "fixed_amount" | "free_delivery",
    value: Number(promo.value),
    maxDiscountAmount:
      promo.maxDiscountAmount !== null && promo.maxDiscountAmount !== undefined
        ? Number(promo.maxDiscountAmount)
        : null,
  };
}

/**
 * Calcule le montant de réduction net à partir des détails promo et d'un prix de base.
 */
export function computeRakTakDiscountFromDetails(
  details: RakTakPromoDetails | null,
  basePrice: number
): number | null {
  if (!details || !details.isActiveNow || !details.type || details.value === undefined) {
    return null;
  }

  let discount = 0;
  if (details.type === "percentage") {
    discount = (details.value * basePrice) / 100;
  } else if (details.type === "fixed_amount") {
    discount = details.value;
  } else {
    discount = 0;
  }

  if (details.maxDiscountAmount !== null && details.maxDiscountAmount !== undefined) {
    discount = Math.min(discount, details.maxDiscountAmount);
  }

  discount = Math.min(discount, basePrice);
  return Math.round(discount);
}

/**
 * Déduit, pour un plat donné, les champs RakTak à exposer.
 */
export function resolveDishRakTak(
  dishHasRakTakPromoFlag: boolean,
  promoStatus: RakTakPromoStatus
): { hasRakTakPromo: boolean; rakTakPromoCode: string | null } {
  const isActive = dishHasRakTakPromoFlag && promoStatus.isActiveNow;
  return {
    hasRakTakPromo: isActive,
    rakTakPromoCode: isActive ? promoStatus.code : null,
  };
}
