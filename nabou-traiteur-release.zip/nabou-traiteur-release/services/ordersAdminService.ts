import { ApiSuccessResponse, ApiErrorResponse } from "@/types/api";
import type { Order, OrderFilters } from "@/types/orders";

// Réponse pour la liste des commandes
export type OrdersListSuccess = ApiSuccessResponse<{
  orders: Order[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}>;

export type OrdersListResponse = OrdersListSuccess | ApiErrorResponse;
export type OrderResponse = ApiSuccessResponse<Order> | ApiErrorResponse;

export class OrdersAdminService {
  private static baseUrl = "/api/orders";

  // Liste des commandes avec filtres
  static async getOrders(params: OrderFilters = {}): Promise<OrdersListResponse> {
    try {
      const searchParams = new URLSearchParams();
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          searchParams.append(key, String(value));
        }
      });

      const url = `${this.baseUrl}?${searchParams.toString()}`;
      const response = await fetch(url, { method: "GET", headers: { "Content-Type": "application/json" } });
      const data = await response.json();

      if (!response.ok || !data.success) {
        return {
          success: false,
          error: {
            code: data.error?.code || "ORDERS_FETCH_ERROR",
            message: data.error?.message || data.message || "Erreur lors du chargement des commandes",
            details: data.error?.details,
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }

      return {
        success: true,
        data: {
          orders: data.data.orders,
          pagination: data.data.pagination,
        },
        message: data.message,
      } as OrdersListSuccess;
    } catch (error) {
      return {
        success: false,
        error: {
          code: "NETWORK_ERROR",
          message: error instanceof Error ? error.message : "Erreur réseau inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  // Détails d'une commande
  static async getOrderById(id: string): Promise<OrderResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/${id}`, { method: "GET", headers: { "Content-Type": "application/json" } });
      const data = await response.json();

      if (!response.ok || !data.success) {
        return {
          success: false,
          error: {
            code: data.error?.code || "ORDER_FETCH_ERROR",
            message: data.error?.message || data.message || "Erreur lors du chargement de la commande",
            details: data.error?.details,
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }

      return { success: true, data: data.data, message: data.message } as ApiSuccessResponse<Order>;
    } catch (error) {
      return {
        success: false,
        error: {
          code: "NETWORK_ERROR",
          message: error instanceof Error ? error.message : "Erreur réseau inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  // Mise à jour du statut d'une commande
  static async updateOrderStatus(
    id: string,
    status: Order["status"],
    adminNotes?: string
  ): Promise<OrderResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/${id}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, ...(adminNotes ? { adminNotes } : {}) }),
      });
      const data = await response.json();

      if (!response.ok || !data.success) {
        return {
          success: false,
          error: {
            code: data.error?.code || "ORDER_STATUS_UPDATE_ERROR",
            message: data.error?.message || data.message || "Erreur lors de la mise à jour du statut",
            details: data.error?.details,
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }

      return { success: true, data: data.data, message: data.message } as ApiSuccessResponse<Order>;
    } catch (error) {
      return {
        success: false,
        error: {
          code: "NETWORK_ERROR",
          message: error instanceof Error ? error.message : "Erreur réseau inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  // Mise à jour d'une commande (notes, adresse, etc.)
  static async updateOrder(id: string, updates: Partial<Order>): Promise<OrderResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      const data = await response.json();

      if (!response.ok || !data.success) {
        return {
          success: false,
          error: {
            code: data.error?.code || "ORDER_UPDATE_ERROR",
            message: data.error?.message || data.message || "Erreur lors de la mise à jour de la commande",
            details: data.error?.details,
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }

      return { success: true, data: data.data, message: data.message } as ApiSuccessResponse<Order>;
    } catch (error) {
      return {
        success: false,
        error: {
          code: "NETWORK_ERROR",
          message: error instanceof Error ? error.message : "Erreur réseau inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }
}

export default OrdersAdminService;