import { ApiSuccessResponse, ApiErrorResponse } from "@/types/api";
import {
  OrderFormData,
  ReservationMode,
  StepValidationResult,
  validateCurrentStep,
} from "@/lib/reservation-utils";
import { WeeklyMenuItem } from "@/types/weeklyMenuPublic";
import { CartItem } from "@/types/cart";
import {
  GuestOrderData,
  OrderItem as ServiceOrderItem,
  Order as ServiceOrder,
} from "@/services/orderService";
import { ReservationSubmissionData } from "@/services/reservationService";
import {
  validatePromoCode,
  PromoValidationResult,
} from "@/services/promoService";
import { useAuthStore } from "@/stores/authStore";

type ApiResponse<T> = ApiSuccessResponse<T> | ApiErrorResponse;

/**
 * Interface pour les totaux de commande
 */
export interface OrderTotals {
  subtotal: number;
  deliveryFee: number;
  promoDiscount: number;
  total: number;
}

/**
 * Service unifié pour la gestion des commandes
 * Combine les fonctionnalités de orderService et reservationService
 */
export class UnifiedOrderService {
  private baseUrl = "/api/orders";

  /**
   * Extrait les liens de paiement disponibles depuis un objet Order
   */
  extractPaymentLinks(order: ServiceOrder): Array<{ label: string; url: string }> {
    const links = order?.paymentInit?.payment_link || {};
    return Object.entries(links)
      .filter(([, url]) => typeof url === "string" && url.length > 0)
      .map(([label, url]) => ({ label, url }));
  }

  /**
   * Indique si un QR code est présent et non vide
   */
  hasQrCode(order: ServiceOrder): boolean {
    const qr = order?.paymentInit?.qrCode;
    return typeof qr === "string" && qr.trim().length > 0;
  }

  /**
   * Doit-on prioriser l'affichage du QR code ?
   * Règle: prioritaire sur desktop si disponible
   */
  shouldPrioritizeQr(order: ServiceOrder, isMobile: boolean): boolean {
    return !isMobile && this.hasQrCode(order);
  }

  /**
   * Crée une commande invité via l'API
   */
  async createGuestOrder(
    orderData: GuestOrderData
  ): Promise<ApiResponse<ServiceOrder>> {
    try {
      // Mode dev: réponse simulée pour permettre les tests et le flux UI
      // Remplacez par le fetch réel si nécessaire
      // return {
      //   success: true,
      //   data: {
      //     id: "cmi20mgdn0007ls0k0vb517uh",
      //     orderNumber: "NAB-20251116-1180",
      //     status: "pending",
      //     totalAmount: "2500",
      //     deliveryFee: "1000",
      //     discountAmount: "0",
      //     finalAmount: "3500",
      //     paymentStatus: "pending",
      //     deliveryDate: "2025-11-16T17:54:31.337Z",
      //     deliveryTime: "13h-14h",
      //     createdAt: "2025-11-16T17:54:32.171Z",
      //     paymentInit: {
      //       qrCode:
      //         "iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAAAAACIM/FCAAAAAklEQVR4nGKkkSsAAAINSURBVO3QQW4DMQxD0bn/pdNVgQAaMpTdIG70tRp4ZInP1+NL6vp0gL8qIKcVkNMKyGkF5LQCclp9KeSK62aSOPd/6/liBiBAgAyGqDC1xw+vnX7yWobfo60hQHohkx4gT99A0pBJj4aokN14yYTk74u9QIAAARIP8Sd1gn8EIECAAHkfxPeo8MlMIECAAOlCVOUBFErFW8sABAgQIEntoHJ4kgEIECCTId1SAVSn6lG3OlH2bgMBIqPs3QbyZkhdpJYmgT2hS/Z7gQABMhOShOl2qmBJeEW+mQMECJDxkHyRpyXw5PvFdiBAgAyG5PHqCrVU3VUnagIQIECAJMPVwGS1ehb/IDkQCBAgkyGNi83wyfzkrh4KBAiQuRAfycdIHiF/lmQLECBAJkPUlbUVyXdy4u8CAQIEiL+y0+Mf5CaenQwECBAg9YqPmv+9Svlb/rluJgABAmQkxF/3hBrDx1aTkx4gQIAA6a7wIf2D+KfwKCBAgABJRl2i1HB/18fzW+pdIECATIZ0KyfkJ3W+wgIBAgRIbVblhyffPrDqVxOAAAEyGXLTZnsqxDO7QDUBCBAgQOrwOmQtkofXXQkfCBAgQLqQHfjaTCBAgADZgeTxVL/6284ABAiQ8ZAkgFrhVyd/23wgQIAMhiSV9KvV6mTtLhAgQCZD/nEBOa2AnFZATisgpxWQ0wrIafUDchTUcZ4daWMAAAAASUVORK5CYII=",
      //       payment_link: {
      //         MAXIT:
      //           "https://sugu.orange-sonatel.com/mp/dme3aqoQqHGsr_f3RR-X",
      //         OM: "https://orange-money-prod-flowlinks.web.app/om/dme3aqoQqHGsr_f3RR-X",
      //       },
      //     },
      //   },
      //   message: "Commande créée avec succès",
      // };
      const response = await fetch(`${this.baseUrl}/guest`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(orderData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error.message || "Erreur lors de la création de la commande"
        );
      }

      return {
        success: true,
        data: data.data.order,
        message: data.message || "Commande créée avec succès",
      } as ApiSuccessResponse<ServiceOrder>;
    } catch (error) {
      console.error("Erreur lors de la création de la commande:", error);
      return {
        success: false,
        error: {
          code: "ORDER_CREATE_ERROR",
          message: error instanceof Error ? error.message : "Erreur inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  /**
   * Récupère une commande par son ID
   */
  async getOrderById(orderId: string): Promise<ApiResponse<ServiceOrder>> {
    try {
      const response = await fetch(`${this.baseUrl}/${orderId}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Erreur lors de la récupération de la commande"
        );
      }

      return {
        success: true,
        data: data.data,
      } as ApiSuccessResponse<ServiceOrder>;
    } catch (error) {
      console.error("Erreur lors de la récupération de la commande:", error);
      return {
        success: false,
        error: {
          code: "ORDER_FETCH_ERROR",
          message: error instanceof Error ? error.message : "Erreur inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  /**
   * Récupère une commande par son numéro
   */
  async getOrderByNumber(
    orderNumber: string
  ): Promise<ApiResponse<ServiceOrder>> {
    try {
      const response = await fetch(`${this.baseUrl}/guest/${orderNumber}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Erreur lors de la récupération de la commande"
        );
      }

      return {
        success: true,
        data: data.data,
      } as ApiSuccessResponse<ServiceOrder>;
    } catch (error) {
      console.error("Erreur lors de la récupération de la commande:", error);
      return {
        success: false,
        error: {
          code: "ORDER_FETCH_ERROR",
          message: error instanceof Error ? error.message : "Erreur inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  /**
   * Crée une commande directe à partir d'un article unique
   */
  async createDirectOrder(
    item: WeeklyMenuItem,
    data: ReservationSubmissionData
  ): Promise<ApiResponse<ServiceOrder>> {
    // Valider les données avant soumission
    const validation = this.validateSubmissionData(
      {
        cartMode: false,
      },
      item
    );

    if (!validation.isValid) {
      return {
        success: false,
        error: {
          code: "VALIDATION_ERROR",
          message: validation.error || "Données invalides",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }

    // Préparer les données de commande
    const orderData = this.prepareDirectOrderData(item, data);

    // Créer la commande
    return this.createGuestOrder(orderData);
  }

  /**
   * Crée une commande à partir du panier
   */
  async createCartOrder(
    cartItems: CartItem[],
    formData: OrderFormData,
    promoCode?: string
  ): Promise<ApiResponse<ServiceOrder>> {
    // Valider les données avant soumission
    const validation = this.validateSubmissionData(
      {
        cartMode: true,
      },
      undefined,
      cartItems
    );

    if (!validation.isValid) {
      return {
        success: false,
        error: {
          code: "VALIDATION_ERROR",
          message: validation.error || "Données invalides",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }

    // Préparer les données de commande
    const orderData = this.prepareCartOrderData(cartItems, formData, promoCode);

    // Créer la commande
    return this.createGuestOrder(orderData);
  }

  /**
   * Valide les données avant soumission
   */
  validateSubmissionData(
    mode: ReservationMode,
    item?: WeeklyMenuItem,
    cartItems?: CartItem[]
  ): { isValid: boolean; error?: string } {
    const { cartMode } = mode;

    if (cartMode) {
      if (!cartItems || cartItems.length === 0) {
        return {
          isValid: false,
          error: "Panier vide",
        };
      }
    } else {
      if (!item?.menuItemId) {
        return {
          isValid: false,
          error: "menuItemId manquant",
        };
      }
    }

    return { isValid: true };
  }

  /**
   * Valide les données du formulaire pour une étape donnée
   */
  validateFormData(
    formData: OrderFormData,
    mode: ReservationMode,
    step: number,
    menuSize?: string
  ): StepValidationResult {
    const { user } = useAuthStore.getState();
    const isEmployee = !!user?.companyId;
    return validateCurrentStep(step, formData, isEmployee);
  }

  /**
   * Valide un code promo
   */
  async validatePromoCode(
    code: string,
    orderAmount: number,
    items: Array<{ menuItemId: string; quantity: number; unitPrice: number }>
  ): Promise<PromoValidationResult> {
    return validatePromoCode(code, orderAmount, items);
  }

  /**
   * Prépare les données pour une commande directe
   */
  prepareDirectOrderData(
    item: WeeklyMenuItem,
    data: ReservationSubmissionData
  ): GuestOrderData {
    const { formData, quantity, menuSize, promoCode, isPromoValid } = data;

    const orderItems: ServiceOrderItem[] = [
      {
        menuItemId: item.menuItemId,
        quantity: quantity,
        options: {
          size: menuSize,
        },
      },
    ];

    const promotionCode = item.hasRakTakPromo
      ? item.rakTakPromoCode || undefined
      : isPromoValid && promoCode
      ? promoCode.toUpperCase()
      : undefined;

    return {
      items: orderItems,
      customerInfo: {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        email: formData.email || undefined,
      },
      // employeeId is now at root level
      employeeId: formData.employeeId || undefined,
      deliveryInfo: {
        deliveryZoneId: formData.deliveryZoneId,
        deliveryAddress: formData.deliveryAddress,
        deliveryTime: formData.deliveryTime,
        type: "delivery",
      },
      customerNotes: formData.customerNotes || undefined,
      paymentMethod: formData.paymentMethod,
      weeklyMenuId: item.weeklyMenuId,
      promotionCode,
    };
  }

  /**
   * Prépare les données pour une commande depuis le panier
   */
  prepareCartOrderData(
    cartItems: CartItem[],
    formData: OrderFormData,
    promoCode?: string
  ): GuestOrderData {
    // Convertir les articles du panier en format OrderItem
    const orderItems: ServiceOrderItem[] = cartItems.map((item) => ({
      menuItemId: item.menuItemId,
      quantity: item.quantity,
      options: item.options,
    }));

    // Utiliser le weeklyMenuId du premier article (tous les articles du panier devraient avoir le même)
    const weeklyMenuId = cartItems[0]?.weeklyMenuId || formData.weeklyMenuId;

    const promotionCode = promoCode ? promoCode.toUpperCase() : undefined;

    return {
      items: orderItems,
      customerInfo: {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phone: formData.phone,
        email: formData.email || undefined,
      },
      deliveryInfo: {
        deliveryZoneId: formData.deliveryZoneId,
        deliveryAddress: formData.deliveryAddress,
        deliveryTime: formData.deliveryTime,
        type: formData.employeeId ? "pickup" : "delivery",
      },
      customerNotes: formData.customerNotes || undefined,
      paymentMethod: formData.paymentMethod,
      weeklyMenuId,
      promotionCode,
      employeeId: formData.employeeId || undefined, // Move employeeId to root level
    };
  }

  /**
   * Calcule les totaux d'une commande
   */
  calculateOrderTotals(
    items: CartItem[],
    deliveryFee: number,
    promoDiscount: number = 0,
    isFreeDelivery: boolean = false
  ): OrderTotals {
    const subtotal = items.reduce((sum, item) => sum + item.totalPrice, 0);
    const effectiveDeliveryFee = isFreeDelivery ? 0 : deliveryFee;
    const effectivePromoDiscount = Math.min(promoDiscount, subtotal);
    const total = Math.max(
      0,
      subtotal - effectivePromoDiscount + effectiveDeliveryFee
    );

    return {
      subtotal,
      deliveryFee: effectiveDeliveryFee,
      promoDiscount: effectivePromoDiscount,
      total,
    };
  }

  /**
   * Génère un message de succès selon le type d'action
   */
  getSuccessMessage(
    actionType: string,
    mode: ReservationMode,
    itemName?: string,
    quantity?: number
  ): string {
    const { cartMode } = mode;

    if (cartMode && itemName && quantity) {
      return `${itemName} ajouté au panier (${quantity}x)`;
    }

    return `${
      actionType.charAt(0).toUpperCase() + actionType.slice(1)
    } créée avec succès !`;
  }

  /**
   * Génère un message de succès pour une commande depuis le panier
   */
  getCartOrderSuccessMessage(clearedItemsCount: number): string {
    return `Commande confirmée ! ${clearedItemsCount} article${
      clearedItemsCount > 1 ? "s ont été supprimés" : " a été supprimé"
    } de votre panier.`;
  }

  /**
   * Valide les options obligatoires pour le mode panier
   */
  validateCartModeOptions(
    item: WeeklyMenuItem,
    menuSize: string
  ): { isValid: boolean; error?: string } {
    // Vérifier qu'une taille/option est sélectionnée
    if (!menuSize || menuSize.trim() === "") {
      return {
        isValid: false,
        error: "Veuillez sélectionner une option avant d'ajouter au panier",
      };
    }

    // Vérifier que l'option sélectionnée existe
    const selectedOption = item?.options.find((opt) => opt.name === menuSize);
    if (!selectedOption) {
      return {
        isValid: false,
        error: "Option sélectionnée invalide",
      };
    }

    return { isValid: true };
  }

  /**
   * Prépare les données pour l'ajout au panier
   */
  prepareCartItemData(
    item: WeeklyMenuItem,
    quantity: number,
    menuSize: string
  ) {
    return {
      item,
      quantity,
      menuSize,
    };
  }
}

// Instance singleton du service unifié
export const unifiedOrderService = new UnifiedOrderService();
export default unifiedOrderService;
