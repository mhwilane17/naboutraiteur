import { ApiSuccessResponse, ApiErrorResponse } from "@/types/api";

export interface DeliveryZone {
  id: string;
  name: string;
  description?: string;
  deliveryFee: number;
  minimumOrderAmount?: number;
  maximumOrderAmount?: number;
  estimatedTime?: string;
  isActive: boolean;
  areas: string[];
}

class DeliveryService {
  async getDeliveryZones(): Promise<ApiSuccessResponse<DeliveryZone[]> | ApiErrorResponse> {
    try {
      const response = await fetch("/api/delivery/zones/public");
      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: {
            code: "DELIVERY_ZONES_ERROR",
            message: data.error || "Erreur lors de la récupération des zones de livraison",
          },
          timestamp: new Date().toISOString(),
        };
      }

      return {
        success: true,
        data: data.data || [],
      };
    } catch (error) {
      console.error("Erreur lors de la récupération des zones de livraison:", error);
      return {
        success: false,
        error: {
          code: "NETWORK_ERROR",
          message: "Erreur réseau lors de la récupération des zones de livraison",
        },
        timestamp: new Date().toISOString(),
      };
    }
  }
}

export const deliveryService = new DeliveryService();
