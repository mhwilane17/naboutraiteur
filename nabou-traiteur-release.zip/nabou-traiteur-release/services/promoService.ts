// Types pour la gestion des codes promo
export interface PromoValidationResult {
  success: boolean;
  data?: {
    discount?: {
      amount?: number;
      isFreeDelivery?: boolean;
    };
  };
  error?: { message?: string };
  message?: string;
}

export interface PromoCode {
  id: string;
  code: string;
  type: 'percentage' | 'fixed' | 'free_delivery';
  value: number;
  minOrderAmount?: number;
  maxDiscountAmount?: number;
  isActive: boolean;
  validFrom: Date;
  validTo: Date;
  usageLimit?: number;
  usedCount: number;
  description?: string;
}

export interface PromoState {
  code: string;
  isValid: boolean;
  isValidating: boolean;
  message: string | null;
  discountAmount: number;
  isFreeDelivery: boolean;
}

export interface PromoCalculation {
  originalAmount: number;
  discountAmount: number;
  finalAmount: number;
  isFreeDelivery: boolean;
  appliedPromo?: PromoCode;
}

// Validation côté serveur
export async function validatePromoCode(
  code: string,
  orderAmount: number,
  items: Array<{ menuItemId: string; quantity: number; unitPrice: number }>
): Promise<PromoValidationResult> {
  try {
    const res = await fetch("/api/promotions/public/validate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: code.toUpperCase(),
        orderAmount: Number(orderAmount),
        items,
      }),
    });
    const data: PromoValidationResult = await res.json();
    if (!res.ok) return { ...data, success: false };
    return data;
  } catch (e) {
    return { success: false, message: "Network error" };
  }
}

// Validation côté client pour les codes RakTak
export function validateRakTakPromo(code: string): boolean {
  if (!code) return false;
  
  // Format attendu: RAKTAK_YYYYMMDD ou RAKTAK-YYYYMMDD
  const rakTakPattern = /^RAKTAK[_-]\d{8}$/i;
  return rakTakPattern.test(code.toUpperCase());
}

// Génération d'un code RakTak pour une date donnée
export function generateRakTakCode(date: Date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `RAKTAK_${year}${month}${day}`;
}

// Vérification si un code est un code RakTak
export function isRakTakCode(code: string): boolean {
  return code.toUpperCase().startsWith('RAKTAK');
}

// Calcul de la réduction basée sur le type de promo
export function calculateDiscount(
  promo: PromoCode,
  orderAmount: number
): PromoCalculation {
  let discountAmount = 0;
  let isFreeDelivery = false;

  // Vérifier le montant minimum de commande
  if (promo.minOrderAmount && orderAmount < promo.minOrderAmount) {
    return {
      originalAmount: orderAmount,
      discountAmount: 0,
      finalAmount: orderAmount,
      isFreeDelivery: false,
    };
  }

  switch (promo.type) {
    case 'percentage':
      discountAmount = (orderAmount * promo.value) / 100;
      if (promo.maxDiscountAmount) {
        discountAmount = Math.min(discountAmount, promo.maxDiscountAmount);
      }
      break;
    
    case 'fixed':
      discountAmount = Math.min(promo.value, orderAmount);
      break;
    
    case 'free_delivery':
      isFreeDelivery = true;
      discountAmount = 0;
      break;
  }

  return {
    originalAmount: orderAmount,
    discountAmount: Math.round(discountAmount),
    finalAmount: Math.max(0, orderAmount - discountAmount),
    isFreeDelivery,
    appliedPromo: promo,
  };
}

// Validation côté client des codes promo
export function validatePromoCodeFormat(code: string): {
  isValid: boolean;
  message?: string;
} {
  if (!code || code.trim().length === 0) {
    return { isValid: false, message: "Code promo requis" };
  }

  if (code.length < 3) {
    return { isValid: false, message: "Code promo trop court" };
  }

  if (code.length > 20) {
    return { isValid: false, message: "Code promo trop long" };
  }

  // Vérifier les caractères autorisés (lettres, chiffres, tirets, underscores)
  const validPattern = /^[A-Z0-9_-]+$/i;
  if (!validPattern.test(code)) {
    return {
      isValid: false,
      message: "Code promo invalide (lettres, chiffres, - et _ uniquement)"
    };
  }

  return { isValid: true };
}

// Utilitaire pour créer un état promo initial
export function createInitialPromoState(): PromoState {
  return {
    code: '',
    isValid: false,
    isValidating: false,
    message: null,
    discountAmount: 0,
    isFreeDelivery: false,
  };
}

// Utilitaire pour réinitialiser un état promo
export function resetPromoState(state: PromoState): PromoState {
  return {
    ...state,
    code: '',
    isValid: false,
    isValidating: false,
    message: null,
    discountAmount: 0,
    isFreeDelivery: false,
  };
}

// Utilitaire pour appliquer un code promo validé
export function applyValidatedPromo(
  state: PromoState,
  code: string,
  discountAmount: number,
  isFreeDelivery: boolean,
  message?: string
): PromoState {
  return {
    ...state,
    code: code.toUpperCase(),
    isValid: true,
    isValidating: false,
    message: message || 'Code promo appliqué',
    discountAmount,
    isFreeDelivery,
  };
}

// Utilitaire pour marquer un code promo comme invalide
export function markPromoAsInvalid(
  state: PromoState,
  message: string
): PromoState {
  return {
    ...state,
    isValid: false,
    isValidating: false,
    message,
    discountAmount: 0,
    isFreeDelivery: false,
  };
}

// Utilitaire pour démarrer la validation d'un code promo
export function startPromoValidation(state: PromoState): PromoState {
  return {
    ...state,
    isValidating: true,
    message: 'Validation en cours...',
  };
}
