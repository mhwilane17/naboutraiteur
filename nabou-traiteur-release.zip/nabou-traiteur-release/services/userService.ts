import { ApiSuccessResponse, ApiErrorResponse } from "@/types/api";

// Types pour les requêtes et réponses
export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  matricule?: string;
  filiale?: string;
  isActive: boolean;
  lastLogin?: string;
  createdAt: string;
  updatedAt: string;
  roles: Role[];
}

export interface Role {
  id: string;
  name: string;
  description?: string;
}

export interface CreateUserRequest {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  roleIds?: string[];
  companyId?: string;
  matricule?: string;
  filiale?: string;
}

export interface UpdateUserRequest {
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  matricule?: string;
  filiale?: string;
  isActive?: boolean;
  roleIds?: string[];
  companyId?: string;
}

export interface UsersListParams {
  page?: number;
  limit?: number;
  search?: string;
  role?: string;
  status?: string;
}

export interface UsersApiResponse extends ApiSuccessResponse<User[]> {
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// Types d'erreur spécifiques aux utilisateurs
export enum UserErrorCodes {
  USER_NOT_FOUND = 'USER_NOT_FOUND',
  EMAIL_ALREADY_EXISTS = 'EMAIL_ALREADY_EXISTS',
  CANNOT_DELETE_USER_WITH_ORDERS = 'CANNOT_DELETE_USER_WITH_ORDERS',
  INSUFFICIENT_PERMISSIONS = 'INSUFFICIENT_PERMISSIONS',
  VALIDATION_ERROR = 'VALIDATION_ERROR'
}

export const UserErrorMessages = {
  [UserErrorCodes.USER_NOT_FOUND]: 'Utilisateur introuvable',
  [UserErrorCodes.EMAIL_ALREADY_EXISTS]: 'Un utilisateur avec cet email existe déjà',
  [UserErrorCodes.CANNOT_DELETE_USER_WITH_ORDERS]: 'Impossible de supprimer cet utilisateur car il a des commandes associées',
  [UserErrorCodes.INSUFFICIENT_PERMISSIONS]: 'Permissions insuffisantes pour cette action',
  [UserErrorCodes.VALIDATION_ERROR]: 'Erreur de validation des données'
};

/**
 * Service pour la gestion des utilisateurs
 * Fournit une interface pour interagir avec l'API des utilisateurs
 */
export class UserService {
  private static baseUrl = "/api/users";

  /**
   * Récupère la liste des utilisateurs avec pagination et filtres
   */
  static async getUsers(params: UsersListParams = {}): Promise<UsersApiResponse | ApiErrorResponse> {
    try {
      const searchParams = new URLSearchParams();
      
      if (params.page) searchParams.set('page', params.page.toString());
      if (params.limit) searchParams.set('limit', params.limit.toString());
      if (params.search) searchParams.set('search', params.search);
      if (params.role) searchParams.set('role', params.role);
      if (params.status) searchParams.set('status', params.status);

      const url = `${this.baseUrl}?${searchParams.toString()}`;
      const response = await fetch(url, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'FETCH_USERS_ERROR',
            message: data.error?.message || "Erreur lors de la récupération des utilisateurs",
            details: data.error?.details
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }

      // Transformation des données pour correspondre à l'interface UsersApiResponse
      return {
        success: true,
        data: data.data.data, // Les utilisateurs sont dans data.data.data selon la structure API
        pagination: data.data.pagination,
        message: data.message
      } as UsersApiResponse;

    } catch (error) {
      console.error("Erreur lors de la récupération des utilisateurs:", error);
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : "Erreur réseau inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  /**
   * Récupère un utilisateur par son ID
   */
  static async getUser(id: string): Promise<ApiSuccessResponse<User> | ApiErrorResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/${id}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'FETCH_USER_ERROR',
            message: data.error?.message || "Erreur lors de la récupération de l'utilisateur",
            details: data.error?.details
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }

      return {
        success: true,
        data: data.data,
        message: data.message
      } as ApiSuccessResponse<User>;

    } catch (error) {
      console.error("Erreur lors de la récupération de l'utilisateur:", error);
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : "Erreur réseau inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  /**
   * Crée un nouvel utilisateur
   */
  static async createUser(userData: CreateUserRequest): Promise<ApiSuccessResponse<User> | ApiErrorResponse> {
    try {
      const response = await fetch(this.baseUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'CREATE_USER_ERROR',
            message: data.error?.message || "Erreur lors de la création de l'utilisateur",
            details: data.error?.details
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }

      return {
        success: true,
        data: data.data,
        message: data.message || "Utilisateur créé avec succès"
      } as ApiSuccessResponse<User>;

    } catch (error) {
      console.error("Erreur lors de la création de l'utilisateur:", error);
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : "Erreur réseau inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  /**
   * Met à jour un utilisateur existant
   */
  static async updateUser(id: string, updates: UpdateUserRequest): Promise<ApiSuccessResponse<User> | ApiErrorResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updates),
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'UPDATE_USER_ERROR',
            message: data.error?.message || "Erreur lors de la mise à jour de l'utilisateur",
            details: data.error?.details
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }

      return {
        success: true,
        data: data.data,
        message: data.message || "Utilisateur mis à jour avec succès"
      } as ApiSuccessResponse<User>;

    } catch (error) {
      console.error("Erreur lors de la mise à jour de l'utilisateur:", error);
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : "Erreur réseau inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  /**
   * Supprime un utilisateur
   */
  static async deleteUser(id: string): Promise<ApiSuccessResponse<{message: string}> | ApiErrorResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/${id}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'DELETE_USER_ERROR',
            message: data.error?.message || "Erreur lors de la suppression de l'utilisateur",
            details: data.error?.details
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }

      return {
        success: true,
        data: {
          message: data.message || "Utilisateur supprimé avec succès"
        },
        message: data.message || "Utilisateur supprimé avec succès"
      } as ApiSuccessResponse<{message: string}>;

    } catch (error) {
      console.error("Erreur lors de la suppression de l'utilisateur:", error);
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : "Erreur réseau inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  /**
   * Récupère la liste des rôles disponibles
   */
  static async getRoles(): Promise<ApiSuccessResponse<Role[]> | ApiErrorResponse> {
    try {
      const response = await fetch("/api/roles?excludeCustomer=true", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'FETCH_ROLES_ERROR',
            message: data.error?.message || "Erreur lors de la récupération des rôles",
            details: data.error?.details
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }

      // Extraire seulement les données nécessaires des rôles actifs
      const roles: Role[] = data.data.data
        .filter((role: any) => role.isActive) // Only include active roles
        .map((role: any) => ({
          id: role.id,
          name: role.name,
          description: role.description,
          isActive: role.isActive,
          createdAt: role.createdAt,
          updatedAt: role.updatedAt
        }));

      return {
        success: true,
        data: roles,
        message: data.message
      } as ApiSuccessResponse<Role[]>;

    } catch (error) {
      console.error("Erreur lors de la récupération des rôles:", error);
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : "Erreur réseau inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  /**
   * Suspend un utilisateur (met isActive à false)
   */
  static async suspendUser(id: string): Promise<ApiSuccessResponse<User> | ApiErrorResponse> {
    return this.updateUser(id, { isActive: false });
  }

  /**
   * Réactive un utilisateur (met isActive à true)
   */
  static async reactivateUser(id: string): Promise<ApiSuccessResponse<User> | ApiErrorResponse> {
    return this.updateUser(id, { isActive: true });
  }

  /**
   * Importe des utilisateurs depuis un fichier Excel/CSV via FormData
   */
  static async importUsers(formData: FormData): Promise<ApiSuccessResponse<any> | ApiErrorResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/import`, {
        method: "POST",
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'IMPORT_USERS_ERROR',
            message: data.error?.message || "Erreur lors de l'import des utilisateurs",
            details: data.error?.details
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }

      return {
        success: true,
        data: data.data.data,
        message: data.data.message || "Import terminé avec succès"
      } as ApiSuccessResponse<any>;

    } catch (error) {
      console.error("Erreur lors de l'import des utilisateurs:", error);
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : "Erreur réseau inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  /**
   * Récupère les statistiques des utilisateurs
   */
  static async getUserStats(): Promise<ApiSuccessResponse<{
    total: number;
    active: number;
    admins: number;
    suspended: number;
  }> | ApiErrorResponse> {
    try {
      // Utiliser l'endpoint existant avec des paramètres pour récupérer toutes les données
      const [totalResponse, activeResponse, suspendedResponse, adminResponse] = await Promise.all([
        this.getUsers({ limit: 1 }), // Juste pour récupérer le total
        this.getUsers({ limit: 1, status: 'active' }),
        this.getUsers({ limit: 1, status: 'inactive' }),
        this.getUsers({ limit: 1, role: 'admin' })
      ]);

      // Vérifier si toutes les requêtes ont réussi
      if (this.isErrorResponse(totalResponse)) {
        return totalResponse;
      }

      const totalData = totalResponse as UsersApiResponse;
      const activeData = this.isErrorResponse(activeResponse) ? { pagination: { total: 0 } } : activeResponse as UsersApiResponse;
      const suspendedData = this.isErrorResponse(suspendedResponse) ? { pagination: { total: 0 } } : suspendedResponse as UsersApiResponse;
      const adminData = this.isErrorResponse(adminResponse) ? { pagination: { total: 0 } } : adminResponse as UsersApiResponse;

      const stats = {
        total: totalData.pagination.total,
        active: activeData.pagination.total,
        suspended: suspendedData.pagination.total,
        admins: adminData.pagination.total,
      };

      return {
        success: true,
        data: stats,
        message: "Statistiques récupérées avec succès"
      } as ApiSuccessResponse<typeof stats>;

    } catch (error) {
      console.error("Erreur lors de la récupération des statistiques:", error);
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : "Erreur réseau inconnue",
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  /**
   * Utilitaire pour vérifier si une réponse est une erreur
   */
  static isErrorResponse(response: any): response is ApiErrorResponse {
    return response && !response.success;
  }

  /**
   * Utilitaire pour extraire le message d'erreur d'une réponse
   */
  static getErrorMessage(response: ApiErrorResponse): string {
    return response.error?.message || "Une erreur inconnue s'est produite";
  }

  /**
   * Utilitaire pour transformer les données utilisateur Prisma vers l'interface User
   */
  static transformPrismaUser(prismaUser: any): User {
    return {
      id: prismaUser.id,
      firstName: prismaUser.firstName,
      lastName: prismaUser.lastName,
      email: prismaUser.email,
      phone: prismaUser.phone,
      address: prismaUser.address,
      city: prismaUser.city,
      postalCode: prismaUser.postalCode,
      matricule: prismaUser.matricule,
      filiale: prismaUser.filiale,
      isActive: prismaUser.isActive,
      lastLogin: prismaUser.lastLogin?.toISOString(),
      createdAt: prismaUser.createdAt.toISOString(),
      updatedAt: prismaUser.updatedAt.toISOString(),
      roles: prismaUser.roles?.map((ur: any) => ur.role) || []
    };
  }
}

// Export par défaut pour faciliter l'importation
export default UserService;