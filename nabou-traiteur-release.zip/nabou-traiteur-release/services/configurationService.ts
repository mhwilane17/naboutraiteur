import { ApiSuccessResponse, ApiErrorResponse } from '@/types/api';

// Types pour les configurations
export interface AppConfiguration {
  id: string;
  key: string;
  value: string;
  type: 'string' | 'number' | 'boolean' | 'json' | 'time';
  section: 'general' | 'orders' | 'notifications';
  label: string;
  description?: string;
  isRequired: boolean;
  isSecret: boolean;
  validation?: ValidationRule;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface ValidationRule {
  min?: number;
  max?: number;
  pattern?: string;
  required?: boolean;
  custom?: string;
}

export interface ConfigurationUpdate {
  key: string;
  value: string;
}

export interface ConfigurationsBySection {
  [section: string]: AppConfiguration[];
}

// Types d'erreur spécifiques aux configurations
export enum ConfigurationErrorCodes {
  CONFIGURATION_NOT_FOUND = 'CONFIGURATION_NOT_FOUND',
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  INVALID_TYPE = 'INVALID_TYPE',
  REQUIRED_FIELD_MISSING = 'REQUIRED_FIELD_MISSING',
  INVALID_TIME_FORMAT = 'INVALID_TIME_FORMAT',
  INVALID_TIME_RANGE = 'INVALID_TIME_RANGE',
  CACHE_ERROR = 'CACHE_ERROR',
  DATABASE_ERROR = 'DATABASE_ERROR'
}

export const ConfigurationErrorMessages = {
  [ConfigurationErrorCodes.CONFIGURATION_NOT_FOUND]: 'Configuration introuvable',
  [ConfigurationErrorCodes.VALIDATION_ERROR]: 'Erreur de validation',
  [ConfigurationErrorCodes.INVALID_TYPE]: 'Type de données invalide',
  [ConfigurationErrorCodes.REQUIRED_FIELD_MISSING]: 'Champ requis manquant',
  [ConfigurationErrorCodes.INVALID_TIME_FORMAT]: 'Format d\'heure invalide (attendu: HH:MM)',
  [ConfigurationErrorCodes.INVALID_TIME_RANGE]: 'L\'heure de fin doit être postérieure à l\'heure de début',
  [ConfigurationErrorCodes.CACHE_ERROR]: 'Erreur de cache',
  [ConfigurationErrorCodes.DATABASE_ERROR]: 'Erreur de base de données'
};

/**
 * Cache simple en mémoire pour les configurations
 */
class ConfigurationCache {
  private cache: Map<string, AppConfiguration> = new Map();
  private lastUpdate: number = 0;
  private readonly TTL = 5 * 60 * 1000; // 5 minutes

  set(key: string, config: AppConfiguration): void {
    this.cache.set(key, config);
    this.lastUpdate = Date.now();
  }

  get(key: string): AppConfiguration | undefined {
    if (this.isExpired()) {
      this.clear();
      return undefined;
    }
    return this.cache.get(key);
  }

  getAll(): AppConfiguration[] {
    if (this.isExpired()) {
      this.clear();
      return [];
    }
    return Array.from(this.cache.values());
  }

  clear(): void {
    this.cache.clear();
    this.lastUpdate = 0;
  }

  private isExpired(): boolean {
    return Date.now() - this.lastUpdate > this.TTL;
  }

  setAll(configurations: AppConfiguration[]): void {
    this.cache.clear();
    configurations.forEach(config => {
      this.cache.set(config.key, config);
    });
    this.lastUpdate = Date.now();
  }
}

/**
 * Service pour la gestion des configurations de l'application
 * Utilise les API routes côté client et Prisma côté serveur
 */
export class ConfigurationService {
  private static cache = new ConfigurationCache();
  private static baseUrl = "/api/admin/configurations";

  /**
   * Vérifie si nous sommes côté client
   */
  private static isClient(): boolean {
    return typeof window !== 'undefined';
  }

  /**
   * Récupère toutes les configurations (côté client via API, côté serveur via Prisma)
   */
  static async getAllConfigurations(): Promise<ApiSuccessResponse<AppConfiguration[]> | ApiErrorResponse> {
    if (this.isClient()) {
      return this.getAllConfigurationsClient();
    } else {
      return this.getAllConfigurationsServer();
    }
  }

  /**
   * Récupère toutes les configurations côté client via l'API
   */
  private static async getAllConfigurationsClient(): Promise<ApiSuccessResponse<AppConfiguration[]> | ApiErrorResponse> {
    try {
      // Vérifier le cache d'abord
      const cachedConfigs = this.cache.getAll();
      if (cachedConfigs.length > 0) {
        return {
          success: true,
          data: cachedConfigs,
          message: 'Configurations récupérées depuis le cache'
        };
      }

      // Récupérer depuis l'API
      const response = await fetch(this.baseUrl, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        return {
          success: false,
          error: {
            code: errorData.code || ConfigurationErrorCodes.DATABASE_ERROR,
            message: errorData.message || ConfigurationErrorMessages[ConfigurationErrorCodes.DATABASE_ERROR],
            details: errorData.details
          },
          timestamp: new Date().toISOString()
        };
      }

      const result = await response.json();
      
      if (result.success && result.data) {
        // Mettre en cache
        this.cache.setAll(result.data);

        return {
          success: true,
          data: result.data,
          message: result.message || 'Configurations récupérées avec succès'
        };
      } else {
        return {
          success: false,
          error: {
            code: ConfigurationErrorCodes.DATABASE_ERROR,
            message: result.message || ConfigurationErrorMessages[ConfigurationErrorCodes.DATABASE_ERROR]
          },
          timestamp: new Date().toISOString()
        };
      }

    } catch (error) {
      console.error('Erreur lors de la récupération des configurations:', error);
      return {
        success: false,
        error: {
          code: ConfigurationErrorCodes.DATABASE_ERROR,
          message: ConfigurationErrorMessages[ConfigurationErrorCodes.DATABASE_ERROR],
          details: error instanceof Error ? error.message : 'Erreur inconnue'
        },
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Récupère toutes les configurations côté serveur via Prisma
   */
  private static async getAllConfigurationsServer(): Promise<ApiSuccessResponse<AppConfiguration[]> | ApiErrorResponse> {
    try {
      // Vérifier le cache d'abord
      const cachedConfigs = this.cache.getAll();
      if (cachedConfigs.length > 0) {
        return {
          success: true,
          data: cachedConfigs,
          message: 'Configurations récupérées depuis le cache'
        };
      }

      // Import dynamique de Prisma pour éviter les erreurs côté client
      const { prisma } = await import('@/lib/prisma');

      // Récupérer depuis la base de données
      const configurations = await prisma.appConfiguration.findMany({
        orderBy: [
          { section: 'asc' },
          { sortOrder: 'asc' },
          { label: 'asc' }
        ]
      });

      const transformedConfigs = configurations.map(this.transformPrismaConfiguration);
      
      // Mettre en cache
      this.cache.setAll(transformedConfigs);

      return {
        success: true,
        data: transformedConfigs,
        message: 'Configurations récupérées avec succès'
      };

    } catch (error) {
      console.error('Erreur lors de la récupération des configurations:', error);
      return {
        success: false,
        error: {
          code: ConfigurationErrorCodes.DATABASE_ERROR,
          message: ConfigurationErrorMessages[ConfigurationErrorCodes.DATABASE_ERROR],
          details: error instanceof Error ? error.message : 'Erreur inconnue'
        },
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Récupère les configurations par section
   */
  static async getConfigurationsBySection(): Promise<ApiSuccessResponse<ConfigurationsBySection> | ApiErrorResponse> {
    const result = await this.getAllConfigurations();
    
    if (!result.success) {
      return result;
    }

    const configsBySection: ConfigurationsBySection = {};
    result.data.forEach(config => {
      if (!configsBySection[config.section]) {
        configsBySection[config.section] = [];
      }
      configsBySection[config.section].push(config);
    });

    return {
      success: true,
      data: configsBySection,
      message: 'Configurations groupées par section récupérées avec succès'
    };
  }

  /**
   * Récupère une configuration par sa clé
   */
  static async getConfiguration(key: string): Promise<ApiSuccessResponse<AppConfiguration> | ApiErrorResponse> {
    try {
      // Vérifier le cache d'abord
      const cachedConfig = this.cache.get(key);
      if (cachedConfig) {
        return {
          success: true,
          data: cachedConfig,
          message: 'Configuration récupérée depuis le cache'
        };
      }

      // Si pas en cache, récupérer toutes les configurations
      const allConfigsResult = await this.getAllConfigurations();
      if (!allConfigsResult.success) {
        return allConfigsResult;
      }

      const configuration = allConfigsResult.data.find(config => config.key === key);
      if (!configuration) {
        return {
          success: false,
          error: {
            code: ConfigurationErrorCodes.CONFIGURATION_NOT_FOUND,
            message: ConfigurationErrorMessages[ConfigurationErrorCodes.CONFIGURATION_NOT_FOUND]
          },
          timestamp: new Date().toISOString()
        };
      }

      return {
        success: true,
        data: configuration,
        message: 'Configuration récupérée avec succès'
      };

    } catch (error) {
      console.error('Erreur lors de la récupération de la configuration:', error);
      return {
        success: false,
        error: {
          code: ConfigurationErrorCodes.DATABASE_ERROR,
          message: ConfigurationErrorMessages[ConfigurationErrorCodes.DATABASE_ERROR],
          details: error instanceof Error ? error.message : 'Erreur inconnue'
        },
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Met à jour plusieurs configurations (côté client via API, côté serveur via Prisma)
   */
  static async updateConfigurations(updates: ConfigurationUpdate[]): Promise<ApiSuccessResponse<AppConfiguration[]> | ApiErrorResponse> {
    if (this.isClient()) {
      return this.updateConfigurationsClient(updates);
    } else {
      return this.updateConfigurationsServer(updates);
    }
  }

  /**
   * Met à jour plusieurs configurations côté client via l'API
   */
  private static async updateConfigurationsClient(updates: ConfigurationUpdate[]): Promise<ApiSuccessResponse<AppConfiguration[]> | ApiErrorResponse> {
    try {
      const response = await fetch(this.baseUrl, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          configurations: updates
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: {
            code: result.code || ConfigurationErrorCodes.DATABASE_ERROR,
            message: result.message || ConfigurationErrorMessages[ConfigurationErrorCodes.DATABASE_ERROR],
            details: result.details
          },
          timestamp: new Date().toISOString()
        };
      }

      if (result.success && result.data) {
        // Mettre à jour le cache
        result.data.forEach((config: AppConfiguration) => {
          this.cache.set(config.key, config);
        });

        return {
          success: true,
          data: result.data,
          message: result.message || `${updates.length} configuration(s) mise(s) à jour avec succès`
        };
      } else {
        return {
          success: false,
          error: {
            code: result.code || ConfigurationErrorCodes.DATABASE_ERROR,
            message: result.message || ConfigurationErrorMessages[ConfigurationErrorCodes.DATABASE_ERROR],
            details: result.details
          },
          timestamp: new Date().toISOString()
        };
      }

    } catch (error) {
      console.error('Erreur lors de la mise à jour des configurations:', error);
      return {
        success: false,
        error: {
          code: ConfigurationErrorCodes.DATABASE_ERROR,
          message: ConfigurationErrorMessages[ConfigurationErrorCodes.DATABASE_ERROR],
          details: error instanceof Error ? error.message : 'Erreur inconnue'
        },
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Met à jour plusieurs configurations côté serveur via Prisma
   */
  private static async updateConfigurationsServer(updates: ConfigurationUpdate[]): Promise<ApiSuccessResponse<AppConfiguration[]> | ApiErrorResponse> {
    try {
      // Valider toutes les mises à jour avant de les appliquer
      const validationErrors: { [key: string]: string } = {};
      
      for (const update of updates) {
        const configResult = await this.getConfiguration(update.key);
        if (!configResult.success) {
          validationErrors[update.key] = 'Configuration introuvable';
          continue;
        }

        const validationError = this.validateConfigurationValue(configResult.data, update.value);
        if (validationError) {
          validationErrors[update.key] = validationError;
        }
      }

      // Validation spéciale pour les heures d'ouverture
      const timeValidationError = this.validateOrderingHours(updates);
      if (timeValidationError) {
        Object.assign(validationErrors, timeValidationError);
      }

      if (Object.keys(validationErrors).length > 0) {
        return {
          success: false,
          error: {
            code: ConfigurationErrorCodes.VALIDATION_ERROR,
            message: 'Erreurs de validation détectées',
            details: validationErrors
          },
          timestamp: new Date().toISOString()
        };
      }

      // Import dynamique de Prisma
      const { prisma } = await import('@/lib/prisma');

      // Appliquer les mises à jour
      const updatedConfigurations: AppConfiguration[] = [];
      
      for (const update of updates) {
        const updatedConfig = await prisma.appConfiguration.update({
          where: { key: update.key },
          data: { 
            value: update.value,
            updatedAt: new Date()
          }
        });

        const transformedConfig = this.transformPrismaConfiguration(updatedConfig);
        updatedConfigurations.push(transformedConfig);
        
        // Mettre à jour le cache
        this.cache.set(update.key, transformedConfig);
      }

      return {
        success: true,
        data: updatedConfigurations,
        message: `${updates.length} configuration(s) mise(s) à jour avec succès`
      };

    } catch (error) {
      console.error('Erreur lors de la mise à jour des configurations:', error);
      return {
        success: false,
        error: {
          code: ConfigurationErrorCodes.DATABASE_ERROR,
          message: ConfigurationErrorMessages[ConfigurationErrorCodes.DATABASE_ERROR],
          details: error instanceof Error ? error.message : 'Erreur inconnue'
        },
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Valide la valeur d'une configuration selon son type et ses règles
   */
  static validateConfigurationValue(config: AppConfiguration, value: string): string | null {
    // Vérifier si le champ est requis
    if (config.isRequired && (!value || value.trim() === '')) {
      return ConfigurationErrorMessages[ConfigurationErrorCodes.REQUIRED_FIELD_MISSING];
    }

    // Si la valeur est vide et non requise, c'est valide
    if (!value || value.trim() === '') {
      return null;
    }

    // Validation selon le type
    switch (config.type) {
      case 'number':
        if (isNaN(Number(value))) {
          return 'La valeur doit être un nombre valide';
        }
        if (config.validation?.min !== undefined && Number(value) < config.validation.min) {
          return `La valeur doit être supérieure ou égale à ${config.validation.min}`;
        }
        if (config.validation?.max !== undefined && Number(value) > config.validation.max) {
          return `La valeur doit être inférieure ou égale à ${config.validation.max}`;
        }
        break;

      case 'boolean':
        if (!['true', 'false', '1', '0'].includes(value.toLowerCase())) {
          return 'La valeur doit être true ou false';
        }
        break;

      case 'time':
        const timeError = this.validateTimeFormat(value);
        if (timeError) {
          return timeError;
        }
        break;

      case 'json':
        try {
          JSON.parse(value);
        } catch {
          return 'La valeur doit être un JSON valide';
        }
        break;

      case 'string':
      default:
        if (config.validation?.pattern) {
          const regex = new RegExp(config.validation.pattern);
          if (!regex.test(value)) {
            return 'Le format de la valeur est invalide';
          }
        }
        if (config.validation?.min !== undefined && value.length < config.validation.min) {
          return `La valeur doit contenir au moins ${config.validation.min} caractères`;
        }
        if (config.validation?.max !== undefined && value.length > config.validation.max) {
          return `La valeur ne peut pas dépasser ${config.validation.max} caractères`;
        }
        break;
    }

    return null;
  }

  /**
   * Valide le format d'une heure (HH:MM)
   */
  static validateTimeFormat(time: string): string | null {
    const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
    if (!timeRegex.test(time)) {
      return ConfigurationErrorMessages[ConfigurationErrorCodes.INVALID_TIME_FORMAT];
    }
    return null;
  }

  /**
   * Valide que les heures d'ouverture sont cohérentes
   */
  static validateOrderingHours(updates: ConfigurationUpdate[]): { [key: string]: string } | null {
    const openingTimeUpdate = updates.find(u => u.key === 'orders.opening_time');
    const closingTimeUpdate = updates.find(u => u.key === 'orders.closing_time');

    if (!openingTimeUpdate && !closingTimeUpdate) {
      return null;
    }

    let openingTime = openingTimeUpdate?.value;
    let closingTime = closingTimeUpdate?.value;

    // Si une seule heure est mise à jour, récupérer l'autre depuis le cache/DB
    if (!openingTime || !closingTime) {
      // Pour la validation, on peut faire une requête synchrone ou utiliser les valeurs actuelles
      // Ici on va juste valider si les deux sont présentes dans les updates
      return null;
    }

    // Valider le format des heures
    const openingError = this.validateTimeFormat(openingTime);
    const closingError = this.validateTimeFormat(closingTime);

    const errors: { [key: string]: string } = {};

    if (openingError) {
      errors['orders.opening_time'] = openingError;
    }
    if (closingError) {
      errors['orders.closing_time'] = closingError;
    }

    // Si les formats sont valides, vérifier que l'heure de fermeture > heure d'ouverture
    if (!openingError && !closingError) {
      const [openHour, openMin] = openingTime.split(':').map(Number);
      const [closeHour, closeMin] = closingTime.split(':').map(Number);
      
      const openMinutes = openHour * 60 + openMin;
      const closeMinutes = closeHour * 60 + closeMin;

      if (closeMinutes <= openMinutes) {
        errors['orders.closing_time'] = ConfigurationErrorMessages[ConfigurationErrorCodes.INVALID_TIME_RANGE];
      }
    }

    return Object.keys(errors).length > 0 ? errors : null;
  }

  /**
   * Vide le cache des configurations
   */
  static clearCache(): void {
    this.cache.clear();
  }

  /**
   * Transforme une configuration Prisma vers l'interface AppConfiguration
   * (utilisé côté serveur dans les API routes)
   */
  static transformPrismaConfiguration(prismaConfig: any): AppConfiguration {
    return {
      id: prismaConfig.id,
      key: prismaConfig.key,
      value: prismaConfig.value,
      type: prismaConfig.type as AppConfiguration['type'],
      section: prismaConfig.section as AppConfiguration['section'],
      label: prismaConfig.label,
      description: prismaConfig.description,
      isRequired: prismaConfig.isRequired,
      isSecret: prismaConfig.isSecret,
      validation: prismaConfig.validation as ValidationRule,
      sortOrder: prismaConfig.sortOrder,
      createdAt: prismaConfig.createdAt.toISOString(),
      updatedAt: prismaConfig.updatedAt.toISOString()
    };
  }

  /**
   * Utilitaire pour vérifier si une réponse est une erreur
   */
  static isErrorResponse(response: any): response is ApiErrorResponse {
    return response && !response.success;
  }

  /**
   * Utilitaire pour extraire le message d'erreur d'une réponse
   */
  static getErrorMessage(response: ApiErrorResponse): string {
    return response.error?.message || "Une erreur inconnue s'est produite";
  }

  /**
   * Récupère la valeur d'une configuration spécifique (utilitaire)
   */
  static async getConfigurationValue(key: string): Promise<string | null> {
    const result = await this.getConfiguration(key);
    return result.success ? result.data.value : null;
  }

  /**
   * Vérifie si les commandes sont ouvertes selon les heures configurées
   */
  static async areOrdersOpen(): Promise<boolean> {
    try {
      const [openingTimeResult, closingTimeResult] = await Promise.all([
        this.getConfigurationValue('orders.opening_time'),
        this.getConfigurationValue('orders.closing_time')
      ]);

      if (!openingTimeResult || !closingTimeResult) {
        // Si les heures ne sont pas configurées, considérer que c'est ouvert
        return true;
      }

      const now = new Date();
      const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      
      const [currentHour, currentMin] = currentTime.split(':').map(Number);
      const [openHour, openMin] = openingTimeResult.split(':').map(Number);
      const [closeHour, closeMin] = closingTimeResult.split(':').map(Number);
      
      const currentMinutes = currentHour * 60 + currentMin;
      const openMinutes = openHour * 60 + openMin;
      const closeMinutes = closeHour * 60 + closeMin;

      return currentMinutes >= openMinutes && currentMinutes <= closeMinutes;

    } catch (error) {
      console.error('Erreur lors de la vérification des heures d\'ouverture:', error);
      // En cas d'erreur, considérer que c'est ouvert pour ne pas bloquer les commandes
      return true;
    }
  }
}

// Export par défaut pour faciliter l'importation
export default ConfigurationService;