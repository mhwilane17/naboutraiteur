import { CompaniesApiResponse, CompanyApiResponse, CompaniesListParams, CreateCompanyRequest, UpdateCompanyRequest, CompanyLimitInput } from '@/types/company';
import { ApiErrorResponse, ApiSuccessResponse } from '@/types/api';

export class CompanyService {
  static async getCompanies(params: CompaniesListParams = {}): Promise<CompaniesApiResponse | ApiErrorResponse> {
    const query = new URLSearchParams();
    if (params.page) query.set('page', String(params.page));
    if (params.limit) query.set('limit', String(params.limit));
    if (params.search) query.set('search', params.search);
    if (params.isActive) query.set('isActive', params.isActive);

    try {
      const res = await fetch(`/api/companies?${query.toString()}`, { method: 'GET' });
      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'FETCH_COMPANIES_ERROR',
            message: data.error?.message || 'Erreur lors de la récupération des entreprises',
            details: data.error?.details,
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }
      return data.data as CompaniesApiResponse;
    } catch (error) {
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : 'Erreur réseau inconnue',
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  static async getCompany(id: string): Promise<CompanyApiResponse | ApiErrorResponse> {
    try {
      const res = await fetch(`/api/companies/${id}`, { method: 'GET' });
      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'FETCH_COMPANY_ERROR',
            message: data.error?.message || "Erreur lors de la récupération de l'entreprise",
            details: data.error?.details,
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }
      return data as CompanyApiResponse;
    } catch (error) {
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : 'Erreur réseau inconnue',
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  static async createCompany(payload: Partial<CreateCompanyRequest>): Promise<CompanyApiResponse | ApiErrorResponse> {
    try {
      const res = await fetch('/api/companies', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'CREATE_COMPANY_ERROR',
            message: data.error?.message || "Erreur lors de la création de l'entreprise",
            details: data.error?.details,
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }
      return data as CompanyApiResponse;
    } catch (error) {
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : 'Erreur réseau inconnue',
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  static async updateCompany(id: string, payload: Partial<UpdateCompanyRequest>): Promise<CompanyApiResponse | ApiErrorResponse> {
    try {
      const res = await fetch(`/api/companies/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'UPDATE_COMPANY_ERROR',
            message: data.error?.message || "Erreur lors de la mise à jour de l'entreprise",
            details: data.error?.details,
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }
      return data as CompanyApiResponse;
    } catch (error) {
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : 'Erreur réseau inconnue',
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  static async deleteCompany(id: string): Promise<ApiSuccessResponse<null> | ApiErrorResponse> {
    try {
      const res = await fetch(`/api/companies/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'DELETE_COMPANY_ERROR',
            message: data.error?.message || "Erreur lors de la suppression de l'entreprise",
            details: data.error?.details,
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }
      return data as ApiSuccessResponse<null>;
    } catch (error) {
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : 'Erreur réseau inconnue',
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  static async updateLimits(id: string, limits: CompanyLimitInput[]): Promise<CompanyApiResponse | ApiErrorResponse> {
    try {
      const res = await fetch(`/api/companies/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ limits }) });
      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: {
            code: data.error?.code || 'UPDATE_COMPANY_LIMITS_ERROR',
            message: data.error?.message || 'Erreur lors de la mise à jour des limites',
            details: data.error?.details,
          },
          timestamp: new Date().toISOString(),
        } as ApiErrorResponse;
      }
      return data as CompanyApiResponse;
    } catch (error) {
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: error instanceof Error ? error.message : 'Erreur réseau inconnue',
        },
        timestamp: new Date().toISOString(),
      } as ApiErrorResponse;
    }
  }

  static isErrorResponse(resp: any): resp is ApiErrorResponse {
    return resp && resp.success === false && 'error' in resp;
  }
}