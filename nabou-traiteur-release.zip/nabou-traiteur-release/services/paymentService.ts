import { ApiSuccessResponse, ApiErrorResponse } from "@/types/api";

export interface PaymentMethod {
  id: string;
  name: string;
  description?: string;
  type: "CARD" | "MOBILE_MONEY" | "BANK_TRANSFER" | "CASH" | "COMPANY_BILLING";
  provider?: string;
  minimumAmount?: number;
  maximumAmount?: number;
  fees?: number;
  processingTime?: string;
  isActive: boolean;
  isDefault?: boolean;
}

class PaymentService {
  async getPaymentMethods(): Promise<ApiSuccessResponse<PaymentMethod[]> | ApiErrorResponse> {
    try {
      const response = await fetch("/api/payments/methods/public");
      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: {
            code: "PAYMENT_METHODS_ERROR",
            message: data.error || "Erreur lors de la récupération des méthodes de paiement",
          },
          timestamp: new Date().toISOString(),
        };
      }

      return {
        success: true,
        data: data.data?.methods || data.methods || [],
      };
    } catch (error) {
      console.error("Erreur lors de la récupération des méthodes de paiement:", error);
      return {
        success: false,
        error: {
          code: "NETWORK_ERROR",
          message: "Erreur réseau lors de la récupération des méthodes de paiement",
        },
        timestamp: new Date().toISOString(),
      };
    }
  }
}

export const paymentService = new PaymentService();
