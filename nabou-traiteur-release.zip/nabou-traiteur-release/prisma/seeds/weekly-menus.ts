import { PrismaClient } from "@prisma/client";

export async function seedWeeklyMenus(prisma: PrismaClient) {
  console.log("📅 Seeding des menus hebdomadaires...");

  // Récupérer les plats existants pour les associer aux menus
  const existingMenuItems = await prisma.menuItem.findMany({
    select: { id: true, name: true },
  });

  // Mapping des noms de plats vers leurs IDs
  const dishNameToId: Record<string, string> = {};
  existingMenuItems.forEach((item: { id: string; name: string }) => {
    dishNameToId[item.name] = item.id;
  });

  // Données des menus hebdomadaires
  const weeklyMenusData = [
    {
      id: "WEEK001",
      name: "Menu de la semaine du 27 au 27 juillet",
      description: "Menu varié avec spécialités sénégalaises",
      startDate: new Date("2025-07-21T00:00:00.000Z"),
      endDate: new Date("2025-07-27T23:59:59.000Z"),
      isActive: true,
      isPublished: true,
      totalPrice: 0, // Prix total estimé pour la semaine
      dishes: [
        {
          dishName: "Thiebou dieune bou weikh", // Correspond au nom dans menu-items.ts
          dayOfWeek: 1, // Lundi
          mealType: "lunch",
          isAvailable: true,
          specialPrice: 1400, // Prix spécial (réduction de 100)
          hasRakTakPromo: true,
        },
        {
          dishName: "Salade niçoise au thon", // Utiliser un plat existant
          dayOfWeek: 1, // Lundi
          mealType: "dinner",
          isAvailable: true,
          hasRakTakPromo: false,
        },
        {
          dishName: "Thiou Cury Poulet",
          dayOfWeek: 2, // Mardi
          mealType: "lunch",
          isAvailable: true,
          specialPrice: 1400,
          hasRakTakPromo: true,
        },
        {
          dishName: "Poisson Braisé + athiéké ou riz blanc",
          dayOfWeek: 3, // Mercredi
          mealType: "lunch",
          isAvailable: true,
          hasRakTakPromo: false,
        },
      ],
    },
    {
      id: "WEEK002",
      name: "Menu de la semaine du 28 juillet au 03 Aout",
      description: "Menu spécial avec promotion Rak Tak",
      startDate: new Date("2024-07-28T00:00:00.000Z"),
      endDate: new Date("2024-08-03T23:59:59.000Z"),
      isActive: true,
      isPublished: true,
      totalPrice: 0,
      dishes: [
        {
          dishName: "Domoda boulettes",
          dayOfWeek: 1, // Lundi
          mealType: "lunch",
          isAvailable: true,
          specialPrice: 1400, // Prix spécial
          hasRakTakPromo: true,
        },
      ],
    },
  ];

  // Créer les menus hebdomadaires
  for (const menuData of weeklyMenusData) {
    try {
      // Vérifier si le menu existe déjà
      const existingMenu = await prisma.weeklyMenu.findUnique({
        where: { id: menuData.id },
      });

      if (existingMenu) {
        console.log(`⏭️  Menu hebdomadaire ${menuData.id} existe déjà, ignoré.`);
        continue;
      }

      // Préparer les plats pour ce menu
      const dishesData = [];
      for (const dish of menuData.dishes) {
        const menuItemId = dishNameToId[dish.dishName];
        if (menuItemId) {
          dishesData.push({
            menuItemId,
            dayOfWeek: dish.dayOfWeek,
            mealType: dish.mealType,
            isAvailable: dish.isAvailable,
            specialPrice: dish.specialPrice,
            hasRakTakPromo: dish.hasRakTakPromo,
          });
        } else {
          console.warn(
            `⚠️  Plat "${dish.dishName}" non trouvé, ignoré pour le menu ${menuData.id}`
          );
        }
      }

      // Créer le menu avec ses plats
      const createdMenu = await prisma.weeklyMenu.create({
        data: {
          id: menuData.id,
          name: menuData.name,
          description: menuData.description,
          startDate: menuData.startDate,
          endDate: menuData.endDate,
          isActive: menuData.isActive,
          isPublished: menuData.isPublished,
          totalPrice: menuData.totalPrice,
          dishes: {
            create: dishesData,
          },
        },
        include: {
          dishes: {
            include: {
              menuItem: {
                select: { name: true },
              },
            },
          },
        },
      });

      console.log(
        `✅ Menu hebdomadaire créé: ${createdMenu.name} avec ${createdMenu.dishes.length} plats`
      );
    } catch (error) {
      console.error(`❌ Erreur lors de la création du menu ${menuData.id}:`, error);
    }
  }

  console.log("📅 Seeding des menus hebdomadaires terminé.");
}
