import { PrismaClient } from "../../lib/generated/prisma";

export async function seedRoles(prisma: PrismaClient) {
  const roles = [
    {
      id: "SUPER_ADMIN",
      name: "Super Administrateur",
      description: "Accès complet à toutes les fonctionnalités du système",
    },
    {
      id: "ADMIN",
      name: "Administrateur",
      description: "Gestion complète du restaurant et des commandes",
    },
    {
      id: "MANAGER",
      name: "Manager",
      description: "Gestion du menu, des commandes et des livraisons",
    },
    {
      id: "CHEF",
      name: "Chef Cuisinier",
      description: "Gestion du menu et des préparations",
    },
    {
      id: "DELIVERY",
      name: "Livreur",
      description: "Gestion des livraisons et statuts de commandes",
    },
    {
      id: "CUSTOMER",
      name: "Client",
      description: "Accès client pour passer des commandes",
    },
    {
      id: "EDITOR",
      name: "Éditeur",
      description:
        "Accès complet sauf suppression - peut créer, lire et modifier mais pas supprimer",
    },
  ];

  for (const role of roles) {
    await prisma.role.upsert({
      where: { id: role.id },
      update: {
        name: role.name,
        description: role.description,
      },
      create: role,
    });
  }

  console.log(`✅ ${roles.length} rôles créés/mis à jour`);
}
