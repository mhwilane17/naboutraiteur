import { PrismaClient } from '../../lib/generated/prisma'

export async function seedCategories(prisma: PrismaClient) {
  const categories = [
    {
      id: 'PLATS_PRINCIPAUX',
      name: 'Plats Principaux',
      description: 'Nos délicieux plats traditionnels sénégalais',
      color: 'orange',
      icon: 'utensils',
      sortOrder: 1
    },
    {
      id: 'SALADES_FRESH',
      name: 'Salades Fraîches',
      description: 'Salades fraîches et légères',
      color: 'green',
      icon: 'leaf',
      sortOrder: 2
    },
    {
      id: 'FAST_FOOD',
      name: 'Fast Food',
      description: 'Options rapides et savoureuses',
      color: 'red',
      icon: 'zap',
      sortOrder: 3
    },
    {
      id: 'DESSERTS_SWEET',
      name: 'Desserts',
      description: 'Desserts traditionnels et modernes',
      color: 'pink',
      icon: 'cake',
      sortOrder: 4
    },
    {
      id: 'BOISSONS_DRINKS',
      name: 'Boissons',
      description: 'Boissons fraîches et chaudes',
      color: 'blue',
      icon: 'coffee',
      sortOrder: 5
    },
    {
      id: 'DIET_HEALTHY',
      name: 'Healthy & Diet',
      description: 'Options saines et équilibrées',
      color: 'emerald',
      icon: 'heart',
      sortOrder: 6
    }
  ]

  for (const category of categories) {
    await prisma.category.upsert({
      where: { id: category.id },
      update: {
        name: category.name,
        description: category.description,
        color: category.color,
        icon: category.icon,
        sortOrder: category.sortOrder
      },
      create: category
    })
  }

  console.log(`✅ ${categories.length} catégories créées/mises à jour`)
}