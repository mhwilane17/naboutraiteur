import { PrismaClient } from "@prisma/client";

export async function seedCompanies(prisma: PrismaClient) {
  console.log("🏢 Seeding des entreprises...");

  const companies = [
    {
      id: "COMP_NABOU",
      name: "Nabou Traiteur",
      contactEmail: "contact@nabou-traiteur.com",
      isActive: true,
    },
    {
      id: "COMP_ACME",
      name: "ACME Corp",
      contactEmail: "contact@acme.com",
      isActive: true,
    },
  ];

  for (const company of companies) {
    await (prisma as any).company.upsert({
      where: { id: company.id },
      update: {
        name: company.name,
        contactEmail: company.contactEmail,
        isActive: company.isActive,
      },
      create: company,
    });
  }

  // Lier quelques utilisateurs existants à des entreprises par leur email
  const userCompanyLinks: { email: string; companyId: string }[] = [
    { email: "manager@nabou-traiteur.com", companyId: "COMP_NABOU" },
    { email: "chef@nabou-traiteur.com", companyId: "COMP_NABOU" },
    { email: "client1@nabou-traiteur.com", companyId: "COMP_ACME" },
    { email: "client2@nabou-traiteur.com", companyId: "COMP_ACME" },
  ];

  for (const link of userCompanyLinks) {
    const user = await prisma.user.findUnique({ where: { email: link.email } });
    if (user) {
      await (prisma as any).user.update({
        where: { id: user.id },
        data: { company: { connect: { id: link.companyId } } },
      });
    } else {
      console.warn(`⚠️ Utilisateur non trouvé pour l'email ${link.email}`);
    }
  }

  console.log(`✅ ${companies.length} entreprises créées/mises à jour et utilisateurs associés`);
}