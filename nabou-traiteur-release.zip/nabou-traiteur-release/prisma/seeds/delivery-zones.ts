import { PrismaClient } from "../../lib/generated/prisma";

export async function seedDeliveryZones(prisma: PrismaClient) {
  const deliveryZones = [
    {
      name: "Dakar Centre",
      description: "Livraison dans le centre de Dakar (Plateau, Médina)",
      deliveryFee: 2000,
      minOrderAmount: 0,
      maxOrderAmount: null,
      estimatedTime: "30-45 minutes",
      sortOrder: 1,
      areas: [
        { postalCode: "11500", city: "Dakar", district: "Plateau" },
        { postalCode: "11500", city: "Dakar", district: "Médina" },
        { postalCode: "11500", city: "Dakar", district: "Gueule Tapée" },
        { postalCode: "11500", city: "Dakar", district: "Fass" },
      ],
    },
    {
      name: "Dakar Nord",
      description: "Livraison dans le nord de Dakar (Yoff, Ngor, Almadies)",
      deliveryFee: 2000,
      minOrderAmount: 0,
      maxOrderAmount: null,
      estimatedTime: "35-50 minutes",
      sortOrder: 2,
      areas: [
        { postalCode: "11500", city: "Dakar", district: "Yoff" },
        { postalCode: "11500", city: "Dakar", district: "Ngor" },
        { postalCode: "11500", city: "Dakar", district: "Almadies" },
        { postalCode: "11500", city: "Dakar", district: "Mamelles" },
      ],
    },
    {
      name: "Dakar Est",
      description: "Livraison dans l'est de Dakar (HLM, Colobane, Biscuiterie)",
      deliveryFee: 2000,
      minOrderAmount: 0,
      maxOrderAmount: null,
      estimatedTime: "35-50 minutes",
      sortOrder: 3,
      areas: [
        { postalCode: "11500", city: "Dakar", district: "HLM" },
        { postalCode: "11500", city: "Dakar", district: "Colobane" },
        { postalCode: "11500", city: "Dakar", district: "Biscuiterie" },
        { postalCode: "11500", city: "Dakar", district: "Dieuppeul" },
      ],
    },
    {
      name: "Dakar Ouest",
      description: "Livraison dans l'ouest de Dakar (Ouakam, Mermoz, Point E)",
      deliveryFee: 2000,
      minOrderAmount: 0,
      maxOrderAmount: null,
      estimatedTime: "40-55 minutes",
      sortOrder: 4,
      areas: [
        { postalCode: "11500", city: "Dakar", district: "Ouakam" },
        { postalCode: "11500", city: "Dakar", district: "Mermoz" },
        { postalCode: "11500", city: "Dakar", district: "Point E" },
      ],
    },
    {
      name: "Grand Dakar",
      description: "Livraison dans Grand Dakar (Grand Dakar, Sicap)",
      deliveryFee: 2000,
      minOrderAmount: 0,
      maxOrderAmount: null,
      estimatedTime: "35-50 minutes",
      sortOrder: 5,
      areas: [
        { postalCode: "11500", city: "Dakar", district: "Grand Dakar" },
        { postalCode: "11500", city: "Dakar", district: "Sicap Liberté" },
      ],
    },
    {
      name: "Banlieue Proche",
      description: "Livraison en banlieue proche (Pikine, Guédiawaye)",
      deliveryFee: 2000,
      minOrderAmount: 0,
      maxOrderAmount: null,
      estimatedTime: "45-60 minutes",
      sortOrder: 6,
      areas: [
        { postalCode: "11500", city: "Dakar", district: "Pikine" },
        { postalCode: "11500", city: "Dakar", district: "Guédiawaye" },
        { postalCode: "11500", city: "Dakar", district: "Parcelles Assainies" },
        { postalCode: "11500", city: "Dakar", district: "Keur Massar" },
      ],
    },
  ];

  for (const zone of deliveryZones) {
    const { areas, ...zoneData } = zone;

    const createdZone = await prisma.deliveryZone.create({
      data: zoneData,
    });

    // Créer les zones géographiques
    for (const area of areas) {
      await prisma.deliveryZoneArea.create({
        data: {
          ...area,
          deliveryZoneId: createdZone.id,
        },
      });
    }
  }

  console.log(
    `✅ ${deliveryZones.length} zones de livraison créées avec leurs zones géographiques`
  );
}
