import { PrismaClient } from "@prisma/client";

export async function seedAppConfigurations(prisma: PrismaClient) {
  console.log("⚙️ Seeding des configurations d'application...");

  const defaultConfigurations = [
    // Section Général
    // {
    //   key: 'app.name',
    //   value: 'Nabou Traiteur',
    //   type: 'string',
    //   section: 'general',
    //   label: 'Nom de l\'application',
    //   description: 'Nom affiché de l\'application',
    //   isRequired: true,
    //   sortOrder: 1
    // },
    // {
    //   key: 'app.environment',
    //   value: process.env.NODE_ENV || 'development',
    //   type: 'string',
    //   section: 'general',
    //   label: 'Environnement',
    //   description: 'Environnement d\'exécution',
    //   isRequired: true,
    //   sortOrder: 2
    // },
    // {
    //   key: 'app.form_estimate_url',
    //   value: process.env.FORM_ESTIMATE_URL || '',
    //   type: 'string',
    //   section: 'general',
    //   label: 'URL du formulaire de devis',
    //   description: 'Lien vers le formulaire Google de demande de devis',
    //   isRequired: false,
    //   sortOrder: 3
    // },

    // // Section Commandes
    // {
    //   key: 'orders.opening_time',
    //   value: '07:00',
    //   type: 'time',
    //   section: 'orders',
    //   label: 'Heure d\'ouverture',
    //   description: 'Heure à partir de laquelle les commandes sont acceptées',
    //   isRequired: true,
    //   sortOrder: 1,
    //   validation: JSON.stringify({
    //     pattern: '^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$',
    //     message: 'Format d\'heure invalide (HH:MM)'
    //   })
    // },
    // {
    //   key: 'orders.closing_time',
    //   value: '16:00',
    //   type: 'time',
    //   section: 'orders',
    //   label: 'Heure de fermeture',
    //   description: 'Heure jusqu\'à laquelle les commandes sont acceptées',
    //   isRequired: true,
    //   sortOrder: 2,
    //   validation: JSON.stringify({
    //     pattern: '^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$',
    //     message: 'Format d\'heure invalide (HH:MM)'
    //   })
    // },

    // // Section Notifications
    // {
    //   key: 'notifications.whatsapp_token',
    //   value: process.env.WHATSAPP_TOKEN || '',
    //   type: 'string',
    //   section: 'notifications',
    //   label: 'Token WhatsApp',
    //   description: 'Token d\'authentification WhatsApp Business API',
    //   isRequired: false,
    //   isSecret: true,
    //   sortOrder: 1
    // },
    // {
    //   key: 'notifications.whatsapp_phone',
    //   value: process.env.WHATSAPP_RECIPIENT_PHONE_NUMBER || '',
    //   type: 'string',
    //   section: 'notifications',
    //   label: 'Numéro WhatsApp',
    //   description: 'Numéro de téléphone pour les notifications WhatsApp',
    //   isRequired: false,
    //   sortOrder: 2,
    //   validation: JSON.stringify({
    //     pattern: '^[0-9]{10,15}$',
    //     message: 'Numéro de téléphone invalide (10-15 chiffres)'
    //   })
    // },
    // {
    //   key: 'notifications.whatsapp_phone_number_id',
    //   value: process.env.WHATSAPP_PHONE_NUMBER_ID || '',
    //   type: 'string',
    //   section: 'notifications',
    //   label: 'ID du numéro WhatsApp',
    //   description: 'Identifiant du numéro de téléphone WhatsApp Business',
    //   isRequired: false,
    //   isSecret: true,
    //   sortOrder: 3
    // },
    // {
    //   key: 'notifications.from_email',
    //   value: process.env.FROM_EMAIL || '',
    //   type: 'string',
    //   section: 'notifications',
    //   label: 'Email expéditeur',
    //   description: 'Adresse email pour l\'envoi des notifications',
    //   isRequired: false,
    //   sortOrder: 4,
    //   validation: JSON.stringify({
    //     pattern: '^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$',
    //     message: 'Adresse email invalide'
    //   })
    // },
    // {
    //   key: 'notifications.from_email_password',
    //   value: process.env.FROM_EMAIL_PASSWORD || '',
    //   type: 'string',
    //   section: 'notifications',
    //   label: 'Mot de passe email',
    //   description: 'Mot de passe pour l\'envoi des notifications',
    //   isRequired: false,
    //   isSecret: true,
    //   sortOrder: 5
    // },
    {
      key: 'notifications.smtp_host',
      value: process.env.SMTP_HOST || '',
      type: 'string',
      section: 'notifications',
      label: 'Hôte SMTP',
      description: 'Hôte SMTP pour l\'envoi des emails',
      isRequired: false,
      isSecret: false,
      sortOrder: 6,
      validation: JSON.stringify({
        pattern: '^[a-zA-Z0-9-]+\\.[a-zA-Z0-9-]+$',
        message: 'Hôte SMTP invalide'
      })
    },
    {
      key: 'notifications.smtp_port',
      value: process.env.SMTP_PORT || '',
      type: 'string',
      section: 'notifications',
      label: 'Port SMTP',
      description: 'Port SMTP pour l\'envoi des emails',
      isRequired: false,
      isSecret: false,
      sortOrder: 7,
      validation: JSON.stringify({
        pattern: '^[0-9]+$',
        message: 'Port SMTP invalide'
      })
    },
    {
      key: 'notifications.smtp_secure',
      value: process.env.SMTP_SECURE || '',
      type: 'string',
      section: 'notifications',
      label: 'Sécurité SMTP',
      isSecret: true,
      description: 'Utiliser SSL/TLS pour l\'envoi des emails',
      isRequired: false,
      sortOrder: 8,
      validation: JSON.stringify({
        pattern: '^[a-zA-Z0-9-]+$',
        message: 'Sécurité SMTP invalide'
      })
    },

    // Section Paiements
    // {
    //   key: 'payments.wave_payment_link',
    //   value: process.env.WAVE_PAYMENT_LINK || '',
    //   type: 'string',
    //   section: 'payments',
    //   label: 'Lien de paiement Wave',
    //   description: 'URL de paiement Wave pour les transactions',
    //   isRequired: false,
    //   sortOrder: 1,
    //   validation: JSON.stringify({
    //     pattern: '^https?:\\/\\/.+',
    //     message: 'URL invalide'
    //   })
    // },
  ];

  // Utiliser upsert pour éviter les doublons lors de re-seeding
  for (const config of defaultConfigurations) {
    await prisma.appConfiguration.upsert({
      where: { key: config.key },
      update: {
        // Ne pas écraser les valeurs existantes, seulement les métadonnées
        type: config.type,
        section: config.section,
        label: config.label,
        description: config.description,
        isRequired: config.isRequired,
        isSecret: config.isSecret,
        validation: config.validation as any,
        sortOrder: config.sortOrder
      },
      create: config
    });
  }

  console.log(`✅ ${defaultConfigurations.length} configurations d'application créées/mises à jour`);
}