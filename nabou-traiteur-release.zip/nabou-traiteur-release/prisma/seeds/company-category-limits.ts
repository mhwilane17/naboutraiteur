import { PrismaClient } from "@prisma/client";

export async function seedCompanyCategoryLimits(prisma: PrismaClient) {
  console.log("📊 Seeding des limites par catégorie par entreprise...");

  // Définir quelques limites d'exemple
  const limits: {
    companyId: string;
    categoryId: string;
    maxPerOrder: number;
  }[] = [
    { companyId: "COMP_NABOU", categoryId: "PLATS_PRINCIPAUX", maxPerOrder: 5 },
    { companyId: "COMP_NABOU", categoryId: "DIET_HEALTHY", maxPerOrder: 3 },
    { companyId: "COMP_ACME", categoryId: "PLATS_PRINCIPAUX", maxPerOrder: 2 },
    { companyId: "COMP_ACME", categoryId: "DESSERTS_SWEET", maxPerOrder: 4 },
  ];

  let createdOrUpdated = 0;

  for (const l of limits) {
    // Vérifier l'existence de la company et de la catégorie
    const [company, category] = await Promise.all([
      (prisma as any).company.findUnique({ where: { id: l.companyId } }),
      prisma.category.findUnique({ where: { id: l.categoryId } }),
    ]);

    if (!company) {
      console.warn(`⚠️ Entreprise non trouvée: ${l.companyId}, limite ignorée.`);
      continue;
    }
    if (!category) {
      console.warn(`⚠️ Catégorie non trouvée: ${l.categoryId}, limite ignorée.`);
      continue;
    }

    await (prisma as any).companyCategoryLimit.upsert({
      where: { companyId_categoryId: { companyId: l.companyId, categoryId: l.categoryId } },
      update: { maxPerOrder: l.maxPerOrder },
      create: {
        companyId: l.companyId,
        categoryId: l.categoryId,
        maxPerOrder: l.maxPerOrder,
      },
    });
    createdOrUpdated += 1;
  }

  console.log(`✅ ${createdOrUpdated} limites par catégorie créées/mises à jour`);
}