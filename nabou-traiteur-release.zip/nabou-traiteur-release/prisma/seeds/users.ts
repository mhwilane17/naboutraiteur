import { hashPassword } from "@/lib/auth";
import { PrismaClient } from "../../lib/generated/prisma";

export async function seedUsers(prisma: PrismaClient) {
  const users = [
    {
      email: "admin@nabou-traiteur.com",
      firstName: "Admin",
      lastName: "Nabou",
      phone: "+33123456789",
      address: "123 Rue de la Paix",
      city: "Paris",
      postalCode: "75001",
      isActive: true,
      roles: ["SUPER_ADMIN"],
      passwordHash: await hashPassword("nab_pass_2025"),
    },
    {
      email: "manager@nabou-traiteur.com",
      firstName: "Manager",
      lastName: "Nabou",
      phone: "+33123456790",
      address: "456 Avenue des Champs",
      city: "Paris",
      postalCode: "75008",
      isActive: true,
      roles: ["MANAGER"],
      passwordHash: await hashPassword("nab_pass_2025"),
    },
    {
      email: "chef@nabou-traiteur.com",
      firstName: "Chef",
      lastName: "Nabou",
      phone: "+33123456791",
      address: "789 Boulevard Saint-Germain",
      city: "Paris",
      postalCode: "75006",
      isActive: true,
      roles: ["CHEF"],
      passwordHash: await hashPassword("nab_pass_2025"),
    },
    {
      email: "livreur1@nabou-traiteur.com",
      firstName: "Livreur1",
      lastName: "nabou",
      phone: "+33123456792",
      address: "321 Rue de Rivoli",
      city: "Paris",
      postalCode: "75004",
      isActive: true,
      roles: ["DELIVERY"],
      passwordHash: await hashPassword("nab_pass_2025"),
    },
    {
      email: "client1@nabou-traiteur.com",
      firstName: "Sophie",
      lastName: "Martin",
      phone: "+33123456793",
      address: "654 Rue de la République",
      city: "Paris",
      postalCode: "75011",
      isActive: true,
      roles: ["CUSTOMER"],
      passwordHash: await hashPassword("nab_pass_2025"),
    },
    {
      email: "client2@nabou-traiteur.com",
      firstName: "Pierre",
      lastName: "Dubois",
      phone: "+33123456794",
      address: "987 Avenue Montaigne",
      city: "Paris",
      postalCode: "75008",
      isActive: true,
      roles: ["CUSTOMER"],
      passwordHash: await hashPassword("nab_pass_2025"),
    },
    {
      email: "client3@nabou-traiteur.com",
      firstName: "Fatou",
      lastName: "Ndiaye",
      phone: "+33123456795",
      address: "147 Rue du Faubourg Saint-Antoine",
      city: "Paris",
      postalCode: "75012",
      isActive: true,
      roles: ["CUSTOMER"],
      passwordHash: await hashPassword("nab_pass_2025"),
    },
    {
      email: "editor@nabou-traiteur.com",
      firstName: "Éditeur",
      lastName: "Nabou",
      phone: "+221777777777",
      address: "Dakar, Sénégal",
      city: "Dakar",
      postalCode: "17000",
      isActive: true,
      roles: ["EDITOR"],
      passwordHash: await hashPassword("nab_pass_2025"),
    },
  ];

  for (const userData of users) {
    const { roles, ...userInfo } = userData;

    // Créer l'utilisateur
    const user = await prisma.user.create({
      data: userInfo,
    });

    // Assigner les rôles
    for (const roleId of roles) {
      await prisma.userRole.create({
        data: {
          userId: user.id,
          roleId: roleId,
          assignedBy: "SYSTEM",
        },
      });
    }
  }

  console.log(`✅ ${users.length} utilisateurs créés avec leurs rôles`);
}
