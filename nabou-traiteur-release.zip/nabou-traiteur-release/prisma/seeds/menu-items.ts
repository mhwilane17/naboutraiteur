import { PrismaClient } from "../../lib/generated/prisma";

export async function seedMenuItems(prisma: PrismaClient) {
  const menuItems = [
    // Lundi
    {
      name: "Steak grillé, gratin de pomme de terre",
      description: "Steak grillé accompagné d'un délicieux gratin de pomme de terre",
      price: 2000,
      categoryId: "PLATS_PRINCIPAUX",
      preparationTime: 35,
      allergens: [],
      sortOrder: 6,
    },
    {
      name: "Brochettes de légumes et poulet + purée",
      description: "Brochettes de légumes et poulet servies avec purée",
      price: 2000,
      categoryId: "DIET_HEALTHY",
      preparationTime: 30,
      allergens: [],
      sortOrder: 3,
    },
    {
      name: "Salade niçoise au thon",
      description: "Salade niçoise traditionnelle au thon",
      price:1500,
      categoryId: "SALADES_FRESH",
      preparationTime: 15,
      allergens: [],
      sortOrder: 3,
    },

    // Mardi
    {
      name: "Thiou Cury Poulet",
      description: "Plat traditionnel sénégalais au curry de poulet",
      price:1500,
      image: "/images/nabou_traiteur_dakhine.png",
      categoryId: "PLATS_PRINCIPAUX",
      preparationTime: 40,
      allergens: [],
      sortOrder: 7,
    },
    {
      name: "Poisson Braisé + athiéké ou riz blanc",
      description: "Poisson braisé servi avec athiéké ou riz blanc",
      price: 2000,
      categoryId: "PLATS_PRINCIPAUX",
      preparationTime: 45,
      allergens: [],
      sortOrder: 8,
    },
    {
      name: "Filet de poisson grillé",
      description: "Filet de poisson grillé, option healthy",
      price: 2000,
      categoryId: "DIET_HEALTHY",
      preparationTime: 25,
      allergens: [],
      sortOrder: 4,
    },
    {
      name: "Salade d'avocat au poulet et crudités",
      description: "Salade fraîche d'avocat au poulet avec crudités",
      price:1500,
      categoryId: "SALADES_FRESH",
      preparationTime: 15,
      allergens: [],
      sortOrder: 4,
    },

    // Mercredi
    {
      name: "Thiebou dieune bou weikh",
      description: "Thiéboudienne blanche traditionnelle",
      price:1500,
      image: "/images/nabou_traiteur_riz_au_poulet.png",
      categoryId: "PLATS_PRINCIPAUX",
      preparationTime: 50,
      allergens: [],
      sortOrder: 9,
    },
    {
      name: "Lasagne à la bolognaise",
      description: "Lasagne traditionnelle à la sauce bolognaise",
      price: 2000,
      categoryId: "PLATS_PRINCIPAUX",
      preparationTime: 40,
      allergens: [],
      sortOrder: 10,
    },
    {
      name: "Poélé de bœuf haché aux légumes + purée",
      description: "Poélé de bœuf haché aux légumes servi avec purée",
      price: 2000,
      categoryId: "DIET_HEALTHY",
      preparationTime: 30,
      allergens: [],
      sortOrder: 5,
    },
    {
      name: "Salade mexicaine crevettes",
      description: "Salade mexicaine aux crevettes épicée",
      price:1500,
      categoryId: "SALADES_FRESH",
      preparationTime: 20,
      allergens: [],
      sortOrder: 5,
    },

    // Jeudi
    {
      name: "Domoda boulettes",
      description: "Domoda traditionnel aux boulettes de viande",
      price:1500,
      image: "/images/nabou_traiteur_mafe_yapp.png",
      categoryId: "PLATS_PRINCIPAUX",
      preparationTime: 45,
      allergens: [],
      sortOrder: 11,
    },
    {
      name: "Poulet Braisé + Frites ou Riz composé",
      description: "Poulet braisé servi avec frites ou riz composé",
      price: 2000,
      categoryId: "PLATS_PRINCIPAUX",
      preparationTime: 35,
      allergens: [],
      sortOrder: 12,
    },
    {
      name: "Spaghetti crémeux au filet de poulet grillé",
      description: "Spaghetti crémeux accompagnés de filet de poulet grillé",
      price: 2000,
      categoryId: "DIET_HEALTHY",
      preparationTime: 25,
      allergens: [],
      sortOrder: 6,
    },
    {
      name: "Salade chinoise aux nems",
      description: "Salade chinoise fraîche accompagnée de nems",
      price:1500,
      categoryId: "SALADES_FRESH",
      preparationTime: 15,
      allergens: [],
      sortOrder: 6,
    },

    // Vendredi
    {
      name: "Thiebou Yapp vermicelles",
      description: "Thiébou Yapp aux vermicelles, spécialité du vendredi",
      price:1500,
      image: "/images/nabou_traiteur_riz_au_poisson.png",
      categoryId: "PLATS_PRINCIPAUX",
      preparationTime: 45,
      allergens: [],
      sortOrder: 13,
    },
    {
      name: "Tagliatelles au poulet",
      description: "Tagliatelles fraîches au poulet",
      price: 2000,
      categoryId: "PLATS_PRINCIPAUX",
      preparationTime: 30,
      allergens: [],
      sortOrder: 14,
    },
    {
      name: "Mini brochette de viande à la sauce tomate légumes sautés",
      description: "Mini brochettes de viande sauce tomate avec légumes sautés",
      price: 2000,
      categoryId: "DIET_HEALTHY",
      preparationTime: 35,
      allergens: [],
      sortOrder: 7,
    },
    {
      name: "Salade composée",
      description: "Salade composée variée et équilibrée",
      price:1500,
      categoryId: "SALADES_FRESH",
      preparationTime: 15,
      allergens: [],
      sortOrder: 7,
    },
  ];

  for (const item of menuItems) {
    await prisma.menuItem.create({
      data: {
        ...item,
        nutritionalInfo: {
          calories: Math.floor(Math.random() * 300) + 200,
          protein: Math.floor(Math.random() * 20) + 10,
          carbs: Math.floor(Math.random() * 40) + 20,
          fat: Math.floor(Math.random() * 15) + 5,
        },
      },
    });
  }

  console.log(`✅ ${menuItems.length} plats créés`);
}
