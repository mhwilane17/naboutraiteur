import { PrismaClient } from "../../lib/generated/prisma";

export async function seedPermissions(prisma: PrismaClient) {
  const permissions = [
    // Gestion des utilisateurs
    { id: "CREATE_USER", name: "Créer un utilisateur", module: "users", action: "create" },
    { id: "READ_USER", name: "Voir les utilisateurs", module: "users", action: "read" },
    { id: "UPDATE_USER", name: "Modifier un utilisateur", module: "users", action: "update" },
    { id: "DELETE_USER", name: "Supprimer un utilisateur", module: "users", action: "delete" },
    {
      id: "ACTIVATE_USER",
      name: "Activer/Désactiver un utilisateur",
      module: "users",
      action: "activate",
    },
    {
      id: "VIEW_USER_PROFILE",
      name: "Voir le profil utilisateur",
      module: "users",
      action: "view_profile",
    },
    
    // Gestion des avis
    { id: "READ_REVIEW", name: "Voir les avis", module: "reviews", action: "read" },
    { id: "UPDATE_REVIEW", name: "Modifier un avis", module: "reviews", action: "update" },
    { id: "DELETE_REVIEW", name: "Supprimer un avis", module: "reviews", action: "delete" },

    // Gestion des rôles
    { id: "CREATE_ROLE", name: "Créer un rôle", module: "roles", action: "create" },
    { id: "READ_ROLE", name: "Voir les rôles", module: "roles", action: "read" },
    { id: "UPDATE_ROLE", name: "Modifier un rôle", module: "roles", action: "update" },
    { id: "DELETE_ROLE", name: "Supprimer un rôle", module: "roles", action: "delete" },
    {
      id: "ASSIGN_PERMISSIONS",
      name: "Assigner des permissions",
      module: "roles",
      action: "assign_permissions",
    },

    // Gestion des permissions
    { id: "READ_PERMISSION", name: "Voir les permissions", module: "permissions", action: "read" },
    {
      id: "MANAGE_PERMISSIONS",
      name: "Gérer les permissions",
      module: "permissions",
      action: "manage",
    },

    // Gestion du menu
    { id: "CREATE_MENU_ITEM", name: "Créer un élément de menu", module: "menu", action: "create" },
    { id: "READ_MENU_ITEM", name: "Voir le menu", module: "menu", action: "read" },
    { id: "UPDATE_MENU_ITEM", name: "Modifier un élément de menu", module: "menu", action: "update" },
    { id: "DELETE_MENU_ITEM", name: "Supprimer un élément de menu", module: "menu", action: "delete" },
    {
      id: "TOGGLE_MENU_ITEM_AVAILABILITY",
      name: "Activer/Désactiver un plat",
      module: "menu",
      action: "toggle_availability",
    },

    // Gestion des options de plats
    {
      id: "CREATE_MENU_ITEM_OPTION",
      name: "Créer une option de plat",
      module: "menu_options",
      action: "create",
    },
    {
      id: "READ_MENU_ITEM_OPTION",
      name: "Voir les options de plats",
      module: "menu_options",
      action: "read",
    },
    {
      id: "UPDATE_MENU_ITEM_OPTION",
      name: "Modifier une option de plat",
      module: "menu_options",
      action: "update",
    },
    {
      id: "DELETE_MENU_ITEM_OPTION",
      name: "Supprimer une option de plat",
      module: "menu_options",
      action: "delete",
    },

    // Gestion des plats
    { id: "CREATE_DISH", name: "Créer un plat", module: "dishes", action: "create" },
    { id: "READ_DISH", name: "Voir les plats", module: "dishes", action: "read" },
    { id: "UPDATE_DISH", name: "Modifier un plat", module: "dishes", action: "update" },
    { id: "DELETE_DISH", name: "Supprimer un plat", module: "dishes", action: "delete" },

    // Gestion des catégories
    { id: "CREATE_CATEGORY", name: "Créer une catégorie", module: "categories", action: "create" },
    { id: "READ_CATEGORY", name: "Voir les catégories", module: "categories", action: "read" },
    {
      id: "UPDATE_CATEGORY",
      name: "Modifier une catégorie",
      module: "categories",
      action: "update",
    },
    {
      id: "DELETE_CATEGORY",
      name: "Supprimer une catégorie",
      module: "categories",
      action: "delete",
    },
    {
      id: "ARCHIVE_CATEGORY",
      name: "Archiver une catégorie",
      module: "categories",
      action: "archive",
    },

    // Gestion des menus hebdomadaires
    {
      id: "CREATE_WEEKLY_MENU",
      name: "Créer un menu hebdomadaire",
      module: "weekly_menus",
      action: "create",
    },
    {
      id: "READ_WEEKLY_MENU",
      name: "Voir les menus hebdomadaires",
      module: "weekly_menus",
      action: "read",
    },
    {
      id: "UPDATE_WEEKLY_MENU",
      name: "Modifier un menu hebdomadaire",
      module: "weekly_menus",
      action: "update",
    },
    {
      id: "DELETE_WEEKLY_MENU",
      name: "Supprimer un menu hebdomadaire",
      module: "weekly_menus",
      action: "delete",
    },
    {
      id: "PUBLISH_WEEKLY_MENU",
      name: "Publier un menu hebdomadaire",
      module: "weekly_menus",
      action: "publish",
    },
    {
      id: "ACTIVATE_WEEKLY_MENU",
      name: "Activer/Désactiver un menu hebdomadaire",
      module: "weekly_menus",
      action: "activate",
    },

    // Gestion des plats de menus hebdomadaires
    {
      id: "CREATE_WEEKLY_MENU_DISH",
      name: "Ajouter un plat au menu hebdomadaire",
      module: "weekly_menu_dishes",
      action: "create",
    },
    {
      id: "READ_WEEKLY_MENU_DISH",
      name: "Voir les plats des menus hebdomadaires",
      module: "weekly_menu_dishes",
      action: "read",
    },
    {
      id: "UPDATE_WEEKLY_MENU_DISH",
      name: "Modifier un plat du menu hebdomadaire",
      module: "weekly_menu_dishes",
      action: "update",
    },
    {
      id: "DELETE_WEEKLY_MENU_DISH",
      name: "Retirer un plat du menu hebdomadaire",
      module: "weekly_menu_dishes",
      action: "delete",
    },

    // Gestion des commandes
    { id: "CREATE_ORDER", name: "Créer une commande", module: "orders", action: "create" },
    { id: "READ_ORDER", name: "Voir les commandes", module: "orders", action: "read" },
    { id: "UPDATE_ORDER", name: "Modifier une commande", module: "orders", action: "update" },
    { id: "DELETE_ORDER", name: "Supprimer une commande", module: "orders", action: "delete" },
    {
      id: "UPDATE_ORDER_STATUS",
      name: "Modifier le statut d'une commande",
      module: "orders",
      action: "update_status",
    },
    { id: "CANCEL_ORDER", name: "Annuler une commande", module: "orders", action: "cancel" },
    { id: "CONFIRM_ORDER", name: "Confirmer une commande", module: "orders", action: "confirm" },
    { id: "PROCESS_ORDER", name: "Traiter une commande", module: "orders", action: "process" },
    { id: "DELIVER_ORDER", name: "Livrer une commande", module: "orders", action: "deliver" },
    {
      id: "VIEW_ORDER_DETAILS",
      name: "Voir les détails d'une commande",
      module: "orders",
      action: "view_details",
    },

    // Gestion des articles de commande
    {
      id: "CREATE_ORDER_ITEM",
      name: "Ajouter un article à une commande",
      module: "order_items",
      action: "create",
    },
    {
      id: "READ_ORDER_ITEM",
      name: "Voir les articles de commande",
      module: "order_items",
      action: "read",
    },
    {
      id: "UPDATE_ORDER_ITEM",
      name: "Modifier un article de commande",
      module: "order_items",
      action: "update",
    },
    {
      id: "DELETE_ORDER_ITEM",
      name: "Supprimer un article de commande",
      module: "order_items",
      action: "delete",
    },

    // Gestion des livraisons
    {
      id: "CREATE_DELIVERY_ZONE",
      name: "Créer une zone de livraison",
      module: "delivery",
      action: "create",
    },
    {
      id: "READ_DELIVERY_ZONE",
      name: "Voir les zones de livraison",
      module: "delivery",
      action: "read",
    },
    {
      id: "UPDATE_DELIVERY_ZONE",
      name: "Modifier une zone de livraison",
      module: "delivery",
      action: "update",
    },
    {
      id: "DELETE_DELIVERY_ZONE",
      name: "Supprimer une zone de livraison",
      module: "delivery",
      action: "delete",
    },
    {
      id: "ACTIVATE_DELIVERY_ZONE",
      name: "Activer/Désactiver une zone de livraison",
      module: "delivery",
      action: "activate",
    },

    // Gestion des paiements
    {
      id: "CREATE_PAYMENT_METHOD",
      name: "Créer une méthode de paiement",
      module: "payments",
      action: "create",
    },
    {
      id: "READ_PAYMENT_METHOD",
      name: "Voir les méthodes de paiement",
      module: "payments",
      action: "read",
    },
    {
      id: "UPDATE_PAYMENT_METHOD",
      name: "Modifier une méthode de paiement",
      module: "payments",
      action: "update",
    },
    {
      id: "DELETE_PAYMENT_METHOD",
      name: "Supprimer une méthode de paiement",
      module: "payments",
      action: "delete",
    },
    {
      id: "ACTIVATE_PAYMENT_METHOD",
      name: "Activer/Désactiver une méthode de paiement",
      module: "payments",
      action: "activate",
    },
    { id: "PROCESS_PAYMENT", name: "Traiter un paiement", module: "payments", action: "process" },

    // Gestion des transactions de paiement
    {
      id: "CREATE_PAYMENT_TRANSACTION",
      name: "Créer une transaction de paiement",
      module: "payment_transactions",
      action: "create",
    },
    {
      id: "READ_PAYMENT_TRANSACTION",
      name: "Voir les transactions de paiement",
      module: "payment_transactions",
      action: "read",
    },
    {
      id: "UPDATE_PAYMENT_TRANSACTION",
      name: "Modifier une transaction de paiement",
      module: "payment_transactions",
      action: "update",
    },
    {
      id: "REFUND_PAYMENT",
      name: "Rembourser un paiement",
      module: "payment_transactions",
      action: "refund",
    },

    // Gestion des promotions
    { id: "CREATE_PROMOTION", name: "Créer une promotion", module: "promotions", action: "create" },
    { id: "READ_PROMOTION", name: "Voir les promotions", module: "promotions", action: "read" },
    {
      id: "UPDATE_PROMOTION",
      name: "Modifier une promotion",
      module: "promotions",
      action: "update",
    },
    {
      id: "DELETE_PROMOTION",
      name: "Supprimer une promotion",
      module: "promotions",
      action: "delete",
    },
    {
      id: "ACTIVATE_PROMOTION",
      name: "Activer/Désactiver une promotion",
      module: "promotions",
      action: "activate",
    },
    {
      id: "VALIDATE_PROMOTION",
      name: "Valider une promotion",
      module: "promotions",
      action: "validate",
    },
    {
      id: "VIEW_PROMOTION_STATS",
      name: "Voir les statistiques des promotions",
      module: "promotions",
      action: "view_stats",
    },

    // Gestion de l'utilisation des promotions
    {
      id: "CREATE_PROMOTION_USAGE",
      name: "Enregistrer l'utilisation d'une promotion",
      module: "promotion_usage",
      action: "create",
    },
    {
      id: "READ_PROMOTION_USAGE",
      name: "Voir l'utilisation des promotions",
      module: "promotion_usage",
      action: "read",
    },
    {
      id: "UPDATE_PROMOTION_USAGE",
      name: "Modifier l'utilisation d'une promotion",
      module: "promotion_usage",
      action: "update",
    },
    {
      id: "DELETE_PROMOTION_USAGE",
      name: "Supprimer l'utilisation d'une promotion",
      module: "promotion_usage",
      action: "delete",
    },

    // Gestion des configurations
    {
      id: "READ_CONFIGURATION",
      name: "Voir les configurations",
      module: "configurations",
      action: "read",
    },
    {
      id: "UPDATE_CONFIGURATION",
      name: "Modifier les configurations",
      module: "configurations",
      action: "update",
    },
    {
      id: "RESET_CONFIGURATION",
      name: "Réinitialiser les configurations",
      module: "configurations",
      action: "reset",
    },

    // Dashboard et statistiques
    { id: "VIEW_DASHBOARD", name: "Voir le tableau de bord", module: "dashboard", action: "read" },
    { id: "VIEW_ANALYTICS", name: "Voir les statistiques", module: "analytics", action: "read" },
    {
      id: "VIEW_SALES_ANALYTICS",
      name: "Voir les statistiques de vente",
      module: "analytics",
      action: "view_sales",
    },
    {
      id: "VIEW_ORDER_ANALYTICS",
      name: "Voir les statistiques de commandes",
      module: "analytics",
      action: "view_orders",
    },
    {
      id: "VIEW_USER_ANALYTICS",
      name: "Voir les statistiques d'utilisateurs",
      module: "analytics",
      action: "view_users",
    },
    {
      id: "EXPORT_ANALYTICS",
      name: "Exporter les statistiques",
      module: "analytics",
      action: "export",
    },

    // Authentification et profil
    { id: "LOGIN", name: "Se connecter", module: "auth", action: "login" },
    { id: "LOGOUT", name: "Se déconnecter", module: "auth", action: "logout" },
    { id: "REGISTER", name: "S'inscrire", module: "auth", action: "register" },
    {
      id: "RESET_PASSWORD",
      name: "Réinitialiser le mot de passe",
      module: "auth",
      action: "reset_password",
    },
    { id: "UPDATE_PROFILE", name: "Modifier le profil", module: "auth", action: "update_profile" },
    { id: "VERIFY_EMAIL", name: "Vérifier l'email", module: "auth", action: "verify_email" },

    // Navigation et accès aux modules
    {
      id: "ACCESS_ADMIN",
      name: "Accès à l'administration",
      module: "navigation",
      action: "access_admin",
    },
    {
      id: "ACCESS_DASHBOARD",
      name: "Accès au tableau de bord",
      module: "navigation",
      action: "access_dashboard",
    },
    {
      id: "ACCESS_USERS_MODULE",
      name: "Accès au module utilisateurs",
      module: "navigation",
      action: "access_users",
    },
    {
      id: "ACCESS_ORDERS_MODULE",
      name: "Accès au module commandes",
      module: "navigation",
      action: "access_orders",
    },
    {
      id: "ACCESS_MENU_MODULE",
      name: "Accès au module menu",
      module: "navigation",
      action: "access_menu",
    },
    {
      id: "ACCESS_ROLES_MODULE",
      name: "Accès au module rôles",
      module: "navigation",
      action: "access_roles",
    },
    {
      id: "ACCESS_SETTINGS_MODULE",
      name: "Accès au module paramètres",
      module: "navigation",
      action: "access_settings",
    },
    {
      id: "ACCESS_ANALYTICS_MODULE",
      name: "Accès au module analytiques",
      module: "navigation",
      action: "access_analytics",
    },
    {
      id: "ACCESS_PROMOTIONS_MODULE",
      name: "Accès au module promotions",
      module: "navigation",
      action: "access_promotions",
    },
    {
      id: "ACCESS_DELIVERY_MODULE",
      name: "Accès au module livraisons",
      module: "navigation",
      action: "access_delivery",
    },
    {
      id: "ACCESS_PAYMENTS_MODULE",
      name: "Accès au module paiements",
      module: "navigation",
      action: "access_payments",
    },

    // Permissions de vue pour la navigation
    { id: "VIEW_USERS", name: "Accéder à la section utilisateurs", module: "navigation", action: "view_users" },
    { id: "VIEW_ORDERS", name: "Accéder à la section commandes", module: "navigation", action: "view_orders" },
    { id: "VIEW_MENU", name: "Voir le menu", module: "navigation", action: "view_menu" },
    { id: "VIEW_CATEGORIES", name: "Accéder à la section catégories", module: "navigation", action: "view_categories" },
    { id: "VIEW_PROMOTIONS", name: "Accéder à la section promotions", module: "navigation", action: "view_promotions" },
    { id: "VIEW_DELIVERY_ZONES", name: "Voir les zones de livraison", module: "navigation", action: "view_delivery_zones" },
    { id: "VIEW_SETTINGS", name: "Voir les paramètres", module: "navigation", action: "view_settings" },
    { id: "VIEW_ROLES", name: "Voir les rôles", module: "navigation", action: "view_roles" },
    { id: "VIEW_PAYMENT_METHODS", name: "Voir les modes de paiement", module: "navigation", action: "view_payment_methods" },

    // Actions système
    {
      id: "SYSTEM_HEALTH_CHECK",
      name: "Vérifier l'état du système",
      module: "system",
      action: "health_check",
    },
    { id: "SYSTEM_BACKUP", name: "Sauvegarder le système", module: "system", action: "backup" },
    {
      id: "SYSTEM_MAINTENANCE",
      name: "Maintenance du système",
      module: "system",
      action: "maintenance",
    },
  ];

  for (const permission of permissions) {
    await prisma.permission.upsert({
      where: { id: permission.id },
      update: {
        name: permission.name,
        module: permission.module,
        action: permission.action,
      },
      create: permission,
    });
  }

  console.log(`✅ ${permissions.length} permissions créées/mises à jour`);
}
