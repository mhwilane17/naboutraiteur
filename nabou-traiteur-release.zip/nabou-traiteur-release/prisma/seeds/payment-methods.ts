import { PrismaClient } from '../../lib/generated/prisma'

export async function seedPaymentMethods(prisma: PrismaClient) {
  const paymentMethods = [
    {
      name: 'Carte Bancaire',
      type: 'card',
      description: 'Paiement par carte bancaire (Visa, Mastercard)',
      provider: 'Stripe',
      fees: 2.9,
      isActive: true,
      isDefault: true,
      minAmount: 5.00,
      maxAmount: 500.00,
      processingTime: 'Instantané',
      config: {
        acceptedCards: ['visa', 'mastercard', 'amex'],
        currency: 'EUR',
        capture: 'automatic'
      }
    },
    {
      name: 'PayPal',
      type: 'digital_wallet',
      description: 'Paiement via PayPal',
      provider: 'PayPal',
      fees: 3.4,
      isActive: true,
      isDefault: false,
      minAmount: 1.00,
      maxAmount: 1000.00,
      processingTime: 'Instantané',
      config: {
        currency: 'EUR',
        intent: 'capture'
      }
    },
    {
      name: 'Espèces',
      type: 'cash',
      description: 'Paiement en espèces à la livraison',
      provider: null,
      fees: 0.0,
      isActive: true,
      isDefault: false,
      minAmount: 5.00,
      maxAmount: 100.00,
      processingTime: 'À la livraison',
      config: {
        requiresChange: true,
        maxChangeAmount: 20.00
      }
    },
    {
      name: 'Virement Bancaire',
      type: 'transfer',
      description: 'Virement bancaire (commandes importantes)',
      provider: null,
      fees: 0.0,
      isActive: true,
      isDefault: false,
      minAmount: 50.00,
      maxAmount: null,
      processingTime: '1-3 jours ouvrés',
      config: {
        iban: 'FR76XXXXXXXXXXXXXXXXXXXXXXX',
        bic: 'BNPAFRPP',
        accountName: 'Nabou Traiteur SARL'
      }
    },
    {
      name: 'Orange Money',
      type: 'mobile',
      description: 'Paiement mobile Orange Money',
      provider: 'Orange',
      fees: 1.5,
      isActive: false, // Désactivé par défaut, à activer selon les besoins
      isDefault: false,
      minAmount: 5.00,
      maxAmount: 200.00,
      processingTime: 'Instantané',
      config: {
        currency: 'EUR',
        country: 'FR'
      }
    },
    {
      name: 'Wave',
      type: 'mobile',
      description: 'Paiement mobile Wave',
      provider: 'Wave',
      fees: 1.0,
      isActive: false, // Désactivé par défaut
      isDefault: false,
      minAmount: 5.00,
      maxAmount: 300.00,
      processingTime: 'Instantané',
      config: {
        currency: 'EUR',
        country: 'SN'
      }
    }
  ]

  for (const method of paymentMethods) {
    await prisma.paymentMethod.create({
      data: method
    })
  }

  console.log(`✅ ${paymentMethods.length} méthodes de paiement créées`)
}