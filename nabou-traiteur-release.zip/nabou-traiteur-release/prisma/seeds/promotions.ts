import { PrismaClient } from '../../lib/generated/prisma'

export async function seedPromotions(prisma: PrismaClient) {
  const now = new Date()
  const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, now.getDate())
  const nextYear = new Date(now.getFullYear() + 1, now.getMonth(), now.getDate())

  const promotions = [
    {
      name: 'Rak Tak 20%',
      description: 'Promotion Rak Tak - 20% de réduction sur votre commande',
      code: 'RAKTAK20',
      type: 'percentage',
      value: 20.00,
      minOrderAmount: 25.00,
      maxDiscountAmount: 15.00,
      usageLimit: 100,
      usagePerUser: 1,
      startDate: now,
      endDate: nextMonth,
      isActive: true,
      applicableCategories: [], // Applicable à toutes les catégories
      applicableMenuItems: []
    },
    {
      name: 'Première Commande',
      description: 'Réduction de 5€ pour votre première commande',
      code: 'WELCOME5',
      type: 'fixed_amount',
      value: 5.00,
      minOrderAmount: 20.00,
      maxDiscountAmount: null,
      usageLimit: null,
      usagePerUser: 1,
      startDate: now,
      endDate: nextYear,
      isActive: true,
      applicableCategories: [],
      applicableMenuItems: []
    },
    {
      name: 'Livraison Gratuite',
      description: 'Livraison gratuite pour les commandes de plus de 40€',
      code: 'FREEDELIVERY',
      type: 'free_delivery',
      value: 0.00,
      minOrderAmount: 40.00,
      maxDiscountAmount: null,
      usageLimit: null,
      usagePerUser: null,
      startDate: now,
      endDate: nextYear,
      isActive: true,
      applicableCategories: [],
      applicableMenuItems: []
    },
    {
      name: 'Menu Étudiant',
      description: '15% de réduction sur les plats principaux pour les étudiants',
      code: 'STUDENT15',
      type: 'percentage',
      value: 15.00,
      minOrderAmount: 15.00,
      maxDiscountAmount: 10.00,
      usageLimit: null,
      usagePerUser: 3,
      startDate: now,
      endDate: nextYear,
      isActive: true,
      applicableCategories: ['PLATS_PRINCIPAUX'],
      applicableMenuItems: []
    },
    {
      name: 'Happy Hour',
      description: '10% de réduction sur les boissons entre 14h et 17h',
      code: 'HAPPYHOUR',
      type: 'percentage',
      value: 10.00,
      minOrderAmount: 10.00,
      maxDiscountAmount: 5.00,
      usageLimit: null,
      usagePerUser: 1,
      startDate: now,
      endDate: nextMonth,
      isActive: true,
      activeStartTime: '14:00',
      activeEndTime: '17:00',
      applicableCategories: ['BOISSONS_DRINKS'],
      applicableMenuItems: []
    },
    {
      name: 'Commande Groupée',
      description: '25% de réduction pour les commandes de plus de 100€',
      code: 'GROUP25',
      type: 'percentage',
      value: 25.00,
      minOrderAmount: 100.00,
      maxDiscountAmount: 30.00,
      usageLimit: 50,
      usagePerUser: 2,
      startDate: now,
      endDate: nextYear,
      isActive: true,
      applicableCategories: [],
      applicableMenuItems: []
    },
    {
      name: 'Weekend Spécial',
      description: '12% de réduction le weekend',
      code: 'WEEKEND12',
      type: 'percentage',
      value: 12.00,
      minOrderAmount: 30.00,
      maxDiscountAmount: 20.00,
      usageLimit: null,
      usagePerUser: 2,
      startDate: now,
      endDate: nextMonth,
      isActive: true,
      applicableCategories: [],
      applicableMenuItems: []
    },
    {
      name: 'Healthy Choice',
      description: '8€ de réduction sur les plats healthy',
      code: 'HEALTHY8',
      type: 'fixed_amount',
      value: 8.00,
      minOrderAmount: 25.00,
      maxDiscountAmount: null,
      usageLimit: 200,
      usagePerUser: 3,
      startDate: now,
      endDate: nextYear,
      isActive: true,
      applicableCategories: ['DIET_HEALTHY', 'SALADES_FRESH'],
      applicableMenuItems: []
    }
  ]

  for (const promotion of promotions) {
    await prisma.promotion.create({
      data: promotion
    })
  }

  console.log(`✅ ${promotions.length} promotions créées`)
}