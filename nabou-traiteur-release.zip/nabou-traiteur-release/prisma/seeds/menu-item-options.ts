import { PrismaClient } from '../../lib/generated/prisma'

export async function seedMenuItemOptions(prisma: PrismaClient) {
  // Récupérer tous les plats pour leur ajouter des options de taille
  const menuItems = await prisma.menuItem.findMany()
  
  for (const menuItem of menuItems) {
    // Ajouter l'option de taille (PM/GM) pour chaque plat
    await prisma.menuItemOption.create({
      data: {
        menuItemId: menuItem.id,
        name: 'Taille',
        type: 'size',
        isRequired: true,
        maxSelections: 1,
        sortOrder: 1,
        values: [
          {
            name: 'PM',
            price: 1000, // Prix de base
            description: 'Portion moyenne'
          },
          {
            name: 'GM',
            price: 1500, // Supplément de 0.50€ pour la grande portion
            description: 'Grande portion'
          }
        ]
      }
    })
  }

  console.log(`✅ Options de taille ajoutées pour ${menuItems.length} plats`)
}