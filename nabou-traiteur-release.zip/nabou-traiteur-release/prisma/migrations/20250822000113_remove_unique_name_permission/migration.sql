-- DropIndex
DROP INDEX "public"."permissions_name_key";
