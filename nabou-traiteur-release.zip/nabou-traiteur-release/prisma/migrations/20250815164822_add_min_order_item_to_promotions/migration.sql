-- AlterTable
ALTER TABLE "public"."promotions" ADD COLUMN     "minOrderItem" INTEGER;
