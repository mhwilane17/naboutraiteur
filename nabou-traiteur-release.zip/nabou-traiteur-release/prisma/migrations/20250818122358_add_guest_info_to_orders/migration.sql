-- AlterTable
ALTER TABLE "public"."orders" ADD COLUMN     "guestFirstName" TEXT,
ADD COLUMN     "guestLastName" TEXT;
