-- AlterTable
ALTER TABLE "public"."users" ADD COLUMN     "filiale" TEXT,
ADD COLUMN     "matricule" TEXT;

-- AlterTable
ALTER TABLE "public"."payment_transactions" ALTER COLUMN "currency" SET DEFAULT 'XOF';

