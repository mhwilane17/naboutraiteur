-- AlterTable
ALTER TABLE "public"."orders" ADD COLUMN     "guestEmail" TEXT;
