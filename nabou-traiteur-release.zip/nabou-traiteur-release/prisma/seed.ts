// import { prisma } from "@/lib/prisma";
import { PrismaClient } from "@prisma/client";
import { seedRoles } from "./seeds/roles.js";
import { seedPermissions } from "./seeds/permissions.js";
import { seedRolePermissions } from "./seeds/role-permissions.js";
import { seedCategories } from "./seeds/categories.js";
import { seedMenuItems } from "./seeds/menu-items.js";
import { seedMenuItemOptions } from "./seeds/menu-item-options.js";
import { seedDeliveryZones } from "./seeds/delivery-zones.js";
import { seedPaymentMethods } from "./seeds/payment-methods.js";
import { seedPromotions } from "./seeds/promotions.js";
import { seedUsers } from "./seeds/users.js";
import { seedWeeklyMenus } from "./seeds/weekly-menus.js";
import { seedAppConfigurations } from "./seeds/app-configurations.js";
import { seedCompanies } from "./seeds/companies.js";
import { seedCompanyCategoryLimits } from "./seeds/company-category-limits.js";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Début du seeding de la base de données...");

  try {
    // 1. Rôles et permissions (ordre important)
    // console.log("📝 Seeding des rôles...");
    // await seedRoles(prisma);

    // console.log("🔐 Seeding des permissions...");
    // await seedPermissions(prisma);

    // console.log("🔗 Seeding des liaisons rôle-permissions...");
    // await seedRolePermissions(prisma);

    // 2. Entreprises (avant les utilisateurs pour pouvoir les lier)
    console.log("🏢 Seeding des entreprises...");
    await seedCompanies(prisma);

    // 3. Utilisateurs (après les rôles et les entreprises)
    // console.log("👥 Seeding des utilisateurs...");
    // await seedUsers(prisma);

    // 4. Catégories et menu
    // console.log("📂 Seeding des catégories...");
    // await seedCategories(prisma);

    console.log("📊 Seeding des limites de catégories par entreprise...");
    await seedCompanyCategoryLimits(prisma);

    // console.log("🍽️ Seeding des plats...");
    // await seedMenuItems(prisma);

    // console.log("⚙️ Seeding des options de plats...");
    // await seedMenuItemOptions(prisma);

    // console.log("📅 Seeding des menus hebdomadaires...");
    // await seedWeeklyMenus(prisma);

    // 5. Livraison et paiement
    // console.log("🚚 Seeding des zones de livraison...");
    // await seedDeliveryZones(prisma);

    // console.log("💳 Seeding des méthodes de paiement...");
    // await seedPaymentMethods(prisma);

    // 6. Promotions
    // console.log("🎁 Seeding des promotions...");
    // await seedPromotions(prisma);

    // 7. Configurations d'application
    console.log("⚙️ Seeding des configurations d'application...");
    await seedAppConfigurations(prisma);

    console.log("✅ Seeding terminé avec succès !");
  } catch (error) {
    console.error("❌ Erreur lors du seeding:", error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
