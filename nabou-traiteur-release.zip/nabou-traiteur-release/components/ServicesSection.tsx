"use client";

import { Truck, Phone, Award } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const services = [
  {
    title: "Livraison à domicile",
    description: "Service de livraison rapide dans tout Dakar",
    icon: Truck,
    details: [
      "Livraison en moins de 45 minutes",
      "Frais de livraison gratuits dès 5000 FCFA",
      "Suivi en temps réel",
    ],
  },
  {
    title: "Commande en ligne",
    description: "Plateforme simple et sécurisée",
    icon: Phone,
    details: ["Interface intuitive", "Paiement mobile sécurisé", "Historique des commandes"],
  },
  {
    title: "Service traiteur",
    description: "Pour vos événements et réceptions",
    icon: Award,
    details: ["Buffets personnalisés", "Service sur site", "Équipe professionnelle"],
  },
];

export function ServicesSection() {
  return (
    <section id="service" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="bg-primary/10 text-primary mb-4">Nos Services</Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Services de qualité
          </h2>
          <p className="text-xl text-gray-600">Une expérience complète pour votre satisfaction</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="border-none bg-background">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mb-6">
                  <service.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold text-black mb-3">{service.title}</h3>
                <p className="text-gray-800 mb-6">{service.description}</p>
                <ul className="space-y-2">
                  {service.details.map((detail, idx) => (
                    <li key={idx} className="flex items-center space-x-2 text-sm text-gray-800">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}