import { Button } from "@/components/ui/button";
import Link from "next/link";

export function CTASection() {
  return (
    <section className="py-20 bg-primary">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
          Une cuisine authentique et raffinée, livrée chez vous
        </h2>
        <p className="text-xl text-red-100 mb-8 max-w-3xl mx-auto">
          Nos plats sont préparés chaque matin avec des produits soigneusement
          sélectionnés. Goûtez la différence d'une cuisine maison, authentique
          et généreuse, pensée pour régaler et rassembler.
        </p>
        <div>
          <Link
            href="#menu"
            // size="lg"
            // variant="secondary"
            className="bg-white text-primary hover:bg-gray-100 px-8 py-3 rounded-full"
          >
            VOIR LE MENU
          </Link>
        </div>
      </div>
    </section>
  );
}
