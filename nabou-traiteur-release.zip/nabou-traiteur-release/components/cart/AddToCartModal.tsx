"use client";

import { useState, useEffect } from "react";
import { Plus, Minus, Loader2 } from "lucide-react";
import Image from "next/image";
import { WeeklyMenuItem } from "@/types/weeklyMenuPublic";
import { useCartStore } from "@/stores/cartStore";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "react-toastify";

interface AddToCartModalProps {
  trigger?: React.ReactNode;
  item: WeeklyMenuItem;
}

export function AddToCartModal({ trigger, item }: AddToCartModalProps) {
  const [open, setOpen] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState(item.options[0]?.name || "");
  const [isAddingToCart, setIsAddingToCart] = useState(false);

  const { addItem } = useCartStore();

  const selectedOption = item.options.find((opt) => opt.name === selectedSize) || item.options[0];
  const unitPrice = selectedOption ? selectedOption.price : 0;
  const totalPrice = unitPrice * quantity;
  const quantityLimit = item.quantity

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity >= 1 && newQuantity <= quantityLimit) {
      setQuantity(newQuantity);
    }
  };

  const handleAddToCart = async () => {
    // Validation des options obligatoires (Requirement 1.2)
    if (!selectedSize || selectedSize.trim() === "") {
      toast.error("Veuillez sélectionner une option avant d'ajouter au panier");
      return;
    }

    // Vérifier que l'option sélectionnée existe
    const selectedOption = item.options.find(opt => opt.name === selectedSize);
    if (!selectedOption) {
      toast.error("Option sélectionnée invalide");
      return;
    }

    // Vérifier que la quantité est valide
    if (quantity < 1) {
      toast.error("La quantité doit être d'au moins 1");
      return;
    }

    try {
      setIsAddingToCart(true);

      // Feedback visuel immédiat (Requirement 6.4)
      await addItem(item, quantity, selectedSize);

      // Notification de succès avec détails
      toast.success(`${item.name} ajouté au panier (${quantity}x ${selectedSize})`);

      // Reset and close
      setQuantity(1);
      setSelectedSize(item.options[0]?.name || "");
      setOpen(false);

    } catch (error) {
      console.error("Erreur lors de l'ajout au panier:", error);
      toast.error("Erreur lors de l'ajout au panier. Veuillez réessayer.");
    } finally {
      setIsAddingToCart(false);
    }
  };

  const isCommand = item.status === "available";

  // Reset modal state when it opens
  useEffect(() => {
    if (open) {
      setQuantity(1);
      setSelectedSize(item.options[0]?.name || "");
      setIsAddingToCart(false);
    }
  }, [open, item.options]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button
            size="sm"
            className="rounded-full px-6 py-2 font-semibold w-full bg-primary hover:bg-primary/90 text-white"
          >
            Ajouter au panier
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] max-w-[95vw] bg-white">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-3">
            <Image
              src={item.image || "/placeholder.svg"}
              alt={item.name}
              width={40}
              height={40}
              className="rounded-lg flex-shrink-0"
            />
            <div className="min-w-0">
              <div className="text-base sm:text-lg font-bold text-gray-900 truncate">
                {item.name}
              </div>
              <div className="flex items-center space-x-2 text-xs sm:text-sm text-gray-600">
                <span>{item.day}</span>
                <Badge
                  variant="secondary"
                  className={`text-xs ${isCommand ? "bg-green-100 text-green-700" : "bg-blue-100 text-blue-700"
                    }`}
                >
                  {isCommand ? "Disponible" : "Réservation"}
                </Badge>
              </div>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Size Selection */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-3">
              Choisir la taille <span className="text-red-500">*</span>
            </h3>
            <div className="space-y-2" role="radiogroup" aria-label="Options de taille disponibles">
              {!selectedSize && (
                <div className="text-sm text-red-600 mb-2">
                  Veuillez sélectionner une option
                </div>
              )}
              {item.options.map((option, index) => (
                <div
                  key={index}
                  className={`flex items-center justify-between p-3 border rounded-lg cursor-pointer transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 ${selectedSize === option.name
                    ? "border-primary bg-primary/5"
                    : "border-gray-200 hover:border-gray-300"
                    }`}
                  onClick={() => setSelectedSize(option.name)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setSelectedSize(option.name);
                    }
                  }}
                  tabIndex={0}
                  role="radio"
                  aria-checked={selectedSize === option.name}
                  aria-label={`Sélectionner ${option.name} pour ${option.price} FCFA`}
                >
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-4 h-4 rounded-full border-2 ${selectedSize === option.name
                        ? "border-primary bg-primary"
                        : "border-gray-300"
                        }`}
                    >
                      {selectedSize === option.name && (
                        <div className="w-full h-full rounded-full bg-white scale-50"></div>
                      )}
                    </div>
                    <span className="font-medium text-gray-900">{option.name}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-semibold text-gray-900">{option.price} FCFA</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quantity Selection */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-3">Quantité</h3>
            <div className="flex items-center space-x-4" role="group" aria-label="Contrôles de quantité">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleQuantityChange(quantity - 1)}
                disabled={quantity <= 1 || isAddingToCart}
                className="w-10 h-10 rounded-full p-0"
                aria-label="Diminuer la quantité"
              >
                <Minus className="w-4 h-4" />
              </Button>
              <span
                className="text-xl font-semibold min-w-[2rem] text-center"
                aria-label={`Quantité: ${quantity}`}
              >
                {quantity}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleQuantityChange(quantity + 1)}
                disabled={isAddingToCart}
                className="w-10 h-10 rounded-full p-0"
                aria-label="Augmenter la quantité"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Price Summary */}
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Prix unitaire:</span>
              <span className="font-medium">{unitPrice} FCFA</span>
            </div>
            <div className="flex justify-between items-center mt-2 pt-2 border-t border-gray-200">
              <span className="font-semibold text-gray-900">Total:</span>
              <span className="font-bold text-lg text-primary">{totalPrice} FCFA</span>
            </div>
            {selectedOption.discountAmount && <div className="flex justify-between items-center mt-2 pt-2 border-t border-gray-200">
              <span className="font-semibold text-green-600">Prix RAKTAK:</span>
              <span className="font-bold text-lg text-green-600">{totalPrice - (selectedOption.discountAmount * quantity)} FCFA</span>
            </div>}
          </div>


          <div>
            {selectedOption.discountAmount && (
              <div className="text-sm text-gray-600 font-medium">
                Une réduction de {selectedOption.discountAmount * quantity} FCFA sera appliquée au moment de la finalisation de la commande.
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <div className="flex space-x-3 w-full">
            <Button
              variant="outline"
              onClick={() => setOpen(false)}
              className="flex-1"
            >
              Annuler
            </Button>
            <Button
              onClick={handleAddToCart}
              disabled={!selectedSize || isAddingToCart}
              className="flex-1 bg-primary hover:bg-primary/90 text-white disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {isAddingToCart ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Ajout en cours...
                </>
              ) : (
                "Ajouter au panier"
              )}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}