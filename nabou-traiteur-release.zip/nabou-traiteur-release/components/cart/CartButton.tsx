'use client';

import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCartStore } from '@/stores/cartStore';
import { CartButtonProps } from '@/types/cart';
import { CartDrawer } from './CartDrawer';
import { cn } from '@/lib/utils';

/**
 * Composant bouton de panier avec indicateur d'articles
 * Affiche un bouton flottant avec icône de panier et badge du nombre d'articles
 */
export const CartButton: React.FC<CartButtonProps> = ({ 
  className,
  position = 'fixed'
}) => {
  const { totalItems, total, isOpen, openCart, closeCart } = useCartStore();

  // Ne pas afficher le bouton si le panier est vide
  if (totalItems === 0) {
    return null;
  }

  const handleClick = () => {
    openCart();
  };

  const formatPrice = (price: number) => {
    return `${price} FCFA`;
  };

  return (
    <>
      {/* Version desktop avec prix */}
      <div className="hidden md:block">
        <Button
          onClick={handleClick}
          className={cn(
            // Styles de base
            'relative flex items-center gap-3 px-4 py-3 shadow-lg hover:shadow-xl transition-all duration-200',
            'bg-primary hover:bg-primary/90 text-primary-foreground',
            'border-2 border-primary-foreground/10 rounded-full',
            
            // Styles de position
            position === 'fixed' && 'fixed bottom-6 right-6 z-50',
            position === 'absolute' && 'absolute',
            position === 'relative' && 'relative',
            
            // Animation au hover
            'hover:scale-105 active:scale-95',
            
            // Classes personnalisées
            className
          )}
          aria-label={`Panier avec ${totalItems} article${totalItems > 1 ? 's' : ''} - Total: ${formatPrice(total)}`}
        >
          {/* Icône du panier */}
          <div className="relative">
            <ShoppingCart className="h-6 w-6" />
            
            {/* Badge avec le nombre d'articles */}
            <Badge
              variant="destructive"
              className={cn(
                'absolute -top-2 -right-2 h-5 w-5 rounded-full p-0',
                'flex items-center justify-center text-xs font-bold',
                'bg-red-500 text-white border-2 border-white',
                'animate-in zoom-in-50 duration-200',
                // Ajuster la taille du badge selon le nombre d'articles
                totalItems > 99 && 'w-6 text-[10px]'
              )}
            >
              {totalItems > 99 ? '99+' : totalItems}
            </Badge>
          </div>
          
          {/* Prix total */}
          <div className="flex flex-col items-start">
            <span className="text-xs opacity-90">Total</span>
            <span className="font-semibold text-sm">{formatPrice(total)}</span>
          </div>
        </Button>
      </div>

      {/* Version mobile compacte */}
      <div className="md:hidden">
        <Button
          onClick={handleClick}
          className={cn(
            // Styles de base
            'relative rounded-full p-3 shadow-lg hover:shadow-xl transition-all duration-200',
            'bg-primary hover:bg-primary/90 text-primary-foreground',
            'border-2 border-primary-foreground/10',
            
            // Styles de position
            position === 'fixed' && 'fixed bottom-6 right-6 z-50',
            position === 'absolute' && 'absolute',
            position === 'relative' && 'relative',
            
            // Styles responsives
            'h-14 w-14',
            
            // Animation au hover
            'hover:scale-105 active:scale-95',
            
            // Classes personnalisées
            className
          )}
          aria-label={`Panier avec ${totalItems} article${totalItems > 1 ? 's' : ''} - Total: ${formatPrice(total)}`}
        >
          {/* Icône du panier */}
          <ShoppingCart className="h-6 w-6" />
          
          {/* Badge avec le nombre d'articles */}
          <Badge
            variant="destructive"
            className={cn(
              'absolute -top-2 -right-2 h-6 w-6 rounded-full p-0',
              'flex items-center justify-center text-xs font-bold',
              'bg-red-500 text-white border-2 border-white',
              'animate-in zoom-in-50 duration-200',
              // Ajuster la taille du badge selon le nombre d'articles
              totalItems > 99 && 'w-8 text-[10px]'
            )}
          >
            {totalItems > 99 ? '99+' : totalItems}
          </Badge>
        </Button>
      </div>

      {/* Cart Drawer */}
      <CartDrawer isOpen={isOpen} onClose={closeCart} />
    </>
  );
};

export default CartButton;