'use client';

import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCartStore } from '@/stores/cartStore';
import { CartDrawerProps, CartItem } from '@/types/cart';
import { cn } from '@/lib/utils';
import { ReservationModal } from '@/components/reservation-modal';
import { useDeliveryAndPayment } from '@/hooks/useDeliveryAndPayment';
import { CartPricingControls } from './CartPricingControls';
import { toast } from 'react-toastify';

/**
 * Composant pour afficher et gérer un article individuel du panier
 */
const CartItemComponent: React.FC<{
  item: CartItem;
  onUpdateQuantity: (itemId: string, quantity: number) => void;
  onRemove: (itemId: string) => void;
}> = ({ item, onUpdateQuantity, onRemove }) => {

  const handleQuantityDecrease = () => {
    onUpdateQuantity(item.id, item.quantity - 1);
  };

  const handleQuantityIncrease = () => {
    onUpdateQuantity(item.id, item.quantity + 1);
  };

  const handleRemove = () => {
    onRemove(item.id);
  };

  const formatPrice = (price: number) => {
    return `${price} FCFA`;
  };

  return (
    <div className="flex items-start gap-3 p-4 border-b border-border/50 last:border-b-0">
      {/* Image du plat */}
      <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-lg bg-muted">
        <Image
          src={item.image || '/placeholder.jpg'}
          alt={item.name}
          fill
          className="object-cover"
          sizes="64px"
        />
      </div>

      {/* Informations du plat */}
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h4 className="font-medium text-sm leading-tight truncate">
              {item.name}
            </h4>

            {/* Options sélectionnées */}
            <div className="flex flex-wrap gap-1 mt-1">
              <Badge variant="secondary" className="text-xs px-2 py-0.5">
                {item.options.size}
              </Badge>
              <Badge variant="outline" className="text-xs px-2 py-0.5">
                {item.day}
              </Badge>
            </div>

            {/* Prix unitaire */}
            <p className="text-xs text-muted-foreground mt-1">
              {formatPrice(item.unitPrice)} / unité
            </p>
          </div>

          {/* Bouton de suppression */}
          <Button
            variant="ghost"
            size="icon"
            onClick={handleRemove}
            className="h-8 w-8 text-muted-foreground hover:text-destructive flex-shrink-0"
            aria-label={`Supprimer ${item.name} du panier`}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>

        {/* Contrôles de quantité et prix total */}
        <div className="flex items-center justify-between mt-3">
          {/* Contrôles de quantité */}
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={handleQuantityDecrease}
              className="h-8 w-8"
              aria-label="Diminuer la quantité"
            >
              <Minus className="h-3 w-3" />
            </Button>

            <span className="min-w-[2rem] text-center text-sm font-medium">
              {item.quantity}
            </span>

            <Button
              variant="outline"
              size="icon"
              onClick={handleQuantityIncrease}
              className="h-8 w-8"
              aria-label="Augmenter la quantité"
            >
              <Plus className="h-3 w-3" />
            </Button>
          </div>

          {/* Prix total de la ligne */}
          <div className="text-right">
            <p className="font-semibold text-sm">
              {formatPrice(item.totalPrice)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * Composant pour afficher l'état vide du panier
 */
const EmptyCartState: React.FC = () => (
  <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
    <div className="rounded-full bg-muted p-6 mb-4">
      <ShoppingBag className="h-12 w-12 text-muted-foreground" />
    </div>
    <h3 className="text-lg font-semibold mb-2">Votre panier est vide</h3>
    <p className="text-muted-foreground text-sm max-w-sm">
      Découvrez nos délicieux plats et ajoutez-les à votre panier pour commencer votre commande.
    </p>
  </div>
);

/**
 * Composant principal CartDrawer pour afficher et gérer le contenu du panier
 */
export const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose }) => {
  const {
    items,
    totalItems,
    subtotal,
    deliveryFee,
    promoDiscount,
    total,
    appliedPromoCode,
    promo,
    promoState,
    updateQuantity,
    removeItem,
    clearCart
  } = useCartStore();

  // Utiliser l'état du modal depuis le store unifié
  const { modal } = useCartStore();
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const { deliveryZones, paymentMethods } = useDeliveryAndPayment();

  const formatPrice = (price: number) => {
    return `${price} FCFA`;
  };

  const handleClearCart = () => {
    setShowClearConfirm(true);
  };

  const confirmClearCart = () => {
    const itemCount = items.length;
    clearCart();
    toast.success(`${itemCount} article${itemCount > 1 ? 's ont été supprimés' : ' a été supprimé'} de votre panier`);
    setShowClearConfirm(false);
  };

  const handleOrderFromCart = () => {
    // Ouvrir le modal via le store unifié en mode commande depuis le panier
    modal.openModal();
  };

  const handleOrderSuccess = () => {
    // Fermer le modal via le store unifié
    modal.closeModal();
    onClose(); // Fermer le drawer après succès
  };

  const handleVal = async () => {
    console.log("test");
    await promo.validatePromoCode()
  }

  useEffect(() => {
    if (!promoState.code) return
    handleVal()
  }, [items])

  return (
    <>
      <Sheet open={isOpen} onOpenChange={onClose}>
        <SheetContent
          side="right"
          className={cn(
            "w-full sm:max-w-md flex flex-col",
            "p-0" // Remove default padding to control it ourselves
          )}
        >
          {/* Header */}
          <SheetHeader className="px-6 py-4 border-b border-border/50">
            {totalItems > 0 && (
              <SheetTitle className=' flex felx-row items-center'>
                {/* Bouton vider le panier */}
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={handleClearCart}
                  className="text-muted-foreground hover:text-destructive text-primary bg-primary/20"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Vider le panier
                </Button>
                <Badge variant="secondary" className="ml-2 h-fit">
                  {totalItems} article{totalItems > 1 ? 's' : ''}
                </Badge>
              </SheetTitle>
            )}
          </SheetHeader>

          {/* Contenu principal */}
          <div className="flex-1 flex flex-col min-h-0">
            {items.length === 0 ? (
              <EmptyCartState />
            ) : (
              <>
                {/* Liste des articles - Zone scrollable */}
                <div className="flex-1 overflow-y-auto min-h-0">
                  <div className="space-y-0">
                    {items.map((item) => (
                      <CartItemComponent
                        key={item.id}
                        item={item}
                        onUpdateQuantity={updateQuantity}
                        onRemove={removeItem}
                      />
                    ))}
                  </div>
                </div>

                {/* Footer avec totaux et actions - Toujours visible */}
                <div className="flex-shrink-0 border-t border-border/50 bg-background">

                  {/* Totaux */}
                  <div className="px-6 pb-4 space-y-2">


                    <div className="pt-2">
                      <div className="flex justify-between items-center text-xs">
                        <span className="">Sous-total</span>
                        <span className="">{formatPrice(subtotal)}</span>
                      </div>
                      {appliedPromoCode && promoDiscount > 0 && (
                        <div className="flex justify-between items-center text-xs text-green-600">
                          <span>Réduction ({appliedPromoCode})</span>
                          <span>- {formatPrice(promoDiscount)}</span>
                        </div>
                      )}
                      <div className="flex justify-between items-center text-xs">
                        <span className="">Livraison</span>
                        <span className="">{formatPrice(deliveryFee)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="font-semibold">Totall</span>
                        <span className="font-bold text-lg">{formatPrice(total)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Contrôles de prix en temps réel - Dans la zone scrollable */}
                  <div className="px-6">
                    <CartPricingControls deliveryZones={deliveryZones || []} />
                  </div>

                  {/* Bouton de commande */}
                  <div className="p-6">
                    <Button
                      onClick={handleOrderFromCart}
                      className="w-full"
                      size="lg"
                    >
                      Commander ({totalItems} article{totalItems > 1 ? 's' : ''})
                    </Button>
                  </div>
                </div>
              </>
            )}
          </div>
        </SheetContent>
      </Sheet>

      {/* Modal de commande depuis le panier */}
      <ReservationModal
        deliveryZones={deliveryZones}
        paymentMethods={paymentMethods}
        onOrderSuccess={handleOrderSuccess}
      />

      {/* Dialog de confirmation pour vider le panier */}
      <AlertDialog open={showClearConfirm} onOpenChange={setShowClearConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Vider le panier</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer tous les articles de votre panier ?
              Cette action ne peut pas être annulée.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={confirmClearCart} className="bg-destructive hover:bg-destructive/90">
              Vider le panier
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default CartDrawer;