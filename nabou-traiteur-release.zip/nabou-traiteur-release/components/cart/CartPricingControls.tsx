'use client';

import { MapPin} from 'lucide-react';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useCartStore } from '@/stores/cartStore';
import { useAuthStore } from '@/stores/authStore';
import { DeliveryZone } from '@/services/deliveryService';
import { PromoCodeCard } from '../reservation/ConfirmationStepParts';

interface CartPricingControlsProps {
  deliveryZones: DeliveryZone[];
  className?: string;
}

export const CartPricingControls: React.FC<CartPricingControlsProps> = ({
  deliveryZones,
  className
}) => {
  const {
    selectedDeliveryZone,
    setDeliveryZone,
  } = useCartStore();

  const { user } = useAuthStore();
  const isEmployee = !!user?.companyId;

  const handleDeliveryZoneChange = (zoneId: string) => {
    const zone = deliveryZones.find(z => z.id === zoneId);
    setDeliveryZone(zone || null);
  };

  const formatPrice = (price: number) => {
    return `${price} FCFA`;
  };

  return (
    <div className={className}>
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Livraison & Promo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Zone de livraison - masquée pour les employés */}
          {!isEmployee && (
            <div className="space-y-2">
              <Label htmlFor="delivery-zone" className="text-sm font-medium">
                Zone de livraison
              </Label>
              <Select 
                value={selectedDeliveryZone?.id || ''} 
                onValueChange={handleDeliveryZoneChange}
              >
                <SelectTrigger className="text-sm">
                  <SelectValue placeholder="Sélectionnez votre zone" />
                </SelectTrigger>
                <SelectContent>
                  {deliveryZones && deliveryZones.length > 0 ? (
                    deliveryZones.map((zone) => (
                      <SelectItem key={zone.id} value={zone.id}>
                        <div className="flex flex-col">
                          <span>{zone.name} - {formatPrice(zone.deliveryFee)}</span>
                          <span className="text-xs text-muted-foreground">
                            {zone.areas.join(', ')}
                          </span>
                        </div>
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="" disabled>
                      Aucune zone disponible
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Code promo */}
          {/* Promo Code Field for cart orders */}
          <PromoCodeCard />
        </CardContent>
      </Card>
    </div>
  );
};

export default CartPricingControls;