import { Phone, MessageCircle } from "lucide-react";
import Image from "next/image";

import { Button } from "@/components/ui/button";
import Link from "next/link";

export function HeroSection() {
  return (
    <section id="accueil" className="p-5">
      <div className="container mx-auto bg-primary p-10 rounded-3xl">
        <div className="flex flex-col lg:flex-row justify-between gap-12 items-center relative">
          <div className="space-y-8">
            <div className="lg:mb-20 space-y-8 text-white">
              <div>
                <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                  Savourez nos <br /> délicieux plats <br />{" "}
                  <span className="text-white">chaque bouchée un délice</span> !
                </h1>
              </div>

              {/* <p className="text-lg max-w-lg">
                Ou passez commande en ligne via le bouton en haut de page.
              </p> */}
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="#menu"
                className="inline-flex items-center justify-center bg-black hover:bg-black text-white px-8 py-3 rounded-md text-lg font-medium transition-colors"
              >
                COMMANDER
              </Link>
              <a
                href="tel:780106925"
                className="inline-flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-600 px-8 py-3 rounded-md text-lg font-medium transition-colors"
              >
                <Phone className="w-5 h-5 mr-2" />
                APPELER
              </a>
              <a
                href="https://wa.me/221780106925?text=Bonjour%20!%20Je%20souhaite%20commander%20ou%20réserver%20un%20repas."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center bg-green-50 text-green-600 hover:bg-green-100 px-8 py-3 rounded-md text-lg font-medium transition-colors"
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                WHATSAPP
              </a>
            </div>
          </div>

          <div className="aspect-video lg:h-80 lg:w-auto h-auto w-full rounded-full overflow-hidden">
            <Image
              src="/images/108755.jpg"
              alt="Plat sénégalais traditionnel"
              width={800}
              height={800}
              className="-mt-10"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
