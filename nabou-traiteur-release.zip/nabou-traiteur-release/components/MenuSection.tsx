"use client";

import { useEffect, useState } from "react";
import { Loader2, AlertCircle } from "lucide-react";
import Image from "next/image";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useWeeklyMenu } from "@/hooks/useWeeklyMenu";
import { usePublicCategoriesStore } from "@/stores/publicCategoriesStore";
import { usePublicDeliveryZonesStore } from "@/stores/publicDeliveryZonesStore";
import { usePublicPaymentMethodsStore } from "@/stores/publicPaymentMethodsStore";
import { CartButton } from "@/components/cart/CartButton";
import { AddToCartModal } from "@/components/cart/AddToCartModal";
import { MenuFilter, DayOption } from "@/types/menu";
import { WeeklyMenuItem } from "@/types/weeklyMenuPublic";



// Fonction pour obtenir le jour actuel en français
const getCurrentDayInFrench = () => {
  const today = new Date();
  const dayNames = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
  return dayNames[today.getDay()];
};

const days: DayOption[] = [
  { key: "lundi", label: "Lundi" },
  { key: "mardi", label: "Mardi" },
  { key: "mercredi", label: "Mercredi" },
  { key: "jeudi", label: "Jeudi" },
  { key: "vendredi", label: "Vendredi" },
];

// Couleurs pour les catégories
const getCategoryColor = (category: string) => {
  const categoryColors: Record<string, string> = {
    plat: "bg-orange-100 text-orange-800 border-orange-200",
    dessert: "bg-pink-100 text-pink-800 border-pink-200",
    boisson: "bg-blue-100 text-blue-800 border-blue-200",
    diet: "bg-green-100 text-green-800 border-green-200",
    salade: "bg-emerald-100 text-emerald-800 border-emerald-200",
    fastfood: "bg-red-100 text-red-800 border-red-200"
  };
  
  return categoryColors[category] || "bg-gray-100 text-gray-800 border-gray-200";
};

const getButtonText = (dish: WeeklyMenuItem) => {
  // Vérifier le statut du plat
  if (dish.status === "sold_out") return "Épuisé";
  if (dish.status === "unavailable") return "Indisponible";

  // Si disponible
  return "Ajouter au panier";
};

// Fonction pour déterminer le statut d'affichage d'un plat en fonction du jour
const getDishDisplayStatus = (
  dayKey: string,
  currentDay: string
): "available" | "upcoming" | "past" => {
  if (dayKey === currentDay) {
    return "available";
  }
  return "upcoming";
};

// Fonction pour générer les filtres de catégories dynamiquement
const generateMenuFilters = (items: WeeklyMenuItem[], dbCategories: any[]): MenuFilter[] => {
  // Toujours inclure l'option "Tout"
  const filters: MenuFilter[] = [
    { key: "all", label: "Tout", color: "bg-gray-100 text-gray-800" }
  ];
  
  // Map pour stocker les catégories de la base de données par leur nom
  const categoryMap = new Map<string, any>();
  dbCategories.forEach(cat => categoryMap.set(cat.name.toLowerCase(), cat));
  
  // Ensemble pour suivre les catégories déjà ajoutées
  const addedCategories = new Set<string>();
  
  // Parcourir les éléments pour extraire les catégories uniques
  items.forEach(item => {
    if (item.category && !addedCategories.has(item.category)) {
      addedCategories.add(item.category);
      
      // Récupérer les informations de la catégorie depuis la base de données
      const dbCategory = categoryMap.get(item.category.toLowerCase());
      
      // Formater le label (utiliser le nom de la catégorie de la base de données si disponible)
      const label = dbCategory ? dbCategory.name : item.category.charAt(0).toUpperCase() + item.category.slice(1);
      
      // Ajouter la catégorie avec sa couleur correspondante
      filters.push({
        key: item.category,
        label: label,
        color: dbCategory && dbCategory.color ? `bg-${dbCategory.color}-100 text-${dbCategory.color}-800 border-${dbCategory.color}-200` : getCategoryColor(item.category)
      });
    }
  });
  
  // Trier les filtres selon l'ordre défini dans la base de données
  return filters.sort((a, b) => {
    if (a.key === "all") return -1;
    if (b.key === "all") return 1;
    
    const catA = categoryMap.get(a.key.toLowerCase());
    const catB = categoryMap.get(b.key.toLowerCase());
    
    if (catA && catB) {
      return catA.sortOrder - catB.sortOrder;
    }
    
    return 0;
  });
};



export function MenuSection() {
  const [selectedDay, setSelectedDay] = useState(() => {
    const currentDay = getCurrentDayInFrench();
    // Si c'est samedi ou dimanche, sélectionner lundi par défaut
    if (currentDay === "samedi" || currentDay === "dimanche") {
      return "lundi";
    }
    return currentDay;
  });
  const [selectedCategory, setSelectedCategory] = useState("all");

  // Utilisation du hook pour le menu hebdomadaire
  const { weeklyMenu, loading: menuLoading, error: menuError, refetch } = useWeeklyMenu();
  
  // Utilisation directe des stores pour les données publiques
  const { 
    categories, 
    loading: categoriesLoading, 
    error: categoriesError,
    fetchCategories,
    isDataFresh: isCategoriesDataFresh
  } = usePublicCategoriesStore();
  
  const { 
    deliveryZones, 
    loading: deliveryZonesLoading, 
    error: deliveryZonesError,
    fetchDeliveryZones,
    isDataFresh: isDeliveryZonesDataFresh
  } = usePublicDeliveryZonesStore();
  
  const { 
    paymentMethods, 
    loading: paymentMethodsLoading, 
    error: paymentMethodsError,
    fetchPaymentMethods,
    isDataFresh: isPaymentMethodsDataFresh
  } = usePublicPaymentMethodsStore();

  const currentDay = getCurrentDayInFrench();
  const currentItems = weeklyMenu[selectedDay] || [];
  
  // Générer dynamiquement les filtres de catégories à partir des éléments actuels et des catégories de la base de données
  const menuFilters = generateMenuFilters(currentItems, categories);

  // Filtrer par catégorie
  const filteredItems =
    selectedCategory === "all"
      ? currentItems
      : currentItems.filter((item: WeeklyMenuItem) => item.category === selectedCategory);

  // État de chargement global
  const loading = menuLoading || categoriesLoading || deliveryZonesLoading || paymentMethodsLoading;
  const error = menuError || categoriesError || deliveryZonesError || paymentMethodsError;

  // Chargement conditionnel des données basé sur la fraîcheur du cache
  useEffect(() => {
    // Charger les catégories seulement si elles ne sont pas fraîches
    if (!isCategoriesDataFresh()) {
      fetchCategories();
    }
    
    // Charger les zones de livraison seulement si elles ne sont pas fraîches
    if (!isDeliveryZonesDataFresh()) {
      fetchDeliveryZones();
    }
    
    // Charger les méthodes de paiement seulement si elles ne sont pas fraîches
    if (!isPaymentMethodsDataFresh()) {
      fetchPaymentMethods();
    }
  }, [
    fetchCategories, 
    fetchDeliveryZones, 
    fetchPaymentMethods,
    isCategoriesDataFresh,
    isDeliveryZonesDataFresh,
    isPaymentMethodsDataFresh
  ]);

  return loading ? (
    <section id="menu" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Chargement du menu...</p>
        </div>
      </div>
    </section>
  ) : error ? (
    <section id="menu" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-4" />
          <p className="text-red-600 mb-4">Erreur lors du chargement du menu: {error}</p>
          <Button onClick={refetch} variant="outline">
            Réessayer
          </Button>
        </div>
      </div>
    </section>
  ) : (
    <section id="menu" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="bg-primary/10 text-primary mb-4">Menu Complet</Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-8">Menu de la semaine</h2>

          <div className="">
            {/* Day Filter */}
            <div className="flex mb-6 justify-center">
              <div className="flex gap-3 overflow-x-auto ">
                {days.map((day) => (
                  <Button
                    key={day.key}
                    onClick={() => setSelectedDay(day.key)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                      selectedDay === day.key
                        ? "bg-primary text-white"
                        : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200"
                    }`}
                  >
                    {day.label}
                  </Button>
                ))}
              </div>
            </div>

            {/* Category Filter */}
            <div className="flex mb-6 justify-center">
              <div className="flex gap-3 overflow-x-auto ">
                {menuFilters.map((filter) => (
                  <Button
                    key={filter.key}
                    onClick={() => setSelectedCategory(filter.key)}
                    variant="outline"
                    size="sm"
                    className={`rounded-full text-xs font-medium transition-colors ${
                      selectedCategory === filter.key
                        ? filter.color + " border-current"
                        : "bg-white text-gray-600 hover:bg-gray-50 border-gray-200"
                    }`}
                  >
                    {filter.label}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {filteredItems.length > 0 ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 lg:gap-8 gap-4 max-w-6xl mx-auto mt-28">
            {filteredItems.map((item: WeeklyMenuItem, index: number) => {
              const categoryColor = getCategoryColor(item.category);
              const displayStatus = getDishDisplayStatus(selectedDay, currentDay);
              // Conserver le statut API pour la disponibilité réelle
              const itemWithDisplayStatus = {
                ...item,
                displayStatus: displayStatus,
              };

              return (
                <div
                  key={index}
                  className="relative bg-background flex flex-col justify-between rounded-3xl lg:p-6 p-2 text-center shadow-sm hover:shadow-md transition-shadow mb-20"
                >
                  <div>
                    <div className="relative mb-2">
                      <div className="lg:-mt-30 w-full h-auto -mt-20 p-4 mx-auto rounded-full">
                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          width={80}
                          height={80}
                          className="w-full h-32 object-center object-cover aspect-square rounded-full"
                        />
                      </div>
                      {/* Badges pour catégorie et sous-catégorie */}
                      <div className="absolute top-10 -right-6 flex flex-col gap-1">
                        <Badge className={`${categoryColor} text-xs`}>
                          {item.category.charAt(0).toUpperCase() + item.category.slice(1)}
                        </Badge>
                        {/* Badge Rak Tak */}
                        {item.hasRakTakPromo && (
                          <Badge className="bg-red-500 text-white text-xs animate-pulse">
                            RAK TAK
                          </Badge>
                        )}
                      </div>
                    </div>
                    <h3 className="lg:text-xl text-md font-bold text-gray-900 mb-3">{item.name}</h3>
                    {item.description && (
                      <p className="text-sm text-gray-600 mb-3 hidden lg:block">
                        {item.description}
                      </p>
                    )}
                  </div>

                  <div>
                    {/* Prix différentiel */}
                    <div className="mb-4 bg-gray-50 rounded-lg flex flex-col divide-y border">
                      {item.options.map((option, optionIndex: number) => (
                        <div
                          key={optionIndex}
                          className="flex justify-between items-end text-sm py-2 px-3"
                        >
                          <span className="text-gray-600 uppercase text-xs">{option.name} :</span>
                          <div className={`font-medium flex flex-col`}>
                            {/* {option.discountPrice && (
                              <span className="text-xs opacity-35 line-through">
                                {option.price} FCFA
                              </span>
                            )} */}

                            <span>{option.price} FCFA</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    {item.status === "available" ? (
                      <AddToCartModal
                        item={itemWithDisplayStatus}
                        trigger={
                          <Button
                            size="sm"
                            className="rounded-full px-6 py-2 font-semibold w-full bg-primary hover:bg-primary/90 text-white"
                          >
                            {getButtonText(item)}
                          </Button>
                        }
                      />
                    ) : (
                      <Button
                        size="sm"
                        disabled={true}
                        className="rounded-full px-6 py-2 font-semibold w-full bg-gray-400 cursor-not-allowed text-white"
                      >
                        {getButtonText(item)}
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center">
            <AlertCircle className="w-8 h-8 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">Aucun plat disponible pour ce jour.</p>
          </div>
        )}
      </div>
      
      {/* Cart Button - Floating button that appears when there are items in cart */}
      <CartButton />
    </section>
  );
}
