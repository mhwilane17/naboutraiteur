"use client";

import React, { useEffect, useMemo } from "react";
import { X, CreditCard, Loader2, ShoppingBag } from "lucide-react";
import { DeliveryZone } from "@/services/deliveryService";
import { PaymentMethod } from "@/services/paymentService";
import { getStepTitle, calculatePricing } from "@/lib/reservation-utils";
import { useCartStore } from "@/stores/cartStore";
import { useAuthStore } from "@/stores/authStore";
import { toast } from "react-toastify";
import { useRouter } from "next/navigation";
import { useIsMobile } from "@/hooks/use-mobile";
import { unifiedOrderService } from "@/services/unifiedOrderService";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

// Import extracted components for better modularity
import { InfoStep } from "@/components/reservation/InfoStep";
import { StepProgress } from "@/components/reservation/StepProgress";
import { PaymentMethodSelector } from "@/components/reservation/ConfirmationStepParts";

/**
 * Props pour le modal de réservation/commande unifié
 */
interface ReservationModalProps {
  /** Zones de livraison disponibles */
  deliveryZones: DeliveryZone[];
  /** Méthodes de paiement disponibles */
  paymentMethods: PaymentMethod[];
  /** Callback appelé lors du succès d'une commande */
  onOrderSuccess?: (orderId: string) => void;
  /** Mode ajout au panier (true = ajouter au panier, false = commander directement) */
  cartMode?: boolean;
}

/**
 * Modal de réservation/commande unifié utilisant le store centralisé
 *
 * Ce composant gère trois modes principaux :
 * 1. Commande directe (item + mode normal)
 * 2. Ajout au panier (cartMode = true)
 * 3. Commande depuis le panier (orderFromCart = true)
 *
 * Optimisations :
 * - Utilise des sélecteurs pour éviter les re-rendus inutiles
 * - États locaux minimaux (quantité et taille seulement)
 * - Calculs mémorisés pour les performances
 */
export function ReservationModal({
  deliveryZones,
  paymentMethods,
  cartMode = false,
  onOrderSuccess,
}: ReservationModalProps) {
  // Etats pour la gestion des modals de paiement/QR
  const [qrModalOpen, setQrModalOpen] = React.useState(false);
  const [qrCode, setQrCode] = React.useState<string | null>(null);
  const [selectionModalOpen, setSelectionModalOpen] = React.useState(false);
  const [paymentOptions, setPaymentOptions] = React.useState<
    Array<{ label: string; url: string }>
  >([]);

  const router = useRouter();
  const { user } = useAuthStore();
  const companyId = user?.id;
  const isEmployee = !!user?.companyId;
  const isMobile = useIsMobile();

  // Utiliser l'état du modal depuis le store unifié
  const open = useCartStore((state) => state.modalState.isOpen);

  // Sélecteurs optimisés du store unifié pour éviter les re-rendus inutiles
  const cartItems = useCartStore((state) => state.items);
  const subtotal = useCartStore((state) => state.subtotal);
  const selectedDeliveryZone = useCartStore(
    (state) => state.selectedDeliveryZone
  );
  const appliedPromoCode = useCartStore((state) => state.appliedPromoCode);

  // États du modal depuis le store unifié
  const modalState = useCartStore((state) => state.modalState);

  // États du formulaire depuis le store unifié
  const formData = useCartStore((state) => state.formData);

  // États des promos depuis le store unifié
  const promoState = useCartStore((state) => state.promoState);

  // États des commandes depuis le store unifié
  const orderState = useCartStore((state) => state.orderState);

  // Actions du store unifié (stables, pas besoin de sélecteurs)
  const { clearCartAfterOrder, modal, form, promo, order } = useCartStore();

  // Données calculées mémorisées pour optimiser les performances
  const pricing = useMemo(() => calculatePricing(subtotal), [subtotal]);

  const selectedZone = useMemo(
    () => deliveryZones.find((zone) => zone.id === formData.deliveryZoneId),
    [deliveryZones, formData.deliveryZoneId]
  );

  const deliveryPrice = selectedZone ? selectedZone.deliveryFee : 0;

  const step = modalState.step;

  // Calculs de prix mémorisés
  const { discountedSubtotal, effectiveDeliveryFee, totalPrice } =
    useMemo(() => {
      const discounted = Math.max(
        0,
        Number(pricing.itemPrice) -
          (promoState.isValid ? promoState.discountAmount : 0)
      );
      const effectiveFee = promoState.isFreeDelivery
        ? 0
        : Number(deliveryPrice);
      const total = discounted + effectiveFee;

      return {
        discountedSubtotal: discounted,
        effectiveDeliveryFee: effectiveFee,
        totalPrice: total,
      };
    }, [
      pricing.itemPrice,
      promoState.isValid,
      promoState.discountAmount,
      promoState.isFreeDelivery,
      deliveryPrice,
    ]);

  // Validation de l'étape actuelle depuis le store unifié
  const currentStepValidation = form.validateCurrentStep();

  // Heures de livraison (constantes)
  const deliveryTimes = useMemo(
    () => [
      { id: "12h-13h", name: "12h00 - 13h00" },
      { id: "13h-14h", name: "13h00 - 14h00" },
      { id: "14h-15h", name: "14h00 - 15h00" },
      { id: "15h-16h", name: "15h00 - 16h00" },
    ],
    []
  );

  // Handlers optimisés utilisant les actions du store unifié
  const handleInputChange = React.useCallback(
    (field: string, value: string) => {
      form.updateFormData(field, value);
    },
    [form]
  );

  const handleNext = React.useCallback(() => {
    modal.nextStep();
  }, [modal]);

  const handleBack = React.useCallback(() => {
    modal.previousStep();
  }, [modal]);

  /**
   * Gestionnaire principal pour la soumission des commandes
   * Gère les trois modes : ajout au panier, commande directe, commande depuis le panier
   */
  const handleSubmit = React.useCallback(async () => {
    try {
      let orderResult = null;

      if (cartItems.length > 0) {
        // Commande depuis le panier
        orderResult = await order.submitCartOrder(
          { ...formData, employeeId: companyId },
          promoState.code
        );
      }

      if (orderResult) {
        toast.success("Commande créée avec succès !");

        // Vider le panier si commande depuis le panier
        if (cartMode && cartItems.length > 0) {
          const clearedItemsCount = clearCartAfterOrder();
          toast.success(
            `${clearedItemsCount} article(s) supprimé(s) du panier`
          );
        }

        // Callback de succès
        // onOrderSuccess?.(orderResult.id);
        // Nouvelle logique de paiement/QR
        const paymentInit = orderResult.paymentInit;

        // Fonction helper pour redirection et fermeture cohérente
        const finalizeAndRedirect = () => {
          try {
            router.push(`/orders/${orderResult.orderNumber}`);
          } finally {
            // Vider le panier après la redirection pour garder le modal
            // ouvert jusqu'à la fin du flux de paiement/QR
            clearCartAfterOrder();
            modal.closeModal();
            modal.resetModal();
          }
        };

        // Si employé, pas de paiement: redirection immédiate
        if (isEmployee || !paymentInit) {
          finalizeAndRedirect();
          return;
        }

        const qrCode = paymentInit.qrCode;
        const paymentLinks =
          unifiedOrderService.extractPaymentLinks(orderResult);

        // Desktop et QR disponible: afficher modal QR en priorité
        const shouldPrioritizeQr = unifiedOrderService.shouldPrioritizeQr(
          orderResult,
          isMobile
        );

        if (shouldPrioritizeQr) {
          setQrCode(qrCode);
          setQrModalOpen(true);
        } else if (paymentLinks.length > 0) {
          if(!isMobile && paymentLinks.length === 1) {
            handleSelectPayment(paymentLinks[0].url);
            return;
          }
          // Toujours afficher le modal de sélection avec les liens disponibles (1 ou plusieurs)
          setPaymentOptions(paymentLinks);
          setSelectionModalOpen(true);
        } else {
          // Aucun lien disponible: redirection directe
          finalizeAndRedirect();
        }
      }
    } catch (error) {
      console.error("Erreur lors de la soumission:", error);
      toast.error("Erreur lors de la soumission de la commande");
    }
  }, [
    cartMode,
    order,
    formData,
    promoState.code,
    promoState.isValid,
    clearCartAfterOrder,
    onOrderSuccess,
    router,
    modal,
    isMobile,
  ]);

  // Synchroniser avec le panier (optimisé avec dépendances spécifiques)
  useEffect(() => {
    if (selectedDeliveryZone) {
      form.updateFormData("deliveryZoneId", selectedDeliveryZone.id);
    }
  }, [selectedDeliveryZone]);

  useEffect(() => {
    if (appliedPromoCode) {
      promo.setPromoCode(appliedPromoCode);
    }
  }, [appliedPromoCode, promo]);

  // Mettre à jour weeklyMenuId quand le panier change en mode panier
  useEffect(() => {
    if (cartItems.length > 0) {
      form.updateFormData("weeklyMenuId", cartItems[0].weeklyMenuId);
    }
  }, [cartItems]);
  
  useEffect(() => {
    if (paymentMethods.length > 0) {
      form.updateFormData("paymentMethod", paymentMethods[0].id);
    }
  }, [paymentMethods]);

  // Fonction helper pour ouvrir un lien de manière compatible avec iOS Safari
  const openPaymentLink = (url: string): boolean => {
      try {
        // Fallback sur window.open
        const win = window.location.href = url // window.open(url, "_blank", "noopener,noreferrer");
        if (win) {
          return true;
        }
      } catch (e2) {
        // Dernier recours - redirection directe
        window.location.href = url;
        return true;
      }
    return false;
  };

  // Handlers pour fermeture des modals et redirection
  const handleCloseQrModal = () => {
    setQrModalOpen(false);
    if (orderState.currentOrder) {
      router.push(`/orders/${orderState.currentOrder.orderNumber}`);
    }
    // Vider le panier à la fermeture du QR
    clearCartAfterOrder();
    modal.closeModal();
    modal.resetModal();
  }

  const handleSelectPayment = (url: string) => {
    const opened = openPaymentLink(url);
    if (opened) {
      // Ne pas fermer le modal immédiatement pour laisser l'utilisateur voir qu'il a cliqué
      // Le modal sera fermé via le bouton "J'ai terminé"
    } else {
      toast.error("Impossible d'ouvrir le lien de paiement");
    }
  }

  return (
    <Dialog open={open} onOpenChange={(open) => !open && modal.closeModal()}>
      <DialogContent className="sm:max-w-[900px] max-w-[95vw] max-h-[95vh] overflow-hidden bg-white flex flex-col justify-between p-2 sm:p-3">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-3">
            <ShoppingBag className="w-10 h-10 text-primary" />
            <div className="min-w-0">
              <div className="text-base sm:text-lg font-bold text-gray-900">
                Commande depuis le panier
              </div>
              <div className="flex items-center space-x-2 text-xs sm:text-sm text-gray-600">
                <span>
                  {cartItems.length} article
                  {cartItems.length > 1 ? "s" : ""}
                </span>
              </div>
            </div>
          </DialogTitle>

          {/* Progress Steps */}
          <StepProgress
            currentStep={step}
            stepCount={2}
            getStepLabel={(stepNumber) => getStepTitle(stepNumber)}
          />
        </DialogHeader>

        {selectionModalOpen ? (
          <div className="space-y-4 p-4">
            <div className="text-center mb-4">
              <h3 className="text-lg font-semibold">
                {paymentOptions.length === 1
                  ? "Payer maintenant"
                  : "Choisir une méthode de paiement"}
              </h3>
            </div>
            <div className="space-y-3">
              {paymentOptions.map((opt) => (
                <Button
                  key={opt.label}
                  onClick={() => handleSelectPayment(opt.url)}
                  className="w-full bg-black hover:bg-gray-800 text-white justify-center"
                >
                  <span className="font-medium">{paymentOptions.length === 1 ? "Finaliser" : opt.label}</span>
                </Button>
              ))}
              {paymentOptions.length === 0 && (
                <div className="text-sm text-gray-600 text-center">
                  Aucun lien de paiement disponible.
                </div>
              )}
            </div>
          </div>
        ) : qrModalOpen ? (
          <div className="flex flex-col items-center space-y-4">
            {qrCode ? (
              <img
                src={`data:image/png;base64,${qrCode}`}
                alt="QR Code de paiement"
                className="w-72 h-72 object-contain border rounded-md"
              />
            ) : (
              <div className="text-sm text-red-600">QR Code indisponible</div>
            )}
            <div className="text-xs text-gray-600 text-center">
              Scannez ce QR Code avec votre application Orange Money ou Maxit pour finaliser.
            </div>
          </div>
        ) : (
          <div className="overflow-y-scroll h-auto">
            <div className="flex-1 overflow-y-auto p-3 sm:p-6">
              {/* Step 1: User Information */}
              {step === 1 && cartItems.length > 0 && (
                <InfoStep
                  formData={{
                    firstName: formData.firstName,
                    lastName: formData.lastName,
                    phone: formData.phone,
                    email: formData.email,
                    deliveryZoneId: formData.deliveryZoneId,
                    deliveryAddress: formData.deliveryAddress,
                    deliveryTime: formData.deliveryTime,
                    customerNotes: formData.customerNotes,
                  }}
                  deliveryTimes={deliveryTimes}
                  deliveryZones={deliveryZones}
                  onChange={handleInputChange}
                />
              )}

              {/* Step 2: Payment & Confirmation */}
              {step === 2 && cartItems.length > 0 && (
                <div className="space-y-4 sm:space-y-6">
                  {/* Cart Summary for cart mode */}
                  <div className="space-y-4">
                    <h4 className="text-lg font-semibold">
                      Résumé de la commande
                    </h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span>
                          Sous-total ({cartItems.length} article
                          {cartItems.length > 1 ? "s" : ""})
                        </span>
                        <span className="font-medium">{subtotal} FCFA</span>
                      </div>
                      {selectedZone && (
                        <div className="flex justify-between items-center text-sm text-gray-600">
                          <span>Livraison ({selectedZone.name})</span>
                          <span>{effectiveDeliveryFee} FCFA</span>
                        </div>
                      )}
                      {promoState.isValid && promoState.discountAmount > 0 && (
                        <div className="flex justify-between items-center text-sm text-green-600">
                          <span>Réduction</span>
                          <span>-{promoState.discountAmount} FCFA</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Payment Method - masqué pour les employés */}
                  {!isEmployee && (
                    <PaymentMethodSelector
                      paymentMethods={paymentMethods}
                      selected={formData.paymentMethod}
                      onChange={(v: string) =>
                        handleInputChange("paymentMethod", v)
                      }
                    />
                  )}
                </div>
              )}
            </div>

            <div className="p-3 sm:px-6">
              {/* Rak Tak Promo Info */}
              {/* <RakTakPromoInfo isActive={!!item?.hasRakTakPromo} /> */}

              {/* Error Display */}
              {(orderState.error || orderState.submissionError) && (
                <div className="px-6 py-3 bg-red-50 border-t border-red-200">
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-red-700">
                      {orderState.error || orderState.submissionError}
                    </p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => order.clearOrderError()}
                      className="text-red-700 hover:text-red-900"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Footer */}
        <DialogFooter className="border-t border-gray-100 p-3 sm:p-6">
          <div className="flex flex-col sm:flex-row justify-between items-center w-full space-y-3 sm:space-y-0 sm:space-x-4">
            {/* Price Display */}
            <div className="text-center sm:text-left">
              <div className="text-xs sm:text-sm text-gray-600">
                Total à payer
              </div>
              <div className="text-xl sm:text-2xl font-bold text-orange-600">
                {cartMode ? `${pricing.itemPrice} FCFA` : `${totalPrice} FCFA`}
              </div>
            </div>

            {selectionModalOpen ? null : qrModalOpen ? (
              <Button
                onClick={handleCloseQrModal}
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                J'ai terminé
              </Button>
            ) : (
              <div className="flex space-x-2 sm:space-x-3 w-full sm:w-auto">
                {step > 1 && (
                  <Button
                    variant="outline"
                    onClick={handleBack}
                    className="flex-1 sm:flex-none text-sm"
                  >
                    Retour
                  </Button>
                )}
                {step < 2 ? (
                  <Button
                    onClick={handleNext}
                    disabled={!currentStepValidation.isValid}
                    className="flex-1 sm:flex-none bg-red-600 hover:bg-red-700 text-white text-sm disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    Continuer
                  </Button>
                ) : (
                  <Button
                    onClick={handleSubmit}
                    disabled={
                      orderState.isSubmitting || !currentStepValidation.isValid
                    }
                    className="flex-1 sm:flex-none bg-red-600 hover:bg-red-700 text-white text-sm disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    {orderState.isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-3 w-3 sm:h-4 sm:w-4 animate-spin" />
                        Traitement...
                      </>
                    ) : cartMode ? (
                      "Ajouter au panier"
                    ) : (
                      <>
                        <CreditCard className="mr-2 h-3 w-3 sm:h-4 sm:w-4" />
                        Finaliser {totalPrice} FCFA
                      </>
                    )}
                  </Button>
                )}
              </div>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
