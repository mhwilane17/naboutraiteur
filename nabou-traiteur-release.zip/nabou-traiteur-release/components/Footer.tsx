import { MapPin, Clock, Facebook, Instagram, Linkedin } from "lucide-react";
import Link from "next/link";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Contact Info */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-red-400">ADRESSE</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-red-400 mt-1" />
                <span className="text-gray-300">HLM Fass Paillotte 6A, Dakar</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-red-400 mt-1" />
                <span className="text-gray-300">Golf Sud numéro 678, Dakar</span>
              </div>
            </div>
          </div>

          {/* Hours */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-red-400">HORAIRES</h3>
            <div className="flex items-center space-x-3">
              <Clock className="w-5 h-5 text-red-400" />
              <span className="text-gray-300">08h - 18h</span>
            </div>
          </div>

          {/* Social Media */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-red-400">SUIVEZ-NOUS</h3>
            <div className="flex space-x-4">
              <Link
                href="#"
                className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center hover:bg-blue-700 transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </Link>
              <Link
                href="#"
                className="w-10 h-10 bg-pink-600 rounded-lg flex items-center justify-center hover:bg-pink-700 transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </Link>
              <Link
                href="#"
                className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center hover:bg-blue-600 transition-colors"
              >
                <Linkedin className="w-5 h-5" />
              </Link>
            </div>
          </div>

          {/* Contact */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-red-400">NOUS CONTACTER</h3>
            <div className="space-y-3">
              <div className="text-gray-300">
                <span className="text-red-400">Email :</span> contact@nabou-traiteur.com
              </div>
              <div className="text-gray-300">
                <span className="text-red-400">Tél :</span> 780106925
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-400">© 2025 Nabou Traiteur. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
}
