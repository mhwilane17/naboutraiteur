"use client";


import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DeliveryZone } from "@/services/deliveryService";
import { DeliveryTime } from "@/types/menu";
import { useAuthStore } from "@/stores/authStore";

interface InfoStepProps {
  formData: {
    firstName: string;
    lastName: string;
    phone: string;
    email: string;
    deliveryZoneId: string;
    deliveryAddress: string;
    deliveryTime: string;
    customerNotes?: string;
  };
  deliveryTimes: DeliveryTime[];
  deliveryZones: DeliveryZone[];
  onChange: (field: string, value: string) => void;
}

export function InfoStep({formData, deliveryTimes, deliveryZones, onChange }: InfoStepProps) {
  const { user } = useAuthStore();
  const isEmployee = !!user?.companyId;
  return (
    <div className="space-y-4 sm:space-y-6">
      <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-3 sm:mb-4">
        Informations de commande
      </h3>

      {/* Champs personnels - masqués pour les employés */}
      {!isEmployee && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            <div>
              <Label htmlFor="firstName" className="text-sm font-medium text-gray-700">
                Prénom *
              </Label>
              <Input
                id="firstName"
                value={formData.firstName}
                onChange={(e) => onChange("firstName", e.target.value)}
                className="mt-1 text-sm"
                required
              />
            </div>
            <div>
              <Label htmlFor="lastName" className="text-sm font-medium text-gray-700">
                Nom *
              </Label>
              <Input
                id="lastName"
                value={formData.lastName}
                onChange={(e) => onChange("lastName", e.target.value)}
                className="mt-1 text-sm"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            <div>
              <Label htmlFor="phone" className="text-sm font-medium text-gray-700">
                Téléphone *
              </Label>
              <Input
                id="phone"
                type="number"
                value={formData.phone}
                onChange={(e) => onChange("phone", e.target.value)}
                className="mt-1 text-sm"
                required
              />
            </div>
            <div>
              <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => onChange("email", e.target.value)}
                className="mt-1 text-sm"
              />
            </div>
          </div>

          {/* Options de livraison - masquées pour les employés */}
          <div>
            <Label htmlFor="deliveryZoneId" className="text-sm font-medium text-gray-700">
              Zone de livraison *
            </Label>

            <Select value={formData.deliveryZoneId} onValueChange={(v) => onChange("deliveryZoneId", v)}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder={"Sélectionnez votre zone"} />
              </SelectTrigger>
              <SelectContent>
                {deliveryZones.map((zone) => (
                  <SelectItem key={zone.id} value={zone.id}>
                    <div>
                      {zone.name} - {zone.deliveryFee} FCFA
                    </div>
                    <span className="text-gray-500 text-xs">({zone.areas.join(", ")})</span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="deliveryAddress" className="text-sm font-medium text-gray-700">
              Adresse de livraison *
            </Label>

            <Input
              id="deliveryAddress"
              value={formData.deliveryAddress}
              onChange={(e) => onChange("deliveryAddress", e.target.value)}
              className="mt-1 text-sm"
              placeholder="Entrez votre adresse complète"
              required
            />
          </div>
        </>
      )}

      <div>
        <Label htmlFor="deliveryTime" className="text-sm font-medium text-gray-700">
          Heure de livraison *
        </Label>
        <Select value={formData.deliveryTime} onValueChange={(v) => onChange("deliveryTime", v)}>
          <SelectTrigger className="mt-1">
            <SelectValue placeholder="Sélectionnez l'heure" />
          </SelectTrigger>
          <SelectContent>
            {deliveryTimes.map((time) => (
              <SelectItem key={time.id} value={time.id}>
                {time.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="notes" className="text-sm font-medium text-gray-700">
          Notes spéciales
        </Label>
        <Textarea
          id="notes"
          value={formData.customerNotes}
          onChange={(e) => onChange("customerNotes", e.target.value)}
          className="mt-1 text-sm"
          rows={2}
          placeholder="Allergies, préférences, instructions de livraison..."
        />
      </div>
    </div>
  );
}