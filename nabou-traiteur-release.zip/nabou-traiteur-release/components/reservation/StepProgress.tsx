"use client";

interface StepProgressProps {
  currentStep: number;
  stepCount: number;
  getStepLabel: (step: number) => string;
}

export function StepProgress({ currentStep, stepCount, getStepLabel }: StepProgressProps) {
  return (
    <div className="py-2 sm:py-4 border-b border-gray-100 border-t">
      <div className="flex items-center justify-between">
        {Array.from({ length: stepCount }, (_, i) => i + 1).map((stepNumber) => (
          <div key={stepNumber} className="flex items-center">
            <div
              className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-xs sm:text-sm font-medium ${
                currentStep >= stepNumber
                  ? "bg-red-600 text-white"
                  : "bg-gray-200 text-gray-600"
              }`}
            >
              {stepNumber}
            </div>
            <span
              className={`ml-1 sm:ml-2 text-xs sm:text-sm ${
                currentStep >= stepNumber
                  ? "text-red-600 font-medium"
                  : "text-gray-500"
              }`}
            >
              {getStepLabel(stepNumber)}
            </span>
            {stepNumber < stepCount && (
              <div className="w-6 sm:w-12 h-0.5 bg-gray-200 mx-2 sm:mx-4"></div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}