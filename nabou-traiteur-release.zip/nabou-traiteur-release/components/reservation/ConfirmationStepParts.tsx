"use client";

import Image from "next/image";
import { Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { WeeklyMenuItem } from "@/types/weeklyMenuPublic";
import { PaymentMethod } from "@/services/paymentService";
import { useCallback } from "react";
import { useCartStore } from "@/stores/cartStore";

export function PromoCodeCard() {


  // États des promos depuis le store unifié
  const { promo, promoState } = useCartStore();

  const handlePromoCodeChange = useCallback((code: string) => {
    promo.setPromoCode(code);
  }, [promo]);

  const handleValidatePromo = useCallback(async () => {
    await promo.validatePromoCode();
  }, [promo]);

  const handleRemovePromo = useCallback(() => {
    promo.removePromoCode();
  }, [promo]);

  const promoCode = promoState.code
  const isValidating = promoState.isValidating
  const isValid = promoState.isValid
  const message = promoState.message
  const onChange = handlePromoCodeChange
  const onValidate = handleValidatePromo
  const onRemove = handleRemovePromo

  return (
    <div>
        <div className="flex gap-2 items-center">
          <Input
            placeholder="Saisir votre code"
            value={promoCode}
            onChange={(e) => onChange(e.target.value)}
            disabled={isValidating}
            className="flex-1"
          />
          {isValid && onRemove ? (
            <Button
              variant="outline"
              onClick={onRemove}
              disabled={isValidating}
            >
              Supprimer
            </Button>
          ) : (
            <Button
              variant="outline"
              onClick={onValidate}
              disabled={isValidating || !promoCode}
            >
              {isValidating ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Vérif...
                </>
              ) : (
                "Valider"
              )}
            </Button>
          )}
        </div>
        {message && (
          <div className={`mt-2 text-sm ${isValid ? "text-green-600" : "text-red-600"}`}>
            {message}
          </div>
        )}
    </div>
  );
}

interface OrderSummaryProps {
  item: WeeklyMenuItem;
  menuSize: string;
  quantity: number;
  itemPrice: number;
  discountedSubtotal: number;
  isPromoValid: boolean;
  promoDiscountAmount: number;
  selectedZoneName?: string;
  deliveryPrice: number;
  effectiveDeliveryFee: number;
  isLoggedIn: boolean;
  isFreeDelivery?: boolean;
}

export function OrderSummary({
  item,
  menuSize,
  quantity,
  itemPrice,
  discountedSubtotal,
  isPromoValid,
  promoDiscountAmount,
  selectedZoneName,
  deliveryPrice,
  effectiveDeliveryFee,
  isLoggedIn,
  isFreeDelivery,
}: OrderSummaryProps) {
  return (
    <Card className="bg-background">
      <CardHeader>
        <CardTitle className="text-base sm:text-lg">Résumé de votre commande</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 sm:space-y-4">
        <div className="flex items-center space-x-3 sm:space-x-4">
          <Image
            src={item.image || "/placeholder.svg"}
            alt={item.name}
            width={50}
            height={50}
            className="rounded-lg sm:w-[60px] sm:h-[60px]"
          />
          <div className="flex-1">
            <h4 className="font-medium text-sm sm:text-base">{item.name}</h4>
            <p className="text-xs sm:text-sm text-gray-600">{item.day}</p>
            <p className="text-xs sm:text-sm text-gray-600">
              Taille: {menuSize} - Quantité: {quantity}
            </p>
          </div>
          <div className="text-right">
            {isPromoValid && promoDiscountAmount > 0 ? (
              <div className="flex flex-col items-end">
                <span className="text-xs opacity-35 line-through">{itemPrice} FCFA</span>
                <p className="font-bold text-orange-600 text-sm sm:text-base">
                  {discountedSubtotal} FCFA
                </p>
              </div>
            ) : (
              <div>
                {/* {item.options.find((o) => o.name === menuSize)?.discountPrice && (
                  <span className="text-xs opacity-35 line-through">
                    {itemPrice} FCFA
                  </span>
                )} */}
                <p className="font-bold text-orange-600 text-sm sm:text-base">{itemPrice} FCFA</p>
              </div>
            )}
          </div>
        </div>

        {!isLoggedIn && selectedZoneName && (
          <div className="flex justify-between items-center pt-2 border-t">
            <span className="text-xs sm:text-sm text-gray-600">Livraison ({selectedZoneName})</span>
            <div className="flex flex-col items-end">
              {isFreeDelivery && deliveryPrice > 0 && (
                <span className="text-xs opacity-35 line-through">{deliveryPrice} FCFA</span>
              )}
              <span className="font-medium text-sm sm:text-base">{effectiveDeliveryFee} FCFA</span>
            </div>
          </div>
        )}

        {isPromoValid && promoDiscountAmount > 0 && (
          <div className="flex justify-between items-center pt-2 border-t">
            <span className="text-xs sm:text-sm text-gray-600">Réduction</span>
            <span className="font-medium text-sm sm:text-base text-green-600">
              - {promoDiscountAmount} FCFA
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

interface PaymentMethodSelectorProps {
  paymentMethods: PaymentMethod[];
  selected: string;
  onChange: (id: string) => void;
}

export function PaymentMethodSelector({
  paymentMethods,
  selected,
  onChange,
}: PaymentMethodSelectorProps) {
  return (
    <Card className="bg-background">
      <CardHeader>
        <CardTitle className="text-base sm:text-lg">Mode de paiement</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {paymentMethods.map((method) => (
            <label key={method.id} className="flex items-center space-x-3 cursor-pointer">
              <input
                type="radio"
                className="accent-red-600"
                checked={selected === method.id}
                onChange={() => onChange(method.id)}
              />
              <div className="flex flex-col">
                <span className="font-medium">{method.name}</span>
                {method.description && (
                  <span className="text-sm text-gray-500">{method.description}</span>
                )}
                {method.processingTime && (
                  <span className="text-xs text-blue-600">Délai: {method.processingTime}</span>
                )}
              </div>
            </label>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
