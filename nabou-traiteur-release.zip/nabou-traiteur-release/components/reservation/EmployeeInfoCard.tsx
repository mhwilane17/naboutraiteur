import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface EmployeeInfoCardProps {
  userInfo: {
    firstName: string;
    lastName: string;
    company: string;
    employeeId: string;
  };
}

export function EmployeeInfoCard({ userInfo }: EmployeeInfoCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Informations employé</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 text-sm">
          <p>
            <span className="font-medium">Nom:</span> {userInfo.firstName}{" "}
            {userInfo.lastName}
          </p>
          <p>
            <span className="font-medium">Entreprise:</span> {userInfo.company}
          </p>
          <p>
            <span className="font-medium">ID Employé:</span> {userInfo.employeeId}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}