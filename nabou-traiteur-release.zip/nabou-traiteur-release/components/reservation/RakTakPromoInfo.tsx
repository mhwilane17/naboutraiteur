import React from "react";
import { Clock } from "lucide-react";

interface RakTakPromoInfoProps {
  isActive: boolean;
}

export function RakTakPromoInfo({ isActive }: RakTakPromoInfoProps) {
  if (!isActive) return null;

  return (
    <div className="bg-red-50 border border-red-200 rounded-lg p-3 sm:p-4">
      <div className="flex items-center space-x-2">
        <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-red-600" />
        <span className="font-medium text-red-800 text-sm sm:text-base">
          Promo Rak Tak active !
        </span>
      </div>
    </div>
  );
}