import { Building, Gift, Zap, CheckCircle, Phone, ExternalLink } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getAppConfig } from "@/lib/app-config";

const offers = [
  {
    title: "Menu Entreprise",
    description: "Solutions de restauration pour vos équipes",
    features: [
      "Livraison groupée",
      "Facturation mensuelle",
      "Menu personnalisé",
      "Service sur place",
    ],
    icon: Building,
    color: "bg-blue-100 text-blue-600",
  },
  {
    title: "Événements",
    description: "Traiteur pour vos événements spéciaux",
    features: ["Buffets", "Cocktails", "Réceptions"],
    icon: Gift,
    color: "bg-purple-100 text-purple-600",
  },

  {
    title: "Commande en ligne",
    description: "Plateforme simple et sécurisée",
    icon: Phone,
    features: ["Interface intuitive", "Paiement mobile sécurisé", "Suivi des commandes"],
  },
  {
    title: "Livraison Express",
    description: "Commande rapide pour particuliers",
    features: ["Livraison rapide", "Paiement mobile", "Suivi temps réel"],
    icon: Zap,
    color: "bg-orange-100 text-orange-600",
  },
];


export async function OffersSection() {
  const formEstimateUrl = await getAppConfig('app.form_estimate_url', '#');
  
  return (
    <section id="offre" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="bg-primary/10 text-primary mb-4">Nos Offres</Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Solutions adaptées à vos besoins
          </h2>
          <p className="text-xl text-gray-600">Découvrez nos différentes formules</p>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {offers.map((offer, index) => (
            <Card key={index} className="bg-background border-none">
              <CardContent className="p-8">
                <div
                  className={`w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mb-6`}
                >
                  <offer.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold text-black mb-3">{offer.title}</h3>
                <p className="text-gray-800 mb-6">{offer.description}</p>
                <ul className="space-y-2 mb-6">
                  {offer.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center space-x-2 text-sm text-gray-800">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                {offer.title === "Menu Entreprise" && (
                  <a
                    href={formEstimateUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full"
                  >
                    <Button className="w-full mt-4 text-white">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Demander un devis
                    </Button>
                  </a>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
