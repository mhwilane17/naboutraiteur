import { AlertCircle, RefreshCw } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ErrorDisplayProps {
  error: string;
  onRetry?: () => void;
  retryText?: string;
  className?: string;
  variant?: "default" | "destructive";
}

export function ErrorDisplay({ 
  error, 
  onRetry, 
  retryText = "Réessayer", 
  className,
  variant = "destructive" 
}: ErrorDisplayProps) {
  return (
    <Alert variant={variant} className={cn("", className)}>
      <AlertCircle className="h-4 w-4" />
      <AlertDescription className="flex items-center justify-between">
        <span>{error}</span>
        {onRetry && (
          <Button
            variant="outline"
            size="sm"
            onClick={onRetry}
            className="ml-4 h-8"
          >
            <RefreshCw className="h-3 w-3 mr-1" />
            {retryText}
          </Button>
        )}
      </AlertDescription>
    </Alert>
  );
}