import Image from "next/image";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export function AboutSection() {
  return (
    <section id="apropos" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div>
              <Badge className="bg-primary/10 text-primary mb-4">
                Notre histoire
              </Badge>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
                Nabou Traiteur : sincérité, attention, humanité
              </h2>
            </div>

            <p className="text-lg text-gray-600 leading-relaxed">
              Tout a commencé entre collègues et amies, réunies par une passion
              commune : la cuisine. Fortes de notre complicité et de notre
              expérience en restauration, nous avons voulu créer un lieu à notre
              image.
            </p>

            <div>
              <Link
                href="#menu"
                className="bg-primary text-white px-8 py-3 rounded-full"
              >
                COMMANDER
              </Link>
            </div>
          </div>

          <div className="relative">
            <Image
              src="/images/dish-5.png"
              alt="Histoire de Nabou Traiteur"
              width={600}
              height={400}
              className="rounded-3xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
