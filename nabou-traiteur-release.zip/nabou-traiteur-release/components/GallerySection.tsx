import Image from "next/image";

import { Badge } from "@/components/ui/badge";

export function GallerySection() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="bg-primary/10 text-primary hover:bg-red-100 mb-4">Galerie</Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Photos de nos plats & événements
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="space-y-8">
            <Image
              src="/images/photo-2.jpeg"
              alt="Buffet événement"
              width={400}
              height={300}
              className="rounded-2xl"
            />
            <Image
              src="/images/photo-6.jpeg"
              alt="Plat traditionnel"
              width={400}
              height={300}
              className="rounded-2xl"
            />
            <Image
              src="/images/photo-8.jpeg"
              alt="Desserts"
              width={400}
              height={300}
              className="rounded-2xl"
            />
          </div>
          <div className="space-y-8 mt-8 md:mt-0">
            <div className="rounded-2xl bg-primary">
              <Image
                src="/images/nabou_traiteur_logo.png"
                alt="Service traiteur"
                width={400}
                height={400}
                className="rounded-2xl"
                style={{ filter: "brightness(10000)" }}
              />
            </div>
            <Image
              src="/images/photo-12.jpeg"
              alt="Service traiteur"
              width={400}
              height={400}
              className="rounded-2xl"
            />
            <Image
              src="/images/photo-5.jpeg"
              alt="Service traiteur"
              width={400}
              height={400}
              className="rounded-2xl"
            />
          </div>
          <div className="space-y-8 mt-16 md:mt-0">
            <Image
              src="/images/photo-7.jpeg"
              alt="Thiéboudienne"
              width={400}
              height={300}
              className="rounded-2xl"
            />
            <Image
              src="/images/photo-13.jpeg"
              alt="Desserts"
              width={400}
              height={300}
              className="rounded-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
