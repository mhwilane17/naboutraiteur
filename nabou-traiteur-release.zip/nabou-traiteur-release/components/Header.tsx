"use client";

import { useState } from "react";
import { Menu, User } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import EmployeeLoginModal from "@/components/EmployeeLoginModal";
import { useAuthStore } from "@/stores/authStore";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const user = useAuthStore((s) => s.user);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const logout = useAuthStore((s) => s.logout);

  return (
    <header className="border-b border-gray-100 z-50 bg-white sticky top-0">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <Image
              src="/images/nabou_traiteur_logo.png"
              alt="Logo Nabou Traiteur"
              width={150}
              height={40}
              className="rounded-full"
            />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="#accueil" className="text-gray-900 font-medium relative">
              Accueil
              <div className="absolute -bottom-1 left-0 w-full h-0.5 bg-primary"></div>
            </Link>
            <Link
              href="#offre"
              className="text-gray-500 hover:text-gray-900 transition-colors font-medium"
            >
              Offre
            </Link>
            <Link
              href="#service"
              className="text-gray-500 hover:text-gray-900 transition-colors font-medium"
            >
              Service
            </Link>
            <Link
              href="#menu"
              className="text-gray-500 hover:text-gray-900 transition-colors font-medium"
            >
              Menu
            </Link>
            <Link
              href="#apropos"
              className="text-gray-500 hover:text-gray-900 transition-colors font-medium"
            >
              À Propos
            </Link>
          </nav>

          {/* Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            {/* Afficher le nom si connecté, sinon bouton Connexion */}
            {isAuthenticated && user ? (
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2 text-green-600">
                    <User className="w-4 h-4" />
                    <span className="text-sm font-medium">{user.name}</span>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-56 p-2" align="end">
                  <div className="flex flex-col">
                    <Button
                      variant="ghost"
                      className="justify-start text-red-600 hover:text-red-700 hover:bg-transparent font-medium"
                      onClick={() => logout()}
                    >
                      Déconnexion
                    </Button>
                  </div>
                </PopoverContent>
              </Popover>
            ) : (
              <Button onClick={() => setLoginOpen(true)} className="font-medium">
                Connexion
              </Button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px]">
              <div className="flex flex-col space-y-6 mt-6">
                <Link
                  href="#accueil"
                  className="text-red-600 font-medium text-lg"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Accueil
                </Link>
                <Link
                  href="#offre"
                  className="text-gray-700 text-lg"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Offre
                </Link>
                <Link
                  href="#service"
                  className="text-gray-700 text-lg"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Service
                </Link>
                <Link
                  href="#menu"
                  className="text-gray-700 text-lg"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Menu
                </Link>
                <Link
                  href="#apropos"
                  className="text-gray-700 text-lg"
                  onClick={() => setIsMenuOpen(false)}
                >
                  À Propos
                </Link>
                {/* Afficher le nom si connecté, sinon bouton Connexion */}
                {isAuthenticated && user ? (
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="ghost" className="justify-start text-green-600">
                        <div className="flex items-center space-x-2">
                          <User className="w-4 h-4" />
                          <span className="text-base font-medium">{user.name}</span>
                        </div>
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-56 p-2" align="end">
                      <div className="flex flex-col">
                        <Button
                          variant="ghost"
                          onClick={() => {
                            logout();
                            setIsMenuOpen(false);
                          }}
                          className="justify-start text-red-600 hover:text-red-700 hover:bg-transparent font-medium"
                        >
                          Déconnexion
                        </Button>
                      </div>
                    </PopoverContent>
                  </Popover>
                ) : (
                  <Button
                    onClick={() => {
                      setIsMenuOpen(false);
                      setLoginOpen(true);
                    }}
                    className="mt-2"
                  >
                    Connexion
                  </Button>
                )}
              </div>
            </SheetContent>
          </Sheet>
          <EmployeeLoginModal open={loginOpen} onOpenChange={setLoginOpen} />
        </div>
      </div>
    </header>
  );
}
