"use client";

import { ProtectedRoute } from "./ProtectedRoute";
import { AdminLayout } from "./AdminLayout";

interface AdminWrapperProps {
  children: React.ReactNode;
}

export function AdminWrapper({ children }: AdminWrapperProps) {
  return (
    <ProtectedRoute>
      <AdminLayout>{children}</AdminLayout>
    </ProtectedRoute>
  );
}