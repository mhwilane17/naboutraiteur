"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { X, Filter, Building2, Calendar, Search } from "lucide-react";
import { useCompaniesStore } from "@/stores/companiesStore";
import { CompanyWithRelations } from "@/types/company";

interface DashboardFiltersProps {
  startDate: string;
  endDate: string;
  selectedCompanyIds: string[];
  onDateRangeChange: (startDate: string, endDate: string) => void;
  onCompanyIdsChange: (companyIds: string[]) => void;
  onReset: () => void;
  onApplyFilters: () => void;
}

export function DashboardFilters({
  startDate,
  endDate,
  selectedCompanyIds,
  onDateRangeChange,
  onCompanyIdsChange,
  onReset,
  onApplyFilters,
}: DashboardFiltersProps) {
  const { companies, fetchCompanies, loading } = useCompaniesStore();
  const [selectedCompanies, setSelectedCompanies] = useState<
    CompanyWithRelations[]
  >([]);

  useEffect(() => {
    fetchCompanies();
  }, [fetchCompanies]);

  useEffect(() => {
    const selected = companies.filter((company) =>
      selectedCompanyIds.includes(company.id)
    );
    setSelectedCompanies(selected);
  }, [companies, selectedCompanyIds]);

  const handleCompanySelect = (companyId: string) => {
    if (selectedCompanyIds.includes(companyId)) {
      // Remove company
      const newIds = selectedCompanyIds.filter((id) => id !== companyId);
      onCompanyIdsChange(newIds);
    } else {
      // Add company
      onCompanyIdsChange([...selectedCompanyIds, companyId]);
    }
  };

  const removeCompany = (companyId: string) => {
    const newIds = selectedCompanyIds.filter((id) => id !== companyId);
    onCompanyIdsChange(newIds);
  };

  const handleStartDateChange = (value: string) => {
    onDateRangeChange(value, endDate);
  };

  const handleEndDateChange = (value: string) => {
    onDateRangeChange(startDate, value);
  };

  const hasActiveFilters =
    selectedCompanyIds.length > 0 || startDate || endDate;

  return (
    <div className="bg-white p-4 rounded-lg border shadow-sm space-y-4">
      <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
        <Filter className="h-4 w-4" />
        Filtres
      </div>

      <div className="flex flex-row items-end justify-between gap-4">
        {/* Filtre de date de début */}
        <div className="space-y-2 w-full">
          <label className="text-sm font-medium text-gray-600 flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Date de début
          </label>
          <Input
            type="date"
            value={startDate}
            onChange={(e) => handleStartDateChange(e.target.value)}
            className="w-full"
          />
        </div>

        {/* Filtre de date de fin */}
        <div className="space-y-2 w-full">
          <label className="text-sm font-medium text-gray-600 flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Date de fin
          </label>
          <Input
            type="date"
            value={endDate}
            onChange={(e) => handleEndDateChange(e.target.value)}
            className="w-full"
            min={startDate} // Empêche de sélectionner une date de fin antérieure à la date de début
          />
        </div>

        {/* Filtre de compagnies */}
        <div className="space-y-2 w-full">
          <label className="text-sm font-medium text-gray-600 flex items-center gap-2">
            <Building2 className="h-4 w-4" />
            Compagnies
          </label>
          <Select onValueChange={handleCompanySelect}>
            <SelectTrigger>
              <SelectValue placeholder="Sélectionner des compagnies" />
            </SelectTrigger>
            <SelectContent>
              {loading ? (
                <SelectItem value="loading" disabled>
                  Chargement...
                </SelectItem>
              ) : companies.length === 0 ? (
                <SelectItem value="empty" disabled>
                  Aucune compagnie disponible
                </SelectItem>
              ) : (
                companies
                  .filter((company) => company.isActive)
                  .map((company) => (
                    <SelectItem
                      key={company.id}
                      value={company.id}
                      disabled={selectedCompanyIds.includes(company.id)}
                    >
                      <div className="flex items-center justify-between w-full">
                        <span>{company.name}</span>
                        {selectedCompanyIds.includes(company.id) && (
                          <Badge variant="secondary" className="ml-2">
                            Sélectionné
                          </Badge>
                        )}
                      </div>
                    </SelectItem>
                  ))
              )}
            </SelectContent>
          </Select>
        </div>

        {/* Actions */}
        <div className="flex flex-row justify-between items-center">
          <Button
            onClick={onApplyFilters}
            className="text-white"
          >
            <Search className="h-4 w-4 mr-2" />
            Appliquer les filtres
          </Button>

          {/* {hasActiveFilters && (
            <Button variant="outline" size="sm" onClick={onReset}>
              <X className="h-4 w-4 mr-2" />
              Réinitialiser les filtres
            </Button>
          )} */}
        </div>
      </div>

      {/* Compagnies sélectionnées */}
      {selectedCompanies.length > 0 && (
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-600">
            Compagnies sélectionnées ({selectedCompanies.length})
          </label>
          <div className="flex flex-wrap gap-2">
            {selectedCompanies.map((company) => (
              <Badge
                key={company.id}
                variant="outline"
                className="flex items-center gap-1 pr-1"
              >
                <Building2 className="h-3 w-3" />
                {company.name}
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-4 w-4 p-0 hover:bg-red-100"
                  onClick={() => removeCompany(company.id)}
                >
                  <X className="h-3 w-3" />
                </Button>
              </Badge>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
