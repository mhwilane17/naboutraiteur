"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, X, Upload } from "lucide-react";
import { useCategories } from "@/hooks/useCategories";
import { useMenuItemsStore } from "@/stores/menuItemsStore";
import { toast } from "sonner";
import { CldUploadButton } from "next-cloudinary";

interface CreateDishModalProps {
  trigger?: React.ReactNode;
}

export function CreateDishModal({ trigger }: CreateDishModalProps) {
  const { createMenuItem } = useMenuItemsStore();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");

  const { categories, loading: categoriesLoading } = useCategories();

  // Gestion de l'échappement pour fermer la modal
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
      }
    };

    if (open) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [open]);

  const [image, setImage] = useState("");
  const [isAvailable, setIsAvailable] = useState(true);
  const [hasRakTakPromo, setHasRakTakPromo] = useState(false);

  const [options, setOptions] = useState([{ name: "Classique", price: 0 }]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!name || !description || !category || !image) {
      alert("Veuillez remplir tous les champs obligatoires");
      return;
    }

    if (options.length === 0) {
      alert("Veuillez ajouter au moins une option");
      return;
    }

    setLoading(true);

    try {
      const newDish = {
        name,
        description,
        categoryId: category,
        image: image || "/placeholder.svg",
        isAvailable,
        isRakTakPromo: hasRakTakPromo,
        price: options[0]?.price || 0,
        options: [
          {
            name: "Taille",
            type: "size",
            isRequired: true,
            sortOrder: 1,
            values: options,
          },
        ],
      };

      await createMenuItem(newDish);
      toast.success("Plat créé avec succès!");
      resetForm();
    } catch (error) {
      console.error("Erreur lors de la création du plat:", error);
      toast.error("Erreur lors de la création du plat");
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setName("");
    setDescription("");
    setCategory("");
    setImage("");
    setIsAvailable(true);
    setHasRakTakPromo(false);
    setOptions([{ name: "PM", price: 0 }]);
    setOpen(false);
  };

  const addOption = () => {
    setOptions([...options, { name: "", price: 0 }]);
  };

  const removeOption = (index: number) => {
    setOptions(options.filter((_, i) => i !== index));
  };

  const updateOption = (index: number, field: "name" | "price", value: string | number) => {
    const newOptions = [...options];
    newOptions[index] = { ...newOptions[index], [field]: value };
    setOptions(newOptions);
  };

  return (
    <>
      {/* Trigger Button */}
      <div onClick={() => setOpen(true)}>
        {trigger || (
          <Button className="bg-red-600 hover:bg-red-700 text-white">
            <Plus className="h-4 w-4 mr-2" />
            Ajouter un plat
          </Button>
        )}
      </div>

      {/* Modal Overlay */}
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 transition-opacity"
            onClick={() => setOpen(false)}
          />
          
          {/* Modal Content */}
           <div className="relative bg-white rounded-lg shadow-xl w-[95vw] max-w-[700px] max-h-[90vh] overflow-y-auto">
             {/* Header */}
             <div className="p-4 sm:p-6 pb-4 border-b border-gray-200">
               <div className="flex items-center justify-between">
                 <h2 className="text-lg sm:text-xl font-semibold text-gray-900">
                   Créer un nouveau plat
                 </h2>
                 <button
                   onClick={() => setOpen(false)}
                   className="text-gray-400 hover:text-gray-600 transition-colors"
                 >
                   <X className="h-6 w-6" />
                 </button>
               </div>
             </div>
             <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-6">
            {/* Informations de base */}
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-700 border-b pb-2">Informations de base</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm font-medium">Nom du plat *</Label>
                  <Input
                    id="name"
                    placeholder="ex: Thiéboudienne"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="w-full"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium">Image du plat</Label>
                  <div className="flex flex-col gap-2">
                    {image && (
                      <div className="relative w-full h-32 border rounded-lg overflow-hidden bg-gray-50">
                        <img 
                          src={image} 
                          alt="Aperçu" 
                          className="w-full h-full object-cover"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="sm"
                          className="absolute top-2 right-2"
                          onClick={() => setImage("")}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    )}
                    <div className="cloudinary-upload-wrapper">
                      <CldUploadButton
                         uploadPreset="nabou_traiteur"
                         options={{
                           folder: "nabou_traiteur",
                           resourceType: "image",
                           maxFiles: 1,
                           sources: ["local", "url", "camera"],
                           multiple: false,
                           maxFileSize: 10000000,
                           clientAllowedFormats: ["jpg", "jpeg", "png", "webp"],
                           showPoweredBy: false,
                           theme: "minimal"
                         }}
                         onSuccess={(result: any) => {
                           console.log("Upload success:", result);
                           setImage(result.info.secure_url);
                           toast.success("Image uploadée avec succès!");
                         }}
                         onError={(error: any) => {
                           console.error("Upload error:", error);
                           toast.error("Erreur lors de l'upload de l'image");
                         }}
                         onOpen={() => {
                           console.log("Widget opened");
                         }}
                       >
                        <div className="flex items-center justify-center gap-2 p-3 border-2 border-dashed border-gray-300 rounded-lg hover:border-gray-400 transition-colors cursor-pointer bg-white">
                          <Upload className="h-4 w-4 text-gray-500" />
                          <span className="text-sm text-gray-600">
                            {image ? "Changer l'image" : "Uploader une image"}
                          </span>
                        </div>
                      </CldUploadButton>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-sm font-medium">Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Description du plat..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  required
                  className="w-full min-h-[80px] resize-none"
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Catégorie *</Label>
                <Select
                  value={category}
                  onValueChange={(value) => {
                    setCategory(value);
                  }}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Sélectionner une catégorie" />
                  </SelectTrigger>
                  <SelectContent>
                    {categoriesLoading ? (
                      <SelectItem value="loading" disabled>
                        Chargement...
                      </SelectItem>
                    ) : (
                      categories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.id}>
                          {cat.name}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Options et prix */}
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-700 border-b pb-2">Options et prix</h3>
              <div className="space-y-3">
                {options.map((option, index) => (
                  <div key={index} className="flex flex-col sm:flex-row gap-2 p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <Input
                        placeholder="Nom (ex: PM, GM)"
                        value={option.name}
                        onChange={(e) => updateOption(index, "name", e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Prix (XOF)"
                        value={option.price || ""}
                        onChange={(e) => updateOption(index, "price", parseInt(e.target.value) || 0)}
                        className="w-full sm:w-32"
                      />
                      {options.length > 1 && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeOption(index)}
                          className="shrink-0"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={addOption} 
                  className="w-full sm:w-auto"
                  size="sm"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Ajouter une option
                </Button>
              </div>
            </div>

            {/* Paramètres */}
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-700 border-b pb-2">Paramètres</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <input
                    type="checkbox"
                    id="isAvailable"
                    checked={isAvailable}
                    onChange={(e) => setIsAvailable(e.target.checked)}
                    className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <Label htmlFor="isAvailable" className="text-sm font-medium cursor-pointer">
                    Plat disponible
                  </Label>
                </div>

                {/* <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <input
                    type="checkbox"
                    id="hasRakTakPromo"
                    checked={hasRakTakPromo}
                    onChange={(e) => setHasRakTakPromo(e.target.checked)}
                    className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <Label htmlFor="hasRakTakPromo" className="text-sm font-medium cursor-pointer">
                    Promotion Rak Tak
                  </Label>
                </div> */}
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row justify-end gap-3 pt-6 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
                disabled={loading}
                className="w-full sm:w-auto order-2 sm:order-1"
              >
                Annuler
              </Button>
              <Button 
                type="submit" 
                disabled={loading}
                className="w-full sm:w-auto order-1 sm:order-2"
              >
                {loading ? "Création en cours..." : "Créer le plat"}
              </Button>
            </div>
            </form>
            </div>
          </div>
        )}
      </>
  );
}
