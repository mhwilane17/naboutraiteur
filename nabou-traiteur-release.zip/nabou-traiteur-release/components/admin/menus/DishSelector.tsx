"use client";

import { useState, useEffect, ReactNode } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Minus, Search } from "lucide-react";
import { MenuItem } from "@/types/menu";
import { WeeklyMenuDish } from "@/types/weeklyMenu";

interface DishSelectorProps {
  children: ReactNode;
  availableDishes: MenuItem[];
  selectedDishes: WeeklyMenuDish[];
  onDishesChange: (dishes: WeeklyMenuDish[]) => void;
}

const days = [
  { value: "lundi", label: "Lundi" },
  { value: "mardi", label: "Mardi" },
  { value: "mercredi", label: "Mercredi" },
  { value: "jeudi", label: "Jeudi" },
  { value: "vendredi", label: "Vendredi" },
] as const;

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "XOF",
    minimumFractionDigits: 0,
  }).format(amount);
};

export function DishSelector({
  children,
  availableDishes,
  selectedDishes,
  onDishesChange,
}: DishSelectorProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDay, setSelectedDay] = useState<string>("lundi");

  // Helper function to convert dayOfWeek number to day string
  const getDayFromNumber = (dayOfWeek: number): string => {
    const dayMap: Record<number, string> = {
      1: "lundi",
      2: "mardi",
      3: "mercredi",
      4: "jeudi",
      5: "vendredi",
    };
    return dayMap[dayOfWeek] || "lundi";
  };

  // Helper function to convert day string to dayOfWeek number
  const getDayNumber = (day: string): number => {
    const dayMap: Record<string, number> = {
      lundi: 1,
      mardi: 2,
      mercredi: 3,
      jeudi: 4,
      vendredi: 5,
    };
    return dayMap[day] || 1;
  };

  // Filtrer les plats disponibles par recherche
  const filteredDishes = availableDishes.filter(
    (dish) =>
      dish.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dish.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Grouper les plats sélectionnés par jour
  const dishesByDay = selectedDishes.reduce((acc, dish) => {
    const dayKey = days.find((d) => d.value === getDayFromNumber(dish.dayOfWeek))?.value || "lundi";
    if (!acc[dayKey]) {
      acc[dayKey] = [];
    }
    acc[dayKey].push(dish);
    return acc;
  }, {} as Record<string, WeeklyMenuDish[]>);

  const handleAddDish = (dish: MenuItem, day: string) => {
    const newDish: WeeklyMenuDish = {
      id: `${dish.id}-${selectedDay}-${Date.now()}`,
      menuItemId: dish.id,
      dayOfWeek: getDayNumber(selectedDay),
      mealType: "lunch",
      isAvailable: true,
      quantity: 10,
      menuItem: {
        ...dish,
        price: dish.price || 0,
      },
    };
    onDishesChange([...selectedDishes, newDish]);
  };

  const handleRemoveDish = (dishId: string) => {
    onDishesChange(selectedDishes.filter((dish) => dish.id !== dishId));
  };

  const handleUpdateQuantity = (dishId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveDish(dishId);
      return;
    }
    onDishesChange(
      selectedDishes.map((dish) => (dish.id === dishId ? { ...dish, quantity } : dish))
    );
  };

  const handleToggleRakTak = (dishId: string) => {
    onDishesChange(
      selectedDishes.map((dish) =>
        dish.id === dishId ? { ...dish, hasRakTakPromo: !dish.hasRakTakPromo } : dish
      )
    );
  };

  const handleToggleAvailability = (dishId: string) => {
    onDishesChange(
      selectedDishes.map((dish) =>
        dish.id === dishId ? { ...dish, isAvailable: !dish.isAvailable } : dish
      )
    );
  };

  const isDishSelected = (dishId: string, day: string) => {
    const dayNumber = getDayNumber(day);
    return selectedDishes.some(
      (dish) => dish.menuItemId === dishId && dish.dayOfWeek === dayNumber
    );
  };

  return (
    <div className="flex flex-col md:flex-row h-auto min-h-[80vh] gap-3 md:gap-5 overflow-y-auto py-3 px-3 sm:px-6">
      {/* Plats disponibles à ajouter */}
      <div className="w-full md:w-1/2 h-[35vh] md:h-full flex flex-col bg-background p-2 sm:p-3 rounded-lg gap-3 md:gap-5">
        <div className="text-sm sm:text-base font-medium">Ajouter des plats</div>
        <div className="relative">
          <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Rechercher un plat..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-7 sm:pl-8 text-sm sm:text-base h-8 sm:h-10"
          />
        </div>
        <div className="grid gap-2 sm:gap-3 h-full overflow-y-auto pb-4">
          {filteredDishes
            .filter((dish) => !isDishSelected(dish.id, selectedDay))
            .map((dish) => (
              <div
                key={dish.id}
                className="flex items-center justify-between p-2 sm:p-3 border rounded-lg"
              >
                <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
                  <img
                    src={dish.image}
                    alt={dish.name}
                    className="w-8 h-8 sm:w-10 sm:h-10 object-cover rounded-md flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-xs sm:text-base line-clamp-1">{dish.name}</h4>
                    <p className="text-xs sm:text-sm text-muted-foreground line-clamp-1">
                      {dish.description}
                    </p>
                    <div className="flex gap-1 sm:gap-2 mt-0.5 sm:mt-1">
                      <Badge variant="outline" className="text-xs px-1 py-0">
                        {dish.category?.name || "Autre"}
                      </Badge>
                    </div>
                  </div>
                </div>
                <Button
                  size="sm"
                  onClick={() => handleAddDish(dish, selectedDay)}
                  className="text-xs px-2 sm:px-3 h-7 sm:h-8 flex-shrink-0"
                >
                  <Plus className="h-3 w-3 sm:h-4 sm:w-4 mr-0 sm:mr-1" />
                  <span className="hidden sm:inline">Ajouter</span>
                </Button>
              </div>
            ))}
          {filteredDishes.filter((dish) => !isDishSelected(dish.id, selectedDay)).length === 0 && (
            <p className="text-center text-muted-foreground py-4 sm:py-8 text-xs sm:text-sm">
              {searchTerm
                ? "Aucun plat trouvé pour cette recherche"
                : "Tous les plats ont été ajoutés"}
            </p>
          )}
        </div>
      </div>

      <div className="w-full md:w-1/2 flex flex-col gap-3 md:gap-5">
        <div className="overflow-x-auto">{children}</div>
        <Tabs value={selectedDay} onValueChange={setSelectedDay} className="w-full overflow-visible">
          <TabsList className="grid w-full grid-cols-5 h-auto p-1 overflow-x-auto sticky top-0 z-10 bg-background">
            {days.map((day) => (
              <TabsTrigger
                key={day.value}
                value={day.value}
                className="text-xs sm:text-sm py-1.5 sm:py-2 px-1 sm:px-3 flex flex-col sm:flex-row items-center gap-0.5 sm:gap-1"
              >
                <span className="hidden sm:inline">{day.label}</span>
                <span className="sm:hidden text-xs">{day.label.slice(0, 3)}</span>
                {dishesByDay[day.value] && (
                  <Badge
                    variant="secondary"
                    className="text-xs px-1 py-0 min-w-[16px] h-4 flex items-center justify-center"
                  >
                    {dishesByDay[day.value].length}
                  </Badge>
                )}
              </TabsTrigger>
            ))}
          </TabsList>

          {days.map((day) => (
            <TabsContent
              key={day.value}
              value={day.value}
              className="space-y-2 sm:space-y-4 mt-2 sm:mt-4 overflow-y-auto max-h-[50vh] md:max-h-none pb-20"
            >
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-1 sm:gap-3">
                <h3 className="text-sm sm:text-lg font-semibold">Plats pour {day.label}</h3>
              </div>

              {/* Plats sélectionnés pour ce jour */}
              {dishesByDay[day.value] && dishesByDay[day.value].length > 0 && (
                <Card className="border-0 shadow-sm">
                  <CardContent className="space-y-2 sm:space-y-3 p-1 sm:p-0">
                    {dishesByDay[day.value].map((dish) => (
                      <div
                        key={dish.id}
                        className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 p-2 sm:p-3 border rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-center gap-2 sm:gap-3 flex-1">
                          <img
                            src={dish.menuItem?.image || "/placeholder.jpg"}
                            alt={dish.menuItem?.name || "Plat"}
                            className="w-8 h-8 sm:w-12 sm:h-12 object-cover rounded-md flex-shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium text-xs sm:text-base line-clamp-1">
                              {dish.menuItem?.name}
                            </h4>
                            <p className="text-xs sm:text-sm text-muted-foreground line-clamp-1 sm:line-clamp-2">
                              {dish.menuItem?.description}
                            </p>
                            <div className="flex flex-wrap gap-1 mt-0.5 sm:mt-1">
                              {dish.menuItem?.options?.slice(0, 2).map((option, index) => (
                                <span
                                  key={index}
                                  className="text-xs bg-gray-100 px-1 py-0.5 rounded truncate max-w-[120px] sm:max-w-none"
                                >
                                  {option.name}: {formatCurrency(option.values?.[0]?.price || 0)}
                                </span>
                              ))}
                              {dish.menuItem?.options && dish.menuItem.options.length > 2 && (
                                <span className="text-xs text-muted-foreground">
                                  +{dish.menuItem.options.length - 2}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col sm:flex-row sm:items-center gap-1.5 sm:gap-3">
                          <div className="flex items-center gap-1 sm:gap-2">
                            <Label className="text-xs sm:text-sm whitespace-nowrap">Qté:</Label>
                            <div className="flex items-center gap-0.5 sm:gap-1">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  handleUpdateQuantity(dish.id, (dish.quantity || 1) - 1)
                                }
                                className="h-6 w-6 sm:h-8 sm:w-8 p-0 flex-shrink-0"
                              >
                                <Minus className="h-2.5 w-2.5 sm:h-3 sm:w-3" />
                              </Button>
                              <Input
                                type="number"
                                min="1"
                                value={dish.quantity || 1}
                                onChange={(e) => {
                                  const newQuantity = parseInt(e.target.value) || 1;
                                  handleUpdateQuantity(dish.id, newQuantity);
                                }}
                                className="w-8 sm:w-12 h-6 sm:h-8 text-center text-xs sm:text-sm p-0 border-0 bg-transparent flex-shrink-0"
                              />
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  handleUpdateQuantity(dish.id, (dish.quantity || 1) + 1)
                                }
                                className="h-6 w-6 sm:h-8 sm:w-8 p-0 flex-shrink-0"
                              >
                                <Plus className="h-2.5 w-2.5 sm:h-3 sm:w-3" />
                              </Button>
                            </div>
                          </div>
                          <div className="flex flex-row sm:flex-col gap-1.5 sm:gap-2 flex-wrap">
                            <div className="flex items-center space-x-1">
                              <Checkbox
                                id={`available-${dish.id}`}
                                checked={dish.isAvailable}
                                onCheckedChange={() => handleToggleAvailability(dish.id)}
                                className="h-3 w-3 sm:h-4 sm:w-4"
                              />
                              <Label htmlFor={`available-${dish.id}`} className="text-xs">
                                <span className="hidden sm:inline">Disponible</span>
                                <span className="sm:hidden">Dispo</span>
                              </Label>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Checkbox
                                id={`raktak-${dish.id}`}
                                checked={dish.hasRakTakPromo || false}
                                onCheckedChange={() => handleToggleRakTak(dish.id)}
                                className="h-3 w-3 sm:h-4 sm:w-4"
                              />
                              <Label htmlFor={`raktak-${dish.id}`} className="text-xs">
                                Rak Tak
                              </Label>
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleRemoveDish(dish.id)}
                            className="text-xs px-1.5 sm:px-3 h-6 sm:h-8 flex-shrink-0"
                          >
                            <span className="hidden sm:inline">Retirer</span>
                            <span className="sm:hidden">×</span>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}
