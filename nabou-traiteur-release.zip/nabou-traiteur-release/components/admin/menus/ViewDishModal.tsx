"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UtensilsCrossed, Star, Clock, Tag } from "lucide-react";
import { MenuItem } from "@/types/menu";

interface ViewDishModalProps {
  dish: MenuItem | null;
  trigger?: React.ReactNode;
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "XOF",
    minimumFractionDigits: 0,
  }).format(amount);
};

export function ViewDishModal({ dish, trigger }: ViewDishModalProps) {
  const [open, setOpen] = useState(false);
  if (!dish) return null;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto w-[95vw] sm:w-full">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base sm:text-lg">
            <UtensilsCrossed className="h-4 w-4 sm:h-5 sm:w-5" />
            <span className="truncate">Détails du plat - {dish.name}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 sm:space-y-6">
          {/* Image et informations principales */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            <div className="space-y-3 sm:space-y-4">
              <img
                src={dish.image}
                alt={dish.name}
                className="w-full h-40 sm:h-48 object-cover rounded-lg border"
              />

              <div className="flex flex-wrap gap-1.5 sm:gap-2">
                <Badge variant={dish.isAvailable ? "default" : "secondary"} className="text-xs">
                  {dish.isAvailable ? "Disponible" : "Indisponible"}
                </Badge>
                {/* {dish.hasRakTakPromo && (
                  <Badge variant="destructive" className="text-xs">
                    Promotion Rak Tak
                  </Badge>
                )} */}
                <Badge variant="outline" className="text-xs">{dish.category.name}</Badge>
              </div>
            </div>

            <div className="space-y-3 sm:space-y-4">
              <div>
                <h3 className="text-base sm:text-lg font-semibold mb-2 line-clamp-2">{dish.name}</h3>
                <p className="text-muted-foreground text-sm line-clamp-3">{dish.description}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 sm:p-4">
                    <CardTitle className="text-xs sm:text-sm font-medium">Statut</CardTitle>
                    <Clock className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent className="p-3 sm:p-4 pt-0">
                    <div className="text-xs sm:text-sm">
                      {dish.isAvailable ? (
                        <span className="text-green-600 font-medium">Disponible</span>
                      ) : (
                        <span className="text-red-600 font-medium">Indisponible</span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          {/* Options et prix */}
          <Card>
            <CardHeader className="p-3 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-sm sm:text-base">
                <Tag className="h-3 w-3 sm:h-4 sm:w-4" />
                Options et prix
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 sm:p-6 pt-0">
              <div className="space-y-3 sm:space-y-4">
                {dish.options.map((option, index) => (
                  <div key={index} className="border rounded-lg p-3 sm:p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium text-sm sm:text-lg truncate pr-2">{option.name}</span>
                      {/* {option.isRequired && (
                        <Badge variant="outline" className="text-xs">Obligatoire</Badge>
                      )} */}
                    </div>
                    <div className="grid grid-cols-1 gap-2 sm:gap-3">
                      {option.values.map((value, valueIndex) => (
                        <div
                          key={valueIndex}
                          className="flex justify-between items-start sm:items-center p-2 sm:p-3 bg-muted/50 rounded gap-2"
                        >
                          <div className="flex-1 min-w-0">
                            <span className="font-medium text-sm block truncate">{value.name}</span>
                            {value.description && (
                              <p className="text-xs sm:text-sm text-muted-foreground line-clamp-2">{value.description}</p>
                            )}
                          </div>
                          <span className="text-primary font-bold text-sm sm:text-base flex-shrink-0">
                            {formatCurrency(value.price)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Informations techniques */}
          <Card>
            <CardHeader className="p-3 sm:p-6">
              <CardTitle className="text-sm sm:text-base">Informations techniques</CardTitle>
            </CardHeader>
            <CardContent className="p-3 sm:p-6 pt-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 text-xs sm:text-sm">
                <div className="flex flex-col sm:flex-row sm:items-center">
                  <span className="font-medium text-muted-foreground">ID:</span>
                  <span className="sm:ml-2 truncate">{dish.id}</span>
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center">
                  <span className="font-medium text-muted-foreground">Catégorie:</span>
                  <span className="sm:ml-2 truncate">{dish.category.name}</span>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center">
                  <span className="font-medium text-muted-foreground">Créé le:</span>
                  <span className="sm:ml-2">
                    {new Date(dish.createdAt).toLocaleDateString("fr-FR")}
                  </span>
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center">
                  <span className="font-medium text-muted-foreground">Modifié le:</span>
                  <span className="sm:ml-2">
                    {new Date(dish.updatedAt).toLocaleDateString("fr-FR")}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
