"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, X, Save, Upload } from "lucide-react";
import { CreateMenuItemData, MenuItem, UpdateMenuItemData } from "@/types/menu";
import { useCategories } from "@/hooks/useCategories";
import { useMenuItemsStore } from "@/stores/menuItemsStore";
import { toast } from "sonner";
import { CldUploadButton } from "next-cloudinary";

interface EditDishModalProps {
  dish: MenuItem;
  open: boolean;
  onClose: () => void;
}

export default function EditDishModal({ dish, open, onClose }: EditDishModalProps) {
  const { updateMenuItem } = useMenuItemsStore();
  const { categories, loading: categoriesLoading } = useCategories();
  const [loading, setLoading] = useState(false);

  const [name, setName] = useState(dish.name);
  const [description, setDescription] = useState(dish.description);
  const [category, setCategory] = useState(() => {
    if (typeof dish.category === "string") {
      return dish.category;
    }
    if (dish.category && typeof dish.category === "object" && "id" in dish.category) {
      return (dish.category as { id: string }).id;
    }
    return "";
  });
  const [image, setImage] = useState(dish.image);
  const [isAvailable, setIsAvailable] = useState(dish.isAvailable);
  const [hasRakTakPromo, setHasRakTakPromo] = useState(false);
  const [options, setOptions] = useState(() => {
    if (dish.options && dish.options.length > 0) {
      return dish.options.map((opt, index) =>
        opt.values.map((val, i) => ({
          id: `option-${i}`,
          name: val.name,
          price: val.price,
        }))
      )[0];
    }
    return [{ id: "default-option", name: "PM", price: 0 }];
  });

  // Gérer l'ouverture/fermeture du modal
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && open) {
        onClose();
      }
    };

    if (open) {
      document.addEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "unset";
    };
  }, [open]);

  // Gestionnaire pour l'upload Cloudinary
  const handleCloudinarySuccess = (result: any) => {
    console.log("Upload successful:", result);
    if (result?.info?.secure_url) {
      setImage(result.info.secure_url);
      toast.success("Image uploadée avec succès!");
    }
  };

  const handleCloudinaryError = (error: any) => {
    console.error("Upload error:", error);
    toast.error("Erreur lors de l'upload de l'image");
  };

  const handleCloudinaryOpen = () => {
    console.log("Cloudinary widget opened");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!name || !description || !category || !image) {
      alert("Veuillez remplir tous les champs obligatoires");
      return;
    }

    if (options.length === 0) {
      alert("Veuillez ajouter au moins une option");
      return;
    }

    setLoading(true);

    try {
      const updatedDish: CreateMenuItemData & { id: string } = {
        id: dish.id,
        name,
        description,
        categoryId: category,
        image: image || "/placeholder.svg",
        isAvailable,
        price: 0,
        options: [{
          name: "Taille",
          type: "size",
          values: options.map((opt, index) => (
            {
              name: opt.name,
              price: opt.price,
              isAvailable: true,
            }
          )),
          isRequired: false,
          sortOrder: 0,
        }],
      };

      await updateMenuItem(updatedDish);
      toast.success("Plat modifié avec succès!");
      onClose();
    } catch (error) {
      console.error("Erreur lors de la mise à jour du plat:", error);
    } finally {
      setLoading(false);
    }
  };

  const addOption = () => {
    setOptions([...options, { id: `option-${Date.now()}`, name: "", price: 0 }]);
  };

  const removeOption = (index: number) => {
    setOptions(options.filter((_, i) => i !== index));
  };

  const updateOption = (index: number, field: "name" | "price", value: string | number) => {
    const newOptions = [...options];
    newOptions[index] = { ...newOptions[index], [field]: value };
    setOptions(newOptions);
  };

  if (!dish) return null;

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Overlay */}
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative bg-white rounded-lg shadow-xl w-[95vw] max-w-[600px] max-h-[80vh] overflow-y-auto p-4 sm:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold">Modifier le plat</h2>
          <Button variant="ghost" size="sm" onClick={onClose} className="h-6 w-6 p-0">
            <X className="h-4 w-4" />
          </Button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nom du plat</Label>
              <Input
                id="name"
                placeholder="ex: Thiéboudienne"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label>Image du plat</Label>
              <div className="space-y-3">
                {/* Aperçu de l'image */}
                {image && (
                  <div className="relative w-full h-32 border rounded-lg overflow-hidden">
                    <img src={image} alt="Aperçu du plat" className="w-full h-full object-cover" />
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={() => setImage("")}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}

                {/* Bouton d'upload Cloudinary */}
                <div className="cloudinary-upload-wrapper">
                  <CldUploadButton
                    uploadPreset="nabou_traiteur"
                    options={{
                      folder: "nabou_traiteur",
                      resourceType: "image",
                      maxFiles: 1,
                      sources: ["local", "camera"],
                      multiple: false,
                      maxFileSize: 10000000,
                      clientAllowedFormats: ["jpg", "jpeg", "png", "webp"],
                      showPoweredBy: false,
                      theme: "minimal",
                    }}
                    onSuccess={handleCloudinarySuccess}
                    onError={handleCloudinaryError}
                    onOpen={handleCloudinaryOpen}
                  >
                    <div className="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg hover:border-gray-400 transition-colors cursor-pointer">
                      <div className="text-center">
                        <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                        <p className="text-sm text-gray-600">Cliquez pour uploader une image</p>
                        <p className="text-xs text-gray-400">PNG, JPG, WEBP jusqu'à 10MB</p>
                      </div>
                    </div>
                  </CldUploadButton>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Description du plat..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Catégorie</Label>
              <Select value={category} onValueChange={setCategory} required>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner une catégorie" />
                </SelectTrigger>
                <SelectContent>
                  {categoriesLoading ? (
                    <SelectItem value="loading" disabled>
                      Chargement...
                    </SelectItem>
                  ) : (
                    categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Options et prix</Label>
            {options.map((option, index) => (
              <div key={option.id || index} className="flex gap-2 items-center">
                <Input
                  placeholder="Nom (ex: PM, GM)"
                  value={option.name}
                  onChange={(e) => updateOption(index, "name", e.target.value)}
                  className="flex-1"
                />
                <Input
                  type="number"
                  placeholder="Prix"
                  value={option.price || ""}
                  onChange={(e) => updateOption(index, "price", parseInt(e.target.value) || 0)}
                  className="w-24"
                />
                {options.length > 1 && (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => removeOption(index)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
            <Button type="button" variant="outline" onClick={addOption} className="w-full">
              <Plus className="mr-2 h-4 w-4" />
              Ajouter une option
            </Button>
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="isAvailable"
                checked={isAvailable}
                onChange={(e) => setIsAvailable(e.target.checked)}
                className="rounded"
              />
              <Label htmlFor="isAvailable">Disponible</Label>
            </div>

            {/* <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="hasRakTakPromo"
                checked={hasRakTakPromo}
                onChange={(e) => setHasRakTakPromo(e.target.checked)}
                className="rounded"
              />
              <Label htmlFor="hasRakTakPromo">Promotion Rak Tak</Label>
            </div> */}
          </div>

          <div className="bg-muted/50 p-3 rounded-lg">
            <p className="text-sm text-muted-foreground">
              <strong>ID:</strong> {dish.id} |<strong> Créé le:</strong>{" "}
              {new Date(dish.createdAt).toLocaleDateString("fr-FR")}
            </p>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>
              Annuler
            </Button>
            <Button type="submit" disabled={loading}>
              <Save className="mr-2 h-4 w-4" />
              {loading ? "Mise à jour en cours..." : "Sauvegarder"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
