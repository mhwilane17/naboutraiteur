"use client";

import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, Clock, MapPin, AlertCircle, Package, Hash } from "lucide-react";
import { WeeklyMenu } from "@/types/weeklyMenu";
import { toast } from "react-toastify";

interface ViewWeeklyMenuModalProps {
  menuId: string | null;
  trigger?: React.ReactNode;
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "XOF",
    minimumFractionDigits: 0,
  }).format(amount);
};

const dayLabels: Record<number, string> = {
  1: "Lundi",
  2: "Mardi",
  3: "Mercredi",
  4: "Jeudi",
  5: "Vendredi",
  6: "Samedi",
  0: "Dimanche",
};

const weekDays = [1, 2, 3, 4, 5]; // Lundi à Vendredi

export function ViewWeeklyMenuModal({ menuId, trigger }: ViewWeeklyMenuModalProps) {
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState<WeeklyMenu | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchMenuDetails = async () => {
    if (!menuId) return;

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/menu/weekly/${menuId}`);
      const responseData = await response.json();

      if (!response.ok || !responseData.success) {
        // Extraction du message d'erreur spécifique
        let errorMessage = "Erreur lors du chargement du menu";

        if (responseData.error) {
          if (typeof responseData.error === "string") {
            errorMessage = responseData.error;
          } else if (responseData.error.message) {
            errorMessage = responseData.error.message;
          }
        } else if (responseData.message) {
          errorMessage = responseData.message;
        }

        throw new Error(errorMessage);
      }

      setMenu(responseData.data);
    } catch (err) {
      let errorMessage = "Erreur lors du chargement du menu";

      if (err instanceof Error) {
        errorMessage = err.message;
      } else if (typeof err === "object" && err !== null) {
        // Essayer d'extraire le message d'erreur si c'est un objet
        if ("message" in err && typeof (err as { message: unknown }).message === "string") {
          errorMessage = (err as { message: string }).message;
        } else if ("error" in err) {
          const errorObj = err as { error: unknown };
          if (typeof errorObj.error === "string") {
            errorMessage = errorObj.error;
          } else if (
            typeof errorObj.error === "object" &&
            errorObj.error !== null &&
            "message" in errorObj.error &&
            typeof (errorObj.error as { message: unknown }).message === "string"
          ) {
            errorMessage = (errorObj.error as { message: string }).message;
          }
        }
      }
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open && menuId) {
      fetchMenuDetails();
    }
  }, [open, menuId]);

  if (!menuId) return null;

  const dishesByDay =
    menu?.dishes.reduce((acc: Record<number, any[]>, dish: any) => {
      if (!acc[dish.dayOfWeek]) {
        acc[dish.dayOfWeek] = [];
      }
      acc[dish.dayOfWeek].push(dish);
      return acc;
    }, {} as Record<number, any[]>) || {};

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="w-[95vw] max-w-5xl sm:w-full max-h-[85vh] sm:max-h-[80vh] overflow-y-auto p-2">
        <DialogHeader className="px-3 sm:px-6">
          <DialogTitle className="flex items-center gap-2 text-sm sm:text-lg">
            <Calendar className="h-4 w-4 sm:h-5 sm:w-5" />
            {loading ? (
              <Skeleton className="h-4 sm:h-6 w-32 sm:w-48" />
            ) : error ? (
              "Erreur de chargement"
            ) : (
              <span className="line-clamp-1">
                <span className="hidden sm:inline">Détails du menu - </span>
                {menu?.name || ""}
              </span>
            )}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3 sm:space-y-6">
          {loading ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-4 w-4" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-4 w-32" />
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <Skeleton className="h-4 w-12" />
                    <Skeleton className="h-4 w-4" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-6 w-16" />
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-4 w-4" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-8 w-8" />
                  </CardContent>
                </Card>
              </div>
              <div className="space-y-4">
                <Skeleton className="h-6 w-32" />
                <Card>
                  <CardHeader>
                    <Skeleton className="h-5 w-16" />
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-3/4" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          ) : error ? (
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 text-destructive">
                  <AlertCircle className="h-5 w-5" />
                  <span>{error}</span>
                </div>
              </CardContent>
            </Card>
          ) : menu ? (
            <>
              {/* Informations générales */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1 sm:pb-2 p-3 sm:p-6">
                    <CardTitle className="text-xs sm:text-sm font-medium">Période</CardTitle>
                    <Calendar className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent className="p-3 sm:p-6 pt-0 sm:pt-0">
                    <div className="text-xs sm:text-sm">
                      <div className="sm:hidden">
                        {new Date(menu.startDate).toLocaleDateString("fr-FR", {
                          day: "2-digit",
                          month: "2-digit",
                        })}{" "}
                        -{" "}
                        {new Date(menu.endDate).toLocaleDateString("fr-FR", {
                          day: "2-digit",
                          month: "2-digit",
                        })}
                      </div>
                      <div className="hidden sm:block">
                        {new Date(menu.startDate).toLocaleDateString("fr-FR")} -{" "}
                        {new Date(menu.endDate).toLocaleDateString("fr-FR")}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1 sm:pb-2 p-3 sm:p-6">
                    <CardTitle className="text-xs sm:text-sm font-medium">Statut</CardTitle>
                    <Clock className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent className="p-3 sm:p-6 pt-0 sm:pt-0">
                    <Badge
                      variant={menu.isActive ? "default" : "secondary"}
                      className="text-xs px-2 py-1"
                    >
                      {menu.isActive ? "Actif" : "Inactif"}
                    </Badge>
                    {menu.isPublished && (
                      <Badge variant="outline" className="text-xs px-2 py-1 mt-1">
                        Publié
                      </Badge>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1 sm:pb-2 p-3 sm:p-6">
                    <CardTitle className="text-xs sm:text-sm font-medium">Total plats</CardTitle>
                    <MapPin className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent className="p-3 sm:p-6 pt-0 sm:pt-0">
                    <div className="text-lg sm:text-2xl font-bold">{menu.dishes.length}</div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1 sm:pb-2 p-3 sm:p-6">
                    <CardTitle className="text-xs sm:text-sm font-medium">Quantité totale</CardTitle>
                    <Package className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent className="p-3 sm:p-6 pt-0 sm:pt-0">
                    <div className="text-lg sm:text-2xl font-bold">
                      {menu.dishes.reduce((total, dish) => total + (dish.quantity || 10), 0)}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Plats par jour */}
              <div className="space-y-2 sm:space-y-4">
                <h3 className="text-sm sm:text-lg font-semibold">
                  Plats par jour (Lundi - Vendredi)
                </h3>

                {weekDays.map((dayNumber) => {
                  const dishes = dishesByDay[dayNumber] || [];
                  return (
                    <Card key={dayNumber}>
                      <CardHeader className="p-3 sm:p-6 pb-2 sm:pb-6">
                        <CardTitle className="text-sm sm:text-base flex items-center justify-between">
                          <span>{dayLabels[dayNumber]}</span>
                          <Badge variant="outline" className="text-xs px-1 py-0">
                            {dishes.length} plat{dishes.length > 1 ? "s" : ""}
                          </Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-3 sm:p-6 pt-0 sm:pt-0">
                        {dishes.length === 0 ? (
                          <div className="text-center py-4 sm:py-8 text-muted-foreground">
                            <p className="text-xs sm:text-sm">Aucun plat défini pour ce jour</p>
                          </div>
                        ) : (
                          <>
                            {/* Vue desktop */}
                            <div className="hidden sm:block">
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead>Plat</TableHead>
                                    <TableHead>Description</TableHead>
                                    <TableHead>Catégorie</TableHead>
                                    <TableHead>Prix</TableHead>
                                    <TableHead>Quantité</TableHead>
                                    <TableHead>Statut</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {dishes.map((dish) => (
                                    <TableRow key={dish.id}>
                                      <TableCell>
                                        <div className="flex items-center gap-3">
                                          <img
                                            src={dish.menuItem?.image || "/placeholder.jpg"}
                                            alt={dish.menuItem?.name || "Plat"}
                                            className="w-10 h-10 object-cover rounded-md"
                                          />
                                          <span className="font-medium">
                                            {dish.menuItem?.name || "Plat non défini"}
                                          </span>
                                        </div>
                                      </TableCell>
                                      <TableCell className="max-w-xs">
                                        <p className="text-sm text-muted-foreground truncate">
                                          {dish.menuItem?.description || "Aucune description"}
                                        </p>
                                      </TableCell>
                                      <TableCell>
                                        <Badge variant="outline">
                                          {dish.menuItem?.category?.name || "Non catégorisé"}
                                        </Badge>
                                      </TableCell>
                                      <TableCell>
                                        <div className="space-y-1">
                                          {dish.menuItem?.options?.length > 0 ? (
                                            dish.menuItem.options.map(
                                              (option: any, index: number) => (
                                                <div key={index} className="text-sm">
                                                  <span className="font-medium">
                                                    {option.name}:
                                                  </span>
                                                  <div className="ml-2 space-y-1">
                                                    {option.values?.map(
                                                      (value: any, valueIndex: number) => (
                                                        <div
                                                          key={valueIndex}
                                                          className="text-xs text-muted-foreground"
                                                        >
                                                          {value.name}:{" "}
                                                          {formatCurrency(value.price)}
                                                          {value.description && (
                                                            <span className="ml-1">
                                                              ({value.description})
                                                            </span>
                                                          )}
                                                        </div>
                                                      )
                                                    )}
                                                  </div>
                                                </div>
                                              )
                                            )
                                          ) : (
                                            <div className="text-sm text-muted-foreground">
                                              {dish.menuItem?.price
                                                ? formatCurrency(dish.menuItem.price)
                                                : "Prix non défini"}
                                            </div>
                                          )}
                                        </div>
                                      </TableCell>
                                      <TableCell>
                                        <div className="flex items-center gap-1">
                                          <Hash className="h-3 w-3 text-muted-foreground" />
                                          <span className="font-medium">{dish.quantity || 10}</span>
                                        </div>
                                      </TableCell>
                                      <TableCell>
                                        <div className="flex flex-col gap-1">
                                          <Badge
                                            variant={dish.isAvailable ? "default" : "secondary"}
                                          >
                                            {dish.isAvailable ? "Disponible" : "Indisponible"}
                                          </Badge>
                                          {dish.specialPrice && (
                                            <Badge variant="destructive" className="text-xs">
                                              Prix spécial: {formatCurrency(dish.specialPrice)}
                                            </Badge>
                                          )}
                                          {dish.hasRakTakPromo && (
                                            <Badge variant="outline" className="text-xs border-yellow-500 text-yellow-600">
                                              Promo Rak Tak
                                            </Badge>
                                          )}
                                        </div>
                                      </TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </div>

                            {/* Vue mobile */}
                            <div className="sm:hidden space-y-2">
                              {dishes.map((dish) => (
                                <Card key={dish.id} className="p-3">
                                  <div className="flex items-start gap-2">
                                    <img
                                      src={dish.menuItem?.image || "/placeholder.jpg"}
                                      alt={dish.menuItem?.name || "Plat"}
                                      className="w-12 h-12 object-cover rounded-md flex-shrink-0"
                                    />
                                    <div className="flex-1 min-w-0 space-y-1">
                                      <div className="flex items-start justify-between gap-2">
                                        <h4 className="font-medium text-sm line-clamp-1">
                                          {dish.menuItem?.name || "Plat non défini"}
                                        </h4>
                                        <div className="flex items-center gap-1 flex-shrink-0">
                                          <Badge
                                            variant={dish.isAvailable ? "default" : "secondary"}
                                            className="text-xs px-1 py-0"
                                          >
                                            {dish.isAvailable ? "Dispo" : "Indispo"}
                                          </Badge>
                                        </div>
                                      </div>

                                      <p className="text-xs text-muted-foreground line-clamp-2">
                                        {dish.menuItem?.description || "Aucune description"}
                                      </p>

                                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1 mt-1">
                                        <Badge variant="outline" className="text-xs px-1 py-0">
                                          {dish.menuItem?.category?.name || "Non catégorisé"}
                                        </Badge>
                                        
                                        <div className="flex items-center gap-1">
                                          <Package className="h-3 w-3 text-muted-foreground" />
                                          <span className="text-xs">{dish.quantity || 10}</span>
                                        </div>
                                        
                                        {dish.hasRakTakPromo && (
                                          <Badge variant="outline" className="text-xs px-1 py-0 border-yellow-500 text-yellow-600">
                                            Rak Tak
                                          </Badge>
                                        )}
                                      </div>

                                      <div className="flex items-center justify-between gap-2 mt-1">
                                        <div className="text-xs">
                                          {dish.menuItem?.options?.length > 0 ? (
                                            <div className="space-y-0.5">
                                              {dish.menuItem.options
                                                .slice(0, 1)
                                                .map((option: any, index: number) => (
                                                  <div key={index}>
                                                    <span className="font-medium">
                                                      {option.name}:
                                                    </span>
                                                    {option.values?.[0] && (
                                                      <span className="ml-1">
                                                        {formatCurrency(option.values[0].price)}
                                                      </span>
                                                    )}
                                                  </div>
                                                ))}
                                              {dish.menuItem.options.length > 1 && (
                                                <div className="text-muted-foreground text-xs">
                                                  +{dish.menuItem.options.length - 1} autres
                                                </div>
                                              )}
                                            </div>
                                          ) : (
                                            <div className="font-medium">
                                              {dish.menuItem?.price
                                                ? formatCurrency(dish.menuItem.price)
                                                : "Prix non défini"}
                                            </div>
                                          )}
                                        </div>
                                        
                                        <div className="text-right">
                                          {dish.specialPrice && (
                                            <Badge variant="destructive" className="text-xs">
                                              {formatCurrency(dish.specialPrice)}
                                            </Badge>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </Card>
                              ))}
                            </div>
                          </>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </>
          ) : null}
        </div>
      </DialogContent>
    </Dialog>
  );
}
