"use client";

import { useState } from "react";
// Dialog components removed - using custom Tailwind modal
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalendarIcon, Loader2, Plus, X } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { MenuItem } from "@/types/menu";
import { WeeklyMenu, WeeklyMenuDish } from "@/types/weeklyMenu";
import { DishSelector } from "./DishSelector";
import { useWeeklyMenuStore } from "@/stores/weeklyMenuStore";
import { toast } from "react-toastify";

interface CreateWeeklyMenuModalProps {
  availableDishes: MenuItem[];
}

export function CreateWeeklyMenuModal({ availableDishes }: CreateWeeklyMenuModalProps) {
  const [open, setOpen] = useState(false);
  const { createWeeklyMenu } = useWeeklyMenuStore();
  const [weekLabel, setWeekLabel] = useState("");
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [isActive, setIsActive] = useState(true);
  const [selectedDishes, setSelectedDishes] = useState<WeeklyMenuDish[]>([]);
  const [currentTab, setCurrentTab] = useState("info");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    if (!weekLabel || !startDate || !endDate) {
      toast.error("Veuillez remplir tous les champs obligatoires");
      return;
    }

    const createData = {
      name: weekLabel,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      dishes: selectedDishes,
      isActive,
    };

    try {
      setIsSubmitting(true);
      const result = await createWeeklyMenu(createData);

      // Reset form
      setWeekLabel("");
      setStartDate(undefined);
      setEndDate(undefined);
      setIsActive(true);
      setSelectedDishes([]);
      setCurrentTab("info");
      setOpen(false);
      toast.success("Menu hebdomadaire créé avec succès");
    } catch (error) {
      // Extraire le message d'erreur de la réponse API
      let errorMessage = "Erreur lors de la création du menu";

      if (error instanceof Error) {
        errorMessage = error.message;
      } else if (typeof error === "object" && error !== null) {
        // Essayer d'extraire le message d'erreur si c'est un objet
        if ("message" in error && typeof (error as { message: unknown }).message === "string") {
          errorMessage = (error as { message: string }).message;
        } else if ("error" in error) {
          const errorObj = error as { error: unknown };
          if (typeof errorObj.error === "string") {
            errorMessage = errorObj.error;
          } else if (
            typeof errorObj.error === "object" &&
            errorObj.error !== null &&
            "message" in errorObj.error &&
            typeof (errorObj.error as { message: unknown }).message === "string"
          ) {
            errorMessage = (errorObj.error as { message: string }).message;
          }
        }
      }

      toast.error(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  const canProceedToNextStep = () => {
    return weekLabel && startDate && endDate;
  };

  const canSubmit = () => {
    return canProceedToNextStep() && selectedDishes.length > 0;
  };

  return (
    <>
      {/* Trigger */}
      <div onClick={() => setOpen(true)}>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Ajouter un menu
        </Button>
      </div>

      {/* Modal Overlay */}
      {open && (
        <div
          className="fixed top-0 inset-0 mt-0 z-50 flex flex-col h-[100vh] w-full overflow-y-auto p-0 bg-white"
          style={{ marginTop: 0 }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-3 sm:px-6 py-3 shadow">
            <h2 className="text-lg sm:text-xl font-semibold text-gray-900">
              Créer un nouveau menu hebdomadaire
            </h2>
            <Button
              onClick={() => setOpen(false)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors bg-transparent"
            >
              <X className="text-black" />
            </Button>
          </div>

          {/* Content */}
          <DishSelector
            availableDishes={availableDishes}
            selectedDishes={selectedDishes}
            onDishesChange={setSelectedDishes}
          >
            <div className="overflow-x-auto">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (canProceedToNextStep()) {
                    setCurrentTab("dishes");
                  }
                }}
                className="space-y-0 sm:space-y-0 space-x-0 sm:space-x-6 flex flex-col sm:flex-row gap-3 sm:gap-0 w-full"
              >
                <div className="space-y-2 w-full sm:w-auto">
                  <Label htmlFor="weekLabel" className="text-sm font-medium text-gray-700">
                    Libellé de la semaine
                  </Label>
                  <Input
                    id="weekLabel"
                    placeholder="ex: 21-25 Janvier 2024"
                    value={weekLabel}
                    onChange={(e) => setWeekLabel(e.target.value)}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="space-y-2 w-full sm:w-auto">
                  <Label className="text-sm font-medium text-gray-700">Date de début</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                          !startDate && "text-gray-400"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4 flex-shrink-0" />
                        <span className="truncate text-xs sm:text-sm">
                          {startDate ? format(startDate, "PPP", { locale: fr }) : "Sélectionner"}
                        </span>
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={startDate}
                        onSelect={setStartDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2 w-full sm:w-auto">
                  <Label className="text-sm font-medium text-gray-700">Date de fin</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                          !endDate && "text-gray-400"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4 flex-shrink-0" />
                        <span className="truncate text-xs sm:text-sm">
                          {endDate ? format(endDate, "PPP", { locale: fr }) : "Sélectionner"}
                        </span>
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={endDate}
                        onSelect={setEndDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="flex items-center space-x-3 w-full sm:w-auto">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="isActive"
                      checked={isActive}
                      onChange={(e) => setIsActive(e.target.checked)}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <Label htmlFor="isActive" className="text-sm font-medium text-gray-700">
                      Menu actif
                    </Label>
                  </div>
                </div>
              </form>
            </div>
          </DishSelector>

          <div className="flex h-fit w-full justify-between pb-3 px-3 sm:px-6">
            <Button onClick={() => setOpen(false)} size="sm" className="sm:text-base sm:h-10">
              Annuler
            </Button>
            <Button
              onClick={() => handleSubmit()}
              disabled={!canSubmit() || isSubmitting}
              size="sm"
              className="sm:text-base sm:h-10"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  <span className="hidden sm:inline">Création en cours...</span>
                  <span className="sm:hidden">Création...</span>
                </>
              ) : (
                <>
                  <Plus className="mr-2 h-4 w-4" />
                  <span className="hidden sm:inline">
                    Créer le menu ({selectedDishes.length} plats)
                  </span>
                  <span className="sm:hidden">Créer ({selectedDishes.length})</span>
                </>
              )}
            </Button>
          </div>
        </div>
      )}
    </>
  );
}
