"use client";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { AlertTriangle, Loader2 } from "lucide-react";
import { useUsersStore } from "@/stores/usersStore";
import { useToast } from "@/components/ui/use-toast";

export function DeleteUserDialog() {
  const {
    loading,
    operationLoading,
    isDeleteDialogOpen,
    selectedUser,
    deleteUser,
    closeAllDialogs,
  } = useUsersStore();
  const { toast } = useToast();

  const handleDeleteUser = async () => {
    if (!selectedUser) return;

    const success = await deleteUser(selectedUser.id);
    if (success) {
      toast({
        title: "Succès",
        description: `L'utilisateur ${getUserFullName()} a été supprimé avec succès`,
        variant: "default",
      });
      closeAllDialogs();
    }
    // Error handling is already done in the store, which will display the error in the main page
  };

  const getUserFullName = () => {
    if (!selectedUser) return "";
    return `${selectedUser.firstName} ${selectedUser.lastName}`;
  };

  return (
    <Dialog open={isDeleteDialogOpen} onOpenChange={(open) => !open && closeAllDialogs()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <AlertTriangle className="h-5 w-5" />
            Supprimer l'utilisateur
          </DialogTitle>
          <DialogDescription>
            Cette action est irréversible. Êtes-vous sûr de vouloir supprimer cet utilisateur ?
          </DialogDescription>
        </DialogHeader>
        {selectedUser && (
          <div className="py-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <span className="font-medium text-red-800">Utilisateur à supprimer :</span>
              </div>
              <div className="text-sm text-red-700">
                <p><strong>Nom :</strong> {getUserFullName()}</p>
                <p><strong>Email :</strong> {selectedUser.email}</p>
                <p><strong>Rôles :</strong> {selectedUser.roles.map(role => role.description || role.name).join(", ")}</p>
              </div>
              <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded">
                <p className="text-sm text-yellow-800">
                  <strong>Attention :</strong> La suppression sera refusée si cet utilisateur a :
                </p>
                <ul className="text-sm text-yellow-800 mt-1 ml-4 list-disc">
                  <li>Des commandes associées</li>
                  <li>Des avis ou commentaires</li>
                </ul>
                <p className="text-sm text-yellow-800 mt-2">
                  Dans ce cas, vous pouvez suspendre le compte au lieu de le supprimer.
                </p>
              </div>
            </div>
          </div>
        )}
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => closeAllDialogs()} 
            disabled={loading || operationLoading.delete}
            className="transition-all duration-200"
          >
            Annuler
          </Button>
          <Button 
            variant="destructive" 
            onClick={handleDeleteUser} 
            disabled={loading || operationLoading.delete}
            className="transition-all duration-200"
          >
            {loading || operationLoading.delete ? (
              <>
                <LoadingSpinner size="sm" />
                <span className="ml-2">Suppression...</span>
              </>
            ) : (
              "Supprimer définitivement"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}