"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { ErrorDisplay } from "@/components/ui/error-display";
import { Plus, Loader2 } from "lucide-react";
import { useUsersStore } from "@/stores/usersStore";
import { useState, useEffect } from "react";
import { useToast } from "@/components/ui/use-toast";

export function AddUserDialog() {
  const {
    roles,
    loading,
    error,
    operationLoading,
    isAddDialogOpen,
    formData,
    createUser,
    openAddDialog,
    closeAllDialogs,
    setFormData,
    resetForm,
    setError,
    fetchRoles,
  } = useUsersStore();

  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  // Clear errors and ensure roles are loaded when dialog opens
  useEffect(() => {
    if (isAddDialogOpen) {
      setError(null);
      setValidationErrors({});
      // Ensure roles are loaded
      if (roles.length === 0) {
        fetchRoles();
      }
    }
  }, [isAddDialogOpen, setError, roles.length, fetchRoles]);

  // Validation function
  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!formData.firstName.trim()) {
      errors.firstName = "Le prénom est requis";
    }

    if (!formData.lastName.trim()) {
      errors.lastName = "Le nom est requis";
    }

    if (!formData.email.trim()) {
      errors.email = "L'email est requis";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = "Format d'email invalide";
    }

    if (formData.phone && formData.phone.trim() && !/^[\d\s\-\+\(\)]+$/.test(formData.phone)) {
      errors.phone = "Format de téléphone invalide";
    }

    if (formData.postalCode && formData.postalCode.trim() && !/^\d{5}$/.test(formData.postalCode)) {
      errors.postalCode = "Le code postal doit contenir 5 chiffres";
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleAddUser = async () => {
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const userData = {
        firstName: formData.firstName.trim(),
        lastName: formData.lastName.trim(),
        email: formData.email.trim(),
        phone: formData.phone?.trim() || undefined,
        address: formData.address?.trim() || undefined,
        city: formData.city?.trim() || undefined,
        postalCode: formData.postalCode?.trim() || undefined,
        roleIds: formData.roleIds.length > 0 ? formData.roleIds : undefined,
      };

      const success = await createUser(userData);
      if (success) {
        toast({
          title: "Succès",
          description: "L'utilisateur a été créé avec succès",
          variant: "default",
        });
        closeAllDialogs();
        resetForm();
      }
    } catch (err) {
      console.error("Erreur lors de la création:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDialogChange = (open: boolean) => {
    if (open) {
      openAddDialog();
    } else {
      closeAllDialogs();
      setValidationErrors({});
      setError(null);
    }
  };

  return (
    <Dialog open={isAddDialogOpen} onOpenChange={handleDialogChange}>
      <DialogTrigger asChild>
        <Button disabled={loading}>
          {loading ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Plus className="h-4 w-4 mr-2" />
          )}
          Ajouter un utilisateur
        </Button>
      </DialogTrigger>
      <DialogContent className="w-[95vw] sm:max-w-[600px] max-h-[85vh] overflow-y-auto">
        <DialogHeader className="sticky -top-6 bg-background py-2 border-b">
          <DialogTitle>Ajouter un nouvel utilisateur</DialogTitle>
          <DialogDescription>
            Remplissez les informations pour créer un nouveau compte utilisateur.
          </DialogDescription>
        </DialogHeader>

        {/* Error Alert */}
        {error && (
          <ErrorDisplay error={error} />
        )}

        <div className="grid gap-6 py-4">
          {/* Informations personnelles */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Informations personnelles</h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="firstName">
                  Prénom <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => {
                    setFormData({ firstName: e.target.value });
                    if (validationErrors.firstName) {
                      setValidationErrors(prev => ({ ...prev, firstName: '' }));
                    }
                  }}
                  className={`transition-all duration-200 ${validationErrors.firstName ? "border-red-500" : ""}`}
                  disabled={isSubmitting || operationLoading.create}
                  placeholder="Prénom"
                />
                {validationErrors.firstName && (
                  <p className="text-sm text-red-500">{validationErrors.firstName}</p>
                )}
              </div>

              <div className="grid gap-2">
                <Label htmlFor="lastName">
                  Nom <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => {
                    setFormData({ lastName: e.target.value });
                    if (validationErrors.lastName) {
                      setValidationErrors(prev => ({ ...prev, lastName: '' }));
                    }
                  }}
                  className={validationErrors.lastName ? "border-red-500" : ""}
                  disabled={isSubmitting}
                  placeholder="Nom"
                />
                {validationErrors.lastName && (
                  <p className="text-sm text-red-500">{validationErrors.lastName}</p>
                )}
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="email">
                Email <span className="text-red-500">*</span>
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => {
                  setFormData({ email: e.target.value });
                  if (validationErrors.email) {
                    setValidationErrors(prev => ({ ...prev, email: '' }));
                  }
                }}
                className={validationErrors.email ? "border-red-500" : ""}
                disabled={isSubmitting}
                placeholder="email@exemple.com"
              />
              {validationErrors.email && (
                <p className="text-sm text-red-500">{validationErrors.email}</p>
              )}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="phone">Téléphone</Label>
              <Input
                id="phone"
                value={formData.phone || ""}
                onChange={(e) => {
                  setFormData({ phone: e.target.value });
                  if (validationErrors.phone) {
                    setValidationErrors(prev => ({ ...prev, phone: '' }));
                  }
                }}
                className={validationErrors.phone ? "border-red-500" : ""}
                disabled={isSubmitting}
                placeholder="+33 1 23 45 67 89"
              />
              {validationErrors.phone && (
                <p className="text-sm text-red-500">{validationErrors.phone}</p>
              )}
            </div>
          </div>

          {/* Adresse */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Adresse</h3>
            
            <div className="grid gap-2">
              <Label htmlFor="address">Adresse</Label>
              <Input
                id="address"
                value={formData.address || ""}
                onChange={(e) => setFormData({ address: e.target.value })}
                disabled={isSubmitting}
                placeholder="123 rue de la Paix"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="city">Ville</Label>
                <Input
                  id="city"
                  value={formData.city || ""}
                  onChange={(e) => setFormData({ city: e.target.value })}
                  disabled={isSubmitting}
                  placeholder="Paris"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="postalCode">Code postal</Label>
                <Input
                  id="postalCode"
                  value={formData.postalCode || ""}
                  onChange={(e) => {
                    setFormData({ postalCode: e.target.value });
                    if (validationErrors.postalCode) {
                      setValidationErrors(prev => ({ ...prev, postalCode: '' }));
                    }
                  }}
                  className={validationErrors.postalCode ? "border-red-500" : ""}
                  disabled={isSubmitting}
                  placeholder="75001"
                />
                {validationErrors.postalCode && (
                  <p className="text-sm text-red-500">{validationErrors.postalCode}</p>
                )}
              </div>
            </div>
          </div>

          {/* Rôles */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Rôles</h3>
            
            {operationLoading.fetchRoles ? (
              <div className="py-4">
                <LoadingSpinner size="sm" text="Chargement des rôles..." />
              </div>
            ) : roles.length > 0 ? (
              <div className="space-y-3 max-h-40 overflow-y-auto border rounded-md p-3">
                {roles.filter(role => role.isActive).map((role) => (
                  <div key={role.id} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`role-${role.id}`}
                      checked={formData.roleIds.includes(role.id)}
                      onChange={(e) => {
                        const isChecked = e.target.checked;
                        const currentRoleIds = formData.roleIds;
                        if (isChecked) {
                          // Add role if not already present
                          if (!currentRoleIds.includes(role.id)) {
                            setFormData({ roleIds: [...currentRoleIds, role.id] });
                          }
                        } else {
                          // Remove role
                          setFormData({ roleIds: currentRoleIds.filter(id => id !== role.id) });
                        }
                      }}
                      disabled={isSubmitting || operationLoading.create}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 transition-all duration-200"
                    />
                    <Label htmlFor={`role-${role.id}`} className="flex-1 cursor-pointer text-sm">
                      <div className="font-medium">{role.name}</div>
                      {role.description && (
                        <div className="text-xs text-muted-foreground">{role.description}</div>
                      )}
                    </Label>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-sm text-muted-foreground border rounded-md p-3">
                Aucun rôle disponible
              </div>
            )}
            <p className="text-sm text-muted-foreground">
              Si aucun rôle n'est sélectionné, le rôle "client" sera assigné par défaut.
            </p>
          </div>
        </div>

        <DialogFooter className="sticky -bottom-6 bg-background border-t p-4 gap-2 flex-row">
          <Button
            variant="outline"
            onClick={() => handleDialogChange(false)}
            disabled={isSubmitting || operationLoading.create}
            className="w-full sm:w-auto transition-all duration-200"
          >
            Annuler
          </Button>
          <Button
            type="submit"
            onClick={handleAddUser}
            disabled={isSubmitting || loading || operationLoading.create}
            className="w-full sm:w-auto transition-all duration-200"
          >
            {isSubmitting || operationLoading.create ? (
              <>
                <LoadingSpinner size="sm" />
                <span className="ml-2">Création...</span>
              </>
            ) : (
              <>
                <Plus className="h-4 w-4 mr-2" />
                Créer l'utilisateur
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}