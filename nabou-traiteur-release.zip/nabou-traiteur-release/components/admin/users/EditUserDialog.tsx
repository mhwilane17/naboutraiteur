"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { ErrorDisplay } from "@/components/ui/error-display";
import { Loader2 } from "lucide-react";
import { useUsersStore } from "@/stores/usersStore";
import { useEffect } from "react";

export function EditUserDialog() {
  const {
    roles,
    loading,
    error,
    operationLoading,
    isEditDialogOpen,
    selectedUser,
    formData,
    updateUser,
    closeAllDialogs,
    setFormData,
    resetForm,
    setError,
    fetchRoles,
  } = useUsersStore();

  // Load roles when dialog opens
  useEffect(() => {
    if (isEditDialogOpen) {
      // Always ensure roles are loaded when dialog opens
      if (roles.length === 0) {
        fetchRoles();
      }
      // Clear any previous errors
      setError(null);
    }
  }, [isEditDialogOpen, roles.length, fetchRoles, setError]);

  // Pre-fill form when selectedUser changes
  useEffect(() => {
    if (selectedUser && isEditDialogOpen) {
      setFormData({
        firstName: selectedUser.firstName,
        lastName: selectedUser.lastName,
        email: selectedUser.email,
        phone: selectedUser.phone || '',
        address: selectedUser.address || '',
        city: selectedUser.city || '',
        postalCode: selectedUser.postalCode || '',
        isActive: selectedUser.isActive,
        roleIds: selectedUser.roles.map(role => role.id),
      });
    }
  }, [selectedUser, isEditDialogOpen, setFormData]);

  const handleEditUser = async () => {
    if (!selectedUser) return;

    // Clear any previous errors
    setError(null);

    // Basic validation
    if (!formData.firstName.trim() || !formData.lastName.trim() || !formData.email.trim()) {
      setError('Les champs prénom, nom et email sont obligatoires');
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('Veuillez saisir une adresse email valide');
      return;
    }

    // Ensure at least one role is selected
    if (formData.roleIds.length === 0) {
      setError('Au moins un rôle doit être sélectionné');
      return;
    }

    const updates = {
      firstName: formData.firstName.trim(),
      lastName: formData.lastName.trim(),
      email: formData.email.trim(),
      phone: formData.phone?.trim() || undefined,
      address: formData.address?.trim() || undefined,
      city: formData.city?.trim() || undefined,
      postalCode: formData.postalCode?.trim() || undefined,
      isActive: formData.isActive,
      roleIds: formData.roleIds,
    };

    const success = await updateUser(selectedUser.id, updates);
    if (success) {
      closeAllDialogs();
      resetForm();
    }
  };

  const handleRoleToggle = (roleId: string, checked: boolean) => {
    const currentRoleIds = formData.roleIds;
    if (checked) {
      // Add role if not already present
      if (!currentRoleIds.includes(roleId)) {
        setFormData({ roleIds: [...currentRoleIds, roleId] });
      }
    } else {
      // Remove role
      setFormData({ roleIds: currentRoleIds.filter(id => id !== roleId) });
    }
  };

  const handleClose = () => {
    setError(null);
    closeAllDialogs();
  };

  return (
    <Dialog open={isEditDialogOpen} onOpenChange={(open) => !open && handleClose()}>
      <DialogContent className="w-[95vw] sm:max-w-[700px] max-h-[85vh] overflow-y-auto">
        <DialogHeader className="sticky -top-6 bg-background py-2 border-b">
          <DialogTitle>Modifier l'utilisateur</DialogTitle>
          <DialogDescription>
            Modifiez les informations de l'utilisateur sélectionné.
          </DialogDescription>
        </DialogHeader>

        {error && (
          <ErrorDisplay error={error} />
        )}

        <div className="grid gap-6 py-4">
          {/* Informations personnelles */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Informations personnelles</h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-firstName">
                  Prénom <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="edit-firstName"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ firstName: e.target.value })}
                  placeholder="Prénom"
                  disabled={loading || operationLoading.update}
                  className="transition-all duration-200"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-lastName">
                  Nom <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="edit-lastName"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ lastName: e.target.value })}
                  placeholder="Nom"
                  disabled={loading || operationLoading.update}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-email">
                Email <span className="text-red-500">*</span>
              </Label>
              <Input
                id="edit-email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ email: e.target.value })}
                placeholder="email@exemple.com"
                disabled={loading || operationLoading.update}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-phone">Téléphone</Label>
              <Input
                id="edit-phone"
                value={formData.phone || ""}
                onChange={(e) => setFormData({ phone: e.target.value })}
                placeholder="+33 1 23 45 67 89"
                disabled={loading || operationLoading.update}
              />
            </div>
          </div>

          {/* Adresse */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Adresse</h3>
            
            <div className="space-y-2">
              <Label htmlFor="edit-address">Adresse</Label>
              <Input
                id="edit-address"
                value={formData.address || ""}
                onChange={(e) => setFormData({ address: e.target.value })}
                placeholder="123 rue de la Paix"
                disabled={loading || operationLoading.update}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-city">Ville</Label>
                <Input
                  id="edit-city"
                  value={formData.city || ""}
                  onChange={(e) => setFormData({ city: e.target.value })}
                  placeholder="Paris"
                  disabled={loading || operationLoading.update}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-postalCode">Code postal</Label>
                <Input
                  id="edit-postalCode"
                  value={formData.postalCode || ""}
                  onChange={(e) => setFormData({ postalCode: e.target.value })}
                  placeholder="75001"
                  disabled={loading || operationLoading.update}
                />
              </div>
            </div>
          </div>

          {/* Rôles */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">
              Rôles <span className="text-red-500">*</span>
            </h3>
            
            {operationLoading.fetchRoles ? (
              <div className="py-4">
                <LoadingSpinner size="sm" text="Chargement des rôles..." />
              </div>
            ) : roles.length > 0 ? (
              <div className="space-y-3">
                {roles.filter(role => role.isActive).map((role) => (
                  <div key={role.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`role-${role.id}`}
                      checked={formData.roleIds.includes(role.id)}
                      onCheckedChange={(checked) => handleRoleToggle(role.id, checked as boolean)}
                      disabled={loading || operationLoading.update}
                      className="transition-all duration-200"
                    />
                    <Label htmlFor={`role-${role.id}`} className="flex-1 cursor-pointer">
                      <div className="font-medium">{role.name}</div>
                      {role.description && (
                        <div className="text-sm text-muted-foreground">{role.description}</div>
                      )}
                    </Label>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-sm text-muted-foreground">
                Aucun rôle disponible
              </div>
            )}
          </div>

          {/* Statut */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Statut</h3>
            
            <Select
              value={formData.isActive ? "active" : "suspended"}
              onValueChange={(value) => setFormData({ isActive: value === "active" })}
              disabled={loading || operationLoading.update}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    Actif
                  </div>
                </SelectItem>
                <SelectItem value="suspended">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
                    Suspendu
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter className="sticky -bottom-6 bg-background border-t p-4 gap-2 flex-row">
          <Button 
            type="button" 
            variant="outline" 
            onClick={handleClose}
            disabled={loading || operationLoading.update}
            className="w-full sm:w-auto transition-all duration-200"
          >
            Annuler
          </Button>
          <Button 
            type="submit" 
            onClick={handleEditUser} 
            disabled={loading || operationLoading.update || !formData.firstName.trim() || !formData.lastName.trim() || !formData.email.trim() || formData.roleIds.length === 0}
            className="w-full sm:w-auto transition-all duration-200"
          >
            {loading || operationLoading.update ? (
              <>
                <LoadingSpinner size="sm" />
                <span className="ml-2">Modification...</span>
              </>
            ) : (
              "Sauvegarder"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}