"use client";

import React from "react";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { ChevronFirst, ChevronLast } from "lucide-react";
import { useUsersStore } from "@/stores/usersStore";

interface UsersPaginationProps {
  className?: string;
}

export function UsersPagination({ className }: UsersPaginationProps) {
  const {
    pagination,
    loading,
    operationLoading,
    goToPage,
    goToNextPage,
    goToPreviousPage,
    goToFirstPage,
    goToLastPage,
    setPageSize,
  } = useUsersStore();

  const { page, limit, total, totalPages } = pagination;
  const isLoading = loading || operationLoading.fetchUsers;

  // Don't render if there's no data or only one page
  if (total === 0 || totalPages <= 1) {
    return null;
  }

  // Calculate the range of items being displayed
  const startItem = (page - 1) * limit + 1;
  const endItem = Math.min(page * limit, total);

  // Generate page numbers to display
  const getPageNumbers = () => {
    const pages: (number | 'ellipsis')[] = [];
    const maxVisiblePages = 5;
    
    if (totalPages <= maxVisiblePages) {
      // Show all pages if total pages is small
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Always show first page
      pages.push(1);
      
      if (page > 3) {
        pages.push('ellipsis');
      }
      
      // Show pages around current page
      const start = Math.max(2, page - 1);
      const end = Math.min(totalPages - 1, page + 1);
      
      for (let i = start; i <= end; i++) {
        if (i !== 1 && i !== totalPages) {
          pages.push(i);
        }
      }
      
      if (page < totalPages - 2) {
        pages.push('ellipsis');
      }
      
      // Always show last page
      if (totalPages > 1) {
        pages.push(totalPages);
      }
    }
    
    return pages;
  };

  const pageNumbers = getPageNumbers();

  const handlePageSizeChange = (newSize: string) => {
    const size = parseInt(newSize, 10);
    if (size > 0) {
      setPageSize(size);
    }
  };

  return (
    <div className={`flex flex-col sm:flex-row items-center justify-between gap-4 ${className}`}>
      {/* Items info and page size selector */}
      <div className="flex items-center gap-4 text-sm text-muted-foreground">
        <span>
          Affichage de {startItem} à {endItem} sur {total} utilisateur{total > 1 ? 's' : ''}
        </span>
        <div className="flex items-center gap-2">
          <span>Éléments par page:</span>
          <Select value={limit.toString()} onValueChange={handlePageSizeChange} disabled={isLoading}>
            <SelectTrigger className="w-20 transition-all duration-200">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="5">5</SelectItem>
              <SelectItem value="10">10</SelectItem>
              <SelectItem value="20">20</SelectItem>
              <SelectItem value="50">50</SelectItem>
              <SelectItem value="100">100</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Pagination controls */}
      <div className="flex items-center gap-2">
        {/* First page button */}
        <Button
          variant="outline"
          size="sm"
          onClick={goToFirstPage}
          disabled={isLoading || page === 1}
          className="hidden sm:flex transition-all duration-200"
        >
          {isLoading && page === 1 ? (
            <LoadingSpinner size="sm" />
          ) : (
            <ChevronFirst className="h-4 w-4" />
          )}
        </Button>

        <Pagination>
          <PaginationContent>
            {/* Previous button */}
            <PaginationItem>
              <PaginationPrevious
                onClick={goToPreviousPage}
                className={`cursor-pointer transition-all duration-200 ${
                  isLoading || page === 1 
                    ? 'pointer-events-none opacity-50' 
                    : 'hover:bg-accent'
                }`}
              />
            </PaginationItem>

            {/* Page numbers */}
            {pageNumbers.map((pageNum, index) => (
              <PaginationItem key={index}>
                {pageNum === 'ellipsis' ? (
                  <PaginationEllipsis />
                ) : (
                  <PaginationLink
                    onClick={() => goToPage(pageNum)}
                    isActive={pageNum === page}
                    className={`cursor-pointer transition-all duration-200 ${
                      isLoading 
                        ? 'pointer-events-none opacity-50' 
                        : 'hover:bg-accent'
                    }`}
                  >
                    {pageNum}
                  </PaginationLink>
                )}
              </PaginationItem>
            ))}

            {/* Next button */}
            <PaginationItem>
              <PaginationNext
                onClick={goToNextPage}
                className={`cursor-pointer transition-all duration-200 ${
                  isLoading || page === totalPages 
                    ? 'pointer-events-none opacity-50' 
                    : 'hover:bg-accent'
                }`}
              />
            </PaginationItem>
          </PaginationContent>
        </Pagination>

        {/* Last page button */}
        <Button
          variant="outline"
          size="sm"
          onClick={goToLastPage}
          disabled={isLoading || page === totalPages}
          className="hidden sm:flex transition-all duration-200"
        >
          {isLoading && page === totalPages ? (
            <LoadingSpinner size="sm" />
          ) : (
            <ChevronLast className="h-4 w-4" />
          )}
        </Button>
      </div>
    </div>
  );
}