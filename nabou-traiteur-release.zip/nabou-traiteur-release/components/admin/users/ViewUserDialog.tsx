"use client";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Edit, UserX, UserCheck, Mail, Phone, MapPin, Calendar, Clock, Shield, AlertTriangle, Loader2 } from "lucide-react";
import { useUsersStore } from "@/stores/usersStore";
import { User } from "@/types/users";
import { useState } from "react";
import { useToast } from "@/components/ui/use-toast";

export function ViewUserDialog() {
  const {
    isViewDialogOpen,
    selectedUser,
    operationLoading,
    openEditDialog,
    closeAllDialogs,
    suspendUser,
    reactivateUser,
    loading,
  } = useUsersStore();

  const { toast } = useToast();
  const [actionLoading, setActionLoading] = useState(false);
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);

  const getUserFullName = (user: User) => {
    return `${user.firstName} ${user.lastName}`;
  };

  const getStatusColor = (isActive: boolean) => {
    return isActive
      ? "bg-green-100 text-green-800 border-green-200"
      : "bg-red-100 text-red-800 border-red-200";
  };

  const getRoleColor = (roleName: string) => {
    switch (roleName.toLowerCase()) {
      case "admin":
        return "bg-purple-100 text-purple-800 border-purple-200";
      case "manager":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "employee":
        return "bg-orange-100 text-orange-800 border-orange-200";
      case "client":
        return "bg-gray-100 text-gray-800 border-gray-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };



  const handleSuspendUser = () => {
    setStatusDialogOpen(true);
  };

  const confirmStatusToggle = async () => {
    if (!selectedUser) return;

    setActionLoading(true);
    try {
      const success = selectedUser.isActive 
        ? await suspendUser(selectedUser.id)
        : await reactivateUser(selectedUser.id);

      if (success) {
        toast({
          title: "Succès",
          description: selectedUser.isActive 
            ? `L'utilisateur ${selectedUser.firstName} ${selectedUser.lastName} a été suspendu avec succès`
            : `L'utilisateur ${selectedUser.firstName} ${selectedUser.lastName} a été réactivé avec succès`,
          variant: "default",
        });
        setStatusDialogOpen(false);
        closeAllDialogs();
      }
    } catch (error) {
      console.error('Erreur lors de la modification du statut:', error);
    } finally {
      setActionLoading(false);
    }
  };

  const cancelStatusToggle = () => {
    setStatusDialogOpen(false);
  };

  const handleEditUser = () => {
    if (selectedUser) {
      closeAllDialogs();
      openEditDialog(selectedUser);
    }
  };

  if (!selectedUser) {
    return null;
  }

  return (
    <Dialog open={isViewDialogOpen} onOpenChange={(open) => !open && closeAllDialogs()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Détails de l'utilisateur
          </DialogTitle>
          <DialogDescription>
            Informations complètes de l'utilisateur sélectionné.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Informations personnelles */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-semibold">Informations personnelles</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-500 flex items-center gap-1">
                  <span>Nom complet</span>
                </Label>
                <p className="text-sm font-medium bg-gray-50 p-2 rounded border">
                  {getUserFullName(selectedUser)}
                </p>
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-500 flex items-center gap-1">
                  <Mail className="h-3 w-3" />
                  Email
                </Label>
                <p className="text-sm bg-gray-50 p-2 rounded border">
                  {selectedUser.email}
                </p>
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-500 flex items-center gap-1">
                  <Phone className="h-3 w-3" />
                  Téléphone
                </Label>
                <p className="text-sm bg-gray-50 p-2 rounded border">
                  {selectedUser.phone || "Non renseigné"}
                </p>
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-500">Statut</Label>
                <div>
                  <Badge className={getStatusColor(selectedUser.isActive)}>
                    {selectedUser.isActive ? "Actif" : "Suspendu"}
                  </Badge>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Adresse */}
          {(selectedUser.address || selectedUser.city || selectedUser.postalCode) && (
            <>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <h3 className="text-lg font-semibold">Adresse</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-500">Adresse</Label>
                    <p className="text-sm bg-gray-50 p-2 rounded border">
                      {selectedUser.address || "Non renseigné"}
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-500">Ville</Label>
                    <p className="text-sm bg-gray-50 p-2 rounded border">
                      {selectedUser.city || "Non renseigné"}
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-500">Code postal</Label>
                    <p className="text-sm bg-gray-50 p-2 rounded border">
                      {selectedUser.postalCode || "Non renseigné"}
                    </p>
                  </div>
                </div>
              </div>
              <Separator />
            </>
          )}

          {/* Rôles et permissions */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              <h3 className="text-lg font-semibold">Rôles et permissions</h3>
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-500">
                Rôles assignés ({selectedUser.roles.length})
              </Label>
              <div className="flex flex-wrap gap-2">
                {selectedUser.roles.length > 0 ? (
                  selectedUser.roles.map((role) => (
                    <Badge 
                      key={role.id} 
                      className={getRoleColor(role.name)}
                      variant="outline"
                    >
                      <Shield className="h-3 w-3 mr-1" />
                      {role.description || role.name}
                    </Badge>
                  ))
                ) : (
                  <Badge variant="outline" className="bg-gray-50 text-gray-500">
                    Aucun rôle assigné
                  </Badge>
                )}
              </div>
            </div>
          </div>

          <Separator />

          {/* Métadonnées */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <h3 className="text-lg font-semibold">Informations système</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-500 flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  Date de création
                </Label>
                <p className="text-sm bg-gray-50 p-2 rounded border">
                  {formatDate(selectedUser.createdAt)}
                </p>
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-500 flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Dernière modification
                </Label>
                <p className="text-sm bg-gray-50 p-2 rounded border">
                  {formatDate(selectedUser.updatedAt)}
                </p>
              </div>
              
              <div className="space-y-2 md:col-span-2">
                <Label className="text-sm font-medium text-gray-500 flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Dernière connexion
                </Label>
                <p className="text-sm bg-gray-50 p-2 rounded border">
                  {selectedUser.lastLogin 
                    ? formatDate(selectedUser.lastLogin)
                    : "Jamais connecté"
                  }
                </p>
              </div>
            </div>
          </div>

          <Separator />

          {/* Actions rapides */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-semibold">Actions rapides</h3>
            </div>
            
            <div className="flex flex-wrap gap-3">
              <Button
                size="sm"
                variant="outline"
                onClick={handleEditUser}
                disabled={loading || actionLoading || Object.values(operationLoading).some(Boolean)}
                className="flex items-center gap-2 transition-all duration-200"
              >
                <Edit className="h-4 w-4" />
                Modifier les informations
              </Button>
              
              <Button
                size="sm"
                variant="outline"
                disabled={loading || actionLoading || operationLoading.suspend || operationLoading.reactivate}
                className={`flex items-center gap-2 transition-all duration-200 ${
                  selectedUser.isActive 
                    ? "text-orange-600 border-orange-200 hover:bg-orange-50"
                    : "text-green-600 border-green-200 hover:bg-green-50"
                }`}
                onClick={handleSuspendUser}
              >
                {selectedUser.isActive ? (
                  <>
                    <UserX className="h-4 w-4" />
                    Suspendre le compte
                  </>
                ) : (
                  <>
                    <UserCheck className="h-4 w-4" />
                    Réactiver le compte
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>

        <DialogFooter className="flex justify-between">
          <div className="text-xs text-gray-500">
            ID: {selectedUser.id}
          </div>
          <Button variant="outline" onClick={closeAllDialogs}>
            Fermer
          </Button>
        </DialogFooter>
      </DialogContent>

      {/* Status Toggle Confirmation Dialog */}
      <Dialog open={statusDialogOpen} onOpenChange={(open) => !open && cancelStatusToggle()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              {selectedUser?.isActive ? "Suspendre l'utilisateur" : "Réactiver l'utilisateur"}
            </DialogTitle>
            <DialogDescription>
              {selectedUser?.isActive 
                ? "Êtes-vous sûr de vouloir suspendre cet utilisateur ? Il ne pourra plus se connecter à son compte."
                : "Êtes-vous sûr de vouloir réactiver cet utilisateur ? Il pourra à nouveau se connecter à son compte."
              }
            </DialogDescription>
          </DialogHeader>
          {selectedUser && (
            <div className="py-4">
              <div className={`border rounded-lg p-4 ${
                selectedUser.isActive 
                  ? "bg-orange-50 border-orange-200" 
                  : "bg-green-50 border-green-200"
              }`}>
                <div className="flex items-center gap-2 mb-2">
                  {selectedUser.isActive ? (
                    <UserX className="h-4 w-4 text-orange-600" />
                  ) : (
                    <UserCheck className="h-4 w-4 text-green-600" />
                  )}
                  <span className={`font-medium ${
                    selectedUser.isActive ? "text-orange-800" : "text-green-800"
                  }`}>
                    Utilisateur à {selectedUser.isActive ? "suspendre" : "réactiver"} :
                  </span>
                </div>
                <div className={`text-sm ${
                  selectedUser.isActive ? "text-orange-700" : "text-green-700"
                }`}>
                  <p><strong>Nom :</strong> {selectedUser.firstName} {selectedUser.lastName}</p>
                  <p><strong>Email :</strong> {selectedUser.email}</p>
                  <p><strong>Statut actuel :</strong> {selectedUser.isActive ? "Actif" : "Suspendu"}</p>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={cancelStatusToggle} 
              disabled={actionLoading || operationLoading.suspend || operationLoading.reactivate}
              className="transition-all duration-200"
            >
              Annuler
            </Button>
            <Button 
              variant={selectedUser?.isActive ? "destructive" : "default"}
              onClick={confirmStatusToggle} 
              disabled={actionLoading || operationLoading.suspend || operationLoading.reactivate}
              className="transition-all duration-200"
            >
              {actionLoading || operationLoading.suspend || operationLoading.reactivate ? (
                <>
                  <LoadingSpinner size="sm" />
                  <span className="ml-2">
                    {selectedUser?.isActive ? "Suspension..." : "Réactivation..."}
                  </span>
                </>
              ) : (
                selectedUser?.isActive ? "Suspendre" : "Réactiver"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Dialog>
  );
}