"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { useCompaniesStore } from "@/stores/companiesStore";
import { CompanyAddEmployee } from "./CompanyAddEmployee";
import { CompanyImportEmployees } from "./CompanyImportEmployees";
import { useUsersStore } from "@/stores/usersStore";
import { useToast } from "@/components/ui/use-toast";
import { CompanyService } from "@/services/companyService";
import { Loader2, UserCheck, UserX } from "lucide-react";

export function CompanyView() {
  const { isViewDialogOpen, selectedCompany, closeDialogs, openViewDialog, fetchCompanies, pagination } = useCompaniesStore();
  const { suspendUser, reactivateUser, operationLoading } = useUsersStore();
  const { toast } = useToast();

  const [togglingId, setTogglingId] = useState<string | null>(null);

  const employees = selectedCompany?.users || [];

  const refreshCompany = async () => {
    if (!selectedCompany) return;
    const resp = await CompanyService.getCompany(selectedCompany.id);
    if (CompanyService.isErrorResponse(resp)) {
      await fetchCompanies(pagination.page, pagination.limit);
    } else {
      openViewDialog(resp.data);
    }
  };

  const handleToggleUser = async (user: { id: string; firstName: string; lastName: string; isActive: boolean }) => {
    try {
      setTogglingId(user.id);
      const ok = user.isActive ? await suspendUser(user.id) : await reactivateUser(user.id);
      if (ok) {
        toast({
          title: user.isActive ? "Employé suspendu" : "Employé réactivé",
          description: `${user.firstName} ${user.lastName} a été ${user.isActive ? "suspendu" : "réactivé"}.`,
        });
        await refreshCompany();
      }
    } catch (e) {
      toast({ title: "Erreur", description: "Impossible de mettre à jour le statut de l'employé", variant: "destructive" });
    } finally {
      setTogglingId(null);
    }
  };

  return (
    <Dialog open={isViewDialogOpen} onOpenChange={(o) => { if (!o) closeDialogs(); }}>
      <DialogContent className="w-[95vw] sm:max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Détails de l'entreprise</DialogTitle>
        </DialogHeader>

        {selectedCompany && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="text-sm text-muted-foreground">Nom</div>
                <div className="font-medium">{selectedCompany.name}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Email de contact</div>
                <div className="font-medium">{selectedCompany.contactEmail || "—"}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Statut</div>
                <Badge className={selectedCompany.isActive ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                  {selectedCompany.isActive ? "Active" : "Suspendue"}
                </Badge>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Employés</h3>
              <div className="flex gap-2">
                <CompanyImportEmployees />
                <CompanyAddEmployee />
              </div>
            </div>

            <div className="space-y-2">
              <div className="border rounded-lg">
                {employees.length === 0 ? (
                  <div className="text-sm text-muted-foreground text-center py-6">Aucun employé</div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nom</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Statut</TableHead>
                        <TableHead className="w-[180px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {employees.map((e) => (
                        <TableRow key={e.id}>
                          <TableCell className="font-medium">{e.firstName} {e.lastName}</TableCell>
                          <TableCell>{e.email}</TableCell>
                          <TableCell>
                            <Badge className={e.isActive ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                              {e.isActive ? "Actif" : "Suspendu"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button
                                size="sm"
                                variant={e.isActive ? "destructive" : "secondary"}
                                onClick={() => handleToggleUser(e)}
                                disabled={togglingId === e.id || operationLoading.suspend || operationLoading.reactivate}
                              >
                                {(togglingId === e.id && (operationLoading.suspend || operationLoading.reactivate)) ? (
                                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Traitement…</>
                                ) : e.isActive ? (
                                  <><UserX className="mr-2 h-4 w-4" />Suspendre</>
                                ) : (
                                  <><UserCheck className="mr-2 h-4 w-4" />Réactiver</>
                                )}
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}