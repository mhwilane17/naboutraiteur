"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ErrorDisplay } from "@/components/ui/error-display";
import { Plus, Loader2 } from "lucide-react";
import { useCompaniesStore } from "@/stores/companiesStore";
import { useToast } from "@/components/ui/use-toast";

export function CompanyAdd() {
  const { isAddDialogOpen, openAddDialog, closeDialogs, loading, operationLoading, error, createCompany } = useCompaniesStore();
  const { toast } = useToast();

  const [name, setName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [isActive, setIsActive] = useState(true);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (isAddDialogOpen) {
      setValidationErrors({});
    }
  }, [isAddDialogOpen]);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = "Le nom est requis";
    if (contactEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactEmail)) errs.contactEmail = "Email invalide";
    setValidationErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setSubmitting(true);
    try {
      const ok = await createCompany({ name: name.trim(), contactEmail: contactEmail.trim() || undefined, isActive });
      if (ok) {
        toast({ title: "Entreprise créée", description: "L'entreprise a été ajoutée avec succès." });
        closeDialogs();
        setName("");
        setContactEmail("");
        setIsActive(true);
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleDialogChange = (open: boolean) => {
    if (open) openAddDialog();
    else closeDialogs();
  };

  return (
    <Dialog open={isAddDialogOpen} onOpenChange={handleDialogChange}>
      <DialogTrigger asChild>
        <Button disabled={loading}>
          {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Plus className="h-4 w-4 mr-2" />}
          Ajouter une entreprise
        </Button>
      </DialogTrigger>
      <DialogContent className="w-[95vw] sm:max-w-[560px] max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Ajouter une entreprise</DialogTitle>
          <DialogDescription>Renseignez les informations de base de l'entreprise.</DialogDescription>
        </DialogHeader>

        {error && <ErrorDisplay error={error} />}

        <div className="grid gap-4 py-2">
          <div className="grid gap-2">
            <Label htmlFor="name">Nom <span className="text-red-500">*</span></Label>
            <Input id="name" value={name} onChange={(e) => { setName(e.target.value); if (validationErrors.name) setValidationErrors(p=>({ ...p, name: "" })); }} placeholder="Ex: ACME Corp" />
            {validationErrors.name && <p className="text-sm text-red-500">{validationErrors.name}</p>}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="email">Email de contact</Label>
            <Input id="email" type="email" value={contactEmail} onChange={(e) => { setContactEmail(e.target.value); if (validationErrors.contactEmail) setValidationErrors(p=>({ ...p, contactEmail: "" })); }} placeholder="contact@entreprise.com" />
            {validationErrors.contactEmail && <p className="text-sm text-red-500">{validationErrors.contactEmail}</p>}
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox id="active" checked={isActive} onCheckedChange={(v) => setIsActive(!!v)} />
            <Label htmlFor="active">Entreprise active</Label>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => closeDialogs()} disabled={submitting || operationLoading.create}>Annuler</Button>
          <Button onClick={handleSubmit} disabled={submitting || operationLoading.create}>
            {(submitting || operationLoading.create) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Créer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}