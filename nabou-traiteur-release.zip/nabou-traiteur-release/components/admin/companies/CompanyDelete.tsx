"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useCompaniesStore } from "@/stores/companiesStore";
import { useToast } from "@/components/ui/use-toast";
import { Loader2 } from "lucide-react";

export function CompanyDelete() {
  const { isDeleteDialogOpen, selectedCompany, closeDialogs, deleteCompany, loading, operationLoading } = useCompaniesStore();
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);

  const onConfirm = async () => {
    if (!selectedCompany) return;
    setSubmitting(true);
    try {
      const ok = await deleteCompany(selectedCompany.id);
      if (ok) {
        toast({ title: "Entreprise supprimée", description: "L'entreprise a été supprimée avec succès." });
        closeDialogs();
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={isDeleteDialogOpen} onOpenChange={(o) => { if (!o) closeDialogs(); }}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Supprimer l'entreprise</DialogTitle>
          <DialogDescription>
            Cette action est irréversible. Les employés rattachés à cette entreprise seront impactés.
          </DialogDescription>
        </DialogHeader>
        <div className="py-2 text-sm">
          Confirmez-vous la suppression de « {selectedCompany?.name} » ?
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => closeDialogs()} disabled={submitting || operationLoading.delete}>Annuler</Button>
          <Button variant="destructive" onClick={onConfirm} disabled={submitting || operationLoading.delete}>
            {(submitting || operationLoading.delete) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Supprimer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}