"use client";

import { useState, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { useCompaniesStore } from "@/stores/companiesStore";
import { useUsersStore } from "@/stores/usersStore";
import { CompanyService } from "@/services/companyService";

export function CompanyAddEmployee() {
  const { selectedCompany, openViewDialog, fetchCompanies, pagination } = useCompaniesStore();
  const { createUser, operationLoading } = useUsersStore();
  const { toast } = useToast();

  const [open, setOpen] = useState(false);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const disabled = useMemo(() => !selectedCompany, [selectedCompany]);

  const resetForm = () => {
    setFirstName("");
    setLastName("");
    setEmail("");
    setPhone("");
  };

  const handleOpen = (value: boolean) => {
    if (!value) {
      resetForm();
    }
    setOpen(value);
  };

  const validate = () => {
    if (!firstName.trim() || !lastName.trim() || !email.trim()) {
      toast({ title: "Champs requis", description: "Prénom, nom et email sont obligatoires", variant: "destructive" });
      return false;
    }
    const emailRegex = /[^@\s]+@[^@\s]+\.[^@\s]+/;
    if (!emailRegex.test(email)) {
      toast({ title: "Email invalide", description: "Veuillez saisir un email valide", variant: "destructive" });
      return false;
    }
    return true;
  };

  const onSubmit = async () => {
    if (!selectedCompany) return;
    if (!validate()) return;

    setSubmitting(true);
    try {
      const success = await createUser({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        email: email.trim(),
        phone: phone.trim() || undefined,
        companyId: selectedCompany.id,
      });

      if (success) {
        toast({ title: "Employé ajouté", description: `${firstName} ${lastName} a été créé pour ${selectedCompany.name}` });
        handleOpen(false);
        // Rafraîchir la fiche entreprise (selectedCompany) pour afficher l'employé
        const resp = await CompanyService.getCompany(selectedCompany.id);
        if (CompanyService.isErrorResponse(resp)) {
          // En fallback, rafraîchir la liste des entreprises pour mettre à jour les stats
          await fetchCompanies(pagination.page, pagination.limit);
        } else {
          openViewDialog(resp.data);
        }
      } else {
        toast({ title: "Échec de la création", description: "Impossible de créer l'employé", variant: "destructive" });
      }
    } catch (e) {
      toast({ title: "Erreur", description: "Une erreur est survenue lors de la création", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <Button size="sm" onClick={() => handleOpen(true)} disabled={disabled}>
        Ajouter un employé
      </Button>

      <Dialog open={open} onOpenChange={handleOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Ajouter un employé {selectedCompany ? `— ${selectedCompany.name}` : ""}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">Prénom</Label>
                <Input id="firstName" value={firstName} onChange={(e) => setFirstName(e.target.value)} placeholder="Prénom" />
              </div>
              <div>
                <Label htmlFor="lastName">Nom</Label>
                <Input id="lastName" value={lastName} onChange={(e) => setLastName(e.target.value)} placeholder="Nom" />
              </div>
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ex: utilisateur@entreprise.com" />
            </div>
            <div>
              <Label htmlFor="phone">Téléphone (optionnel)</Label>
              <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="ex: 0601020304" />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => handleOpen(false)} disabled={submitting}>
              Annuler
            </Button>
            <Button onClick={onSubmit} disabled={submitting || operationLoading.create}>
              {submitting || operationLoading.create ? "Création..." : "Créer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}