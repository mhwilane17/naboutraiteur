"use client";

import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { ErrorDisplay } from "@/components/ui/error-display";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useCompaniesStore } from "@/stores/companiesStore";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCategoriesStore } from "@/stores/categoriesStore";
import type { Category } from "@/types/categories";

export function CompanyEdit() {
  const { isEditDialogOpen, selectedCompany, closeDialogs, updateCompany, updateLimits, loading, operationLoading, error } = useCompaniesStore();
  const { categories, fetchCategories, loading: categoriesLoading } = useCategoriesStore();
  const { toast } = useToast();

  const [name, setName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [isActive, setIsActive] = useState(true);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  type LimitRow = { categoryId: string; maxPerOrder: number | "" };
  const [limits, setLimits] = useState<LimitRow[]>([]);
  const [limitsError, setLimitsError] = useState<string>("");

  useEffect(() => {
    if (isEditDialogOpen) {
      if (!categories || categories.length === 0) {
        fetchCategories();
      }
    }
  }, [isEditDialogOpen, fetchCategories, categories]);

  useEffect(() => {
    if (isEditDialogOpen && selectedCompany) {
      setName(selectedCompany.name);
      setContactEmail(selectedCompany.contactEmail || "");
      setIsActive(selectedCompany.isActive);
      setValidationErrors({});
      // Précharger limites
      setLimits(
        (selectedCompany.limits || []).map((l) => ({ categoryId: l.categoryId, maxPerOrder: l.maxPerOrder }))
      );
      setLimitsError("");
    }
  }, [isEditDialogOpen, selectedCompany]);

  const availableCategoriesForRow = useMemo(() => {
    return (rowIndex: number) => {
      const used = new Set(limits.map((l, i) => (i === rowIndex ? null : l.categoryId)).filter(Boolean) as string[]);
      const list: Category[] = (categories || []) as Category[];
      return list.filter((c: Category) => !used.has(c.id) || limits[rowIndex]?.categoryId === c.id);
    };
  }, [categories, limits]);

  const validateGeneral = () => {
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = "Le nom est requis";
    if (contactEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactEmail)) errs.contactEmail = "Email invalide";
    setValidationErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const validateLimits = () => {
    if (!limits.length) {
      setLimitsError("");
      return true;
    }
    // Max > 0 et catégories uniques
    for (const l of limits) {
      if (!l.categoryId) { setLimitsError("Chaque ligne doit avoir une catégorie."); return false; }
      if (l.maxPerOrder === "" || Number.isNaN(Number(l.maxPerOrder)) || Number(l.maxPerOrder) <= 0) {
        setLimitsError("La quantité maximale doit être un nombre positif.");
        return false;
      }
    }
    const ids = limits.map((l) => l.categoryId);
    if (new Set(ids).size !== ids.length) {
      setLimitsError("Chaque catégorie ne peut apparaître qu'une seule fois.");
      return false;
    }
    setLimitsError("");
    return true;
  };

  const onSaveGeneral = async () => {
    if (!selectedCompany) return;
    if (!validateGeneral()) return;
    try {
      const ok = await updateCompany(selectedCompany.id, { name: name.trim(), contactEmail: contactEmail.trim() || undefined, isActive });
      if (ok) {
        toast({ title: "Entreprise mise à jour", description: "Les informations de l'entreprise ont été enregistrées." });
        closeDialogs();
      }
    } finally {
      // noop
    }
  };

  const onSaveLimits = async () => {
    if (!selectedCompany) return;
    if (!validateLimits()) return;
    const payload = limits.map((l) => ({ categoryId: l.categoryId, maxPerOrder: Number(l.maxPerOrder) }));
    const ok = await updateLimits(selectedCompany.id, payload);
    if (ok) {
      toast({ title: "Limites mises à jour", description: "Les limites par catégorie ont été enregistrées." });
      // On garde le dialogue ouvert pour continuer l'édition si besoin
    }
  };

  // Nouveau gestionnaire unique pour tout enregistrer
  const onSaveAll = async () => {
    if (!selectedCompany) return;

    const isGeneralOk = validateGeneral();
    const isLimitsOk = validateLimits();
    if (!isGeneralOk || !isLimitsOk) return;

    const companyPayload = { name: name.trim(), contactEmail: contactEmail.trim() || undefined, isActive };
    const limitsPayload = limits.map((l) => ({ categoryId: l.categoryId, maxPerOrder: Number(l.maxPerOrder) }));

    let okInfo = true;
    let okLimits = true;

    okInfo = await updateCompany(selectedCompany.id, companyPayload);
    okLimits = await updateLimits(selectedCompany.id, limitsPayload);

    if (okInfo && okLimits) {
      toast({ title: "Entreprise mise à jour", description: "Les informations et limites ont été enregistrées." });
      closeDialogs();
    }
  };

  const canAddMore = useMemo(() => {
    const totalCategories = (categories || []).length;
    const used = new Set(limits.map((l) => l.categoryId).filter(Boolean));
    return totalCategories > used.size;
  }, [categories, limits]);

  const addLimitRow = () => {
    const opts = availableCategoriesForRow(-1);
    const nextCategory = (opts as Category[]).find((c: Category) => !limits.some((l) => l.categoryId === c.id));
    setLimits((prev) => [...prev, { categoryId: nextCategory?.id || "", maxPerOrder: 1 }]);
  };

  const removeLimitRow = (idx: number) => {
    setLimits((prev) => prev.filter((_, i) => i !== idx));
  };

  // Etat combiné pour le bouton unique
  const savingAll = (operationLoading.update || operationLoading.updateLimits || categoriesLoading);

  return (
    <Dialog open={isEditDialogOpen} onOpenChange={(o) => { if (!o) closeDialogs(); }}>
      <DialogContent className="w-[95vw] sm:max-w-[720px] max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Modifier l'entreprise</DialogTitle>
          <DialogDescription>Mettre à jour les informations générales et les limites par catégorie.</DialogDescription>
        </DialogHeader>

        {error && <ErrorDisplay error={error} />}

        <div className="grid gap-6 py-2">
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Nom <span className="text-red-500">*</span></Label>
              <Input id="name" value={name} onChange={(e) => { setName(e.target.value); if (validationErrors.name) setValidationErrors(p=>({ ...p, name: "" })); }} />
              {validationErrors.name && <p className="text-sm text-red-500">{validationErrors.name}</p>}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="email">Email de contact</Label>
              <Input id="email" type="email" value={contactEmail} onChange={(e) => { setContactEmail(e.target.value); if (validationErrors.contactEmail) setValidationErrors(p=>({ ...p, contactEmail: "" })); }} />
              {validationErrors.contactEmail && <p className="text-sm text-red-500">{validationErrors.contactEmail}</p>}
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox id="active" checked={isActive} onCheckedChange={(v) => setIsActive(!!v)} />
              <Label htmlFor="active">Entreprise active</Label>
            </div>
          </div>

          <div className="border-t pt-4">
            <div className="flex items-center justify-between mb-2">
              <div>
                <h4 className="font-semibold">Limites par catégorie</h4>
                <p className="text-sm text-muted-foreground">Définissez une quantité maximale par commande pour chaque catégorie.</p>
              </div>
              <Button variant="outline" size="sm" onClick={addLimitRow} disabled={!canAddMore || categoriesLoading}>
                {categoriesLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                <Plus className="mr-2 h-4 w-4" />Ajouter une limite
              </Button>
            </div>

            {limits.length === 0 ? (
              <p className="text-sm text-muted-foreground">Aucune limite définie.</p>
            ) : (
              <div className="space-y-3">
                {limits.map((row, idx) => (
                  <div key={idx} className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                    <div className="sm:col-span-6">
                      <Label className="text-xs">Catégorie</Label>
                      <Select
                        value={row.categoryId}
                        onValueChange={(val) => setLimits((prev) => prev.map((r, i) => i === idx ? { ...r, categoryId: val } : r))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder={categoriesLoading ? "Chargement..." : "Sélectionner"} />
                        </SelectTrigger>
                        <SelectContent>
                          {availableCategoriesForRow(idx).map((c: Category) => (
                            <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="sm:col-span-4">
                      <Label className="text-xs">Quantité max par commande</Label>
                      <Input
                        type="number"
                        min={1}
                        value={row.maxPerOrder}
                        onChange={(e) => {
                          const v = e.target.value;
                          setLimits((prev) => prev.map((r, i) => i === idx ? { ...r, maxPerOrder: v === "" ? "" : Number(v) } : r));
                        }}
                      />
                    </div>
                    <div className="sm:col-span-2 flex items-end">
                      <Button type="button" variant="ghost" className="text-red-600 hover:text-red-700" onClick={() => removeLimitRow(idx)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            {limitsError && <p className="text-sm text-red-500 mt-2">{limitsError}</p>}
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => closeDialogs()} disabled={savingAll}>Annuler</Button>
          <Button onClick={onSaveAll} disabled={savingAll}>
            {savingAll && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Enregistrer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}