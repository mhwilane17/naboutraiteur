"use client";

import { useState, useMemo, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { useCompaniesStore } from "@/stores/companiesStore";
import { CompanyService } from "@/services/companyService";
import { UserService } from "@/services/userService";
import { Upload, Loader2, AlertCircle, CheckCircle, Download } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export function CompanyImportEmployees() {
  const { selectedCompany, openViewDialog, fetchCompanies, pagination } = useCompaniesStore();
  const { toast } = useToast();

  const [open, setOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ success: number; failed: number; errors: string[] } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const disabled = useMemo(() => !selectedCompany, [selectedCompany]);

  const resetForm = () => {
    setFile(null);
    setResult(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleOpen = (value: boolean) => {
    if (value) {
      resetForm();
    }
    setOpen(value);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setResult(null);
    }
  };

  const onSubmit = async () => {
    if (!selectedCompany || !file) return;

    setSubmitting(true);
    setResult(null);
    
    const formData = new FormData();
    formData.append("file", file);
    formData.append("companyId", selectedCompany.id);

    try {
      const resp = await UserService.importUsers(formData);
      
      if (UserService.isErrorResponse(resp)) {
        toast({ 
          title: "Erreur d'import", 
          description: resp.error.message || "Impossible d'importer le fichier", 
          variant: "destructive" 
        });
      } else {
        const data = resp.data;
        setResult(data);
        
        toast({ 
          title: "Import terminé", 
          description: `${data.success} utilisateurs ajoutés.`,
          variant: "default"
        });

        // Rafraîchir la vue
        const refreshResp = await CompanyService.getCompany(selectedCompany.id);
        if (!CompanyService.isErrorResponse(refreshResp)) {
          openViewDialog(refreshResp.data);
        } else {
           await fetchCompanies(pagination.page, pagination.limit);
        }
      }
    } catch (e) {
      toast({ title: "Erreur", description: "Une erreur est survenue lors de l'import", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <Button size="sm" variant="outline" onClick={() => handleOpen(true)} disabled={disabled}>
        <Upload className="mr-2 h-4 w-4" />
        Importer Excel
      </Button>

      <Dialog open={open} onOpenChange={handleOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Importer des employés {selectedCompany ? `— ${selectedCompany.name}` : ""}</DialogTitle>
            <DialogDescription>
              Sélectionnez un fichier Excel (.xlsx) contenant les colonnes : PRENOMS, NOMS, EMAIL, TELEPHONE.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="grid w-full max-w-sm items-center gap-1.5">
              <div className="flex justify-between items-center">
                <Label htmlFor="excel-file">Fichier Excel</Label>
                <Button variant="link" size="sm" className="h-auto p-0 text-xs" asChild>
                  <a href="/LISTE%20PERSONNEL%20SAMPLE.xlsx" download>
                    <Download className="mr-1 h-3 w-3" />
                    Télécharger le modèle
                  </a>
                </Button>
              </div>
              <Input 
                id="excel-file" 
                type="file" 
                accept=".xlsx, .xls"
                onChange={handleFileChange}
                ref={fileInputRef}
                disabled={submitting}
              />
            </div>

            {result && (
              <div className="space-y-3 mt-4">
                <div className="flex items-center gap-4">
                    <div className="flex items-center text-green-600 gap-2">
                        <CheckCircle className="h-5 w-5" />
                        <span className="font-medium">{result.success} succès</span>
                    </div>
                    {result.failed > 0 && (
                        <div className="flex items-center text-red-600 gap-2">
                            <AlertCircle className="h-5 w-5" />
                            <span className="font-medium">{result.failed} échecs</span>
                        </div>
                    )}
                </div>
                
                {result.errors.length > 0 && (
                  <Alert variant="destructive" className="max-h-60 overflow-y-auto">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Erreurs détaillées</AlertTitle>
                    <AlertDescription>
                      <ul className="list-disc pl-4 text-xs space-y-1 mt-2">
                        {result.errors.map((err, i) => (
                          <li key={i}>{err}</li>
                        ))}
                      </ul>
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            )}
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => handleOpen(false)} disabled={submitting}>
              Fermer
            </Button>
            <Button onClick={onSubmit} disabled={!file || submitting}>
              {submitting ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Importation...</>
              ) : (
                "Importer"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
