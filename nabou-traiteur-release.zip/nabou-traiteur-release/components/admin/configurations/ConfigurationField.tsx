"use client";

import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Eye, EyeOff, AlertCircle } from 'lucide-react';
import { AppConfiguration } from '@/services/configurationService';

interface ConfigurationFieldProps {
  config: AppConfiguration;
  value: string;
  onChange: (value: string) => void;
  error?: string;
}

export function ConfigurationField({ config, value, onChange, error }: ConfigurationFieldProps) {
  const [showSecret, setShowSecret] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // Détecter si on est sur mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const renderField = () => {
    switch (config.type) {
      case 'boolean':
        return (
          <div className={`flex items-center space-x-3 ${isMobile ? 'py-2' : ''}`}>
            <Switch
              id={config.key}
              checked={value === 'true' || value === '1'}
              onCheckedChange={(checked) => onChange(checked ? 'true' : 'false')}
              className={isMobile ? 'scale-110' : ''}
            />
            <Label 
              htmlFor={config.key} 
              className={`font-medium cursor-pointer ${isMobile ? 'text-base' : 'text-sm'}`}
            >
              {config.label}
            </Label>
          </div>
        );

      case 'number':
        return (
          <div className={`space-y-2 ${isMobile ? 'space-y-3' : ''}`}>
            <Label htmlFor={config.key} className={`font-medium ${isMobile ? 'text-base' : 'text-sm'}`}>
              {config.label}
              {config.isRequired && <span className="text-red-500 ml-1">*</span>}
            </Label>
            <Input
              id={config.key}
              type="number"
              inputMode="numeric"
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder={config.description}
              min={config.validation?.min}
              max={config.validation?.max}
              className={`${error ? 'border-red-500 focus-visible:ring-red-500' : ''} ${
                isMobile ? 'h-12 text-base' : ''
              }`}
            />
          </div>
        );

      case 'time':
        return (
          <div className={`space-y-2 ${isMobile ? 'space-y-3' : ''}`}>
            <Label htmlFor={config.key} className={`font-medium ${isMobile ? 'text-base' : 'text-sm'}`}>
              {config.label}
              {config.isRequired && <span className="text-red-500 ml-1">*</span>}
            </Label>
            <Input
              id={config.key}
              type="time"
              value={value}
              onChange={(e) => onChange(e.target.value)}
              className={`${error ? 'border-red-500 focus-visible:ring-red-500' : ''} ${
                isMobile ? 'h-12 text-base' : ''
              }`}
            />
          </div>
        );

      case 'json':
        return (
          <div className={`space-y-2 ${isMobile ? 'space-y-3' : ''}`}>
            <Label htmlFor={config.key} className={`font-medium ${isMobile ? 'text-base' : 'text-sm'}`}>
              {config.label}
              {config.isRequired && <span className="text-red-500 ml-1">*</span>}
            </Label>
            <Textarea
              id={config.key}
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder={config.description || 'Entrez un JSON valide...'}
              rows={isMobile ? 6 : 4}
              className={`${error ? 'border-red-500 focus-visible:ring-red-500' : ''} ${
                isMobile ? 'text-base min-h-[120px]' : ''
              }`}
            />
          </div>
        );

      case 'string':
      default:
        if (config.isSecret) {
          return (
            <div className={`space-y-2 ${isMobile ? 'space-y-3' : ''}`}>
              <Label htmlFor={config.key} className={`font-medium ${isMobile ? 'text-base' : 'text-sm'}`}>
                {config.label}
                {config.isRequired && <span className="text-red-500 ml-1">*</span>}
              </Label>
              <div className="relative">
                <Input
                  id={config.key}
                  type={showSecret ? 'text' : 'password'}
                  value={value}
                  onChange={(e) => onChange(e.target.value)}
                  placeholder={config.description}
                  minLength={config.validation?.min}
                  maxLength={config.validation?.max}
                  className={`${isMobile ? 'pr-14 h-12 text-base' : 'pr-10'} ${
                    error ? 'border-red-500 focus-visible:ring-red-500' : ''
                  }`}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size={isMobile ? "default" : "sm"}
                  className={`absolute right-0 top-0 h-full hover:bg-transparent ${
                    isMobile ? 'px-4 py-3' : 'px-3 py-2'
                  }`}
                  onClick={() => setShowSecret(!showSecret)}
                >
                  {showSecret ? (
                    <EyeOff className={`text-gray-400 ${isMobile ? 'h-5 w-5' : 'h-4 w-4'}`} />
                  ) : (
                    <Eye className={`text-gray-400 ${isMobile ? 'h-5 w-5' : 'h-4 w-4'}`} />
                  )}
                </Button>
              </div>
            </div>
          );
        }

        // Champ texte long si description longue ou validation max > 100
        if (config.description && config.description.length > 100 || 
            (config.validation?.max && config.validation.max > 100)) {
          return (
            <div className={`space-y-2 ${isMobile ? 'space-y-3' : ''}`}>
              <Label htmlFor={config.key} className={`font-medium ${isMobile ? 'text-base' : 'text-sm'}`}>
                {config.label}
                {config.isRequired && <span className="text-red-500 ml-1">*</span>}
              </Label>
              <Textarea
                id={config.key}
                value={value}
                onChange={(e) => onChange(e.target.value)}
                placeholder={config.description}
                minLength={config.validation?.min}
                maxLength={config.validation?.max}
                rows={isMobile ? 4 : 3}
                className={`${error ? 'border-red-500 focus-visible:ring-red-500' : ''} ${
                  isMobile ? 'text-base min-h-[100px]' : ''
                }`}
              />
            </div>
          );
        }

        // Champ texte standard
        return (
          <div className={`space-y-2 ${isMobile ? 'space-y-3' : ''}`}>
            <Label htmlFor={config.key} className={`font-medium ${isMobile ? 'text-base' : 'text-sm'}`}>
              {config.label}
              {config.isRequired && <span className="text-red-500 ml-1">*</span>}
            </Label>
            <Input
              id={config.key}
              type="text"
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder={config.description}
              minLength={config.validation?.min}
              maxLength={config.validation?.max}
              className={`${error ? 'border-red-500 focus-visible:ring-red-500' : ''} ${
                isMobile ? 'h-12 text-base' : ''
              }`}
            />
          </div>
        );
    }
  };

  return (
    <div className={`space-y-1 ${isMobile ? 'space-y-2' : ''}`}>
      {renderField()}
      
      {/* Description pour les champs non-boolean */}
      {config.type !== 'boolean' && config.description && (
        <p className={`text-gray-500 mt-1 ${isMobile ? 'text-sm' : 'text-xs'}`}>
          {config.description}
        </p>
      )}
      
      {/* Message d'erreur - optimisé pour mobile */}
      {error && (
        <div className={`mt-2 p-2 bg-red-50 border border-red-200 rounded-md ${isMobile ? 'p-3' : ''}`}>
          <p className={`text-red-600 flex items-start space-x-2 ${isMobile ? 'text-sm' : 'text-xs'}`}>
            <AlertCircle className={`flex-shrink-0 mt-0.5 ${isMobile ? 'h-4 w-4' : 'h-3 w-3'}`} />
            <span>{error}</span>
          </p>
        </div>
      )}
      
      {/* Informations de validation */}
      {config.validation && (config.validation.min || config.validation.max) && !error && (
        <p className={`text-gray-400 mt-1 ${isMobile ? 'text-sm' : 'text-xs'}`}>
          {config.type === 'string' && (
            <>
              {config.validation.min && config.validation.max 
                ? `${config.validation.min}-${config.validation.max} caractères`
                : config.validation.min 
                  ? `Min. ${config.validation.min} caractères`
                  : `Max. ${config.validation.max} caractères`
              }
            </>
          )}
          {config.type === 'number' && (
            <>
              {config.validation.min && config.validation.max 
                ? `Entre ${config.validation.min} et ${config.validation.max}`
                : config.validation.min 
                  ? `Min. ${config.validation.min}`
                  : `Max. ${config.validation.max}`
              }
            </>
          )}
        </p>
      )}
    </div>
  );
}