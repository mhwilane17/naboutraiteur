"use client";

import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, Settings, ShoppingCart, Bell, Shield, Palette } from 'lucide-react';
import { AppConfiguration } from '@/services/configurationService';
import { ConfigurationField } from './ConfigurationField';
import { TimeRangeField } from './TimeRangeField';

interface ConfigurationSectionProps {
  section: string;
  configurations: AppConfiguration[];
  values: Record<string, string>;
  onChange: (key: string, value: string) => void;
  errors: Record<string, string>;
}

// Métadonnées des sections
const sectionMetadata = {
  general: {
    title: 'Général',
    description: 'Paramètres généraux de l\'application',
    icon: Settings,
    color: 'bg-blue-50 border-blue-200',
    badgeColor: 'bg-blue-100 text-blue-800'
  },
  orders: {
    title: 'Commandes',
    description: 'Configuration des commandes et heures d\'ouverture',
    icon: ShoppingCart,
    color: 'bg-green-50 border-green-200',
    badgeColor: 'bg-green-100 text-green-800'
  },
  notifications: {
    title: 'Notifications',
    description: 'Paramètres des notifications WhatsApp et email',
    icon: Bell,
    color: 'bg-yellow-50 border-yellow-200',
    badgeColor: 'bg-yellow-100 text-yellow-800'
  },
  security: {
    title: 'Sécurité',
    description: 'Paramètres de sécurité et authentification',
    icon: Shield,
    color: 'bg-red-50 border-red-200',
    badgeColor: 'bg-red-100 text-red-800'
  },
  appearance: {
    title: 'Apparence',
    description: 'Personnalisation de l\'interface utilisateur',
    icon: Palette,
    color: 'bg-purple-50 border-purple-200',
    badgeColor: 'bg-purple-100 text-purple-800'
  }
} as const;

export function ConfigurationSection({ 
  section, 
  configurations, 
  values, 
  onChange, 
  errors 
}: ConfigurationSectionProps) {
  const [isMobile, setIsMobile] = useState(false);

  // Détecter si on est sur mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);
  
  const metadata = sectionMetadata[section as keyof typeof sectionMetadata] || {
    title: section.charAt(0).toUpperCase() + section.slice(1),
    description: `Configuration de la section ${section}`,
    icon: Settings,
    color: 'bg-gray-50 border-gray-200',
    badgeColor: 'bg-gray-100 text-gray-800'
  };

  const IconComponent = metadata.icon;
  
  // Compter les erreurs dans cette section
  const sectionErrors = configurations.filter(config => errors[config.key]).length;
  
  // Vérifier si cette section contient les heures d'ouverture
  const hasOrderingHours = section === 'orders' && 
    configurations.some(config => config.key === 'orders.opening_time') &&
    configurations.some(config => config.key === 'orders.closing_time');

  // Séparer les configurations des heures d'ouverture des autres
  const orderingTimeConfigs = configurations.filter(config => 
    config.key === 'orders.opening_time' || config.key === 'orders.closing_time'
  );
  const otherConfigs = configurations.filter(config => 
    config.key !== 'orders.opening_time' && config.key !== 'orders.closing_time'
  );

  const handleTimeRangeChange = (startTime: string, endTime: string) => {
    onChange('orders.opening_time', startTime);
    onChange('orders.closing_time', endTime);
  };

  return (
    <Card className={`${metadata.color} border-2`}>
      <CardHeader className={`pb-4 ${isMobile ? 'pb-5' : ''}`}>
        <div className={`flex justify-between ${isMobile ? 'flex-col space-y-3' : 'items-center'}`}>
          <div className="flex items-center gap-3">
            <div className={`rounded-lg bg-white shadow-sm ${isMobile ? 'p-3' : 'p-2'}`}>
              <IconComponent className={`text-gray-600 ${isMobile ? 'h-6 w-6' : 'h-5 w-5'}`} />
            </div>
            <div>
              <CardTitle className={`font-semibold text-gray-900 ${isMobile ? 'text-xl' : 'text-lg'}`}>
                {metadata.title}
              </CardTitle>
              <CardDescription className={`text-gray-600 mt-1 ${isMobile ? 'text-base' : 'text-sm'}`}>
                {metadata.description}
              </CardDescription>
            </div>
          </div>
          
          <div className={`flex items-center gap-2 ${isMobile ? 'justify-start' : ''}`}>
            {/* Badge du nombre de configurations */}
            <Badge variant="secondary" className={`${metadata.badgeColor} ${isMobile ? 'text-sm px-3 py-1' : ''}`}>
              {configurations.length} config{configurations.length > 1 ? 's' : ''}
            </Badge>
            
            {/* Badge d'erreur si applicable */}
            {sectionErrors > 0 && (
              <Badge variant="destructive" className={`bg-red-100 text-red-800 ${isMobile ? 'text-sm px-3 py-1' : ''}`}>
                <AlertCircle className={`mr-1 ${isMobile ? 'h-4 w-4' : 'h-3 w-3'}`} />
                {sectionErrors} erreur{sectionErrors > 1 ? 's' : ''}
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className={`space-y-6 ${isMobile ? 'space-y-8' : ''}`}>
        {/* Composant spécialisé pour les heures d'ouverture */}
        {hasOrderingHours && (
          <div className={`bg-white rounded-lg border ${isMobile ? 'p-5' : 'p-4'}`}>
            <TimeRangeField
              startTime={values['orders.opening_time'] || ''}
              endTime={values['orders.closing_time'] || ''}
              onChange={handleTimeRangeChange}
              error={errors['orders.opening_time'] || errors['orders.closing_time']}
            />
          </div>
        )}

        {/* Autres configurations */}
        {otherConfigs.length > 0 && (
          <div className={`space-y-4 ${isMobile ? 'space-y-6' : ''}`}>
            {otherConfigs.map((config) => (
              <div key={config.key} className={`bg-white rounded-lg border ${isMobile ? 'p-5' : 'p-4'}`}>
                <ConfigurationField
                  config={config}
                  value={values[config.key] || ''}
                  onChange={(value) => onChange(config.key, value)}
                  error={errors[config.key]}
                />
              </div>
            ))}
          </div>
        )}

        {/* Message si aucune configuration */}
        {configurations.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <Settings className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">Aucune configuration disponible pour cette section</p>
          </div>
        )}

        {/* Informations supplémentaires par section */}
        {section === 'orders' && (
          <div className={`bg-blue-50 border border-blue-200 rounded-lg mt-4 ${isMobile ? 'p-4' : 'p-3'}`}>
            <p className={`text-blue-700 ${isMobile ? 'text-sm' : 'text-xs'}`}>
              <strong>Note :</strong> Les heures d'ouverture définies ici seront utilisées pour 
              valider automatiquement les nouvelles commandes. Les clients ne pourront pas 
              passer de commandes en dehors de ces heures.
            </p>
          </div>
        )}

        {section === 'notifications' && (
          <div className={`bg-yellow-50 border border-yellow-200 rounded-lg mt-4 ${isMobile ? 'p-4' : 'p-3'}`}>
            <p className={`text-yellow-700 ${isMobile ? 'text-sm' : 'text-xs'}`}>
              <strong>Sécurité :</strong> Les tokens et clés d'API sont masqués par défaut. 
              Cliquez sur l'icône œil pour les afficher temporairement.
            </p>
          </div>
        )}

        {section === 'security' && (
          <div className={`bg-red-50 border border-red-200 rounded-lg mt-4 ${isMobile ? 'p-4' : 'p-3'}`}>
            <p className={`text-red-700 ${isMobile ? 'text-sm' : 'text-xs'}`}>
              <strong>Attention :</strong> Modifiez ces paramètres avec précaution. 
              Des valeurs incorrectes peuvent affecter la sécurité de l'application.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}