"use client";

import React, { useEffect, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Clock, AlertCircle } from 'lucide-react';

interface TimeRangeFieldProps {
  startTime: string;
  endTime: string;
  onChange: (start: string, end: string) => void;
  error?: string;
  startLabel?: string;
  endLabel?: string;
  description?: string;
}

export function TimeRangeField({ 
  startTime, 
  endTime, 
  onChange, 
  error,
  startLabel = "Heure d'ouverture",
  endLabel = "Heure de fermeture",
  description = "Définissez les heures pendant lesquelles les commandes sont acceptées"
}: TimeRangeFieldProps) {
  const [isMobile, setIsMobile] = useState(false);

  // Détecter si on est sur mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);
  
  const handleStartTimeChange = (newStartTime: string) => {
    onChange(newStartTime, endTime);
  };

  const handleEndTimeChange = (newEndTime: string) => {
    onChange(startTime, newEndTime);
  };

  // Validation en temps réel pour l'affichage visuel
  const hasTimeRangeError = () => {
    if (!startTime || !endTime) return false;
    
    const [startHour, startMin] = startTime.split(':').map(Number);
    const [endHour, endMin] = endTime.split(':').map(Number);
    
    const startMinutes = startHour * 60 + startMin;
    const endMinutes = endHour * 60 + endMin;
    
    return endMinutes <= startMinutes;
  };

  const timeRangeError = hasTimeRangeError();

  return (
    <div className={`space-y-4 ${isMobile ? 'space-y-5' : ''}`}>
      {/* En-tête avec description */}
      <div className={`space-y-1 ${isMobile ? 'space-y-2' : ''}`}>
        <div className="flex items-center gap-2">
          <Clock className={`text-gray-500 ${isMobile ? 'h-5 w-5' : 'h-4 w-4'}`} />
          <Label className={`font-medium ${isMobile ? 'text-base' : 'text-sm'}`}>Heures d'ouverture</Label>
        </div>
        {description && (
          <p className={`text-gray-500 ${isMobile ? 'text-sm' : 'text-xs'}`}>
            {description}
          </p>
        )}
      </div>

      {/* Champs de saisie des heures */}
      <div className={`grid gap-4 ${isMobile ? 'grid-cols-1 gap-5' : 'grid-cols-1 md:grid-cols-2'}`}>
        {/* Heure de début */}
        <div className={`space-y-2 ${isMobile ? 'space-y-3' : ''}`}>
          <Label htmlFor="start-time" className={`font-medium ${isMobile ? 'text-base' : 'text-sm'}`}>
            {startLabel}
            <span className="text-red-500 ml-1">*</span>
          </Label>
          <Input
            id="start-time"
            type="time"
            value={startTime}
            onChange={(e) => handleStartTimeChange(e.target.value)}
            className={`${error || timeRangeError ? 'border-red-500 focus-visible:ring-red-500' : ''} ${
              isMobile ? 'h-12 text-base' : ''
            }`}
          />
        </div>

        {/* Heure de fin */}
        <div className={`space-y-2 ${isMobile ? 'space-y-3' : ''}`}>
          <Label htmlFor="end-time" className={`font-medium ${isMobile ? 'text-base' : 'text-sm'}`}>
            {endLabel}
            <span className="text-red-500 ml-1">*</span>
          </Label>
          <Input
            id="end-time"
            type="time"
            value={endTime}
            onChange={(e) => handleEndTimeChange(e.target.value)}
            className={`${error || timeRangeError ? 'border-red-500 focus-visible:ring-red-500' : ''} ${
              isMobile ? 'h-12 text-base' : ''
            }`}
          />
        </div>
      </div>

      {/* Affichage de la plage horaire */}
      {startTime && endTime && !timeRangeError && (
        <div className={`bg-green-50 border border-green-200 rounded-md ${isMobile ? 'p-4' : 'p-3'}`}>
          <p className={`text-green-700 flex items-center ${isMobile ? 'text-sm' : 'text-sm'}`}>
            <Clock className={`inline mr-2 ${isMobile ? 'h-5 w-5' : 'h-4 w-4'}`} />
            Commandes acceptées de <strong className='mx-1'>{startTime}</strong> à <strong className='mx-1'>{endTime}</strong>
          </p>
        </div>
      )}

      {/* Messages d'erreur - optimisés pour mobile */}
      {error && (
        <div className={`bg-red-50 border border-red-200 rounded-md ${isMobile ? 'p-4' : 'p-3'}`}>
          <p className={`text-red-600 flex items-start space-x-2 ${isMobile ? 'text-sm' : 'text-xs'}`}>
            <AlertCircle className={`flex-shrink-0 mt-0.5 ${isMobile ? 'h-4 w-4' : 'h-3 w-3'}`} />
            <span>{error}</span>
          </p>
        </div>
      )}

      {timeRangeError && !error && (
        <div className={`bg-red-50 border border-red-200 rounded-md ${isMobile ? 'p-4' : 'p-3'}`}>
          <p className={`text-red-600 flex items-start space-x-2 ${isMobile ? 'text-sm' : 'text-xs'}`}>
            <AlertCircle className={`flex-shrink-0 mt-0.5 ${isMobile ? 'h-4 w-4' : 'h-3 w-3'}`} />
            <span>L'heure de fermeture doit être postérieure à l'heure d'ouverture</span>
          </p>
        </div>
      )}

      {/* Aide contextuelle */}
      <div className={`bg-blue-50 border border-blue-200 rounded-md ${isMobile ? 'p-4' : 'p-3'}`}>
        <p className={`text-blue-700 ${isMobile ? 'text-sm' : 'text-xs'}`}>
          <strong>Conseil :</strong> Les clients ne pourront passer de commandes qu'entre ces heures. 
          Assurez-vous que la plage horaire correspond à vos heures de service.
        </p>
      </div>
    </div>
  );
}