"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useCategoriesStore } from "@/stores/categoriesStore";
import { availableColors, availableIcons } from "@/types/categories";

export function EditCategoryDialog() {
  const {
    isEditDialogOpen,
    selectedCategory,
    formData,
    loading,
    setFormData,
    updateCategory,
    closeAllDialogs,
  } = useCategoriesStore();

  const handleSubmit = async () => {
    if (!selectedCategory || !formData.name) return;
    
    const success = await updateCategory(selectedCategory.id, {
      name: formData.name,
      description: formData.description || "",
      color: formData.color || "blue",
      icon: formData.icon || "utensils",
      isActive: formData.isActive ?? true,
    });
    
    if (success) {
      closeAllDialogs();
    }
  };

  return (
    <Dialog open={isEditDialogOpen} onOpenChange={closeAllDialogs}>
      <DialogContent className="sm:max-w-[425px] mx-4 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg md:text-xl">Modifier la catégorie</DialogTitle>
          <DialogDescription className="text-sm md:text-base">
            Modifiez les informations de la catégorie.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="edit-name">Nom de la catégorie</Label>
            <Input
              id="edit-name"
              value={formData.name || ""}
              onChange={(e) => setFormData({ name: e.target.value })}
              placeholder="Ex: Plats principaux"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="edit-description">Description</Label>
            <Textarea
              id="edit-description"
              value={formData.description || ""}
              onChange={(e) => setFormData({ description: e.target.value })}
              placeholder="Description de la catégorie..."
              rows={3}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-color">Couleur</Label>
              <Select
                value={formData.color || "blue"}
                onValueChange={(value) => setFormData({ color: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {availableColors.map((color) => (
                    <SelectItem key={color.value} value={color.value}>
                      <div className="flex items-center gap-2">
                        <div className={`w-4 h-4 rounded-full ${color.class}`} />
                        {color.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-icon">Icône</Label>
              <Select
                value={formData.icon || "utensils"}
                onValueChange={(value) => setFormData({ icon: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {availableIcons.map((icon) => (
                    <SelectItem key={icon.value} value={icon.value}>
                      {icon.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={closeAllDialogs}>
            Annuler
          </Button>
          <Button onClick={handleSubmit} disabled={!formData.name || loading}>
            {loading ? "Sauvegarde..." : "Sauvegarder"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}