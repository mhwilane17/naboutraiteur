"use client";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useCategoriesStore } from '@/stores/categoriesStore';

export function DeleteCategoryDialog() {
  const {
    isDeleteDialogOpen,
    selectedCategory,
    loading,
    deleteCategory,
    closeAllDialogs,
  } = useCategoriesStore();

  const handleDelete = async () => {
    if (!selectedCategory) return;
    const success = await deleteCategory(selectedCategory.id);
    if (success) {
      closeAllDialogs();
    }
  };

  return (
    <AlertDialog open={isDeleteDialogOpen} onOpenChange={closeAllDialogs}>
      <AlertDialogContent className="mx-4">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-lg md:text-xl">Supprimer la catégorie</AlertDialogTitle>
          <AlertDialogDescription className="text-sm md:text-base">
            Êtes-vous sûr de vouloir supprimer la catégorie "{selectedCategory?.name}" ? Cette
            action est irréversible et supprimera également tous les plats associés.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Annuler</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={loading}
            className="bg-red-600 hover:bg-red-700 disabled:opacity-50"
          >
            {loading ? "Suppression..." : "Supprimer"}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}