"use client";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useCategoriesStore } from "@/stores/categoriesStore";
import { availableColors, availableIcons } from "@/types/categories";

export function ViewCategoryDialog() {
  const {
    isViewDialogOpen,
    selectedCategory,
    closeAllDialogs,
  } = useCategoriesStore();

  if (!selectedCategory) return null;

  return (
    <Dialog open={isViewDialogOpen} onOpenChange={closeAllDialogs}>
      <DialogContent className="sm:max-w-[500px] mx-4 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg md:text-xl">Détails de la catégorie</DialogTitle>
          <DialogDescription className="text-sm md:text-base">
            Informations complètes sur la catégorie sélectionnée.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold text-lg">{selectedCategory.name}</h3>
            <p className="text-muted-foreground">{selectedCategory.description}</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium">Couleur</Label>
              <div className="flex items-center gap-2 mt-1">
                <div
                  className={`w-4 h-4 rounded-full ${
                    availableColors.find((c) => c.value === selectedCategory.color)?.class
                  }`}
                />
                <span className="text-sm">
                  {availableColors.find((c) => c.value === selectedCategory.color)?.label}
                </span>
              </div>
            </div>
            <div>
              <Label className="text-sm font-medium">Icône</Label>
              <p className="text-sm mt-1">
                {availableIcons.find((i) => i.value === selectedCategory.icon)?.label}
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium">Nombre de plats</Label>
              <p className="text-sm mt-1">{selectedCategory.stats?.totalMenuItems || 0}</p>
            </div>
            <div>
              <Label className="text-sm font-medium">Statut</Label>
              <div className="mt-1">
                <Badge variant={selectedCategory.isActive ? "default" : "secondary"}>
                  {selectedCategory.isActive ? "Active" : "Inactive"}
                </Badge>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium">Créée le</Label>
              <p className="text-sm mt-1">
                {new Date(selectedCategory.createdAt).toLocaleDateString("fr-FR")}
              </p>
            </div>
            <div>
              <Label className="text-sm font-medium">Modifiée le</Label>
              <p className="text-sm mt-1">
                {new Date(selectedCategory.updatedAt).toLocaleDateString("fr-FR")}
              </p>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={closeAllDialogs}>
            Fermer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}