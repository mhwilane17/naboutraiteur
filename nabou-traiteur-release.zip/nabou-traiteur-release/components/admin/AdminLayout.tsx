"use client";

import { useState } from "react";
import { useAdmin } from "./AdminProvider";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Menu,
  X,
  Home,
  Users,
  Shield,
  ShoppingCart,
  UtensilsCrossed,
  Tag,
  Percent,
  MapPin,
  CreditCard,
  Settings,
  LogOut,
  ChevronDown,
  ContactRound,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { ProtectedView } from "@/components/ProtectedView";
import { OrangeMoneyBalance } from "./orange-money/OrangeMoneyBalance";

interface AdminLayoutProps {
  children: React.ReactNode;
}

const menuItems = [
  {
    title: "Dashboard",
    href: "/admin/dashboard",
    icon: Home,
    disabled: false,
    permissions: ["VIEW_DASHBOARD"],
  },
  {
    title: "Entreprises & Clients",
    href: "/admin/companies",
    icon: ContactRound,
    disabled: false,
    permissions: ["VIEW_DASHBOARD"],
  },
  {
    title: "La direction",
    href: "/admin/users",
    icon: Users,
    disabled: false,
    permissions: ["VIEW_USERS"],
  },
  {
    title: "Commandes",
    href: "/admin/orders",
    icon: ShoppingCart,
    disabled: false,
    permissions: ["VIEW_ORDERS"],
  },
  {
    title: "Menu & Plats",
    href: "/admin/menu",
    icon: UtensilsCrossed,
    disabled: false,
    permissions: ["VIEW_MENU"],
  },
  {
    title: "Catégories",
    href: "/admin/categories",
    icon: Tag,
    disabled: false,
    permissions: ["VIEW_CATEGORIES"],
  },
  {
    title: "Promotions",
    href: "/admin/promotions",
    icon: Percent,
    disabled: false,
    permissions: ["VIEW_PROMOTIONS"],
  },
  {
    title: "Zones de livraison",
    href: "/admin/delivery-zones",
    icon: MapPin,
    disabled: false,
    permissions: ["VIEW_DELIVERY_ZONES"],
  },
  {
    title: "Rôles",
    href: "/admin/roles",
    icon: Shield,
    disabled: false,
    permissions: ["VIEW_ROLES"],
  },
  {
    title: "Modes de paiement",
    href: "/admin/payment-methods",
    icon: CreditCard,
    disabled: false,
    permissions: ["VIEW_PAYMENT_METHODS"],
  },
  {
    title: "Configuration",
    href: "/admin/settings",
    icon: Settings,
    disabled: false,
    permissions: ["VIEW_SETTINGS"],
  },
];

export function AdminLayout({ children }: AdminLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, logout } = useAdmin();
  const pathname = usePathname();

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Sidebar pour mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="fixed inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <div className="fixed left-0 top-0 h-full w-64 bg-white shadow-lg">
            <SidebarContent
              menuItems={menuItems}
              pathname={pathname}
              onClose={() => setSidebarOpen(false)}
            />
          </div>
        </div>
      )}

      {/* Sidebar pour desktop */}
      <div className="hidden lg:relative lg:h-full lg:w-64 lg:block border-r ">
        <SidebarContent menuItems={menuItems} pathname={pathname} />
      </div>

      {/* Contenu principal */}
      <div className="lg:ml-0 w-full h-full flex flex-col">
        {/* Header */}
        <header className="bg-white shadow-sm sticky top-0 z-20">
          <div className="flex items-center justify-between px-4 h-16">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>
              <h1 className="text-xl font-semibold text-gray-900"></h1>
            </div>

            <div className="flex items-center space-x-4">
              <OrangeMoneyBalance />
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-primary text-white">
                        {user?.name?.charAt(0) || "A"}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden md:block">{user?.name}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium">{user?.name}</p>
                      <p className="text-xs text-gray-500">{user?.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Déconnexion
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {/* Contenu de la page */}
        <main className="p-6 h-full  overflow-scroll">{children}</main>
      </div>
    </div>
  );
}

interface SidebarContentProps {
  menuItems: typeof menuItems;
  pathname: string;
  onClose?: () => void;
}

function SidebarContent({ menuItems, pathname, onClose }: SidebarContentProps) {
  return (
    <div className="flex h-full flex-col justify-between bg-white">
      <div>
        {/* Logo */}
        <div className="flex items-center justify-between px-6  h-20">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <UtensilsCrossed className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold text-gray-900">Nabou Admin</span>
          </div>
          {onClose && (
            <Button variant="ghost" size="sm" onClick={onClose} className="lg:hidden">
              <X className="h-5 w-5" />
            </Button>
          )}
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-2 h-fit overflow-auto">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            const isDisabled = item.disabled;

            if (isDisabled) {
              return (
                <ProtectedView key={item.href} permissions={item.permissions}>
                  <div
                    className={cn(
                      "flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium cursor-not-allowed opacity-50",
                      "text-gray-400"
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    <span>{item.title}</span>
                  </div>
                </ProtectedView>
              );
            }

            return (
              <ProtectedView key={item.href} permissions={item.permissions}>
                <Link
                  href={item.href}
                  onClick={onClose}
                  className={cn(
                    "flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                    isActive ? "bg-primary text-white" : "text-gray-700 hover:bg-gray-100"
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.title}</span>
                </Link>
              </ProtectedView>
            );
          })}
        </nav>
      </div>

      {/* Footer */}
      <div className="p-4">
        <div className="flex items-center space-x-2">
          <Badge variant="secondary" className="text-xs">
            v1.0.0
          </Badge>
          <span className="text-xs text-gray-500">Nabou Traiteur</span>
        </div>
      </div>
    </div>
  );
}
