"use client";

import { ReactNode } from "react";
import { useAuthStore } from "@/stores/authStore";

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
}

interface AdminContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  loading: boolean;
}

export function AdminProvider({ children }: { children: ReactNode }) {
  return <>{children}</>;
}

// Hook de compatibilité pour les composants existants
export function useAdmin(): AdminContextType {
  const { user, isAuthenticated, login, logout, isLoading } = useAuthStore();
  
  return {
    user,
    isAuthenticated,
    login,
    logout,
    loading: isLoading,
  };
}
