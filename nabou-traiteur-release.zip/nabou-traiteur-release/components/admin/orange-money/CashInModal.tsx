"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ErrorDisplay } from "@/components/ui/error-display";
import { Loader2, Wallet, Phone } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

interface CashInModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBalance: number;
  customerMsisdn: string;
  onSuccess: () => void;
}

interface CashInFormData {
  amount: number;
  reference?: string;
}

export function CashInModal({
  isOpen,
  onClose,
  currentBalance,
  customerMsisdn,
  onSuccess,
}: CashInModalProps) {
  const [amount, setAmount] = useState<string>("");
  const [reference, setReference] = useState<string>("");
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      setAmount("");
      setReference("");
      setValidationErrors({});
      setError(null);
    }
  }, [isOpen]);

  const formatBalance = (value: number): string => {
    return new Intl.NumberFormat("fr-FR", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    
    const amountNum = parseFloat(amount);
    
    if (!amount || amount.trim() === "") {
      errs.amount = "Le montant est requis";
    } else if (isNaN(amountNum)) {
      errs.amount = "Le montant doit être un nombre valide";
    } else if (amountNum <= 0) {
      errs.amount = "Le montant doit être supérieur à zéro";
    } else if (amountNum > currentBalance) {
      errs.amount = `Le montant ne peut pas dépasser le solde disponible (${formatBalance(currentBalance)} XOF)`;
    }
    
    setValidationErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    
    setSubmitting(true);
    setError(null);
    
    try {
      const payload: CashInFormData = {
        amount: parseFloat(amount),
      };
      
      if (reference && reference.trim()) {
        payload.reference = reference.trim();
      }
      
      const response = await fetch("/api/admin/orange-money/cashin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error?.message || "Erreur lors de l'encaissement");
      }

      if (data.success) {
        toast({
          title: "Encaissement réussi",
          description: `Transaction ${data.data.transactionId} effectuée avec succès`,
        });
        onSuccess();
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Erreur inconnue";
      setError(errorMessage);
      toast({
        title: "Erreur",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAmount(e.target.value);
    if (validationErrors.amount) {
      setValidationErrors((prev) => ({ ...prev, amount: "" }));
    }
  };

  const isSubmitDisabled = submitting || currentBalance <= 0;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="w-[95vw] sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Encaisser un montant</DialogTitle>
          <DialogDescription>
            Effectuez un encaissement depuis le compte client Orange Money
          </DialogDescription>
        </DialogHeader>

        {error && <ErrorDisplay error={error} />}

        <div className="grid gap-4 py-2">
          {/* Current Balance Display */}
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <Wallet className="h-4 w-4 text-orange-600" />
                <span className="text-sm font-medium text-gray-700">Solde disponible</span>
              </div>
              <span className="text-lg font-bold text-orange-600">
                {currentBalance} XOF
              </span>
            </div>
            
            {customerMsisdn && (
              <div className="flex items-center space-x-2 mt-2 pt-2 border-t border-orange-200">
                <Phone className="h-4 w-4 text-gray-500" />
                <span className="text-sm text-gray-600">Client: {customerMsisdn}</span>
              </div>
            )}
          </div>

          {/* Amount Input */}
          <div className="grid gap-2">
            <Label htmlFor="amount">
              Montant à encaisser <span className="text-red-500">*</span>
            </Label>
            <Input
              id="amount"
              type="number"
              value={amount}
              onChange={(e) => Number(e.target.value) <= currentBalance && handleAmountChange(e)}
              max={3000}
              placeholder="Ex: 10000"
              min="0"
              step="100"
              disabled={submitting || currentBalance <= 0}
            />
            {validationErrors.amount && (
              <p className="text-sm text-red-500">{validationErrors.amount}</p>
            )}
            {currentBalance <= 0 && (
              <p className="text-sm text-orange-600">
                Le solde est insuffisant pour effectuer un encaissement
              </p>
            )}
          </div>

          {/* Reference Input (Optional) */}
          <div className="grid gap-2">
            <Label htmlFor="reference">Référence (optionnel)</Label>
            <Input
              id="reference"
              type="text"
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              placeholder="Ex: Commande #123"
              disabled={submitting}
            />
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={onClose}
            disabled={submitting}
          >
            Annuler
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isSubmitDisabled}
            className="bg-orange-600 hover:bg-orange-700"
          >
            {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Encaisser
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
