"use client";

import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { RefreshCw, Wallet, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { CashInModal } from "./CashInModal";

interface BalanceData {
  value: number;
  unit: string;
}

export function OrangeMoneyBalance() {
  const [balance, setBalance] = useState<BalanceData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isCashInModalOpen, setIsCashInModalOpen] = useState(false);
  const [customerMsisdn, setCustomerMsisdn] = useState<string>("");
  const { toast } = useToast();

  const fetchBalance = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch("/api/admin/orange-money/balance", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
      });

      const data = await response.json();
    

      if (!response.ok) {
        throw new Error(data.error?.message || "Erreur lors de la récupération du solde");
      }

      if (data.success && data.data) {
        setBalance(data.data);
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Erreur inconnue";
      setError(errorMessage);
      toast({
        title: "Erreur",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const fetchConfig = useCallback(async () => {
    try {
      const response = await fetch("/api/payment/methods", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
      });

      const data = await response.json();

      if (response.ok && data.success && data.data) {
        const orangeMoneyMethod = data.data.methods.find(
          (method: any) => method.provider === "Sonatel"
        );
        
        if (orangeMoneyMethod?.config?.customer_msisdn) {
            console.log("customer_msisdn", orangeMoneyMethod.config.customer_msisdn);
            
          setCustomerMsisdn(orangeMoneyMethod.config.customer_msisdn);
        }
      }
    } catch (err) {
      console.error("Error fetching Orange Money config:", err);
    }
  }, []);

  useEffect(() => {
    fetchBalance();
    fetchConfig();
  }, [fetchBalance, fetchConfig]);

  const formatBalance = (value: number): string => {
    return new Intl.NumberFormat("fr-FR", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const handleRefresh = () => {
    fetchBalance();
  };

  const handleCashInSuccess = () => {
    fetchBalance();
    setIsCashInModalOpen(false);
  };

  return (
    <>
      <div className="flex items-center space-x-2 bg-gray-50 px-3 py-2 rounded-lg">
        <Wallet className="h-4 w-4 text-orange-600" />
        
        {loading && !balance ? (
          <div className="flex items-center space-x-2">
            <Loader2 className="h-4 w-4 animate-spin text-gray-500" />
            <span className="text-sm text-gray-500">Chargement...</span>
          </div>
        ) : error && !balance ? (
          <span className="text-sm text-red-500">Erreur</span>
        ) : balance ? (
          <div className="flex items-center space-x-3">
            <div className="flex flex-col">
              <span className="text-xs text-gray-500">Solde Orange Money</span>
              <span className="text-sm font-semibold text-gray-900">
                {balance.value} {balance.unit}
              </span>
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRefresh}
              disabled={loading}
              className="h-8 w-8 p-0"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            </Button>
            
            <Button
              variant="default"
              size="sm"
              onClick={() => setIsCashInModalOpen(true)}
              disabled={loading || !balance || balance.value <= 0}
              className="hover:bg-orange-700"
            >
              Encaisser
            </Button>
          </div>
        ) : null}
      </div>

      <CashInModal
        isOpen={isCashInModalOpen}
        onClose={() => setIsCashInModalOpen(false)}
        currentBalance={balance?.value || 0}
        customerMsisdn={customerMsisdn}
        onSuccess={handleCashInSuccess}
      />
    </>
  );
}
