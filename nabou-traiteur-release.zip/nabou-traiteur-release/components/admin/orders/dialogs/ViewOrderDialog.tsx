"use client";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Loader2 } from "lucide-react";
import type { Order } from "@/types/orders";

export interface ViewOrderDialogProps {
  open: boolean;
  onClose: () => void;
  order: Order | null | undefined;
  loading?: boolean;
}

const orderStatuses = [
  { value: "pending", label: "En attente", color: "bg-yellow-100 text-yellow-800" },
  { value: "confirmed", label: "Confirmée", color: "bg-blue-100 text-blue-800" },
  { value: "preparing", label: "En préparation", color: "bg-orange-100 text-orange-800" },
  { value: "ready", label: "Prête", color: "bg-purple-100 text-purple-800" },
  { value: "delivering", label: "En livraison", color: "bg-indigo-100 text-indigo-800" },
  { value: "delivered", label: "Livrée", color: "bg-green-100 text-green-800" },
  { value: "cancelled", label: "Annulée", color: "bg-red-100 text-red-800" },
];

const paymentStatuses = [
  { value: "pending", label: "En attente", color: "bg-yellow-100 text-yellow-800" },
  { value: "paid", label: "Payée", color: "bg-green-100 text-green-800" },
  { value: "failed", label: "Échouée", color: "bg-red-100 text-red-800" },
  { value: "refunded", label: "Remboursée", color: "bg-gray-100 text-gray-800" },
];

function getStatusLabel(status: string) {
  return orderStatuses.find((s) => s.value === status)?.label || status;
}

function getStatusColor(status: string) {
  return orderStatuses.find((s) => s.value === status)?.color || "bg-gray-100 text-gray-800";
}

function getPaymentStatusLabel(status: string) {
  return paymentStatuses.find((s) => s.value === status)?.label || status;
}

function getPaymentStatusColor(status: string) {
  return paymentStatuses.find((s) => s.value === status)?.color || "bg-gray-100 text-gray-800";
}

function formatDate(dateString: string) {
  return new Date(dateString).toLocaleDateString("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "XOF",
    minimumFractionDigits: 0,
  }).format(amount);
}

function getCustomerName(order: Order) {
  if (order.customer) {
    return `${order.customer.firstName} ${order.customer.lastName}`;
  }
  return "Client invité";
}

function getCustomerPhone(order: Order) {
  return order.customer?.phone || order.deliveryPhone || "N/A";
}

export function ViewOrderDialog({ open, onClose, order, loading = false }: ViewOrderDialogProps) {
  return (
    <Dialog open={open} onOpenChange={(isOpen) => { if (!isOpen) onClose(); }}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0 border-b pb-3">
          <DialogTitle>Détails de la commande</DialogTitle>
          <DialogDescription>
            Informations complètes de la commande {order?.orderNumber}
          </DialogDescription>
        </DialogHeader>
        {loading && (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2">Chargement des détails...</span>
          </div>
        )}
        {!loading && order && (
          <div className="flex-1 overflow-y-auto">
            <div className="grid gap-6 py-4">
              {/* Informations générales */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">
                      Informations client
                    </Label>
                    <div className="mt-2 space-y-1">
                      <p className="font-medium">{getCustomerName(order)}</p>
                      {order.customer?.email && (
                        <p className="text-sm text-gray-600">
                          {order.customer?.email || "N/A"}
                        </p>
                      )}
                      <p className="text-sm text-gray-600">
                        {getCustomerPhone(order)}
                      </p>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">
                      Adresse de livraison
                    </Label>
                    <p className="text-sm mt-1">
                      {order.deliveryZone?.name || "N/A"}
                    </p>
                    <span className="text-sm text-gray-500">
                      ({order.deliveryAddress || order.deliveryZone?.areas.join(", ")})
                    </span>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Statut</Label>
                      <div className="mt-1">
                        <Badge className={getStatusColor(order.status)}>
                          {getStatusLabel(order.status)}
                        </Badge>
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Paiement</Label>
                      <div className="mt-1">
                        <Badge className={getPaymentStatusColor(order.paymentStatus)}>
                          {getPaymentStatusLabel(order.paymentStatus)}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-500">
                        Date de commande
                      </Label>
                      <p className="text-sm mt-1">{formatDate(order.createdAt)}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">
                        Livraison prévue
                      </Label>
                      <p className="text-sm mt-1">
                        {order?.deliveryTime || "Non défini"}
                      </p>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">
                      Mode de paiement
                    </Label>
                    <p className="text-sm mt-1">{order.paymentMethod || "N/A"}</p>
                  </div>
                </div>
              </div>

              {/* Articles commandés */}
              <div>
                <Label className="text-sm font-medium text-gray-500">
                  Articles commandés
                </Label>
                <div className="mt-2 border rounded-lg overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Article</TableHead>
                        <TableHead>Quantité</TableHead>
                        <TableHead>Prix unitaire</TableHead>
                        <TableHead>Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {order.items.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{item.menuItem.name}</div>
                              {item.options && (
                                <div className="text-sm text-gray-500">
                                  {item.options &&
                                    Object.entries(item.options)
                                      .map(([key, value]) => `${key}: ${value}`)
                                      .join(", ")}
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>{item.quantity}</TableCell>
                          <TableCell>{formatCurrency(item.unitPrice)}</TableCell>
                          <TableCell>{formatCurrency(item.totalPrice)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Résumé financier */}
              <div className="border-t pt-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Sous-total:</span>
                    <span>{formatCurrency(order.totalAmount)}</span>
                  </div>
                  {order.deliveryFee && (
                    <div className="flex justify-between">
                      <span>Frais de livraison:</span>
                      <span>{formatCurrency(order.deliveryFee)}</span>
                    </div>
                  )}
                  {Boolean(order.discountAmount) && (
                    <div className="flex justify-between text-green-600">
                      <span>Remise:</span>
                      <span>-{formatCurrency(order.discountAmount)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-lg border-t pt-2">
                    <span>Total:</span>
                    <span>{formatCurrency(order.finalAmount)}</span>
                  </div>
                </div>
              </div>

              {/* Promotions utilisées */}
              {order.promotionUsage && order.promotionUsage.length > 0 && (
                <div className="border-t pt-4">
                  <Label className="text-sm font-medium text-gray-500">
                    Promotions utilisées
                  </Label>
                  <div className="mt-2 border rounded-lg overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Code</TableHead>
                          <TableHead>Nom</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Valeur</TableHead>
                          <TableHead>Montant remisé</TableHead>
                          <TableHead>Date d'utilisation</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {order.promotionUsage.map((usage) => (
                          <TableRow key={usage.id}>
                            <TableCell>{usage.promotion.code}</TableCell>
                            <TableCell>{usage.promotion.name}</TableCell>
                            <TableCell>
                              {usage.promotion.type === "percentage" ? "Pourcentage" : "Montant fixe"}
                            </TableCell>
                            <TableCell>
                              {usage.promotion.type === "percentage"
                                ? `${usage.promotion.value}%`
                                : formatCurrency(Number(usage.promotion.value))}
                            </TableCell>
                            <TableCell>{formatCurrency(Number(usage.discountAmount))}</TableCell>
                            <TableCell>{formatDate(usage.usedAt)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}

              {/* Notes */}
              {(order.customerNotes || order.adminNotes) && (
                <div className="space-y-4">
                  {order.customerNotes && (
                    <div>
                      <Label className="text-sm font-medium text-gray-500">
                        Notes du client
                      </Label>
                      <p className="text-sm mt-1">{order.customerNotes}</p>
                    </div>
                  )}
                  {order.adminNotes && (
                    <div>
                      <Label className="text-sm font-medium text-gray-500">
                        Notes administratives
                      </Label>
                      <p className="text-sm mt-1">{order.adminNotes}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
        <DialogFooter className="flex-shrink-0 border-t pt-3">
          <Button variant="outline" onClick={onClose}>
            Fermer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}