import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { usePromotionsStore, promoTypes } from "@/stores/promotionsStore";

export function EditPromoDialog() {
  const {
    isEditDialogOpen,
    setIsEditDialogOpen,
    formData,
    setFormData,
    editPromo,
    isLoading,
    error,
  } = usePromotionsStore();

  return (
    <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
      <DialogContent className="w-[95vw] sm:max-w-[700px] max-h-[85vh] overflow-y-auto">
        <DialogHeader className="sticky -top-6 bg-background py-2 border-b">
          <DialogTitle>Modifier la promotion</DialogTitle>
          <DialogDescription>Modifiez les informations de la promotion.</DialogDescription>
        </DialogHeader>
        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        )}

        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name">Nom de la promotion</Label>
              <Input
                id="edit-name"
                value={formData.name}
                onChange={(e) => setFormData({ name: e.target.value })}
                placeholder="Ex: Bienvenue Nouveau Client"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-code">Code promo</Label>
              <Input
                id="edit-code"
                value={formData.code}
                onChange={(e) => setFormData({ code: e.target.value.toUpperCase() })}
                placeholder="Ex: BIENVENUE15"
                className="font-mono"
              />
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="edit-description">Description</Label>
            <Textarea
              id="edit-description"
              value={formData.description}
              onChange={(e) => setFormData({ description: e.target.value })}
              placeholder="Description de la promotion..."
              rows={2}
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-type">Type de réduction</Label>
              <Select
                value={formData.type}
                onValueChange={(value: "percentage" | "fixed_amount" | "free_delivery") =>
                  setFormData({ type: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {promoTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-value">Valeur</Label>
              <Input
                id="edit-value"
                type="number"
                min="0"
                step={formData.type === "percentage" ? "1" : "0.01"}
                max={formData.type === "percentage" ? "100" : undefined}
                value={formData.value}
                onChange={(e) => setFormData({ value: parseFloat(e.target.value) || 0 })}
                placeholder={formData.type === "percentage" ? "15" : "5.00"}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-minOrderAmount">Commande minimum (FCFA)</Label>
              <Input
                id="edit-minOrderAmount"
                type="number"
                min="0"
                // step="1"
                value={formData.minOrderAmount || 0}
                onChange={(e) => setFormData({ minOrderAmount: parseFloat(e.target.value) || 0 })}
                placeholder="15000"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-minOrderItem">Nombre minimum d'articles</Label>
              <Input
                id="edit-minOrderItem"
                type="number"
                min="0"
                step="1"
                value={formData.minOrderItem ?? 0}
                onChange={(e) =>
                  setFormData({
                    minOrderItem: e.target.value === "" ? 0 : parseInt(e.target.value) || 0,
                  })
                }
                placeholder="2"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-maxDiscountAmount">Réduction maximum (FCFA)</Label>
              <Input
                id="edit-maxDiscountAmount"
                type="number"
                min="0"
                step="1"
                value={formData.maxDiscountAmount || 0}
                onChange={(e) =>
                  setFormData({ maxDiscountAmount: parseFloat(e.target.value) || 0 })
                }
                placeholder="10000"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-usageLimit">Limite d'utilisation totale</Label>
              <Input
                id="edit-usageLimit"
                type="number"
                min="0"
                step="1"
                value={formData.usageLimit ?? 0}
                onChange={(e) =>
                  setFormData({
                    usageLimit: e.target.value === "" ? 0 : parseInt(e.target.value) || 0,
                  })
                }
                placeholder="100"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-usagePerUser">Limite par utilisateur</Label>
              <Input
                id="edit-usagePerUser"
                type="number"
                min="0"
                step="1"
                value={formData.usagePerUser ?? 0}
                onChange={(e) =>
                  setFormData({
                    usagePerUser: e.target.value === "" ? 0 : parseInt(e.target.value) || 0,
                  })
                }
                placeholder="1"
              />
            </div>
          </div>

          {/* <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-applicableCategories">
                Catégories applicables (IDs séparés par virgule)
              </Label>
              <Input
                id="edit-applicableCategories"
                value={formData.applicableCategories?.join(", ") || ""}
                onChange={(e) =>
                  setFormData({
                    applicableCategories: e.target.value
                      ? e.target.value
                          .split(",")
                          .map((id) => id.trim())
                          .filter(Boolean)
                      : [],
                  })
                }
                placeholder="cat1, cat2, cat3"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-applicableMenuItems">
                Articles de menu applicables (IDs séparés par virgule)
              </Label>
              <Input
                id="edit-applicableMenuItems"
                value={formData.applicableMenuItems?.join(", ") || ""}
                onChange={(e) =>
                  setFormData({
                    applicableMenuItems: e.target.value
                      ? e.target.value
                          .split(",")
                          .map((id) => id.trim())
                          .filter(Boolean)
                      : [],
                  })
                }
                placeholder="item1, item2, item3"
              />
            </div>
          </div> */}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-startDate">Date de début</Label>
              <Input
                id="edit-startDate"
                type="date"
                value={formData.startDate}
                onChange={(e) => setFormData({ startDate: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-endDate">Date de fin</Label>
              <Input
                id="edit-endDate"
                type="date"
                value={formData.endDate}
                onChange={(e) => setFormData({ endDate: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-activeStartTime">Heure de début (facultatif)</Label>
              <Input
                id="edit-activeStartTime"
                type="time"
                value={formData.activeStartTime ?? ""}
                onChange={(e) => setFormData({ activeStartTime: e.target.value || undefined })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-activeEndTime">Heure de fin (facultatif)</Label>
              <Input
                id="edit-activeEndTime"
                type="time"
                value={formData.activeEndTime ?? ""}
                onChange={(e) => setFormData({ activeEndTime: e.target.value || undefined })}
              />
            </div>
          </div>
        </div>

        <DialogFooter className="sticky -bottom-6 bg-background border-t p-4 gap-2 flex-row">
          <Button
            variant="outline"
            onClick={() => setIsEditDialogOpen(false)}
            disabled={isLoading}
            className="w-full sm:w-auto"
          >
            Annuler
          </Button>
          <Button
            onClick={editPromo}
            disabled={!formData.name || !formData.code || isLoading}
            className="w-full sm:w-auto"
          >
            {isLoading ? "Sauvegarde..." : "Sauvegarder"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
