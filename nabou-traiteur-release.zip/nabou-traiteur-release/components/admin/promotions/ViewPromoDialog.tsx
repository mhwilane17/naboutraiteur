import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { usePromotionsStore } from "@/stores/promotionsStore";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Tag, Percent, Calendar, Clock, Clipboard, Info } from "lucide-react";

export function ViewPromoDialog() {
  const {
    isViewDialogOpen,
    setIsViewDialogOpen,
    selectedPromo,
    formatValue,
    isExpired,
  } = usePromotionsStore();

  if (!selectedPromo) return null;

  return (
    <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
      <DialogContent className="w-[95vw] sm:max-w-[600px] max-h-[85vh] overflow-y-auto">
        <DialogHeader className="sticky -top-6 bg-background py-2 border-b">
          <DialogTitle>Détails de la promotion</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold text-lg">{selectedPromo.name}</h3>
            <p className="text-muted-foreground text-sm line-clamp-3">{selectedPromo.description}</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium flex items-center gap-2"><Tag className="h-4 w-4" /> Code promo</Label>
              <div className="mt-1 flex items-center gap-2">
                <Badge variant="outline" className="font-mono text-base">
                  {selectedPromo.code}
                </Badge>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => navigator.clipboard.writeText(selectedPromo.code)}>
                        <Clipboard className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Copier</TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
            </div>
            <div>
              <Label className="text-sm font-medium flex items-center gap-2"><Percent className="h-4 w-4" /> Type de réduction</Label>
              <div className="mt-1">
                <Badge variant={selectedPromo.type === "percentage" ? "default" : selectedPromo.type === "fixed_amount" ? "secondary" : "default"}>
                  {selectedPromo.type === "percentage"
                    ? "Pourcentage"
                    : selectedPromo.type === "fixed_amount"
                    ? "Montant fixe"
                    : "Livraison gratuite"}
                </Badge>
              </div>
            </div>
          </div>
          <Separator />

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            <div className="rounded-md border p-3">
              <div className="text-xs text-muted-foreground">Valeur</div>
              <div className="text-base font-semibold">{formatValue(selectedPromo)}</div>
            </div>
            <div className="rounded-md border p-3">
              <div className="text-xs text-muted-foreground">Commande minimum</div>
              <div className="text-base font-medium">{(selectedPromo.minOrderAmount ?? 0).toLocaleString("fr-FR")} FCFA</div>
            </div>
            <div className="rounded-md border p-3">
              <div className="text-xs text-muted-foreground">Articles minimum</div>
              <div className="text-base font-medium">{selectedPromo.minOrderItem && selectedPromo.minOrderItem > 0 ? selectedPromo.minOrderItem : "—"}</div>
            </div>
            <div className="rounded-md border p-3">
              <div className="text-xs text-muted-foreground">Réduction max</div>
              <div className="text-base font-medium">{selectedPromo.maxDiscountAmount && selectedPromo.maxDiscountAmount > 0 ? `${selectedPromo.maxDiscountAmount.toLocaleString("fr-FR")} FCFA` : "—"}</div>
            </div>
            <div className="rounded-md border p-3">
              <div className="text-xs text-muted-foreground">Statut</div>
              <div className="mt-1 flex gap-2 items-center">
                <Badge variant={selectedPromo.isActive ? "default" : "secondary"}>
                  {selectedPromo.isActive ? "Active" : "Inactive"}
                </Badge>
                {isExpired(selectedPromo.endDate) && (
                  <Badge variant="destructive">Expirée</Badge>
                )}
              </div>
            </div>
          </div>

          <Separator />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium flex items-center gap-2"><Calendar className="h-4 w-4" /> Période de validité</Label>
              <div className="text-sm mt-1">
                <div>Du {new Date(selectedPromo.startDate).toLocaleDateString("fr-FR")}</div>
                <div className={isExpired(selectedPromo.endDate) ? "text-red-600" : ""}>
                  Au {new Date(selectedPromo.endDate).toLocaleDateString("fr-FR")}
                </div>
              </div>
            </div>
            <div>
              <Label className="text-sm font-medium flex items-center gap-2"><Info className="h-4 w-4" /> Créée le</Label>
              <p className="text-sm mt-1">
                {new Date(selectedPromo.createdAt).toLocaleDateString("fr-FR")}
              </p>
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium flex items-center gap-2"><Clock className="h-4 w-4" /> Plage d’heures actives</Label>
            <p className="text-sm mt-1 text-muted-foreground">
              {selectedPromo.activeStartTime && selectedPromo.activeEndTime
                ? `${selectedPromo.activeStartTime} - ${selectedPromo.activeEndTime}`
                : selectedPromo.activeStartTime
                ? `À partir de ${selectedPromo.activeStartTime}`
                : selectedPromo.activeEndTime
                ? `Jusqu’à ${selectedPromo.activeEndTime}`
                : "Toute la journée"}
            </p>
          </div>

          <Separator />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium">Limites d'utilisation</Label>
              <div className="text-sm mt-1 space-y-1">
                <div>
                  Usage total: {selectedPromo.usageLimit && selectedPromo.usageLimit > 0 ? selectedPromo.usageLimit : "Illimitée"}
                </div>
                <div>
                  Par utilisateur: {selectedPromo.usagePerUser && selectedPromo.usagePerUser > 0 ? selectedPromo.usagePerUser : "Illimitée"}
                </div>
              </div>
            </div>
            <div>
              <Label className="text-sm font-medium">Réduction maximum</Label>
              <p className="text-sm mt-1">{selectedPromo.maxDiscountAmount && selectedPromo.maxDiscountAmount > 0 ? `${selectedPromo.maxDiscountAmount} FCFA` : "—"}</p>
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium">Applicabilité</Label>
            <div className="mt-2">
              <div className="text-xs text-muted-foreground mb-1">Catégories</div>
              <div className="flex flex-wrap gap-2">
                {selectedPromo.applicableCategories && selectedPromo.applicableCategories.length > 0 ? (
                  selectedPromo.applicableCategories.map((cat, idx) => (
                    <Badge key={`cat-${idx}`} variant="outline" className="text-xs">
                      {cat}
                    </Badge>
                  ))
                ) : (
                  <span className="text-sm">Toutes les catégories</span>
                )}
              </div>
              <div className="text-xs text-muted-foreground mt-3 mb-1">Articles</div>
              <div className="flex flex-wrap gap-2">
                {selectedPromo.applicableMenuItems && selectedPromo.applicableMenuItems.length > 0 ? (
                  selectedPromo.applicableMenuItems.map((item, idx) => (
                    <Badge key={`item-${idx}`} variant="outline" className="text-xs">
                      {item}
                    </Badge>
                  ))
                ) : (
                  <span className="text-sm">Tous les articles</span>
                )}
              </div>
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium">Dernière mise à jour</Label>
            <p className="text-sm mt-1">{new Date(selectedPromo.updatedAt).toLocaleString("fr-FR")}</p>
          </div>
        </div>
        <DialogFooter className="sticky -bottom-6 bg-background border-t p-4">
          <Button variant="outline" onClick={() => setIsViewDialogOpen(false)} className="w-full sm:w-auto">
            Fermer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}