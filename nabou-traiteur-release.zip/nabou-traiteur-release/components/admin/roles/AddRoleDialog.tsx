import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useRolesStore } from "@/stores/rolesStore";
import { Permission } from "@/types/roles";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { ErrorDisplay } from "@/components/ui/error-display";

export function AddRoleDialog() {
  const {
    isAddDialogOpen,
    closeAllDialogs,
    permissions,
    formData,
    setFormData,
    resetForm,
    createRole,
    operationLoading,
    error,
    fetchPermissions,
  } = useRolesStore();

  // Load permissions when dialog opens
  useEffect(() => {
    if (isAddDialogOpen && (!Array.isArray(permissions) || permissions.length === 0)) {
      fetchPermissions();
    }
  }, [isAddDialogOpen, permissions, fetchPermissions]);

  // Grouper les permissions par module
  const permissionsByModule = Array.isArray(permissions) 
    ? permissions.reduce((acc, permission) => {
        if (!acc[permission.module]) {
          acc[permission.module] = [];
        }
        acc[permission.module].push(permission);
        return acc;
      }, {} as Record<string, Permission[]>)
    : {};

  const handlePermissionToggle = (permissionId: string) => {
    const currentPermissions = formData.permissions || [];
    const updatedPermissions = currentPermissions.includes(permissionId)
      ? currentPermissions.filter(p => p !== permissionId)
      : [...currentPermissions, permissionId];
    setFormData({ permissions: updatedPermissions });
  };

  const handleSubmit = async () => {
    // Generate a unique ID for the role
    const roleId = `role_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const roleData = {
      id: roleId,
      name: formData.name,
      description: formData.description,
      isActive: formData.isActive,
      permissionIds: formData.permissions,
    };

    const success = await createRole(roleData);
    if (success) {
      resetForm();
      closeAllDialogs();
    }
  };

  const handleClose = () => {
    resetForm();
    closeAllDialogs();
  };

  const handleRetryPermissions = () => {
    fetchPermissions();
  };

  return (
    <Dialog open={isAddDialogOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle>Créer un nouveau rôle</DialogTitle>
          <DialogDescription>
            Définissez le nom, la description et les permissions du nouveau rôle
          </DialogDescription>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto">
          <div className="grid gap-6 py-4">
            {error && (
              <ErrorDisplay 
                error={error} 
                onRetry={handleRetryPermissions}
                retryText="Recharger les permissions"
              />
            )}
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nom du rôle</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ name: e.target.value })}
                  placeholder="Ex: Gestionnaire de commandes"
                  disabled={operationLoading.create}
                />
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="isActive"
                  checked={formData.isActive}
                  onChange={(e) => setFormData({ isActive: e.target.checked })}
                  disabled={operationLoading.create}
                />
                <Label htmlFor="isActive">Rôle actif</Label>
              </div>
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ description: e.target.value })}
                placeholder="Décrivez les responsabilités de ce rôle..."
                rows={3}
                disabled={operationLoading.create}
              />
            </div>
            
            {/* Permissions */}
            <div>
              <Label className="text-base font-medium">Permissions</Label>
              <p className="text-sm text-muted-foreground mb-4">
                Sélectionnez les permissions à accorder à ce rôle
              </p>
              
              {operationLoading.fetchPermissions ? (
                <div className="flex items-center justify-center py-8">
                  <LoadingSpinner />
                  <span className="ml-2">Chargement des permissions...</span>
                </div>
              ) : (
                <div className="space-y-6">
                  {Object.entries(permissionsByModule).map(([module, modulePermissions]) => (
                    <div key={module} className="border rounded-lg p-4">
                      <h4 className="font-medium mb-3 capitalize">{module}</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {modulePermissions.map((permission) => (
                          <div key={permission.id} className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              id={`perm-${permission.id}`}
                              checked={formData.permissions?.includes(permission.id) || false}
                              onChange={() => handlePermissionToggle(permission.id)}
                              className="rounded"
                              disabled={operationLoading.create}
                            />
                            <Label 
                              htmlFor={`perm-${permission.id}`}
                              className="text-sm font-normal cursor-pointer"
                            >
                              {permission.name}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
        <DialogFooter className="flex-shrink-0">
          <Button 
            variant="outline" 
            onClick={handleClose}
            disabled={operationLoading.create}
          >
            Annuler
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={operationLoading.create || !formData.name.trim()}
          >
            {operationLoading.create ? (
              <>
                <LoadingSpinner className="mr-2 h-4 w-4" />
                Création...
              </>
            ) : (
              "Créer le rôle"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}