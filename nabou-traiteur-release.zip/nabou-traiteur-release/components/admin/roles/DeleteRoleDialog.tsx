import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useRolesStore } from "@/stores/rolesStore";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { ErrorDisplay } from "@/components/ui/error-display";

export function DeleteRoleDialog() {
  const {
    isDeleteDialogOpen,
    closeAllDialogs,
    selectedRole,
    deleteRole,
    operationLoading,
    error,
    clearError,
  } = useRolesStore();

  const handleDelete = async () => {
    if (!selectedRole) return;

    const success = await deleteRole(selectedRole.id);
    if (success) {
      closeAllDialogs();
    }
  };

  const handleRetry = () => {
    // Clear error and allow user to try again
    clearError();
  };

  return (
    <AlertDialog open={isDeleteDialogOpen} onOpenChange={closeAllDialogs}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Supprimer le rôle</AlertDialogTitle>
          <AlertDialogDescription>
            Êtes-vous sûr de vouloir supprimer le rôle "{selectedRole?.name}" ?
            Cette action est irréversible et affectera tous les utilisateurs assignés à ce rôle.
            {selectedRole?.userCount && selectedRole.userCount > 0 && (
              <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded text-yellow-800">
                <strong>Attention :</strong> Ce rôle est assigné à {selectedRole.userCount} utilisateur(s).
              </div>
            )}
          </AlertDialogDescription>
        </AlertDialogHeader>
        
        {error && (
          <ErrorDisplay 
            error={error} 
            onRetry={handleRetry}
            retryText="Réessayer"
          />
        )}
        
        <AlertDialogFooter>
          <AlertDialogCancel disabled={operationLoading.delete}>
            Annuler
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={operationLoading.delete}
            className="bg-red-600 hover:bg-red-700"
          >
            {operationLoading.delete ? (
              <>
                <LoadingSpinner className="mr-2 h-4 w-4" />
                Suppression...
              </>
            ) : (
              "Supprimer"
            )}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}