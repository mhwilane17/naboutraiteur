import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Edit, Users } from "lucide-react";
import { useRolesStore } from "@/stores/rolesStore";
import { Permission } from "@/types/roles";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { ErrorDisplay } from "@/components/ui/error-display";

export function ViewRoleDialog() {
  const {
    isViewDialogOpen,
    closeAllDialogs,
    selectedRole,
    permissions,
    openEditDialog,
    operationLoading,
    error,
    fetchPermissions,
  } = useRolesStore();

  if (!selectedRole) return null;

  // Grouper les permissions par module
  const permissionsByModule = (permissions || []).reduce((acc, permission) => {
    if (!acc[permission.module]) {
      acc[permission.module] = [];
    }
    acc[permission.module].push(permission);
    return acc;
  }, {} as Record<string, Permission[]>);

  const handleEdit = () => {
    closeAllDialogs();
    openEditDialog(selectedRole);
  };

  const handleRetryPermissions = () => {
    fetchPermissions();
  };

  return (
    <Dialog open={isViewDialogOpen} onOpenChange={closeAllDialogs}>
      <DialogContent className="max-w-3xl max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle>Détails du rôle</DialogTitle>
          <DialogDescription>
            Informations complètes du rôle {selectedRole.name}
          </DialogDescription>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto">
          <div className="grid gap-6 py-4">
            {/* Error Display */}
            {error && (
              <ErrorDisplay 
                error={error} 
                onRetry={handleRetryPermissions}
                retryText="Recharger les permissions"
              />
            )}
            {/* Informations générales */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">Nom</Label>
                  <p className="text-lg font-semibold">{selectedRole.name}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Description</Label>
                  <p className="text-sm mt-1 p-3 bg-gray-50 rounded-lg">
                    {selectedRole.description || "Aucune description"}
                  </p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">Statut</Label>
                  <div className="mt-1">
                    <Badge
                      className={selectedRole.isActive
                        ? "bg-green-100 text-green-800"
                        : "bg-red-100 text-red-800"
                      }
                    >
                      {selectedRole.isActive ? "Actif" : "Inactif"}
                    </Badge>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Utilisateurs assignés</Label>
                  <div className="flex items-center mt-1">
                    <Users className="h-4 w-4 mr-1 text-muted-foreground" />
                    {selectedRole.userCount || 0} utilisateur(s)
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Créé le</Label>
                  <p className="text-sm mt-1">
                    {new Date(selectedRole.createdAt).toLocaleDateString('fr-FR')}
                  </p>
                </div>
              </div>
            </div>

            {/* Permissions */}
            <div>
              <Label className="text-sm font-medium text-gray-500">
                Permissions ({selectedRole.permissions?.length || 0})
              </Label>
              
              {operationLoading.fetchPermissions ? (
                <div className="flex items-center justify-center py-8">
                  <LoadingSpinner text="Chargement des permissions..." />
                </div>
              ) : (
                <div className="mt-3 space-y-4">
                  {Object.entries(permissionsByModule).map(([module, modulePermissions]) => {
                    const rolePermissionIds = (selectedRole.permissions || []).map(p => p.id);
                    const categoryPermissions = modulePermissions.filter(p => 
                      rolePermissionIds.includes(p.id)
                    );
                    
                    if (categoryPermissions.length === 0) return null;
                    
                    return (
                      <div key={module} className="border rounded-lg p-4">
                        <h4 className="font-medium mb-2 capitalize">{module}</h4>
                        <div className="flex flex-wrap gap-2">
                          {categoryPermissions.map((permission) => (
                            <Badge key={permission.id} variant="secondary" className="text-xs">
                              {permission.name}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                  
                  {(!selectedRole.permissions || selectedRole.permissions.length === 0) && (
                    <p className="text-sm text-muted-foreground italic">
                      Aucune permission assignée à ce rôle
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
        <DialogFooter className="flex-shrink-0">
          <div className="flex gap-2">
            <Button 
              variant="outline"
              onClick={handleEdit}
              disabled={operationLoading.update || operationLoading.delete}
            >
              <Edit className="h-4 w-4 mr-2" />
              Modifier
            </Button>
            <Button variant="outline" onClick={closeAllDialogs}>
              Fermer
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}