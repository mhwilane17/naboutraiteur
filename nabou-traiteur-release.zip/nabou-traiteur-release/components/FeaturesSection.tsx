import { ChefHat, Heart, Users, Truck } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const features = [
  {
    icon: ChefHat,
    title: "Cuisine authentique",
    description:
      "Des recettes traditionnelles, transmises et revisitées avec passion pour un goût inimitable.",
    color: "bg-red-100 text-red-600",
  },
  {
    icon: Heart,
    title: "Produits frais",
    description:
      "Nous sélectionnons chaque ingrédient avec soin pour garantir fraîcheur et qualité à chaque repas.",
    color: "bg-red-100 text-red-600",
  },
  {
    icon: Users,
    title: "Chaleur humaine",
    description:
      "Un service courtois, attentif et personnalisé, pour que chaque client se sente privilégié.",
    color: "bg-red-100 text-red-600",
  },
  {
    icon: Truck,
    title: "Livraison fiable",
    description:
      "Votre déjeuner livré à l'heure, où que vous soyez à Dakar, pour ne jamais manquer votre pause.",
    color: "bg-red-100 text-red-600",
  },
];

export function FeaturesSection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="bg-primary/10 text-primary mb-4">Nos atouts</Badge>
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Pourquoi choisir Nabou Traiteur ?
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="border bg-background border-gray-100">
              <CardContent className="p-8 text-center">
                <div
                  className={`w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mx-auto mb-6`}
                >
                  <feature.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
