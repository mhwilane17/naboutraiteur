import Image from "next/image";

import { Badge } from "@/components/ui/badge";

export function CoFoundersSection() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <Image
              src="/placeholder.svg"
              alt="Awa Gueye et Oumy Mbengue - Co-fondatrices de Nabou Traiteur"
              width={600}
              height={400}
              className="rounded-3xl"
            />
          </div>
          <div className="space-y-8">
            <div>
              <Badge className="bg-primary/10 text-primary mb-4">Nos Co-fondatrices</Badge>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
                Awa & Oumy
              </h2>
            </div>

            <blockquote className="text-lg text-gray-600 leading-relaxed italic border-l-4 border-primary pl-6">
              "Une équipe passionnée, à votre service pour une expérience culinaire authentique et
              humaine. Nous mettons tout notre cœur dans chaque plat pour vous offrir le meilleur de
              la cuisine sénégalaise."
            </blockquote>

            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span className="text-gray-700">Plus de 5 ans d'expérience en restauration</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span className="text-gray-700">
                  Passion pour la cuisine traditionnelle sénégalaise
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span className="text-gray-700">Engagement pour la qualité et l'authenticité</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
