'use client';

import React from 'react';
import { useAuthStore } from '@/stores/authStore';

interface ProtectedViewProps {
  children: React.ReactNode;
  permission?: string;
  permissions?: string[];
  requireAll?: boolean;
  fallback?: React.ReactNode;
  className?: string;
}

/**
 * Composant qui contrôle l'affichage de son contenu enfant en fonction des permissions utilisateur
 * 
 * @param children - Le contenu à afficher si les permissions sont suffisantes
 * @param permission - Une permission unique requise
 * @param permissions - Un tableau de permissions requises
 * @param requireAll - Si true, toutes les permissions sont requises. Si false, au moins une permission est requise (défaut: false)
 * @param fallback - Contenu à afficher si les permissions sont insuffisantes
 * @param className - Classes CSS à appliquer au conteneur
 */
export const ProtectedView: React.FC<ProtectedViewProps> = ({
  children,
  permission,
  permissions = [],
  requireAll = false,
  fallback = null,
  className,
}) => {
  const { hasPermission, hasAnyPermission, hasAllPermissions, isAuthenticated } = useAuthStore();

  // Si l'utilisateur n'est pas authentifié, ne pas afficher le contenu
  if (!isAuthenticated) {
    return <>{fallback}</>;
  }

  // Construire la liste des permissions à vérifier
  const permissionsToCheck = permission ? [permission, ...permissions] : permissions;

  // Si aucune permission n'est spécifiée, afficher le contenu (utilisateur authentifié)
  if (permissionsToCheck.length === 0) {
    return <div className={className}>{children}</div>;
  }

  // Vérifier les permissions selon le mode requis
  let hasRequiredPermissions = false;

  if (requireAll) {
    // Toutes les permissions sont requises
    hasRequiredPermissions = hasAllPermissions(permissionsToCheck);
  } else {
    // Au moins une permission est requise
    hasRequiredPermissions = hasAnyPermission(permissionsToCheck);
  }

  // Afficher le contenu ou le fallback selon les permissions
  if (hasRequiredPermissions) {
    return <div className={className}>{children}</div>;
  }

  return <>{fallback}</>;
};

export default ProtectedView;