import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest'
import type { NextRequest } from 'next/server'

// Mock rate limiter
vi.mock('@/lib/rate-limiter', () => ({
  rateLimit: vi.fn().mockResolvedValue(undefined),
}))

// Mock auth
vi.mock('@/lib/auth', () => ({
  requireAuth: vi.fn(),
}))

// Mock orangeMoneyService
vi.mock('@/services/orangeMoneyService', () => ({
  orangeMoneyService: {
    getBalance: vi.fn(),
  },
}))

// Import mocked modules
import * as auth from '@/lib/auth'
import * as rateLimiter from '@/lib/rate-limiter'
import { orangeMoneyService } from '@/services/orangeMoneyService'

// Import handler AFTER mocks
import { GET } from '@/app/api/admin/orange-money/balance/route'

describe('API GET /api/admin/orange-money/balance', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  afterEach(() => {
    vi.restoreAllMocks()
  })

  it('returns 200 with balance data for admin user', async () => {
    // Arrange
    const adminUser = {
      id: 'admin1',
      email: 'admin@test.com',
      firstName: 'Admin',
      lastName: 'User',
      roles: ['ADMIN'],
      permissions: [],
    }
    ;(auth.requireAuth as any).mockResolvedValue(adminUser)

    const mockBalance = {
      value: 50000,
      unit: 'XOF',
    }
    ;(orangeMoneyService.getBalance as any).mockResolvedValue(mockBalance)

    const req = new Request('http://localhost/api/admin/orange-money/balance', {
      method: 'GET',
      headers: {
        Authorization: 'Bearer valid-token',
      },
    }) as unknown as NextRequest

    // Act
    const res = await GET(req)

    // Assert
    expect(rateLimiter.rateLimit).toHaveBeenCalled()
    expect(auth.requireAuth).toHaveBeenCalledWith(req)
    expect(orangeMoneyService.getBalance).toHaveBeenCalled()

    expect(res.status).toBe(200)
    const body = await res.json()

    expect(body.success).toBe(true)
    expect(body.data).toEqual(mockBalance)
    expect(body.data.value).toBe(50000)
    expect(body.data.unit).toBe('XOF')
  })

  it('returns 403 for non-admin user', async () => {
    // Arrange
    const regularUser = {
      id: 'user1',
      email: 'user@test.com',
      firstName: 'Regular',
      lastName: 'User',
      roles: ['CLIENT'],
      permissions: [],
    }
    ;(auth.requireAuth as any).mockResolvedValue(regularUser)

    const req = new Request('http://localhost/api/admin/orange-money/balance', {
      method: 'GET',
      headers: {
        Authorization: 'Bearer valid-token',
      },
    }) as unknown as NextRequest

    // Act
    const res = await GET(req)

    // Assert
    expect(auth.requireAuth).toHaveBeenCalledWith(req)
    expect(orangeMoneyService.getBalance).not.toHaveBeenCalled()

    expect(res.status).toBe(403)
    const body = await res.json()

    expect(body.success).toBe(false)
    expect(body.error.code).toBeDefined()
  })

  it('returns 401 when authentication fails', async () => {
    // Arrange
    ;(auth.requireAuth as any).mockRejectedValue(new Error('Unauthorized'))

    const req = new Request('http://localhost/api/admin/orange-money/balance', {
      method: 'GET',
    }) as unknown as NextRequest

    // Act
    const res = await GET(req)

    // Assert
    expect(auth.requireAuth).toHaveBeenCalledWith(req)
    expect(orangeMoneyService.getBalance).not.toHaveBeenCalled()

    expect(res.status).toBeGreaterThanOrEqual(400)
    const body = await res.json()

    expect(body.success).toBe(false)
  })
})
