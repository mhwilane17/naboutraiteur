import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest'
import type { NextRequest } from 'next/server'

// Mocks des modules utilisés par le handler
vi.mock('@/lib/rate-limiter', () => ({
  rateLimit: vi.fn().mockResolvedValue(undefined),
}))

// Mock complet de l'auth: requireAuth et hasRole (string | string[])
vi.mock('@/lib/auth', () => ({
  requireAuth: vi.fn(),
  hasRole: (user: any, roles: string | string[]) => {
    const arr = Array.isArray(roles) ? roles : [roles]
    return arr.some((r) => user?.roles?.includes(r))
  },
}))

// Mock DB utils - fakeDb/fakeTx définis plus bas et mutables
let fakeDb: any
let fakeTx: any
vi.mock('@/lib/db', () => ({
  withDatabase: vi.fn((operation: any) => operation(fakeDb)),
  withTransaction: vi.fn((operation: any) => operation(fakeTx)),
}))

// Importer les modules mockés pour accéder aux espions
import * as auth from '@/lib/auth'
import * as db from '@/lib/db'

// Import du handler APRÈS avoir défini les mocks
import { PUT } from '@/app/api/companies/[id]/route'

function makeNextRequest(url: string, method: string, body?: any): NextRequest {
  const init: RequestInit = { method, headers: { 'content-type': 'application/json', authorization: 'Bearer token' } }
  if (body !== undefined) init.body = JSON.stringify(body)
  return new Request(url, init) as unknown as NextRequest
}

describe('API PUT /api/companies/[id]', () => {
  beforeEach(() => {
    vi.clearAllMocks()

    fakeDb = {
      company: {
        findUnique: vi.fn(),
      },
      category: {
        findMany: vi.fn(),
      },
    }

    fakeTx = {
      company: {
        update: vi.fn(),
        findUnique: vi.fn(),
      },
      companyCategoryLimit: {
        findMany: vi.fn(),
        upsert: vi.fn(),
        deleteMany: vi.fn(),
      },
    }
  })

  afterEach(() => {
    vi.restoreAllMocks()
  })

  it('met à jour une entreprise et gère les limites de catégories (upsert + delete)', async () => {
    // Arrange
    const user = { id: 'u1', email: 'admin@test.com', firstName: 'A', lastName: 'B', roles: ['ADMIN'], permissions: [] }
    ;(auth.requireAuth as any).mockResolvedValue(user)

    // Entreprise existante
    ;(fakeDb as any).company.findUnique = vi.fn().mockResolvedValue({ id: 'comp1' })

    // Catégories existantes
    ;(fakeDb as any).category.findMany = vi.fn().mockResolvedValue([{ id: 'cat1' }, { id: 'cat2' }])

    // Limites existantes avant màj
    ;(fakeTx as any).companyCategoryLimit.findMany = vi.fn().mockResolvedValue([
      { categoryId: 'cat1' },
      { categoryId: 'cat3' },
    ])

    // Retour de la company après transaction
    ;(fakeTx as any).company.findUnique = vi.fn().mockResolvedValue({
      id: 'comp1',
      name: 'Compagnie X',
      contactEmail: 'c@example.com',
      isActive: true,
      createdAt: new Date('2024-01-01'),
      updatedAt: new Date('2024-01-02'),
      users: [],
      limits: [
        { categoryId: 'cat1', maxPerOrder: 5, category: { id: 'cat1', name: 'Cat 1' } },
        { categoryId: 'cat2', maxPerOrder: 2, category: { id: 'cat2', name: 'Cat 2' } },
      ],
    })

    const body = {
      name: 'Compagnie X',
      contactEmail: 'c@example.com',
      isActive: true,
      limits: [
        { categoryId: 'cat1', maxPerOrder: 5 }, // reste
        { categoryId: 'cat2', maxPerOrder: 2 }, // upsert
      ],
    }

    const req = makeNextRequest('http://localhost/api/companies/comp1', 'PUT', body)

    // Act
    const res = await PUT(req, { params: Promise.resolve({ id: 'comp1' }) })

    // Assert
    expect(db.withDatabase).toHaveBeenCalled()
    expect(db.withTransaction).toHaveBeenCalled()

    expect((fakeTx as any).companyCategoryLimit.upsert).toHaveBeenCalledTimes(2)
    expect((fakeTx as any).companyCategoryLimit.deleteMany).toHaveBeenCalledWith({
      where: { companyId: 'comp1', categoryId: { in: ['cat3'] } },
    })

    expect(res.status).toBe(200)
    const json = await res.json()
    expect(json.success).toBe(true)
    expect(json.data).toMatchObject({
      id: 'comp1',
      name: 'Compagnie X',
      limits: [
        { categoryId: 'cat1', maxPerOrder: 5 },
        { categoryId: 'cat2', maxPerOrder: 2 },
      ],
    })
  })

  it("retourne 404 si l'entreprise n'existe pas", async () => {
    // Arrange
    const user = { id: 'u1', email: 'admin@test.com', firstName: 'A', lastName: 'B', roles: ['ADMIN'], permissions: [] }
    ;(auth.requireAuth as any).mockResolvedValue(user)

    ;(fakeDb as any).company.findUnique = vi.fn().mockResolvedValue(null)

    const req = makeNextRequest('http://localhost/api/companies/bad-id', 'PUT', {})

    // Act
    const res = await PUT(req, { params: Promise.resolve({ id: 'bad-id' }) })

    // Assert
    expect(res.status).toBe(404)
    const json = await res.json()
    expect(json.success).toBe(false)
  })

  it('retourne 400 si des catégories fournies sont inexistantes', async () => {
    // Arrange
    const user = { id: 'u1', email: 'admin@test.com', firstName: 'A', lastName: 'B', roles: ['ADMIN'], permissions: [] }
    ;(auth.requireAuth as any).mockResolvedValue(user)

    ;(fakeDb as any).company.findUnique = vi.fn().mockResolvedValue({ id: 'comp1' })

    ;(fakeDb as any).category.findMany = vi.fn().mockResolvedValue([{ id: 'cat1' }])

    const req = makeNextRequest('http://localhost/api/companies/comp1', 'PUT', {
      limits: [
        { categoryId: 'cat1', maxPerOrder: 5 },
        { categoryId: 'cat2', maxPerOrder: 2 }, // inexistante
      ],
    })

    // Act
    const res = await PUT(req, { params: Promise.resolve({ id: 'comp1' }) })

    // Assert
    expect(res.status).toBe(400)
    const json = await res.json()
    expect(json.success).toBe(false)
    expect(json.error.message).toContain('Catégories inexistantes')
  })

  it("retourne 403 si l'utilisateur n'a pas le rôle requis", async () => {
    // Arrange
    const user = { id: 'u9', email: 'user@test.com', firstName: 'U', lastName: 'S', roles: ['CLIENT'], permissions: [] }
    ;(auth.requireAuth as any).mockResolvedValue(user)

    const req = makeNextRequest('http://localhost/api/companies/comp1', 'PUT', { name: 'X' })

    // Act
    const res = await PUT(req, { params: Promise.resolve({ id: 'comp1' }) })

    // Assert
    expect(res.status).toBe(403)
    const json = await res.json()
    expect(json.success).toBe(false)
  })
})