import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest'
import type { NextRequest } from 'next/server'

// Mocks des modules utilisés par le handler
vi.mock('@/lib/rate-limiter', () => ({
  rateLimit: vi.fn().mockResolvedValue(undefined),
}))

// Mock complet de l'auth: requireAuth et hasRole (gère string | string[])
vi.mock('@/lib/auth', () => ({
  requireAuth: vi.fn(),
  hasRole: (user: any, roles: string | string[]) => {
    const arr = Array.isArray(roles) ? roles : [roles]
    return Array.isArray(arr) && arr.some((r) => user?.roles?.includes(r))
  },
}))

// Mock de la DB utils
let fakeDb: any
vi.mock('@/lib/db', () => ({
  withDatabase: vi.fn((operation: any) => operation(fakeDb)),
}))

// Importer les modules mockés pour accéder aux espions
import * as auth from '@/lib/auth'
import * as rateLimiter from '@/lib/rate-limiter'
import * as db from '@/lib/db'

// Import du handler APRÈS avoir défini les mocks
import { GET } from '@/app/api/companies/route'

describe('API GET /api/companies', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    fakeDb = {
      company: {
        findMany: vi.fn(),
        count: vi.fn(),
      },
    }
  })

  afterEach(() => {
    vi.restoreAllMocks()
  })

  it('retourne 200 avec la liste des entreprises et pagination pour un utilisateur autorisé', async () => {
    // Arrange
    const user = { id: 'u1', email: 'admin@test.com', firstName: 'A', lastName: 'B', roles: ['SUPER_ADMIN'], permissions: [] }
    ;(auth.requireAuth as any).mockResolvedValue(user)

    const companies = [
      {
        id: 'c1',
        name: 'Comp 1',
        contactEmail: 'c1@test.com',
        isActive: true,
        createdAt: new Date('2024-01-01'),
        updatedAt: new Date('2024-01-02'),
        users: [
          { id: 'u1', firstName: 'John', lastName: 'Doe', email: 'john@c1.com', isActive: true, createdAt: new Date(), updatedAt: new Date() },
        ],
        limits: [
          { categoryId: 'cat1', maxPerOrder: 3, category: { id: 'cat1', name: 'Cat 1' } },
        ],
      },
      {
        id: 'c2',
        name: 'Comp 2',
        contactEmail: 'c2@test.com',
        isActive: false,
        createdAt: new Date('2024-02-01'),
        updatedAt: new Date('2024-02-02'),
        users: [],
        limits: [],
      },
    ]

    ;(db as any).withDatabase.mock.calls // access ensures mock is bound
    ;(fakeDb as any).company.findMany = vi.fn().mockResolvedValue(companies)
    ;(fakeDb as any).company.count = vi.fn().mockResolvedValue(2)

    const req = new Request('http://localhost/api/companies?page=1&limit=10', { method: 'GET' }) as unknown as NextRequest

    // Act
    const res = await GET(req)

    // Assert
    expect(rateLimiter.rateLimit).toHaveBeenCalled()
    expect(db.withDatabase).toHaveBeenCalled()

    expect(res.status).toBe(200)
    const body = await res.json()

    expect(body.success).toBe(true)
    // Le handler enveloppe les données comme { data: formatted, pagination: {...} }
    expect(Array.isArray(body.data.data)).toBe(true)
    expect(body.data.data.length).toBe(2)
    expect(body.data.pagination.total).toBe(2)
    expect(body.data.pagination.page).toBe(1)
    expect(body.data.pagination.limit).toBe(10)

    // Vérifier quelques champs formatés
    expect(body.data.data[0]).toMatchObject({ id: 'c1', name: 'Comp 1', contactEmail: 'c1@test.com' })
  })

  it("retourne 403 si l'utilisateur n'a pas un rôle suffisant", async () => {
    // Arrange
    const user = { id: 'u2', email: 'user@test.com', firstName: 'U', lastName: 'S', roles: ['CLIENT'], permissions: [] }
    ;(auth.requireAuth as any).mockResolvedValue(user)

    ;(fakeDb as any).company.findMany = vi.fn().mockResolvedValue([])
    ;(fakeDb as any).company.count = vi.fn().mockResolvedValue(0)

    const req = new Request('http://localhost/api/companies?page=1&limit=10', { method: 'GET' }) as unknown as NextRequest

    // Act
    const res = await GET(req)

    // Assert
    expect(res.status).toBe(403)
    const body = await res.json()
    expect(body.success).toBe(false)
    expect(body.error.code).toBeDefined()
  })
})