import { ApiSuccessResponse } from './api';

export interface Company {
  id: string;
  name: string;
  contactEmail?: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CompanyUserSummary {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CompanyLimit {
  categoryId: string;
  maxPerOrder: number;
  category?: { id: string; name: string } | null;
}

export interface CompanyLimitInput {
  categoryId: string;
  maxPerOrder: number;
}

export interface CompanyWithRelations extends Company {
  users?: CompanyUserSummary[];
  limits: CompanyLimit[];
  stats?: {
    userCount: number;
    limitsCount: number;
  };
}

export type IsActiveFilter = 'all' | 'true' | 'false';

export interface CompanyFilters {
  search: string;
  isActive: IsActiveFilter;
}

export interface CompanyFormData {
  name: string;
  contactEmail?: string;
  isActive: boolean;
  limits: CompanyLimitInput[];
}

export interface CreateCompanyRequest {
  name: string;
  contactEmail?: string;
  isActive?: boolean;
  limits?: CompanyLimitInput[];
}

export interface UpdateCompanyRequest {
  name?: string;
  contactEmail?: string; // API attend un email string si fourni
  isActive?: boolean;
  limits?: CompanyLimitInput[];
}

export interface CompaniesListParams {
  page?: number;
  limit?: number;
  search?: string;
  isActive?: 'true' | 'false';
}

export interface CompaniesApiResponse extends ApiSuccessResponse<CompanyWithRelations[]> {
  pagination: { page: number; limit: number; total: number; totalPages: number };
}

export type CompanyApiResponse = ApiSuccessResponse<CompanyWithRelations>;