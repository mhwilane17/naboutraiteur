export interface WeeklyMenuDish {
  id: string;
  menuItemId: string;
  dayOfWeek: number;
  mealType: "lunch" | "dinner";
  isAvailable: boolean;
  specialPrice?: number;
  hasRakTakPromo?: boolean;
  quantity?: number;
  menuItem?: {
    id: string;
    name: string;
    description: string;
    price: number;
    image: string;
    category?: {
      id: string;
      name: string;
      color: string;
      icon: string;
    };
    options?: {
      id: string;
      name: string;
      type: string;
      values: {
        name: string;
        price: number;
        description?: string;
      }[];
      isRequired?: boolean;
      sortOrder?: number;
    }[];
  };
}

export interface WeeklyMenu {
  id: string;
  name: string;
  description?: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  isPublished?: boolean;
  totalPrice?: number;
  dishes: WeeklyMenuDish[];
  createdAt: string;
  updatedAt: string;
}

export interface CreateWeeklyMenuData {
  name: string;
  description?: string;
  startDate: string;
  endDate: string;
  isActive?: boolean;
  isPublished?: boolean;
  totalPrice?: number;
  dishes?: {
    menuItemId: string;
    dayOfWeek: number;
    mealType: "lunch" | "dinner";
    isAvailable?: boolean;
    specialPrice?: number;
    hasRakTakPromo?: boolean;
    quantity?: number;
  }[];
}

export interface UpdateWeeklyMenuData extends Partial<CreateWeeklyMenuData> {
  id: string;
}

export interface WeeklyMenuState {
  weeklyMenus: WeeklyMenu[];
  loading: boolean;
  error: string | null;
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  } | null;
}

export interface WeeklyMenuActions {
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  setWeeklyMenus: (weeklyMenus: WeeklyMenu[]) => void;
  setPagination: (pagination: WeeklyMenuState["pagination"]) => void;
  fetchWeeklyMenus: (params?: {
    page?: number;
    limit?: number;
    search?: string;
    isActive?: boolean;
    isPublished?: boolean;
    startDate?: string;
    endDate?: string;
    sortBy?: string;
    sortOrder?: "asc" | "desc";
    includeDishes?: boolean;
    includeStats?: boolean;
    employee?: string;
  }) => Promise<void>;
  createWeeklyMenu: (data: CreateWeeklyMenuData) => Promise<WeeklyMenu | null>;
  updateWeeklyMenu: (data: UpdateWeeklyMenuData) => Promise<WeeklyMenu | null>;
  deleteWeeklyMenu: (id: string) => Promise<boolean>;
  refreshWeeklyMenus: () => Promise<void>;
}

export type WeeklyMenuStore = WeeklyMenuState & WeeklyMenuActions;

// Constantes utiles
export const DAYS_OF_WEEK = {
  MONDAY: 1,
  TUESDAY: 2,
  WEDNESDAY: 3,
  THURSDAY: 4,
  FRIDAY: 5,
  SATURDAY: 6,
  SUNDAY: 0,
} as const;

export const MEAL_TYPES = {
  LUNCH: "lunch",
  DINNER: "dinner",
} as const;

export const DAY_LABELS = {
  [DAYS_OF_WEEK.MONDAY]: "Lundi",
  [DAYS_OF_WEEK.TUESDAY]: "Mardi",
  [DAYS_OF_WEEK.WEDNESDAY]: "Mercredi",
  [DAYS_OF_WEEK.THURSDAY]: "Jeudi",
  [DAYS_OF_WEEK.FRIDAY]: "Vendredi",
  [DAYS_OF_WEEK.SATURDAY]: "Samedi",
  [DAYS_OF_WEEK.SUNDAY]: "Dimanche",
} as const;
