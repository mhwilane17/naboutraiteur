// export interface MenuItem {
//   id?: string;
//   menuItemId?: string;
//   name: string;
//   options: {
//     name: string;
//     price: number;
//   }[];
//   rating: number;
//   reviews: number;
//   image: string;
//   status: "available" | "upcoming" | "past";
//   day: string;
//   description?: string;
//   category: "plat" | "dessert" | "boisson" | "diet" | "salade" | "fastfood";
//   hasRakTakPromo?: boolean;
// }
export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price?: number;
  image: string;
  isAvailable?: boolean;
  isActive?: boolean;
  preparationTime?: number;
  createdAt: string;
  updatedAt: string;
  category: {
    id: string;
    name: string;
    color: string;
    icon: string;
  };
  options: {
    id: string;
    name: string;
    type: string;
    values: {
      name: string;
      price: number;
      description?: string;
    }[];
    isRequired?: boolean;
    sortOrder?: number;
  }[];
}



export interface MenuItemOption {
  id?: string;
  name: string;
  type: string;
  values: {
    name: string;
    price: number;
    isAvailable?: boolean;
  }[];
  isRequired?: boolean;
  maxSelections?: number;
  sortOrder?: number;
}

export interface CreateMenuItemData {
  name: string;
  description: string;
  price: number;
  image?: string;
  categoryId: string;
  isAvailable?: boolean;
  isActive?: boolean;
  preparationTime?: number;
  allergens?: string[];
  nutritionalInfo?: Record<string, any>;
  sortOrder?: number;
  options?: MenuItemOption[];
}

export interface UpdateMenuItemData extends Partial<CreateMenuItemData> {
  id: string;
}

export interface MenuItemsState {
  menuItems: MenuItem[];
  loading: boolean;
  error: string | null;
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  } | null;
}


export interface MenuFilter {
  key: string;
  label: string;
  color: string;
}

export interface DayOption {
  key: string;
  label: string;
}

export interface DeliveryTime {
  id: string;
  name: string;
}
