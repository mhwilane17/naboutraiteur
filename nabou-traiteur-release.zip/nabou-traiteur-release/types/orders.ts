// Types
export interface OrderItem {
  id: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  options?: any;
  notes?: string;
  menuItem: {
    id: string;
    name: string;
    price: number;
    imageUrl?: string;
  };
}

export interface Order {
  id: string;
  orderNumber: string;
  status:
    | "pending"
    | "confirmed"
    | "preparing"
    | "ready"
    | "delivered"
    | "cancelled";
  type: string;
  totalAmount: number;
  deliveryFee?: number;
  discountAmount: number;
  finalAmount: number;
  paymentStatus: "pending" | "paid" | "failed" | "refunded";
  paymentMethod?: string;
  deliveryAddress?: string;
  deliveryCity?: string;
  deliveryPostalCode?: string;
  deliveryPhone?: string;
  deliveryDate?: string;
  deliveryTime?: string;
  customerNotes?: string;
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
  customer?: {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    phone?: string;
  };
  weeklyMenu?: {
    id: string;
    name: string;
    startDate: string;
    endDate: string;
  };
  deliveryZone?: {
    id: string;
    name: string;
    deliveryFee: number;
    areas: [];
  };
  items: OrderItem[];
  itemsCount: number;
  transactions?: any[];
  paymentInit?: {
    qrCode: string;
    payment_link?: Record<string, string>;
  };
  promotionUsage?: {
    id: string;
    discountAmount: string;
    usedAt: string;
    promotionId: string;
    userId: string | null;
    orderId: string;
    promotion: {
      id: string;
      name: string;
      code: string;
      type: "percentage" | "fixed";
      value: string;
    };
  }[];
}

export interface OrderFilters {
  page?: number;
  limit?: number;
  status?: string;
  type?: string;
  paymentStatus?: string;
  customerId?: string;
  startDate?: string;
  endDate?: string;
  search?: string;
  sortBy?: "createdAt" | "orderNumber" | "finalAmount" | "deliveryDate";
  sortOrder?: "asc" | "desc";
}

export interface OrdersResponse {
  orders: Order[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}
