/**
 * Types pour l'API publique du menu hebdomadaire
 */

/**
 * Interface pour les options de menu (tailles, variantes, etc.)
 */
export interface MenuItemOption {
  name: string;
  // Prix final (après éventuelle remise)
  price: number;
  // Prix d'origine (avant remise) – présent si une promo est appliquée
  discountPrice?: number;
  // Montant de la remise nette appliquée sur cette option
  discountAmount?: number;
}

/**
 * Statut possible d'un plat dans le menu
 */
export type MenuItemStatus = "available" | "unavailable" | "sold_out";

/**
 * Catégories de plats disponibles
 */
export type MenuItemCategory = "plat" | "dessert" | "boisson" | "diet" | "salade" | "fastfood";

/**
 * Interface pour un plat du menu hebdomadaire retourné par l'API
 */
export interface WeeklyMenuItem {
  // Informations de base
  id: string;
  menuItemId: string;
  weeklyMenuId: string;
  name: string;
  description?: string;
  image: string;
  category: MenuItemCategory;

  // Options et prix
  options: MenuItemOption[];
  specialPrice: number | null;

  // Statut et disponibilité
  status: MenuItemStatus;
  isAvailable: boolean;
  quantity: number;

  // Informations temporelles
  day: string;
  dayOfWeek: number;
  mealType: string;
  preparationTime?: number;

  // Conditions de commande
  isCurrentDay: boolean;
  canOrderNow: boolean;

  // Promotions
  hasRakTakPromo: boolean;
  rakTakPromoCode: string | null;
}

/**
 * Interface pour les statistiques du menu hebdomadaire
 */
export interface WeeklyMenuStats {
  menusCount: number;
  totalDishes: number;
  daysWithMeals: number;
}

/**
 * Interface pour la réponse de l'API du menu hebdomadaire
 */
export interface WeeklyMenuResponse {
  success: boolean;
  data: {
    weeklyMenu: Record<string, WeeklyMenuItem[]>;
    stats: WeeklyMenuStats;
  };
}

/**
 * Interface pour le hook useWeeklyMenu
 */
export interface UseWeeklyMenuReturn {
  weeklyMenu: Record<string, WeeklyMenuItem[]>;
  loading: boolean;
  error: string | null;
  stats: WeeklyMenuStats | null;
  refetch: () => Promise<void>;
}

/**
 * Options de jour pour les filtres
 */
export interface DayOption {
  key: string;
  label: string;
}

/**
 * Options de filtre pour les catégories
 */
export interface MenuFilter {
  key: string;
  label: string;
  color: string;
}
