import { ApiSuccessResponse } from './api';

// Core Role interface based on Prisma model
export interface Role {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  permissions: Permission[];
  userCount: number;
}

// Core Permission interface based on Prisma model
export interface Permission {
  id: string;
  name: string;
  description?: string;
  module: string;
  action: string;
  createdAt: string;
  updatedAt: string;
}

// Form data interface for role creation and editing
export interface RoleFormData {
  name: string;
  description: string;
  permissions: string[];
  isActive: boolean;
}

// Filters interface for role list filtering
export interface RoleFilters {
  search: string;
  status: 'all' | 'active' | 'inactive';
}

// API Request types
export interface CreateRoleRequest {
  id: string;
  name: string;
  description?: string;
  isActive?: boolean;
  permissionIds?: string[];
}

export interface UpdateRoleRequest {
  name?: string;
  description?: string;
  isActive?: boolean;
  permissionIds?: string[];
}

// API Response types
export interface RolesApiResponse extends ApiSuccessResponse<Role[]> {
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface RoleApiResponse extends ApiSuccessResponse<Role> {}

export interface PermissionsApiResponse extends ApiSuccessResponse<Permission[]> {
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// Error codes enum
export enum RoleErrorCodes {
  ROLE_NOT_FOUND = 'ROLE_NOT_FOUND',
  ROLE_NAME_EXISTS = 'ROLE_NAME_EXISTS',
  ROLE_ID_EXISTS = 'ROLE_ID_EXISTS',
  CANNOT_DELETE_ROLE_WITH_USERS = 'CANNOT_DELETE_ROLE_WITH_USERS',
  CANNOT_DELETE_SYSTEM_ROLE = 'CANNOT_DELETE_SYSTEM_ROLE',
  INVALID_PERMISSIONS = 'INVALID_PERMISSIONS',
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  INSUFFICIENT_PERMISSIONS = 'INSUFFICIENT_PERMISSIONS'
}

// Error messages mapping
export const RoleErrorMessages: Record<RoleErrorCodes, string> = {
  [RoleErrorCodes.ROLE_NOT_FOUND]: 'Rôle introuvable',
  [RoleErrorCodes.ROLE_NAME_EXISTS]: 'Un rôle avec ce nom existe déjà',
  [RoleErrorCodes.ROLE_ID_EXISTS]: 'Un rôle avec cet identifiant existe déjà',
  [RoleErrorCodes.CANNOT_DELETE_ROLE_WITH_USERS]: 'Impossible de supprimer ce rôle car il est assigné à des utilisateurs',
  [RoleErrorCodes.CANNOT_DELETE_SYSTEM_ROLE]: 'Impossible de supprimer un rôle système',
  [RoleErrorCodes.INVALID_PERMISSIONS]: 'Permissions invalides ou inexistantes',
  [RoleErrorCodes.VALIDATION_ERROR]: 'Erreur de validation des données',
  [RoleErrorCodes.INSUFFICIENT_PERMISSIONS]: 'Permissions insuffisantes pour cette action'
};

// Role status constants
export const RoleStatus = {
  ACTIVE: 'active',
  INACTIVE: 'inactive',
  ALL: 'all'
} as const;

export type RoleStatusType = typeof RoleStatus[keyof typeof RoleStatus];

// Default role constants
export const DefaultRoles = {
  ADMIN: 'admin',
  MANAGER: 'manager',
  CLIENT: 'client'
} as const;

export type DefaultRoleType = typeof DefaultRoles[keyof typeof DefaultRoles];

// Permission module constants
export const PermissionModules = {
  USERS: 'users',
  ROLES: 'roles',
  ORDERS: 'orders',
  MENU: 'menu',
  CATEGORIES: 'categories',
  PROMOTIONS: 'promotions',
  DELIVERY: 'delivery',
  PAYMENTS: 'payments',
  ANALYTICS: 'analytics',
  SETTINGS: 'settings'
} as const;

export type PermissionModuleType = typeof PermissionModules[keyof typeof PermissionModules];

// Permission action constants
export const PermissionActions = {
  CREATE: 'create',
  READ: 'read',
  UPDATE: 'update',
  DELETE: 'delete',
  MANAGE: 'manage'
} as const;

export type PermissionActionType = typeof PermissionActions[keyof typeof PermissionActions];

// Utility type for role creation form
export interface RoleCreationForm extends RoleFormData {
  id: string;
}

// Utility type for role update form
export interface RoleUpdateForm extends RoleFormData {
  id: string;
}

// Type for role list item display
export interface RoleListItem {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  userCount: number;
  permissionCount: number;
  createdAt: string;
  updatedAt: string;
}

// Type for permission list item display
export interface PermissionListItem {
  id: string;
  name: string;
  description?: string;
  module: string;
  action: string;
}

// Type for role search and filter parameters
export interface RoleSearchParams {
  page?: number;
  limit?: number;
  search?: string;
  status?: RoleStatusType;
  sortBy?: 'name' | 'createdAt' | 'updatedAt' | 'userCount';
  sortOrder?: 'asc' | 'desc';
}

// Type for permission search and filter parameters
export interface PermissionSearchParams {
  page?: number;
  limit?: number;
  search?: string;
  module?: PermissionModuleType;
  action?: PermissionActionType;
  sortBy?: 'name' | 'module' | 'action' | 'createdAt';
  sortOrder?: 'asc' | 'desc';
}

// Type for role statistics
export interface RoleStats {
  total: number;
  active: number;
  inactive: number;
  withUsers: number;
}

// Type for permission statistics
export interface PermissionStats {
  total: number;
  byModule: Record<string, number>;
  byAction: Record<string, number>;
}

// Type for role-permission relationship
export interface RolePermissionRelation {
  roleId: string;
  permissionId: string;
  grantedAt: string;
  grantedBy?: string;
}

// Type for user-role relationship
export interface UserRoleRelation {
  userId: string;
  roleId: string;
  assignedAt: string;
  assignedBy?: string;
}

// Type for grouped permissions (by module)
export interface GroupedPermissions {
  [module: string]: Permission[];
}

// Type for role with detailed information
export interface RoleDetails extends Role {
  users: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
  }[];
  permissionsByModule: GroupedPermissions;
}

// Type for bulk role operations
export interface BulkRoleOperation {
  roleIds: string[];
  operation: 'activate' | 'deactivate' | 'delete';
}

// Type for role validation result
export interface RoleValidationResult {
  isValid: boolean;
  errors: {
    field: string;
    message: string;
  }[];
}

// Type for permission validation result
export interface PermissionValidationResult {
  isValid: boolean;
  errors: {
    field: string;
    message: string;
  }[];
}

// Type for role assignment to user
export interface RoleAssignment {
  userId: string;
  roleIds: string[];
  assignedBy?: string;
}

// Type for role history/audit
export interface RoleAuditLog {
  id: string;
  roleId: string;
  action: 'created' | 'updated' | 'deleted' | 'activated' | 'deactivated';
  changes: Record<string, any>;
  performedBy: string;
  performedAt: string;
}