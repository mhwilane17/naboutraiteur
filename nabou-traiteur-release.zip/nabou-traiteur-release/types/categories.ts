export interface Category {
  id: string;
  name: string;
  description?: string;
  color: string;
  icon: string;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
  stats?: {
    totalMenuItems: number;
    activeMenuItems: number;
    availableMenuItems?: number;
    averagePrice?: number;
  };
  menuItems?: MenuItem[];
}

export interface MenuItem {
  id: string;
  name: string;
  price?: number;
  image?: string;
  isAvailable?: boolean;
  isActive: boolean;
  preparationTime?: number;
  createdAt: string;
}

export interface CategoryFormData {
  id?: string;
  name: string;
  description?: string;
  color: string;
  icon: string;
  isActive?: boolean;
  sortOrder?: number;
}

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
}

export interface ApiError {
  success: false;
  error: string;
  message: string;
}

// Couleurs disponibles pour les catégories
export const availableColors = [
  { value: "red", label: "Rouge", class: "bg-red-500" },
  { value: "orange", label: "Orange", class: "bg-orange-500" },
  { value: "yellow", label: "Jaune", class: "bg-yellow-500" },
  { value: "green", label: "Vert", class: "bg-green-500" },
  { value: "blue", label: "Bleu", class: "bg-blue-500" },
  { value: "purple", label: "Violet", class: "bg-purple-500" },
  { value: "pink", label: "Rose", class: "bg-pink-500" },
  { value: "gray", label: "Gris", class: "bg-gray-500" },
];

// Icônes disponibles
export const availableIcons = [
  { value: "utensils", label: "Couverts" },
  { value: "coffee", label: "Café" },
  { value: "pizza", label: "Pizza" },
  { value: "fish", label: "Poisson" },
  { value: "drumstick", label: "Viande" },
  { value: "carrot", label: "Légumes" },
  { value: "cake", label: "Dessert" },
  { value: "wine", label: "Boisson" },
];

// Données initiales
export const initialCategories: Category[] = [
  {
    id: "CAT001",
    name: "Plats",
    description: "Plats principaux traditionnels sénégalais et internationaux",
    color: "orange",
    icon: "utensils",
    isActive: true,
    sortOrder: 0,
    createdAt: "2024-01-01T00:00:00",
    updatedAt: "2024-12-19T10:00:00",
    stats: {
      totalMenuItems: 15,
      activeMenuItems: 15,
    },
  },
  {
    id: "CAT002",
    name: "Diet",
    description: "Plats équilibrés et healthy pour une alimentation saine",
    color: "green",
    icon: "carrot",
    isActive: true,
    sortOrder: 1,
    createdAt: "2024-01-15T10:00:00",
    updatedAt: "2024-12-19T10:00:00",
    stats: {
      totalMenuItems: 8,
      activeMenuItems: 8,
    },
  },
  {
    id: "CAT003",
    name: "Salades",
    description: "Salades fraîches et variées avec accompagnements",
    color: "green",
    icon: "carrot",
    isActive: true,
    sortOrder: 2,
    createdAt: "2024-02-01T10:00:00",
    updatedAt: "2024-12-19T10:00:00",
    stats: {
      totalMenuItems: 6,
      activeMenuItems: 6,
    },
  },
  {
    id: "CAT004",
    name: "Fast Food",
    description: "Restauration rapide et burgers gourmets",
    color: "red",
    icon: "pizza",
    isActive: true,
    sortOrder: 3,
    createdAt: "2024-02-15T10:00:00",
    updatedAt: "2024-12-19T10:00:00",
    stats: {
      totalMenuItems: 4,
      activeMenuItems: 4,
    },
  },
  {
    id: "CAT005",
    name: "Desserts",
    description: "Douceurs et desserts traditionnels et modernes",
    color: "pink",
    icon: "cake",
    isActive: true,
    sortOrder: 4,
    createdAt: "2024-03-01T10:00:00",
    updatedAt: "2024-12-19T10:00:00",
    stats: {
      totalMenuItems: 3,
      activeMenuItems: 3,
    },
  },
  {
    id: "CAT006",
    name: "Boissons",
    description: "Boissons traditionnelles, jus frais et boissons modernes",
    color: "blue",
    icon: "wine",
    isActive: true,
    sortOrder: 5,
    createdAt: "2024-03-15T10:00:00",
    updatedAt: "2024-12-19T10:00:00",
    stats: {
      totalMenuItems: 5,
      activeMenuItems: 5,
    },
  },
];