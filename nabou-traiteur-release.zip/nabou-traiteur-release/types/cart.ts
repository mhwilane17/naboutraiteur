import { WeeklyMenuItem } from './weeklyMenuPublic';
import { OrderItem, Order } from './orders';
import { OrderFormData, PromoState, StepValidationResult } from '../lib/reservation-utils';
import { ReservationSubmissionData } from '../services/reservationService';
import { DeliveryZone } from '../services/deliveryService';
import { PaymentMethod } from '../services/paymentService';
import { DeliveryTime } from './menu';
import { GuestOrderData } from '../services/orderService';

/**
 * Interface pour un article dans le panier
 * Basée sur WeeklyMenuItem avec des propriétés spécifiques au panier
 */
export interface CartItem {
  /** Identifiant unique pour la ligne (menuItemId + options hash) */
  id: string;
  /** ID du menu item d'origine */
  menuItemId: string;
  /** Nom du plat */
  name: string;
  /** URL de l'image du plat */
  image: string;
  /** Quantité sélectionnée */
  quantity: number;
  /** Prix unitaire de l'option sélectionnée */
  unitPrice: number;
  /** Prix total (unitPrice * quantity) */
  totalPrice: number;
  /** Options sélectionnées pour cet article */
  options: {
    /** Taille/option sélectionnée */
    size: string;
    /** Autres options possibles */
    [key: string]: any;
  };
  /** ID du menu hebdomadaire */
  weeklyMenuId: string;
  /** Catégorie du plat */
  category: string;
  /** Jour de la semaine (format string) */
  day: string;
  /** Jour de la semaine (format numérique) */
  dayOfWeek: number;
  /** Type de repas (lunch/dinner) */
  mealType: string;
  rakTakPromoCode: string | null
}

/**
 * Interface pour la persistance dans localStorage
 */
export interface CartStorage {
  /** Liste des articles du panier */
  items: CartItem[];
  /** Timestamp de la dernière modification */
  timestamp: number;
  /** Version du schéma pour migration future */
  version: string;
}

/**
 * Interface étendue pour la persistance incluant les nouvelles données
 */
export interface ExtendedCartStorage extends CartStorage {
  // Données existantes (héritées de CartStorage)
  items: CartItem[];
  timestamp: number;
  version: string;

  // Nouvelles données à persister
  formData?: Partial<OrderFormData>;
  selectedDeliveryZone?: DeliveryZone;
  appliedPromoCode?: string;
  modalState?: {
    lastStep: number;
  };
}

/**
 * Actions disponibles pour le store du panier
 */
export interface CartActions {
  /** Ajouter un article au panier */
  addItem: (item: WeeklyMenuItem, quantity: number, selectedSize: string) => Promise<void>;
  /** Supprimer un article du panier */
  removeItem: (itemId: string) => void;
  /** Mettre à jour la quantité d'un article */
  updateQuantity: (itemId: string, quantity: number) => void;
  /** Vider complètement le panier */
  clearCart: () => void;
  /** Vider le panier après une commande réussie et retourner le nombre d'articles supprimés */
  clearCartAfterOrder: () => number;
  /** Ouvrir l'interface du panier */
  openCart: () => void;
  /** Fermer l'interface du panier */
  closeCart: () => void;
  /** Convertir le panier en format OrderItem pour l'API */
  getCartForOrder: () => OrderItem[];
  /** Convertir le panier en format pour l'API guest order */
  getCartForGuestOrder: () => Array<{
    menuItemId: string;
    quantity: number;
    options?: any;
  }>;
  /** Recalculer les totaux du panier */
  calculateTotals: () => Promise<void>;
  /** Générer un ID unique pour un article du panier */
  generateCartItemId: (menuItemId: string, options: any) => string;
  /** Définir la zone de livraison */
  setDeliveryZone: (zone: any | null) => void;
  /** Appliquer un code promo */
  applyPromoCode: (code: string, discount: number, isFreeDelivery?: boolean) => void;
  /** Supprimer le code promo */
  removePromoCode: () => void;
}

/**
 * État du panier
 */
export interface CartState {
  /** Liste des articles dans le panier */
  items: CartItem[];
  /** Nombre total d'articles */
  totalItems: number;
  /** Sous-total du panier */
  subtotal: number;
  /** Frais de livraison */
  deliveryFee: number;
  /** Montant de la réduction promo */
  promoDiscount: number;
  /** Livraison gratuite via promo */
  isFreeDelivery: boolean;
  /** Total final (subtotal + deliveryFee - promoDiscount) */
  total: number;
  /** Zone de livraison sélectionnée */
  selectedDeliveryZone: any | null;
  /** Code promo appliqué */
  appliedPromoCode: string | null;
  /** État d'ouverture de l'interface du panier */
  isOpen: boolean;
}

/**
 * État de gestion des commandes
 */
export interface OrderState {
  isLoading: boolean;
  isSubmitting: boolean;
  error: string | null;
  submissionError: string | null;
  currentOrder: Order | null;
}

/**
 * État du modal de commande
 */
export interface ModalState {
  isOpen: boolean;
  step: number;
}

/**
 * Configuration pour les zones de livraison et méthodes de paiement
 */
export interface OrderConfig {
  deliveryZones: DeliveryZone[];
  paymentMethods: PaymentMethod[];
  deliveryTimes: DeliveryTime[];
}

/**
 * État étendu du panier incluant la gestion des commandes
 */
export interface ExtendedCartState extends CartState {
  // États existants du panier (hérités de CartState)
  // items, totalItems, subtotal, deliveryFee, etc.

  // Nouveaux états pour la gestion des commandes
  orderState: OrderState;

  // États du modal de commande
  modalState: ModalState;

  // Données du formulaire (réutilise OrderFormData existant)
  formData: OrderFormData;

  // État des codes promo (réutilise PromoState existant)
  promoState: PromoState;

  // Configuration
  configState: OrderConfig;
}

/**
 * Actions pour la gestion des commandes
 */
export interface OrderActions {
  createOrder: (orderData: GuestOrderData) => Promise<Order | null>;
  getOrder: (orderId: string) => Promise<Order | null>;
  getOrderByNumber: (orderNumber: string) => Promise<Order | null>;
  submitDirectOrder: (item: WeeklyMenuItem, data: ReservationSubmissionData) => Promise<Order | null>;
  submitCartOrder: (formData: OrderFormData, promoCode?: string) => Promise<Order | null>;
  clearOrderError: () => void;
  resetOrderState: () => void;
}

/**
 * Actions du modal
 */
export interface ModalActions {
  openModal: () => void;
  closeModal: () => void;
  setStep: (step: number) => void;
  nextStep: () => void;
  previousStep: () => void;
  resetModal: () => void;
  getStepCount: () => number;
  getStepTitle: (step?: number) => string;
  canGoNext: () => boolean;
  canGoPrevious: () => boolean;
}

/**
 * Interface pour la validation d'un champ individuel
 */
export interface FieldValidationResult {
  isValid: boolean;
  errors?: string[];
}

/**
 * Interface pour la validation de tous les champs
 */
export interface AllFieldsValidationResult {
  isValid: boolean;
  errors?: { [key: string]: string[] };
}

/**
 * Actions du formulaire
 */
export interface FormActions {
  updateFormData: (field: string, value: string) => void;
  setFormData: (data: Partial<OrderFormData>) => void;
  resetFormData: () => void;
  validateCurrentStep: () => StepValidationResult;
  validateField: (field: string, value: string) => FieldValidationResult;
  validateAllFields: () => AllFieldsValidationResult;
  getRequiredFields: () => string[];
  isStepValid: (step?: number) => boolean;
  getStepErrors: (step?: number) => string[];
}

/**
 * Interface pour le résumé d'un code promo appliqué
 */
export interface PromoSummary {
  code: string;
  discountAmount: number;
  isFreeDelivery: boolean;
  message: string | null;
}

/**
 * Actions des codes promo
 */
export interface PromoActions {
  setPromoCode: (code: string) => void;
  validatePromoCode: () => Promise<void>;
  applyPromoCode: (code: string, discount: number, isFreeDelivery?: boolean) => void;
  removePromoCode: () => void;
  resetPromoState: () => void;
  clearPromoMessage: () => void;
  isValidating: () => boolean;
  hasValidPromo: () => boolean;
  getPromoSummary: () => PromoSummary | null;
}

/**
 * Actions de configuration
 */
export interface ConfigActions {
  setDeliveryZones: (zones: DeliveryZone[]) => void;
  setPaymentMethods: (methods: PaymentMethod[]) => void;
  setDeliveryTimes: (times: DeliveryTime[]) => void;
  updateConfig: (configUpdate: Partial<OrderConfig>) => void;
  getDeliveryZones: () => DeliveryZone[];
  getPaymentMethods: () => PaymentMethod[];
  getDeliveryTimes: () => DeliveryTime[];
  getDeliveryZoneById: (zoneId: string) => DeliveryZone | null;
  getPaymentMethodById: (methodId: string) => PaymentMethod | null;
  isDeliveryZoneAvailable: (zoneId: string) => boolean;
  isPaymentMethodAvailable: (methodId: string) => boolean;
  refreshConfiguration: () => Promise<boolean>;
  resetConfiguration: () => void;
}

/**
 * Actions étendues du panier incluant toutes les nouvelles actions groupées
 */
export interface ExtendedCartActions extends CartActions {
  // Actions existantes du panier (héritées de CartActions)
  // addItem, removeItem, updateQuantity, clearCart, etc.

  // Nouvelles actions groupées
  order: OrderActions;
  modal: ModalActions;
  form: FormActions;
  promo: PromoActions;
  config: ConfigActions;
}

/**
 * Store complet du panier (état + actions)
 */
export type CartStore = CartState & CartActions;

/**
 * Store unifié étendu (état étendu + actions étendues)
 */
export type ExtendedCartStore = ExtendedCartState & ExtendedCartActions;

/**
 * Props pour les composants liés au panier
 */
export interface CartButtonProps {
  /** Classe CSS personnalisée */
  className?: string;
  /** Position du bouton (fixed, absolute, etc.) */
  position?: 'fixed' | 'absolute' | 'relative';
}

export interface CartDrawerProps {
  /** État d'ouverture du drawer */
  isOpen: boolean;
  /** Fonction pour fermer le drawer */
  onClose: () => void;
}

export interface CartItemProps {
  /** Article du panier à afficher */
  item: CartItem;
  /** Fonction appelée lors de la mise à jour de quantité */
  onUpdateQuantity: (itemId: string, quantity: number) => void;
  /** Fonction appelée lors de la suppression */
  onRemove: (itemId: string) => void;
}

/**
 * Configuration pour la persistance du panier
 */
export interface CartPersistConfig {
  /** Nom de la clé dans localStorage */
  name: string;
  /** Version du schéma */
  version: number;
  /** Fonction de partialisation pour ne sauvegarder que certaines propriétés */
  partialize: (state: CartStore) => CartStorage;
}

/**
 * Configuration étendue pour la persistance du store unifié
 */
export interface ExtendedCartPersistConfig {
  /** Nom de la clé dans localStorage */
  name: string;
  /** Version du schéma */
  version: number;
  /** Fonction de partialisation pour ne sauvegarder que certaines propriétés */
  partialize: (state: ExtendedCartStore) => ExtendedCartStorage;
}

/**
 * Utilitaires pour la gestion du panier
 */
export interface CartUtils {
  /** Générer un hash pour les options */
  generateOptionsHash: (options: any) => string;
  /** Trouver le prix d'une option dans un WeeklyMenuItem */
  getOptionPrice: (item: WeeklyMenuItem, selectedSize: string) => number;
  /** Valider qu'un article peut être ajouté au panier */
  validateCartItem: (item: WeeklyMenuItem, selectedSize: string) => boolean;
  /** Formater le prix pour l'affichage */
  formatPrice: (price: number) => string;
}