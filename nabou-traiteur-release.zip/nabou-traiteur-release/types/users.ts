import { ApiSuccessResponse } from './api';
import type { Company } from './company';

// Core User interface based on Prisma model
export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  isActive: boolean;
  lastLogin?: string;
  createdAt: string;
  updatedAt: string;
  roles: Role[];
  companyId?: string;
  company?: Company;
}

// Role interface
export interface Role {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

// Form data interface for user creation and editing
export interface UserFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  isActive: boolean;
  roleIds: string[];
  companyId?: string;
}

// Filters interface for user list filtering
export interface UserFilters {
  search: string;
  role: string;
  status: string;
}

// Statistics interface for user dashboard
export interface UserStats {
  total: number;
  active: number;
  admins: number;
  suspended: number;
}

// API Request types
export interface CreateUserRequest {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  roleIds?: string[];
  companyId?: string;
}

export interface UpdateUserRequest {
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  isActive?: boolean;
  roleIds?: string[];
  companyId?: string;
}

// API Response types
export interface UsersApiResponse extends ApiSuccessResponse<User[]> {
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface UserApiResponse extends ApiSuccessResponse<User> {}

export interface RolesApiResponse extends ApiSuccessResponse<Role[]> {
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// Error codes enum
export enum UserErrorCodes {
  USER_NOT_FOUND = 'USER_NOT_FOUND',
  EMAIL_ALREADY_EXISTS = 'EMAIL_ALREADY_EXISTS',
  CANNOT_DELETE_USER_WITH_ORDERS = 'CANNOT_DELETE_USER_WITH_ORDERS',
  INSUFFICIENT_PERMISSIONS = 'INSUFFICIENT_PERMISSIONS',
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  INVALID_ROLE = 'INVALID_ROLE',
  CANNOT_DEACTIVATE_SELF = 'CANNOT_DEACTIVATE_SELF',
  CANNOT_REMOVE_LAST_ADMIN = 'CANNOT_REMOVE_LAST_ADMIN'
}

// Error messages mapping
export const UserErrorMessages: Record<UserErrorCodes, string> = {
  [UserErrorCodes.USER_NOT_FOUND]: 'Utilisateur introuvable',
  [UserErrorCodes.EMAIL_ALREADY_EXISTS]: 'Un utilisateur avec cet email existe déjà',
  [UserErrorCodes.CANNOT_DELETE_USER_WITH_ORDERS]: 'Impossible de supprimer cet utilisateur car il a des commandes associées',
  [UserErrorCodes.INSUFFICIENT_PERMISSIONS]: 'Permissions insuffisantes pour cette action',
  [UserErrorCodes.VALIDATION_ERROR]: 'Erreur de validation des données',
  [UserErrorCodes.INVALID_ROLE]: 'Rôle invalide ou inexistant',
  [UserErrorCodes.CANNOT_DEACTIVATE_SELF]: 'Impossible de désactiver votre propre compte',
  [UserErrorCodes.CANNOT_REMOVE_LAST_ADMIN]: 'Impossible de supprimer le dernier administrateur'
};

// User status constants
export const UserStatus = {
  ACTIVE: 'active',
  SUSPENDED: 'suspended',
  ALL: 'all'
} as const;

export type UserStatusType = typeof UserStatus[keyof typeof UserStatus];

// Default role constants
export const DefaultRoles = {
  CLIENT: 'client',
  ADMIN: 'admin',
  MANAGER: 'manager'
} as const;

export type DefaultRoleType = typeof DefaultRoles[keyof typeof DefaultRoles];

// Utility type for user creation form
export interface UserCreationForm extends Omit<UserFormData, 'isActive'> {
  password?: string;
  confirmPassword?: string;
}

// Utility type for user update form
export interface UserUpdateForm extends UserFormData {
  id: string;
}

// Type for user list item display
export interface UserListItem {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  isActive: boolean;
  lastLogin?: string;
  roles: string[];
  createdAt: string;
}

// Type for user search and filter parameters
export interface UserSearchParams {
  page?: number;
  limit?: number;
  search?: string;
  role?: string;
  status?: UserStatusType;
  sortBy?: 'firstName' | 'lastName' | 'email' | 'createdAt' | 'lastLogin';
  sortOrder?: 'asc' | 'desc';
}