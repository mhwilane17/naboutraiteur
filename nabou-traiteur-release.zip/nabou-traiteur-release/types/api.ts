// Types pour les réponses API standardisées
export interface ApiSuccessResponse<T = any> {
  success: true;
  data: T;
  message?: string;
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface ApiErrorResponse {
  success: false;
  error: {
    code: string;
    message: string;
    details?: any;
  };
  timestamp: string;
}

// Types pour l'authentification
export interface AuthenticatedUser {
  id: string
  email: string
  firstName: string
  lastName: string
  roles: string[]
  permissions: string[]
  companyId?: string // Ajout: rattachement éventuel à une entreprise
}

export interface Permission {
  id: string;
  name: string;
  module: string;
  action: string;
}

// Types pour les requêtes
export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  name: string;
  email: string;
  password: string;
  phone?: string;
}

// Types pour les tokens
export interface UserTokenPayload {
  userId: string
  email: string
  roles: string[]
  permissions: string[]
  type: 'user'
  iat?: number
  exp?: number
  [key: string]: any // Index signature pour JWT
}

export interface TokenPayload {
  userId: string
  email: string
  roles: string[]
  permissions: string[]
  type: 'user'
  iat?: number
  exp?: number
}

export interface GuestTokenPayload {
  sessionId: string
  type: 'guest'
  iat?: number
  exp?: number
  [key: string]: any // Index signature pour JWT
}

// Types pour les paramètres de requête
export interface PaginationQuery {
  page: number;
  limit: number;
  search?: string;
}

// Types pour les erreurs
export interface ApiError {
  code: string;
  message: string;
  details?: any;
}

// Types pour les logs
export interface LogContext {
  userId?: string;
  requestId: string;
  method: string;
  url: string;
  userAgent?: string;
  ip?: string;
  [key: string]: any; // Permet d'ajouter des propriétés supplémentaires
}