// Types pour les données du dashboard
export interface DashboardStats {
  totalOrders: {
    count: number;
    change: number;
    changeType: "positive" | "negative";
  };
  todayOrders: {
    count: number;
    change: number;
    changeType: "positive" | "negative";
  };
  todayRevenue: {
    amount: number;
    change: number;
    changeType: "positive" | "negative";
  };
  totalRevenue: {
    amount: number;
    change: number;
    changeType: "positive" | "negative";
  };
  averageOrderValue: {
    amount: number;
    change: number;
    changeType: "positive" | "negative";
  };
  satisfactionRate: {
    rate: number;
    change: number;
    changeType: "positive" | "negative";
  };
}

export interface WeeklySales {
  day: string;
  sales: number;
  revenue: number;
}

export interface MonthlySales {
  month: string;
  sales: number;
  revenue: number;
}

export interface TopProduct {
  id: string;
  name: string;
  sales: number;
  revenue: number;
  image?: string;
}

export interface RecentOrder {
  id: string;
  orderNumber: string;
  customerName?: string;
  customerEmail?: string;
  items: {
    name: string;
    quantity: number;
  }[];
  totalAmount: number;
  status: string;
  createdAt: string;
}

export interface RecentTransaction {
  id: string;
  orderNumber: string;
  customerName?: string;
  amount: number;
  method: string;
  status: string;
  createdAt: string;
}

export interface OrderStatusDistribution {
  status: string;
  count: number;
  percentage: number;
}

export interface PaymentMethodDistribution {
  method: string;
  count: number;
  percentage: number;
}

export interface DashboardData {
  stats: DashboardStats;
  weeklySales: WeeklySales[];
  monthlySales: MonthlySales[];
  topProducts: TopProduct[];
  recentOrders: RecentOrder[];
  recentTransactions: RecentTransaction[];
  orderStatusDistribution: OrderStatusDistribution[];
  paymentMethodDistribution: PaymentMethodDistribution[];
}

export type DashboardPeriod = "today" | "week" | "month" | "year";