import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Analytics } from "@vercel/analytics/next";

export const metadata: Metadata = {
  title: {
    default: "Nabou Traiteur - Service de Restauration d'Entreprise",
    template: "%s | Nabou Traiteur",
  },
  description:
    "Chez Nabou Traiteur, chaque repas est une invitation à la découverte et au partage. Nous cuisinons avec passion pour offrir aux entreprises, employés de bureau des repas savoureux et équilibrés. Service de restauration d'entreprise, livraison de repas, traiteur professionnel.",
  keywords: [
    "traiteur",
    "restauration d'entreprise",
    "livraison repas",
    "catering",
    "repas bureau",
    "menu entreprise",
    "traiteur professionnel",
    "cuisine africaine",
    "repas équilibrés",
  ],
  authors: [{ name: "Teldoo Group", url: "https://teldoogroup.com" }],
  creator: "Teldoo Group",
  publisher: "Nabou Traiteur",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_APP_URL || "https://nabou-traiteur.com"
  ),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    type: "website",
    locale: "fr_FR",
    url: "/",
    title: "Nabou Traiteur - Service de Restauration d'Entreprise",
    description:
      "Chez Nabou Traiteur, chaque repas est une invitation à la découverte et au partage. Service de restauration d'entreprise avec des repas savoureux et équilibrés.",
    siteName: "Nabou Traiteur",
    images: [
      {
        url: "/images/nabou_traiteur_logo.png",
        width: 1200,
        height: 630,
        alt: "Nabou Traiteur - Plats savoureux",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Nabou Traiteur - Service de Restauration",
    description:
      "Service de restauration avec des repas savoureux et équilibrés. Découvrez notre cuisine avec passion.",  
    images: ["/images/nabou_traiteur_logo.png"],
    creator: "@naboutraiteur",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  icons: {
    icon: [
      { url: "/favicon.svg", type: "image/svg+xml" },
      { url: "/favicon.ico", sizes: "any" },
    ],
    shortcut: "/favicon.svg",
    apple: [{ url: "/favicon.svg", sizes: "180x180", type: "image/svg+xml" }],
  },
  manifest: "/site.webmanifest",
  verification: {
    google: process.env.GOOGLE_SITE_VERIFICATION,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <body className="bg-white">
        {children}
        <Analytics />
        <Toaster />
      </body>
    </html>
  );
}
