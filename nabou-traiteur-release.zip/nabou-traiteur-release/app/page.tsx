import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { FeaturesSection } from "@/components/FeaturesSection";
import { MenuSection } from "@/components/MenuSection";
import { OffersSection } from "@/components/OffersSection";
import { CoFoundersSection } from "@/components/CoFoundersSection";
import { AboutSection } from "@/components/AboutSection";
import { GallerySection } from "@/components/GallerySection";
import { CTASection } from "@/components/CTASection";
import { Footer } from "@/components/Footer";
import { WhatsAppButton } from "@/components/WhatsAppButton";

export default async function NabouTraiteur() {
  return (
    <div className="min-h-screen">
      <Header />
      <HeroSection />
      <MenuSection />
      <FeaturesSection />
      <OffersSection />
      <CoFoundersSection />
      <AboutSection />
      <GallerySection />
      <CTASection />
      <Footer />
      {/* <WhatsAppButton /> */}
    </div>
  );
}
