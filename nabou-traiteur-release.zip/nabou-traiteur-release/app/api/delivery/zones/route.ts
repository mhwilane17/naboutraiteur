import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";

const CreateDeliveryZoneSchema = z.object({
  name: z.string().min(2).max(100),
  description: z.string().optional(),
  deliveryFee: z.number().min(0),
  minOrderAmount: z.number().min(0).optional(),
  maxOrderAmount: z.number().min(0).optional(),
  estimatedTime: z.string().optional(), // Ex: "30-45 minutes"
  isActive: z.boolean().default(true),
  sortOrder: z.number().default(0),
  areas: z.array(z.string().min(1)).optional(),
});

// GET /api/delivery/zones
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête GET /api/delivery/zones", context);

    // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    Logger.info("Utilisateur authentifié", context);

    // Construction des filtres
    const where: any = {};

    // Récupération des zones de livraison
    const [zones, total] = await Promise.all([
      prisma.deliveryZone.findMany({
        where,
        include: {
          _count: {
            select: {
              orders: true,
            },
          },
        },
        orderBy: { name: "asc" },
      }),
      prisma.deliveryZone.count({ where }),
    ]);

    Logger.info("Requête GET /api/delivery/zones terminée avec succès", context, {
      zonesCount: zones.length,
      total,
    });

    return ApiResponse.success({
      data: zones,
      pagination: {
        page: 1,
        limit: 1,
        total,
        totalPages: Math.ceil(total / 1),
      },
    });
  } catch (error) {
    Logger.error("Erreur lors de GET /api/delivery/zones", error as Error, context);
    return ApiError.handle(error);
  }
}

// POST /api/delivery/zones
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête POST /api/delivery/zones", context);

    // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // Validation du body
    const body = await request.json();
    const validatedData = CreateDeliveryZoneSchema.parse(body);

    // Vérification de l'unicité du nom
    const existingZone = await prisma.deliveryZone.findFirst({
      where: {
        name: {
          equals: validatedData.name,
          mode: "insensitive",
        },
      },
    });

    if (existingZone) {
      return ApiError.conflict("Une zone de livraison avec ce nom existe déjà");
    }

    // Création de la zone de livraison
    const newZone = await prisma.deliveryZone.create({
      data: {
        ...validatedData,
        areas: validatedData.areas || [],
      },
      include: {
        _count: {
          select: {
            orders: true,
          },
        },
      },
    });

    Logger.info("Zone de livraison créée avec succès", context, {
      zoneId: newZone.id,
      zoneName: newZone.name,
    });

    return ApiResponse.created(newZone, "Zone de livraison créée avec succès");
  } catch (error) {
    Logger.error("Erreur lors de POST /api/delivery/zones", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/delivery/zones
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
