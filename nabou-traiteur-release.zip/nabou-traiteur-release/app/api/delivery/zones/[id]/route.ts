import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";

// Schémas de validation
const UpdateDeliveryZoneSchema = z.object({
  name: z.string().min(2).max(100).optional(),
  description: z.string().optional(),
  deliveryFee: z.number().min(0).optional(),
  minOrderAmount: z.number().min(0).optional(),
  maxOrderAmount: z.number().min(0).optional(),
  estimatedTime: z.string().optional(),
  isActive: z.boolean().optional(),
  sortOrder: z.number().optional(),
  areas: z.array(z.string().min(1)).optional(),
}).refine(
  (data) => Object.keys(data).length > 0,
  {
    message: "Au moins un champ doit être fourni pour la mise à jour",
  }
);

// GET /api/delivery/zones/[id]
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);
  const { id } = await params;
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête GET /api/delivery/zones/[id]", context);

    // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    Logger.info("Utilisateur authentifié", context);

    // Récupération de la zone de livraison
    const zone = await prisma.deliveryZone.findUnique({
      where: { id },
      include: {
        _count: {
          select: {
            orders: true,
          },
        },
      },
    });

    if (!zone) {
      return ApiError.notFound("Zone de livraison introuvable");
    }

    Logger.info("Zone de livraison récupérée avec succès", context, {
      zoneId: zone.id,
      zoneName: zone.name,
    });

    return ApiResponse.success(zone);
  } catch (error) {
    Logger.error("Erreur lors de GET /api/delivery/zones/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// PUT /api/delivery/zones/[id]
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);
  const { id } = await params;
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête PUT /api/delivery/zones/[id]", context);

    // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    Logger.info("Utilisateur authentifié", context);

    // Validation du body
    const body = await request.json();
    const validatedData = UpdateDeliveryZoneSchema.parse(body);

    // Vérification de l'existence de la zone
    const existingZone = await prisma.deliveryZone.findUnique({
      where: { id },
    });

    if (!existingZone) {
      return ApiError.notFound("Zone de livraison introuvable");
    }

    // Vérification de l'unicité du nom (si modifié)
    if (validatedData.name && validatedData.name !== existingZone.name) {
      const nameExists = await prisma.deliveryZone.findFirst({
        where: {
          name: {
            equals: validatedData.name,
            mode: "insensitive",
          },
          id: { not: id },
        },
      });

      if (nameExists) {
        return ApiError.conflict("Une zone de livraison avec ce nom existe déjà");
      }
    }

    // Mise à jour de la zone
    const updatedZone = await prisma.deliveryZone.update({
      where: { id },
      data: {
        ...validatedData,
        areas: validatedData.areas || existingZone.areas,
      },
      include: {
        _count: {
          select: {
            orders: true,
          },
        },
      },
    });

    Logger.info("Zone de livraison mise à jour avec succès", context, {
      zoneId: updatedZone?.id,
      zoneName: updatedZone?.name,
    });

    return ApiResponse.updated(updatedZone, "Zone de livraison mise à jour avec succès");
  } catch (error) {
    Logger.error("Erreur lors de PUT /api/delivery/zones/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// DELETE /api/delivery/zones/[id]
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);
  const { id } = await params;
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête DELETE /api/delivery/zones/[id]", context);

    // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    Logger.info("Utilisateur authentifié", context);

    // Vérification de l'existence de la zone
    const existingZone = await prisma.deliveryZone.findUnique({
      where: { id },
      include: {
        _count: {
          select: {
            orders: true,
          },
        },
      },
    });

    if (!existingZone) {
      return ApiError.notFound("Zone de livraison introuvable");
    }

    // Vérification des contraintes métier
    if (existingZone._count.orders > 0) {
      return ApiError.conflict(
        "Impossible de supprimer cette zone de livraison car elle est utilisée dans des commandes"
      );
    }

    // Suppression de la zone (les zones géographiques seront supprimées en cascade)
    await prisma.deliveryZone.delete({
      where: { id },
    });

    Logger.info("Zone de livraison supprimée avec succès", context, {
      zoneId: id,
      zoneName: existingZone.name,
    });

    return ApiResponse.deleted("Zone de livraison supprimée avec succès");
  } catch (error) {
    Logger.error("Erreur lors de DELETE /api/delivery/zones/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/delivery/zones/[id]
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}