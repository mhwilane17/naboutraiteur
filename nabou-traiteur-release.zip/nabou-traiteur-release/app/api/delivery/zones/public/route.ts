import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";

// Schéma de validation pour les paramètres de requête publique
const PublicQuerySchema = z.object({
  isActive: z.coerce.boolean().optional().default(true),
});

// GET /api/delivery/zones/public - Récupérer les zones de livraison publiques
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête GET /api/delivery/zones/public", context);

    // Récupération des zones de livraison actives uniquement
    const zones = await prisma.deliveryZone.findMany({
      where: {
        isActive: true,
      },
      select: {
        id: true,
        name: true,
        description: true,
        deliveryFee: true,
        minOrderAmount: true,
        maxOrderAmount: true,
        estimatedTime: true,
        areas: true,
      },
      orderBy: { sortOrder: "asc" },
    });

    Logger.info("Requête GET /api/delivery/zones/public terminée avec succès", context, {
      zonesCount: zones.length,
    });

    return ApiResponse.success(zones);
  } catch (error) {
    Logger.error("Erreur lors de GET /api/delivery/zones/public", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/delivery/zones/public
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}
