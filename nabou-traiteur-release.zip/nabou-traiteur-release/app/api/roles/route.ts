import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { withDatabase, withTransaction } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";

// Schémas de validation
const CreateRoleSchema = z.object({
  id: z.string().min(2, "L'ID doit contenir au moins 2 caractères").max(50),
  name: z
    .string()
    .min(2, "Le nom doit contenir au moins 2 caractères")
    .max(100),
  description: z.string().optional(),
  isActive: z.boolean().default(true),
  permissionIds: z.array(z.string()).optional(), // IDs des permissions à assigner
});

const QuerySchema = z.object({
  page: z.coerce.number().min(1).default(1),
  limit: z.coerce.number().min(1).max(100).default(10),
  excludeCustomer: z
    .enum(["true", "false"])
    .optional()
    .transform((val) => val === "true"),
  // search: z.string().optional(),
  // isActive: z.enum(['true', 'false']).optional().transform(val => val === 'true'),
});

// GET /api/roles - Liste des rôles avec pagination
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête GET /api/roles", context);

    // 1. Rate limiting
    await rateLimit(request, "general");

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'roles.read'
    // await requirePermission('roles.read')(request, user);

    // 3. Validation des paramètres de requête
    const { searchParams } = new URL(request.url);
    const query = QuerySchema.parse({
      page: searchParams.get("page") || "1",
      limit: searchParams.get("limit") || "10",
      excludeCustomer: searchParams.get("excludeCustomer") || undefined,
      // search: searchParams.get("search") || undefined,
      // isActive: searchParams.get("isActive") || undefined,
    });

    // 4. Construction des filtres
    const where: any = {};

    // Exclure le rôle CUSTOMER si le filtre est activé
    if (query.excludeCustomer) {
      where.id = {
        not: "CUSTOMER",
      };
    }

    // 5. Récupération des rôles avec gestion des connexions
    const [roles, total] = await withDatabase(async (db) => {
      return Promise.all([
        db.role.findMany({
          where,
          skip: (query.page - 1) * query.limit,
          take: query.limit,
          include: {
            permissions: {
              include: {
                permission: {
                  select: {
                    id: true,
                    name: true,
                    description: true,
                    module: true,
                    action: true,
                  },
                },
              },
            },
            users: {
              select: {
                userId: true,
              },
            },
          },
          orderBy: {
            name: "asc",
          },
        }),
        db.role.count({ where }),
      ]);
    });

    // 6. Formatage des données
    const formattedRoles = roles.map((role) => ({
      ...role,
      permissions: role.permissions.map((rp) => rp.permission),
      userCount: role.users.length,
    }));

    Logger.info("Requête GET /api/roles terminée avec succès", context, {
      roleCount: roles.length,
      total,
      page: query.page,
    });

    // 7. Réponse avec pagination
    return ApiResponse.success({
      data: formattedRoles,
      pagination: {
        page: query.page,
        limit: query.limit,
        total,
        totalPages: Math.ceil(total / query.limit),
      },
    });
  } catch (error) {
    Logger.error("Erreur lors de GET /api/roles", error as Error, context);
    return ApiError.handle(error);
  }
}

// POST /api/roles - Créer un nouveau rôle
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête POST /api/roles", context);

    // 1. Rate limiting
    await rateLimit(request, "general");

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'roles.create'
    // await requirePermission('roles.create')(request, user);

    // 3. Validation du body
    const body = await request.json();
    const validatedData = CreateRoleSchema.parse(body);

    // 4. Vérification de l'unicité de l'ID et du nom avec gestion des connexions
    const [existingRoleById, existingRoleByName] = await withDatabase(
      async (db) => {
        return Promise.all([
          db.role.findUnique({ where: { id: validatedData.id } }),
          db.role.findUnique({ where: { name: validatedData.name } }),
        ]);
      }
    );

    if (existingRoleById) {
      return ApiError.conflict("Un rôle avec cet ID existe déjà");
    }

    if (existingRoleByName) {
      return ApiError.conflict("Un rôle avec ce nom existe déjà");
    }

    // 5. Validation des permissions si spécifiées
    if (validatedData.permissionIds && validatedData.permissionIds.length > 0) {
      const existingPermissions = await withDatabase(async (db) => {
        return db.permission.findMany({
          where: {
            id: { in: validatedData.permissionIds },
          },
        });
      });

      if (existingPermissions.length !== validatedData.permissionIds.length) {
        return ApiError.badRequest(
          "Une ou plusieurs permissions spécifiées n'existent pas"
        );
      }
    }

    // 6. Création du rôle avec transaction et gestion des connexions
    const newRole = await withTransaction(async (tx) => {
      // Créer le rôle
      const role = await tx.role.create({
        data: {
          id: validatedData.id,
          name: validatedData.name,
          description: validatedData.description,
          isActive: validatedData.isActive,
        },
      });

      // Assigner les permissions
      if (
        validatedData.permissionIds &&
        validatedData.permissionIds.length > 0
      ) {
        await tx.rolePermission.createMany({
          data: validatedData.permissionIds.map((permissionId) => ({
            roleId: role.id,
            permissionId,
          })),
        });
      }

      // Retourner le rôle avec ses permissions
      return await tx.role.findUnique({
        where: { id: role.id },
        include: {
          permissions: {
            include: {
              permission: {
                select: {
                  id: true,
                  name: true,
                  description: true,
                  module: true,
                  action: true,
                },
              },
            },
          },
          users: {
            select: {
              userId: true,
            },
          },
        },
      });
    });

    // 7. Formatage des données de réponse
    const formattedRole = {
      ...newRole!,
      permissions: newRole!.permissions.map((rp) => rp.permission),
      userCount: newRole!.users.length,
    };

    Logger.info("Rôle créé avec succès", context, {
      roleId: newRole!.id,
      roleName: newRole!.name,
      permissionCount: formattedRole.permissions.length,
    });

    // 8. Réponse de succès
    return ApiResponse.created(formattedRole);
  } catch (error) {
    Logger.error("Erreur lors de POST /api/roles", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS - Gestion CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
