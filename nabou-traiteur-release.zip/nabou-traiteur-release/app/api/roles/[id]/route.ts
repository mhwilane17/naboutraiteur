import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { ERROR_CODES } from "@/lib/error-codes";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";

// Schémas de validation
const UpdateRoleSchema = z.object({
  name: z.string().min(2, "Le nom doit contenir au moins 2 caractères").max(100).optional(),
  description: z.string().optional(),
  isActive: z.boolean().optional(),
  permissionIds: z.array(z.string()).optional(), // IDs des permissions à assigner
});

const ParamsSchema = z.object({
  id: z.string().min(1, "ID de rôle invalide"),
});

// GET /api/roles/[id] - Détails d'un rôle
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête GET /api/roles/[id]", context);

    // 1. Rate limiting
    await rateLimit(request, 'general');

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'roles.read'
    // await requirePermission('roles.read')(request, user);

    // 3. Validation des paramètres
    const resolvedParams = await params;
    const validatedParams = ParamsSchema.parse(resolvedParams);

    // 4. Récupération du rôle
    const role = await prisma.role.findUnique({
      where: { id: validatedParams.id },
      include: {
        permissions: {
          include: {
            permission: {
              select: {
                id: true,
                name: true,
                description: true,
                module: true,
                action: true,
              }
            }
          }
        },
        users: {
          include: {
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                isActive: true,
              }
            }
          }
        }
      }
    });

    if (!role) {
      return ApiError.notFound("Rôle introuvable");
    }

    // 5. Formatage des données
    const formattedRole = {
      ...role,
      permissions: role.permissions.map(rp => rp.permission),
      users: role.users.map(ur => ur.user),
      userCount: role.users.length
    };

    Logger.info("Rôle récupéré avec succès", context, {
      roleId: role.id,
      roleName: role.name,
      userCount: role.users.length,
      permissionCount: role.permissions.length
    });

    // 6. Réponse de succès
    return ApiResponse.success(formattedRole);

  } catch (error) {
    Logger.error("Erreur lors de GET /api/roles/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// PUT /api/roles/[id] - Modifier un rôle
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête PUT /api/roles/[id]", context);

    // 1. Rate limiting
    await rateLimit(request, 'general');

    const reqParams = await params;

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'roles.update'
    // await requirePermission('roles.update')(request, user);

    // 3. Validation des paramètres
    Logger.info("Validating params", context, { reqParams });
    const validatedParams = ParamsSchema.parse(reqParams);
    Logger.info("Params validated successfully", context, { validatedParams });

    // 4. Validation du body
    let body;
    try {
      // Check if body has already been consumed
      const bodyUsed = (request as any).bodyUsed;
      Logger.info("Request body status", context, { bodyUsed });
      
      body = await request.json();
      Logger.info("Request body received", context, { 
        body, 
        bodyType: typeof body,
        isPromise: body instanceof Promise,
        keys: Object.keys(body || {}),
        bodyStringified: JSON.stringify(body)
      });
    } catch (error) {
      Logger.error("Error parsing request body", error as Error, context);
      return ApiError.badRequest("Corps de requête invalide");
    }

    // Validate that body is an object
    if (!body || typeof body !== 'object' || Array.isArray(body)) {
      Logger.error("Invalid body type", new Error("Body is not an object"), context);
      return ApiError.badRequest("Le corps de la requête doit être un objet JSON valide");
    }
    
    // Temporary manual validation for debugging
    Logger.info("About to validate", context, { 
      body,
      bodyType: typeof body,
      isObject: typeof body === 'object' && body !== null && !Array.isArray(body),
      isPromise: body instanceof Promise
    });
    
    // Manual validation to bypass Zod temporarily
    if (body instanceof Promise) {
      Logger.error("Body is a promise!", new Error("Body is promise"), context);
      return ApiError.badRequest("Corps de requête invalide - promise détectée");
    }
    
    if (typeof body !== 'object' || body === null || Array.isArray(body)) {
      Logger.error("Body is not an object", new Error("Body type error"), context);
      return ApiError.badRequest("Corps de requête invalide - doit être un objet");
    }
    
    // Use body directly for now (bypassing Zod validation temporarily)
    const validatedData = body as any;
    Logger.info("Manual validation successful", context, { validatedData });

    // 5. Vérification de l'existence du rôle
    const existingRole = await prisma.role.findUnique({
      where: { id: validatedParams.id }
    });

    if (!existingRole) {
      return ApiError.notFound("Rôle introuvable");
    }

    // 6. Vérification de l'unicité du nom si modifié
    if (validatedData.name && validatedData.name !== existingRole.name) {
      const nameExists = await prisma.role.findUnique({
        where: { name: validatedData.name }
      });

      if (nameExists) {
        return ApiError.conflict("Un rôle avec ce nom existe déjà");
      }
    }

    // 7. Validation des permissions si spécifiées
    if (validatedData.permissionIds && validatedData.permissionIds.length > 0) {
      const existingPermissions = await prisma.permission.findMany({
        where: {
          id: { in: validatedData.permissionIds }
        }
      });

      if (existingPermissions.length !== validatedData.permissionIds.length) {
        return ApiError.badRequest("Une ou plusieurs permissions spécifiées n'existent pas");
      }
    }

    // 8. Mise à jour avec transaction
    const updatedRole = await prisma.$transaction(async (tx) => {
      // Extraire les données du rôle (sans permissionIds)
      const { permissionIds, ...roleData } = validatedData;

      // Mettre à jour les données du rôle
      const role = await tx.role.update({
        where: { id: validatedParams.id },
        data: roleData
      });

      // Mettre à jour les permissions si spécifiées
      if (permissionIds !== undefined) {
        // Supprimer les anciennes permissions
        await tx.rolePermission.deleteMany({
          where: { roleId: validatedParams.id }
        });

        // Ajouter les nouvelles permissions
        if (permissionIds.length > 0) {
          await tx.rolePermission.createMany({
            data: permissionIds.map(permissionId => ({
              roleId: validatedParams.id,
              permissionId
            }))
          });
        }
      }

      // Retourner le rôle avec ses permissions et utilisateurs
      return await tx.role.findUnique({
        where: { id: validatedParams.id },
        include: {
          permissions: {
            include: {
              permission: {
                select: {
                  id: true,
                  name: true,
                  description: true,
                  module: true,
                  action: true,
                }
              }
            }
          },
          users: {
            include: {
              user: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  email: true,
                  isActive: true,
                }
              }
            }
          }
        }
      });
    });

    // 9. Formatage des données de réponse
    const formattedRole = {
      ...updatedRole!,
      permissions: updatedRole!.permissions.map(rp => rp.permission),
      users: updatedRole!.users.map(ur => ur.user),
      userCount: updatedRole!.users.length
    };

    Logger.info("Rôle mis à jour avec succès", context, {
      roleId: updatedRole!.id,
      roleName: updatedRole!.name,
      updatedFields: Object.keys(validatedData),
      permissionCount: formattedRole.permissions.length
    });

    // 10. Réponse de succès
    return ApiResponse.success(formattedRole);

  } catch (error) {
    Logger.error("Erreur lors de PUT /api/roles/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// DELETE /api/roles/[id] - Supprimer un rôle
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête DELETE /api/roles/[id]", context);

    // 1. Rate limiting
    await rateLimit(request, 'general');
    const resolvedParams = await params;

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'roles.delete'
    // await requirePermission('roles.delete')(request, user);

    // 3. Validation des paramètres
    const validatedParams = ParamsSchema.parse(resolvedParams);

    // 4. Vérification de l'existence du rôle
    const existingRole = await prisma.role.findUnique({
      where: { id: validatedParams.id },
      include: {
        users: { select: { userId: true } }
      }
    });

    if (!existingRole) {
      return ApiError.notFound("Rôle introuvable");
    }

    // 5. Vérification des contraintes métier
    // Empêcher la suppression si le rôle a des utilisateurs assignés
    if (existingRole.users.length > 0) {
      return ApiError.conflict(
        `Impossible de supprimer ce rôle car ${existingRole.users.length} utilisateur(s) y sont assigné(s)`
      );
    }

    // 6. Empêcher la suppression des rôles système critiques
    const systemRoles = ['SUPER_ADMIN', 'ADMIN', 'CLIENT'];
    if (systemRoles.includes(existingRole.id)) {
      return ApiError.conflict(
        "Impossible de supprimer un rôle système"
      );
    }

    // 7. Suppression avec transaction
    await prisma.$transaction(async (tx) => {
      // Supprimer les relations RolePermission
      await tx.rolePermission.deleteMany({
        where: { roleId: validatedParams.id }
      });

      // Supprimer le rôle
      await tx.role.delete({
        where: { id: validatedParams.id }
      });
    });

    Logger.info("Rôle supprimé avec succès", context, {
      deletedRoleId: validatedParams.id,
      deletedRoleName: existingRole.name
    });

    // 8. Réponse de succès
    return ApiResponse.success({
      message: "Rôle supprimé avec succès",
      deletedId: validatedParams.id,
      deletedName: existingRole.name
    });

  } catch (error) {
    Logger.error("Erreur lors de DELETE /api/roles/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS - Gestion CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}