import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";

// Schémas de validation
const QuerySchema = z.object({
  page: z.coerce.number().min(1).default(1),
  limit: z.coerce.number().min(1).max(100).default(50), // Plus de permissions par page par défaut
  search: z.string().optional(),
  module: z.string().optional(), // Filtrer par module (users, menu, orders, etc.)
  action: z.string().optional(), // Filtrer par action (create, read, update, delete)
});

// GET /api/permissions - Liste des permissions avec pagination
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête GET /api/permissions", context);

    // 1. Rate limiting
    await rateLimit(request, "general");

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'permissions.read'
    // await requirePermission('permissions.read')(request, user);

    // 3. Validation des paramètres de requête
    const { searchParams } = new URL(request.url);
    const query = QuerySchema.parse({
      page: searchParams.get("page") || "1",
      limit: searchParams.get("limit") || "50",
      search: searchParams.get("search") || undefined,
      module: searchParams.get("module") || undefined,
      action: searchParams.get("action") || undefined,
    });

    // 4. Construction des filtres
    const where: any = {};

    // if (query.search) {
    //   where.OR = [
    //     { name: { contains: query.search, mode: "insensitive" } },
    //     { description: { contains: query.search, mode: "insensitive" } },
    //     { module: { contains: query.search, mode: "insensitive" } },
    //   ];
    // }

    // if (query.module) {
    //   where.module = { equals: query.module, mode: "insensitive" };
    // }

    // if (query.action) {
    //   where.action = { equals: query.action, mode: "insensitive" };
    // }

    // 5. Récupération des permissions
    const [permissions, total] = await Promise.all([
      prisma.permission.findMany({
        where,
        // skip: (query.page - 1) * query.limit,
        // take: query.limit,
        include: {
          roles: {
            include: {
              role: {
                select: {
                  id: true,
                  name: true,
                  description: true,
                },
              },
            },
          },
        },
        orderBy: [{ module: "asc" }, { action: "asc" }, { name: "asc" }],
      }),
      prisma.permission.count({ where }),
    ]);

    // 6. Formatage des données
    const formattedPermissions = permissions.map((permission) => ({
      ...permission,
      roles: permission.roles.map((rp) => rp.role),
      roleCount: permission.roles.length,
    }));

    // 7. Groupement par module pour une meilleure organisation
    const groupedByModule = formattedPermissions.reduce((acc, permission) => {
      const module = permission.module;
      if (!acc[module]) {
        acc[module] = [];
      }
      acc[module].push(permission);
      return acc;
    }, {} as Record<string, typeof formattedPermissions>);

    // 8. Statistiques par module
    const moduleStats = Object.keys(groupedByModule).map((module) => ({
      module,
      count: groupedByModule[module].length,
      actions: [...new Set(groupedByModule[module].map((p) => p.action))],
    }));

    Logger.info("Requête GET /api/permissions terminée avec succès", context, {
      permissionCount: permissions.length,
      total,
      page: query.page,
      moduleCount: Object.keys(groupedByModule).length,
    });

    // 9. Réponse avec pagination et métadonnées
    return ApiResponse.success({
      data: formattedPermissions,
      groupedByModule,
      moduleStats,
      pagination: {
        page: query.page,
        limit: query.limit,
        total,
        totalPages: Math.ceil(total / query.limit),
      },
    });
  } catch (error) {
    Logger.error(
      "Erreur lors de GET /api/permissions",
      error as Error,
      context
    );
    return ApiError.handle(error);
  }
}

// OPTIONS - Gestion CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
