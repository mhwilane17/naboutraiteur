import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";

// Schéma de validation des paramètres
const ParamsSchema = z.object({
  id: z.string().min(1, "L'ID de la permission est requis"),
});

// GET /api/permissions/[id] - Récupérer une permission spécifique
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);
  const { id } = await params;
  
  try {
    Logger.info("Début de la requête GET /api/permissions/[id]", context, { permissionId: id });

    // 1. Rate limiting
    await rateLimit(request, 'general');

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'permissions.read'
    // await requirePermission('permissions.read')(request, user);

    // 3. Validation des paramètres
    const validatedParams = ParamsSchema.parse({ id });

    // 4. Récupération de la permission
    const permission = await prisma.permission.findUnique({
      where: { id: validatedParams.id },
      include: {
        roles: {
          include: {
            role: {
              select: {
                id: true,
                name: true,
                description: true,
                isActive: true,
                users: {
                  select: {
                    user: {
                      select: {
                        id: true,
                        email: true,
                        firstName: true,
                        lastName: true,
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    });

    if (!permission) {
      return ApiError.notFound("Permission non trouvée");
    }

    // 5. Formatage des données
    const formattedPermission = {
      ...permission,
      roles: permission.roles.map((rp: any) => ({
        ...rp.role,
        userCount: rp.role.users.length,
        users: rp.role.users.map((ur: any) => ur.user)
      })),
      roleCount: permission.roles.length,
      totalUsers: permission.roles.reduce((acc: number, rp: any) => acc + rp.role.users.length, 0)
    };

    // 6. Statistiques supplémentaires
    const stats = {
      rolesWithPermission: permission.roles.length,
      activeRoles: permission.roles.filter((rp: any) => rp.role.isActive).length,
      inactiveRoles: permission.roles.filter((rp: any) => !rp.role.isActive).length,
      totalUsersWithPermission: formattedPermission.totalUsers
    };

    Logger.info("Requête GET /api/permissions/[id] terminée avec succès", context, {
      permissionId: id,
      roleCount: permission.roles.length,
      totalUsers: formattedPermission.totalUsers
    });

    return ApiResponse.success({
      data: formattedPermission,
      stats
    });

  } catch (error) {
    Logger.error("Erreur lors de GET /api/permissions/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS - Gestion CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}