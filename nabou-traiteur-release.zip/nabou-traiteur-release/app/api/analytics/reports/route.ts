import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";
import { startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfYear, endOfYear, subDays, subWeeks, subMonths, subYears } from "date-fns";
import { fr } from "date-fns/locale";

// Schéma de validation pour les paramètres de requête
const reportsQuerySchema = z.object({
  type: z.enum(["sales", "products", "customers", "revenue", "orders"]).default("sales"),
  period: z.enum(["day", "week", "month", "quarter", "year", "custom"]).default("month"),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  format: z.enum(["json", "csv", "pdf"]).default("json"),
  groupBy: z.enum(["day", "week", "month", "category", "product", "customer"]).optional(),
  categoryId: z.string().optional(),
  customerId: z.string().optional(),
  limit: z.coerce.number().min(1).max(1000).default(100),
  offset: z.coerce.number().min(0).default(0),
});

// Types pour les réponses
interface SalesReport {
  period: string;
  totalSales: number;
  totalRevenue: number;
  averageOrderValue: number;
  orderCount: number;
  topProducts: Array<{
    id: string;
    name: string;
    sales: number;
    revenue: number;
  }>;
  salesByCategory: Array<{
    categoryId: string;
    categoryName: string;
    sales: number;
    revenue: number;
  }>;
  dailyBreakdown?: Array<{
    date: string;
    sales: number;
    revenue: number;
    orders: number;
  }>;
}

interface ProductReport {
  products: Array<{
    id: string;
    name: string;
    category: string;
    totalSales: number;
    totalRevenue: number;
    averagePrice: number;
    stockLevel?: number;
    profitMargin?: number;
  }>;
  totalProducts: number;
  topPerformers: Array<{
    id: string;
    name: string;
    sales: number;
    revenue: number;
  }>;
  lowPerformers: Array<{
    id: string;
    name: string;
    sales: number;
    revenue: number;
  }>;
}

interface CustomerReport {
  customers: Array<{
    id: string;
    name: string;
    email: string;
    totalOrders: number;
    totalSpent: number;
    averageOrderValue: number;
    lastOrderDate: string;
    customerSince: string;
  }>;
  totalCustomers: number;
  newCustomers: number;
  returningCustomers: number;
  customerLifetimeValue: number;
  churnRate: number;
}

// Fonction utilitaire pour calculer les dates de période
function getPeriodDates(period: string, startDate?: string, endDate?: string) {
  const now = new Date();
  
  if (period === "custom" && startDate && endDate) {
    return {
      start: startOfDay(new Date(startDate)),
      end: endOfDay(new Date(endDate)),
    };
  }
  
  switch (period) {
    case "day":
      return {
        start: startOfDay(now),
        end: endOfDay(now),
      };
    case "week":
      return {
        start: startOfWeek(now, { locale: fr }),
        end: endOfWeek(now, { locale: fr }),
      };
    case "month":
      return {
        start: startOfMonth(now),
        end: endOfMonth(now),
      };
    case "quarter":
      const quarterStart = new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1);
      const quarterEnd = new Date(quarterStart.getFullYear(), quarterStart.getMonth() + 3, 0);
      return {
        start: quarterStart,
        end: quarterEnd,
      };
    case "year":
      return {
        start: startOfYear(now),
        end: endOfYear(now),
      };
    default:
      return {
        start: startOfMonth(now),
        end: endOfMonth(now),
      };
  }
}

// Fonction pour générer un rapport de ventes
async function generateSalesReport(
  startDate: Date,
  endDate: Date,
  groupBy?: string,
  categoryId?: string
): Promise<SalesReport> {
  const whereClause: any = {
    createdAt: {
      gte: startDate,
      lte: endDate,
    },
    status: {
      in: ["CONFIRMED", "PREPARING", "READY", "DELIVERED", "COMPLETED"],
    },
  };

  if (categoryId) {
    whereClause.items = {
      some: {
        menuItem: {
          categoryId: categoryId,
        },
      },
    };
  }

  // Statistiques globales
  const orders = await prisma.order.findMany({
    where: whereClause,
    include: {
      items: {
        include: {
          menuItem: {
            include: {
              category: true,
            },
          },
        },
      },
    },
  });

  const totalRevenue = orders.reduce((sum, order) => sum + Number(order.totalAmount), 0);
  const totalSales = orders.reduce((sum, order) => 
    sum + order.items.reduce((itemSum, item) => itemSum + item.quantity, 0), 0
  );
  const orderCount = orders.length;
  const averageOrderValue = orderCount > 0 ? totalRevenue / orderCount : 0;

  // Top produits
  const productSales = new Map<string, { name: string; sales: number; revenue: number }>();
  orders.forEach(order => {
    order.items.forEach(item => {
      const existing = productSales.get(item.menuItemId) || {
        name: item.menuItem.name,
        sales: 0,
        revenue: 0,
      };
      existing.sales += item.quantity;
      existing.revenue += Number(item.totalPrice);
      productSales.set(item.menuItemId, existing);
    });
  });

  const topProducts = Array.from(productSales.entries())
    .map(([id, data]) => ({ id, ...data }))
    .sort((a, b) => b.sales - a.sales)
    .slice(0, 10);

  // Ventes par catégorie
  const categorySales = new Map<string, { name: string; sales: number; revenue: number }>();
  orders.forEach(order => {
    order.items.forEach(item => {
      const categoryId = item.menuItem.categoryId;
      const categoryName = item.menuItem.category?.name || "Sans catégorie";
      const existing = categorySales.get(categoryId) || {
        name: categoryName,
        sales: 0,
        revenue: 0,
      };
      existing.sales += item.quantity;
      existing.revenue += Number(item.totalPrice);
      categorySales.set(categoryId, existing);
    });
  });

  const salesByCategory = Array.from(categorySales.entries())
    .map(([categoryId, data]) => ({
      categoryId,
      categoryName: data.name,
      sales: data.sales,
      revenue: data.revenue,
    }));

  // Répartition quotidienne si demandée
  let dailyBreakdown: Array<{ date: string; sales: number; revenue: number; orders: number }> | undefined;
  if (groupBy === "day") {
    const dailyData = new Map<string, { sales: number; revenue: number; orders: number }>();
    orders.forEach(order => {
      const dateKey = order.createdAt.toISOString().split('T')[0];
      const existing = dailyData.get(dateKey) || { sales: 0, revenue: 0, orders: 0 };
      existing.sales += order.items.reduce((sum, item) => sum + item.quantity, 0);
      existing.revenue += Number(order.totalAmount);
      existing.orders += 1;
      dailyData.set(dateKey, existing);
    });

    dailyBreakdown = Array.from(dailyData.entries())
      .map(([date, data]) => ({ date, ...data }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  return {
    period: `${startDate.toISOString().split('T')[0]} - ${endDate.toISOString().split('T')[0]}`,
    totalSales,
    totalRevenue,
    averageOrderValue,
    orderCount,
    topProducts,
    salesByCategory,
    dailyBreakdown,
  };
}

// Fonction pour générer un rapport de produits
async function generateProductReport(
  startDate: Date,
  endDate: Date,
  limit: number,
  offset: number
): Promise<ProductReport> {
  // Récupérer tous les produits avec leurs ventes
  const products = await prisma.menuItem.findMany({
    skip: offset,
    take: limit,
    include: {
      category: true,
      orderItems: {
        where: {
          order: {
            createdAt: {
              gte: startDate,
              lte: endDate,
            },
            status: {
              in: ["CONFIRMED", "PREPARING", "READY", "DELIVERED", "COMPLETED"],
            },
          },
        },
      },
    },
  });

  const totalProducts = await prisma.menuItem.count();

  const productData = products.map(product => {
    const totalSales = product.orderItems.reduce((sum, item) => sum + item.quantity, 0);
    const totalRevenue = product.orderItems.reduce((sum, item) => sum + Number(item.totalPrice), 0);
    const averagePrice = totalSales > 0 ? totalRevenue / totalSales : Number(product.price);

    return {
      id: product.id,
      name: product.name,
      category: product.category?.name || "Sans catégorie",
      totalSales,
      totalRevenue,
      averagePrice,
    };
  });

  const topPerformers = [...productData]
    .sort((a, b) => b.totalSales - a.totalSales)
    .slice(0, 10)
    .map(p => ({
      id: p.id,
      name: p.name,
      sales: p.totalSales,
      revenue: p.totalRevenue,
    }));

  const lowPerformers = [...productData]
    .sort((a, b) => a.totalSales - b.totalSales)
    .slice(0, 10)
    .map(p => ({
      id: p.id,
      name: p.name,
      sales: p.totalSales,
      revenue: p.totalRevenue,
    }));

  return {
    products: productData,
    totalProducts,
    topPerformers,
    lowPerformers,
  };
}

// Fonction pour générer un rapport de clients
async function generateCustomerReport(
  startDate: Date,
  endDate: Date,
  limit: number,
  offset: number
): Promise<CustomerReport> {
  const customers = await prisma.user.findMany({
    skip: offset,
    take: limit,
    where: {
      roles: {
        some: {
          role: {
            name: "CUSTOMER",
          },
        },
      },
    },
    include: {
      orders: {
        where: {
          createdAt: {
            gte: startDate,
            lte: endDate,
          },
          status: {
            in: ["CONFIRMED", "PREPARING", "READY", "DELIVERED", "COMPLETED"],
          },
        },
      },
    },
  });

  const totalCustomers = await prisma.user.count({
    where: {
      roles: {
        some: {
          role: {
            name: "CUSTOMER",
          },
        },
      },
    },
  });

  // Nouveaux clients dans la période
  const newCustomers = await prisma.user.count({
    where: {
      createdAt: {
        gte: startDate,
        lte: endDate,
      },
      roles: {
        some: {
          role: {
            name: "CUSTOMER",
          },
        },
      },
    },
  });

  const customerData = customers.map(customer => {
    const totalOrders = customer.orders.length;
    const totalSpent = customer.orders.reduce((sum, order) => sum + Number(order.totalAmount), 0);
    const averageOrderValue = totalOrders > 0 ? totalSpent / totalOrders : 0;
    const lastOrder = customer.orders.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())[0];

    return {
      id: customer.id,
      name: `${customer.firstName} ${customer.lastName}`,
      email: customer.email,
      totalOrders,
      totalSpent,
      averageOrderValue,
      lastOrderDate: lastOrder?.createdAt.toISOString() || "",
      customerSince: customer.createdAt.toISOString(),
    };
  });

  const returningCustomers = customerData.filter(c => c.totalOrders > 1).length;
  const customerLifetimeValue = customerData.reduce((sum, c) => sum + c.totalSpent, 0) / customerData.length || 0;
  const churnRate = totalCustomers > 0 ? ((totalCustomers - returningCustomers) / totalCustomers) * 100 : 0;

  return {
    customers: customerData,
    totalCustomers,
    newCustomers,
    returningCustomers,
    customerLifetimeValue,
    churnRate,
  };
}

export async function GET(request: NextRequest) {
  try {
    // Rate limiting
    try {
      await rateLimit(request, "general");
    } catch (error) {
      if (error instanceof Error && error.message.includes("Trop de requêtes")) {
        return NextResponse.json(
          { error: "Trop de requêtes. Veuillez réessayer plus tard." },
          { status: 429 }
        );
      }
      throw error;
    }

    // Authentification et vérification des permissions
    const authHeader = request.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json(
        { error: "Token d'authentification requis" },
        { status: 401 }
      );
    }

    const token = authHeader.substring(7);
    // TODO: Vérifier le token JWT et récupérer l'utilisateur
    const userId = "user-id-from-token"; // Remplacer par la logique de décodage du token

    // Vérifier les permissions (admin ou manager)
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        roles: {
          include: {
            role: {
              include: {
                permissions: true,
              },
            },
          },
        },
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: "Utilisateur non trouvé" },
        { status: 404 }
      );
    }

    const hasPermission = user.roles.some((userRole: any) => {
      const role = userRole.role;
      return role.name === "ADMIN" || role.name === "MANAGER" ||
        role.permissions.some((rp: any) => rp.permission === "READ:analytics");
    });

    if (!hasPermission) {
      return NextResponse.json(
        { error: "Permissions insuffisantes" },
        { status: 403 }
      );
    }

    // Validation des paramètres
    const { searchParams } = new URL(request.url);
    const params = Object.fromEntries(searchParams.entries());
    
    const validatedParams = reportsQuerySchema.parse(params);
    const { type, period, startDate, endDate, format, groupBy, categoryId, customerId, limit, offset } = validatedParams;

    // Calculer les dates de la période
    const { start, end } = getPeriodDates(period, startDate, endDate);

    let reportData: any;

    // Générer le rapport selon le type demandé
    switch (type) {
      case "sales":
        reportData = await generateSalesReport(start, end, groupBy, categoryId);
        break;
      case "products":
        reportData = await generateProductReport(start, end, limit, offset);
        break;
      case "customers":
        reportData = await generateCustomerReport(start, end, limit, offset);
        break;
      case "revenue":
        // Rapport de revenus (similaire aux ventes mais focalisé sur les montants)
        reportData = await generateSalesReport(start, end, groupBy, categoryId);
        break;
      case "orders":
        // Rapport de commandes (similaire aux ventes mais focalisé sur les commandes)
        reportData = await generateSalesReport(start, end, groupBy, categoryId);
        break;
      default:
        return NextResponse.json(
          { error: "Type de rapport non supporté" },
          { status: 400 }
        );
    }

    // Log de l'activité
    await Logger.info("Rapport généré", {
      type,
      period,
      startDate: start.toISOString(),
      endDate: end.toISOString(),
      format,
      userId,
    });

    // Retourner les données selon le format demandé
    if (format === "json") {
      return NextResponse.json({
        success: true,
        data: reportData,
        metadata: {
          type,
          period,
          startDate: start.toISOString(),
          endDate: end.toISOString(),
          generatedAt: new Date().toISOString(),
        },
      });
    }

    // TODO: Implémenter l'export CSV et PDF
    if (format === "csv" || format === "pdf") {
      return NextResponse.json(
        { error: "Format d'export non encore implémenté" },
        { status: 501 }
      );
    }

    return NextResponse.json(
      { error: "Format non supporté" },
      { status: 400 }
    );

  } catch (error) {
    console.error("Erreur lors de la génération du rapport:", error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { 
          error: "Paramètres invalides",
          details: error.errors
        },
        { status: 400 }
      );
    }

    await Logger.error("Erreur lors de la génération du rapport", error as Error);

    return NextResponse.json(
      { error: "Erreur interne du serveur" },
      { status: 500 }
    );
  }
}