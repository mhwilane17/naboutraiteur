import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limiter";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";

// Schéma de validation pour les paramètres de requête
const DashboardQuerySchema = z.object({
  startDate: z.string().nullable().optional().transform((val) => val ? new Date(val) : undefined),
  endDate: z.string().nullable().optional().transform((val) => val ? new Date(val) : undefined),
  companyIds: z.string().nullable().optional().transform((val) => val ? val.split(',').filter(Boolean) : []),
});

// Interface pour les données du dashboard
interface DashboardStats {
  totalOrders: {
    count: number;
    change: number;
    changeType: "positive" | "negative";
  };
  todayOrders: {
    count: number;
    change: number;
    changeType: "positive" | "negative";
  };
  todayRevenue: {
    amount: number;
    change: number;
    changeType: "positive" | "negative";
  };
  totalRevenue: {
    amount: number;
    change: number;
    changeType: "positive" | "negative";
  };
  averageOrderValue: {
    amount: number;
    change: number;
    changeType: "positive" | "negative";
  };
}

interface WeeklySales {
  day: string;
  sales: number;
  revenue: number;
}

interface MonthlySales {
  month: string;
  sales: number;
  revenue: number;
}

interface TopProduct {
  id: string;
  name: string;
  sales: number;
  revenue: number;
  image?: string;
}

interface RecentOrder {
  id: string;
  orderNumber: string;
  customerName?: string;
  customerEmail?: string;
  items: {
    name: string;
    quantity: number;
  }[];
  totalAmount: number;
  status: string;
  createdAt: string;
}

interface RecentTransaction {
  id: string;
  orderNumber: string;
  customerName?: string;
  amount: number;
  method: string;
  status: string;
  createdAt: string;
}

interface DashboardData {
  stats: DashboardStats;
  weeklySales: WeeklySales[];
  monthlySales: MonthlySales[];
  topProducts: TopProduct[];
  recentOrders: RecentOrder[];
  recentTransactions: RecentTransaction[];
  orderStatusDistribution: {
    status: string;
    count: number;
    percentage: number;
  }[];
  paymentMethodDistribution: {
    method: string;
    count: number;
    percentage: number;
  }[];
}

/**
 * GET /api/analytics/dashboard
 * Récupère les données du dashboard admin
 */
export async function GET(request: NextRequest) {
  try {
    // Rate limiting
    await rateLimit(request, "general");

    // Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // Vérification des permissions admin/manager
    // const userWithRoles = await prisma.user.findUnique({
    //   where: { id: user.id },
    //   include: {
    //     roles: {
    //       include: {
    //         role: {
    //           include: {
    //             permissions: {
    //               include: {
    //                 permission: true,
    //               },
    //             },
    //           },
    //         },
    //       },
    //     },
    //   },
    // });

    // const hasAnalyticsPermission = userWithRoles?.roles.some((userRole: any) =>
    //   userRole.role.permissions.some(
    //     (rp: any) => rp.permission.name === "analytics.read" || rp.permission.name === "admin.all"
    //   )
    // );

    // if (!hasAnalyticsPermission) {
    //   return ApiError.forbidden("Permission insuffisante pour accéder aux analytics");
    // }

    // Validation des paramètres
    const { searchParams } = new URL(request.url);
    const query = DashboardQuerySchema.parse({
      startDate: searchParams.get("startDate"),
      endDate: searchParams.get("endDate"),
      companyIds: searchParams.get("companyIds"),
    });

    // Calcul des dates de période
    const now = new Date();
    let startDate: Date;
    let endDate: Date;
    let previousStartDate: Date;
    let previousEndDate: Date;

    // Si des dates personnalisées sont fournies, les utiliser
    if (query.startDate && query.endDate) {
      startDate = query.startDate;
      endDate = query.endDate;
      
      // Calculer la période précédente de même durée
      const duration = endDate.getTime() - startDate.getTime();
      previousEndDate = new Date(startDate.getTime() - 1);
      previousStartDate = new Date(previousEndDate.getTime() - duration);
    } else {
      // Utiliser la période par défaut (mois actuel) si aucune date n'est fournie
      startDate = new Date(now.getFullYear(), now.getMonth(), 1);
      endDate = now;
      previousEndDate = new Date(startDate.getTime() - 1);
      previousStartDate = new Date(previousEndDate.getFullYear(), previousEndDate.getMonth(), 1);
    }

    // Récupération des statistiques principales
    const [currentOrders, previousOrders] = await Promise.all([
      prisma.order.findMany({
        where: {
          createdAt: {
            gte: startDate,
            lte: endDate,
          },
          status: {
            in: ["delivered", "confirmed"],
          },
          ...(query.companyIds.length > 0 && {
            customer: {
              companyId: {
                in: query.companyIds,
              },
            },
          }),
        },
        include: {
          items: {
            include: {
              menuItem: true,
            },
          },
          transactions: true,
        },
      }),
      prisma.order.findMany({
        where: {
          createdAt: {
            gte: previousStartDate,
            lte: previousEndDate,
          },
          status: {
            in: ["delivered", "confirmed"],
          },
          ...(query.companyIds.length > 0 && {
            customer: {
              companyId: {
                in: query.companyIds,
              },
            },
          }),
        },
        include: {
          items: true,
          transactions: true,
        },
      }),
    ]);

    // Calcul des statistiques
    const currentRevenue = currentOrders.reduce((sum, order) => sum + Number(order.totalAmount), 0);
    const previousRevenue = previousOrders.reduce(
      (sum, order) => sum + Number(order.totalAmount),
      0
    );
    const currentOrderCount = currentOrders.length;
    const previousOrderCount = previousOrders.length;

    const orderChange =
      previousOrderCount > 0
        ? ((currentOrderCount - previousOrderCount) / previousOrderCount) * 100
        : 0;

    // Commandes d'aujourd'hui - PAS AFFECTÉES PAR LES FILTRES DE COMPAGNIE
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const todayOrders = await prisma.order.count({
      where: {
        createdAt: {
          gte: todayStart,
        },
      },
    });

    const yesterdayStart = new Date(todayStart.getTime() - 24 * 60 * 60 * 1000);
    const yesterdayOrders = await prisma.order.count({
      where: {
        createdAt: {
          gte: yesterdayStart,
          lt: todayStart,
        },
      },
    });

    const todayChange =
      yesterdayOrders > 0 ? ((todayOrders - yesterdayOrders) / yesterdayOrders) * 100 : 0;

    // Revenus d'aujourd'hui - PAS AFFECTÉS PAR LES FILTRES DE COMPAGNIE
    const todayOrdersData = await prisma.order.findMany({
      where: {
        createdAt: {
          gte: todayStart,
        },
        status: {
          in: ["delivered", "confirmed"],
        },
      },
    });

    const yesterdayOrdersData = await prisma.order.findMany({
      where: {
        createdAt: {
          gte: yesterdayStart,
          lt: todayStart,
        },
        status: {
          in: ["delivered", "confirmed"],
        },
      },
    });

    const todayRevenue = todayOrdersData.reduce((sum, order) => sum + Number(order.totalAmount), 0);
    const yesterdayRevenue = yesterdayOrdersData.reduce(
      (sum, order) => sum + Number(order.totalAmount),
      0
    );
    const todayRevenueChange =
      yesterdayRevenue > 0 ? ((todayRevenue - yesterdayRevenue) / yesterdayRevenue) * 100 : 0;

    // Calcul du changement de revenus basé sur la comparaison jour par jour
    const revenueChange = todayRevenueChange;

    // Valeur moyenne des commandes
    const currentAOV = currentOrderCount > 0 ? currentRevenue / currentOrderCount : 0;
    const previousAOV = previousOrderCount > 0 ? previousRevenue / previousOrderCount : 0;
    const aovChange = previousAOV > 0 ? ((currentAOV - previousAOV) / previousAOV) * 100 : 0;

    // Taux de satisfaction (simulé - à remplacer par de vraies données de reviews)
    const satisfactionRate = 4.8;
    const satisfactionChange = 0.2;

    // Ventes par jour de la semaine (7 derniers jours)
    const weeklyData: WeeklySales[] = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(now.getDate() - i);
      date.setHours(0, 0, 0, 0);
      const nextDate = new Date(date);
      nextDate.setDate(date.getDate() + 1);

      const dayOrders = await prisma.order.findMany({
        where: {
          createdAt: {
            gte: date,
            lt: nextDate,
          },
          status: {
            in: ["delivered", "confirmed"],
          },
          ...(query.companyIds.length > 0 && {
            customer: {
              companyId: {
                in: query.companyIds,
              },
            },
          }),
        },
      });

      const dayNames = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
      weeklyData.push({
        day: dayNames[date.getDay()],
        sales: dayOrders.length,
        revenue: dayOrders.reduce((sum, order) => sum + Number(order.totalAmount), 0),
      });
    }

    // Ventes par mois (12 derniers mois)
    const monthlyData: MonthlySales[] = [];
    for (let i = 11; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const nextDate = new Date(date.getFullYear(), date.getMonth() + 1, 1);

      const monthOrders = await prisma.order.findMany({
        where: {
          createdAt: {
            gte: date,
            lt: nextDate,
          },
          status: {
            in: ["delivered", "confirmed"],
          },
          ...(query.companyIds.length > 0 && {
            customer: {
              companyId: {
                in: query.companyIds,
              },
            },
          }),
        },
      });

      const monthNames = [
        "Jan",
        "Fév",
        "Mar",
        "Avr",
        "Mai",
        "Jun",
        "Jul",
        "Aoû",
        "Sep",
        "Oct",
        "Nov",
        "Déc",
      ];
      monthlyData.push({
        month: monthNames[date.getMonth()],
        sales: monthOrders.length,
        revenue: monthOrders.reduce((sum, order) => sum + Number(order.totalAmount), 0),
      });
    }

    // Top 5 des produits les plus vendus
    const topProductsData = await prisma.orderItem.groupBy({
      by: ["menuItemId"],
      _sum: {
        quantity: true,
        totalPrice: true,
      },
      where: {
        order: {
          status: {
            in: ["delivered", "confirmed"],
          },
          ...(query.companyIds.length > 0 && {
            customer: {
              companyId: {
                in: query.companyIds,
              },
            },
          }),
        },
      },
      orderBy: {
        _sum: {
          quantity: "desc",
        },
      },
      take: 5,
    });

    const topProducts: TopProduct[] = await Promise.all(
      topProductsData.map(async (item) => {
        const menuItem = await prisma.menuItem.findUnique({
          where: { id: item.menuItemId },
        });
        return {
          id: item.menuItemId,
          name: menuItem?.name || "Produit inconnu",
          sales: item._sum.quantity || 0,
          revenue: Number(item._sum.totalPrice || 0),
          image: menuItem?.image || undefined,
        };
      })
    );

    // Commandes récentes (10 dernières)
    const recentOrdersData = await prisma.order.findMany({
      take: 10,
      orderBy: {
        createdAt: "desc",
      },
      where: {
        ...(query.companyIds.length > 0 && {
          customer: {
            companyId: {
              in: query.companyIds,
            },
          },
        }),
      },
      include: {
        items: {
          include: {
            menuItem: true,
          },
        },
        customer: true,
      },
    });

    const recentOrders: RecentOrder[] = recentOrdersData.map((order) => ({
      id: order.id,
      orderNumber: order.orderNumber,
      customerName: order.customer
        ? `${order.customer.firstName} ${order.customer.lastName}`
        : undefined,
      customerEmail: order.customer?.email,
      items: order.items.map((item: any) => ({
        name: item.menuItem.name,
        quantity: item.quantity,
      })),
      totalAmount: Number(order.totalAmount),
      status: order.status,
      createdAt: order.createdAt.toISOString(),
    }));

    // Transactions récentes (10 dernières)
    const recentTransactionsData = await prisma.paymentTransaction.findMany({
      take: 10,
      orderBy: {
        createdAt: "desc",
      },
      where: {
        order: {
          status: {
            in: ["delivered", "confirmed"],
          },
          ...(query.companyIds.length > 0 && {
            customer: {
              companyId: {
                in: query.companyIds,
              },
            },
          }),
        },
      },
      include: {
        order: {
          include: {
            customer: true,
          },
        },
        paymentMethod: true,
      },
    });

    const recentTransactions: RecentTransaction[] = recentTransactionsData.map((transaction) => ({
      id: transaction.id,
      orderNumber: transaction.order.orderNumber,
      customerName: transaction.order.customer
        ? `${transaction.order.customer.firstName} ${transaction.order.customer.lastName}`
        : undefined,
      amount: Number(transaction.amount),
      method: transaction.paymentMethod?.name || "Inconnu",
      status: transaction.status,
      createdAt: transaction.createdAt.toISOString(),
    }));

    // Distribution des statuts de commandes
    const orderStatusData = await prisma.order.groupBy({
      by: ["status"],
      _count: {
        status: true,
      },
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
        ...(query.companyIds.length > 0 && {
          customer: {
            companyId: {
              in: query.companyIds,
            },
          },
        }),
      },
    });

    const totalOrdersForDistribution = orderStatusData.reduce(
      (sum, item) => sum + item._count.status,
      0
    );
    const orderStatusDistribution = orderStatusData.map((item) => ({
      status: item.status,
      count: item._count.status,
      percentage:
        totalOrdersForDistribution > 0
          ? (item._count.status / totalOrdersForDistribution) * 100
          : 0,
    }));

    // Distribution des méthodes de paiement
    const paymentMethodData = await prisma.paymentTransaction.groupBy({
      by: ["paymentMethodId"],
      _count: {
        paymentMethodId: true,
      },
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
        order: {
          status: {
            in: ["delivered", "confirmed"],
          },
          ...(query.companyIds.length > 0 && {
            customer: {
              companyId: {
                in: query.companyIds,
              },
            },
          }),
        },
      },
    });

    const totalTransactionsForDistribution = paymentMethodData.reduce(
      (sum, item) => sum + (item._count.paymentMethodId || 0),
      0
    );
    const paymentMethodDistribution = await Promise.all(
      paymentMethodData.map(async (item) => {
        const paymentMethod = await prisma.paymentMethod.findUnique({
          where: { id: item.paymentMethodId },
        });
        return {
          method: paymentMethod?.name || "Inconnu",
          count: item._count.paymentMethodId || 0,
          percentage:
            totalTransactionsForDistribution > 0
              ? ((item._count.paymentMethodId || 0) / totalTransactionsForDistribution) * 100
              : 0,
        };
      })
    );

    // Construction de la réponse
    const dashboardData: DashboardData = {
      stats: {
        totalOrders: {
          count: currentOrderCount,
          change: Math.round(orderChange * 100) / 100,
          changeType: orderChange >= 0 ? "positive" : "negative",
        },
        todayOrders: {
          count: todayOrders,
          change: Math.round(todayChange * 100) / 100,
          changeType: todayChange >= 0 ? "positive" : "negative",
        },
        todayRevenue: {
          amount: todayRevenue,
          change: Math.round(todayRevenueChange * 100) / 100,
          changeType: todayRevenueChange >= 0 ? "positive" : "negative",
        },
        totalRevenue: {
          amount: currentRevenue,
          change: Math.round(revenueChange * 100) / 100,
          changeType: revenueChange >= 0 ? "positive" : "negative",
        },
        averageOrderValue: {
          amount: Math.round(currentAOV),
          change: Math.round(aovChange * 100) / 100,
          changeType: aovChange >= 0 ? "positive" : "negative",
        },
      },
      weeklySales: weeklyData,
      monthlySales: monthlyData,
      topProducts,
      recentOrders,
      recentTransactions,
      orderStatusDistribution,
      paymentMethodDistribution,
    };

    Logger.info("Données dashboard récupérées avec succès", {
      // userId: user.id,
      startDate: query.startDate?.toISOString(),
      endDate: query.endDate?.toISOString(),
      companyIds: query.companyIds,
      ordersCount: currentOrderCount,
      revenue: currentRevenue,
    });

    return ApiResponse.success(dashboardData);
  } catch (error) {
    Logger.error("Erreur lors de la récupération des données dashboard", error as Error, {
      userId: (error as any).userId,
    });
    return ApiError.handle(error);
  }
}
