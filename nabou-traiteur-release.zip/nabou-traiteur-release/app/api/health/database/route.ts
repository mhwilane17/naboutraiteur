import { NextRequest, NextResponse } from "next/server";
import { checkDatabaseHealth } from "@/lib/db";
import { getDatabaseConnectionInfo } from "@/lib/middleware/database";
import { ApiResponse, ApiError } from "@/lib/api-response";

// GET /api/health/database - Vérifier la santé de la base de données
export async function GET(request: NextRequest) {
  try {
    const [isHealthy, connectionInfo] = await Promise.all([
      checkDatabaseHealth(),
      getDatabaseConnectionInfo()
    ]);

    if (!isHealthy) {
      return ApiError.serviceUnavailable("Database connection failed");
    }

    return ApiResponse.success({
      status: "healthy",
      database: connectionInfo,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error("Database health check failed:", error);
    return ApiError.serviceUnavailable("Database health check failed");
  }
}

// OPTIONS - Gestion CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}