import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { requireAuth } from "@/lib/auth";
import { ERROR_CODES } from "@/lib/error-codes";

// Validation schemas
const OrderQuerySchema = z.object({
  page: z
    .string()
    .optional()
    .transform((val) => (val ? parseInt(val) : 1)),
  limit: z
    .string()
    .optional()
    .transform((val) => (val ? parseInt(val) : 10)),
  status: z
    .enum(["pending", "confirmed", "preparing", "ready", "delivered", "cancelled"])
    .optional(),
  type: z.enum(["delivery", "pickup", "weekly_menu"]).optional(),
  paymentStatus: z.enum(["pending", "paid", "failed", "refunded"]).optional(),
  customerId: z.string().optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  search: z.string().optional(),
  sortBy: z
    .enum(["createdAt", "orderNumber", "finalAmount", "deliveryDate"])
    .optional()
    .default("createdAt"),
  sortOrder: z.enum(["asc", "desc"]).optional().default("desc"),
});

const OrderUpdateSchema = z.object({
  status: z
    .enum(["pending", "confirmed", "preparing", "ready", "delivered", "cancelled"])
    .optional(),
  paymentStatus: z.enum(["pending", "paid", "failed", "refunded"]).optional(),
  deliveryAddress: z.string().optional(),
  deliveryCity: z.string().optional(),
  deliveryPostalCode: z.string().optional(),
  deliveryPhone: z.string().optional(),
  deliveryDate: z.string().optional(),
  deliveryTime: z.string().optional(),
  customerNotes: z.string().optional(),
  adminNotes: z.string().optional(),
});

// GET /api/orders - Liste des commandes (admin)
export async function GET(request: NextRequest) {
  try {
    // Rate limiting
    await rateLimit(request, "general");

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check admin permissions
    // const hasPermission = await checkPermission(authResult.user.id, "orders.read");
    // if (!hasPermission) {
    //   return createApiResponse(
    //     null,
    //     ERROR_CODES.FORBIDDEN.message,
    //     ERROR_CODES.FORBIDDEN.code,
    //     403
    //   );
    // }

    // Parse and validate query parameters
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());

    const validatedQuery = OrderQuerySchema.parse(queryParams);
    const {
      page,
      limit,
      status,
      type,
      paymentStatus,
      customerId,
      startDate,
      endDate,
      search,
      sortBy,
      sortOrder,
    } = validatedQuery;

    // Build where clause
    const where: any = {};

    if (status) where.status = status;
    if (type) where.type = type;
    if (paymentStatus) where.paymentStatus = paymentStatus;
    if (customerId) where.customerId = customerId;

    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0); // Début de la journée
        where.createdAt.gte = start;
      }
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999); // Fin de la journée
        where.createdAt.lte = end;
      }
    }

    if (search) {
      where.OR = [
        { orderNumber: { contains: search, mode: "insensitive" } },
        { deliveryAddress: { contains: search, mode: "insensitive" } },
        { deliveryCity: { contains: search, mode: "insensitive" } },
        { customer: { email: { contains: search, mode: "insensitive" } } },
        { customer: { firstName: { contains: search, mode: "insensitive" } } },
        { customer: { lastName: { contains: search, mode: "insensitive" } } },
        { guestFirstName: { contains: search, mode: "insensitive" } },
        { guestLastName: { contains: search, mode: "insensitive" } },
        { guestEmail: { contains: search, mode: "insensitive" } },
      ];
    }

    // Calculate pagination
    const skip = (page - 1) * limit;

    // Get orders with related data
    const [orders, totalCount] = await Promise.all([
      prisma.order.findMany({
        where,
        include: {
          customer: {
            select: {
              id: true,
              email: true,
              firstName: true,
              lastName: true,
              phone: true,
            },
          },
          items: {
            include: {
              menuItem: {
                select: {
                  id: true,
                  name: true,
                  price: true,
                  image: true,
                },
              },
            },
          },
          weeklyMenu: {
            select: {
              id: true,
              name: true,
              startDate: true,
              endDate: true,
            },
          },
          deliveryZone: {
            select: {
              id: true,
              name: true,
              deliveryFee: true,
              areas: true,
            },
          },
          transactions: {
            select: {
              id: true,
              amount: true,
              status: true,
              type: true,
              createdAt: true,
            },
          },

          promotionUsage: {
            include: {
              promotion: {
                select: {
                  id: true,
                  name: true,
                  code: true,
                  type: true,
                  value: true,
                },
              },
            },
          },
        },
        orderBy: {
          [sortBy]: sortOrder,
        },
        skip,
        take: limit,
      }),
      prisma.order.count({ where }),
    ]);

    // Calculate pagination info
    const totalPages = Math.ceil(totalCount / limit);
    const hasNextPage = page < totalPages;
    const hasPreviousPage = page > 1;

    // Format response
    const formattedOrders = orders.map((order: any) => ({
      id: order.id,
      orderNumber: order.orderNumber,
      status: order.status,
      type: order.type,
      totalAmount: order.totalAmount,
      deliveryFee: order.deliveryFee,
      discountAmount: order.discountAmount,
      promotionUsage: order.promotionUsage,
      finalAmount: order.finalAmount,
      paymentStatus: order.paymentStatus,
      paymentMethod: order.paymentMethod,
      deliveryAddress: order.deliveryAddress,
      deliveryCity: order.deliveryCity,
      deliveryPostalCode: order.deliveryPostalCode,
      deliveryPhone: order.deliveryPhone,
      deliveryDate: order.deliveryDate,
      deliveryTime: order.deliveryTime,
      customerNotes: order.customerNotes,
      adminNotes: order.adminNotes,
      createdAt: order.createdAt,
      updatedAt: order.updatedAt,
      customer:
        order.customer ||
        (order.guestFirstName || order.guestLastName
          ? {
            id: null,
            email: order.guestEmail,
            firstName: order.guestFirstName,
            lastName: order.guestLastName,
            phone: order.deliveryPhone,
          }
          : null),
      weeklyMenu: order.weeklyMenu,
      deliveryZone: order.deliveryZone,
      itemsCount: order.items.length,
      items: order.items.map((item: any) => ({
        id: item.id,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        totalPrice: item.totalPrice,
        options: item.options,
        notes: item.notes,
        menuItem: {
          ...item.menuItem,
          imageUrl: item.menuItem.image,
        },
      })),
      transactions: order.transactions,
    }));

    return ApiResponse.success({
      orders: formattedOrders,
      pagination: {
        page,
        limit,
        total: totalCount,
        totalPages,
      },
    });
  } catch (error) {
    console.error("Error fetching orders:", error);

    return ApiError.handle(error);
  }
}

// OPTIONS - CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
