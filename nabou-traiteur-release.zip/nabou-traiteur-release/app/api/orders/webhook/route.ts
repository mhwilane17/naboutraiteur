import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";
import crypto from "crypto";

// Schéma du payload envoyé par Wave
const WaveWebhookSchema = z.object({
  id: z.string(),
  type: z.string(), // e.g. "checkout.session.completed"
  data: z.object({
    id: z.string(),
    amount: z.string(), // Wave envoie le montant comme string
    currency: z.string(),
    transaction_id: z.string(),
    payment_status: z.string(), // e.g. "succeeded", "failed", "pending"
    checkout_status: z.string().optional(), // e.g. "complete"
    client_reference: z.string().nullable().optional(), // orderNumber
    when_created: z.string().optional(),
    when_completed: z.string().nullable().optional(),
    when_expires: z.string().optional(),
    success_url: z.string().optional(),
    error_url: z.string().optional(),
    business_name: z.string().optional(),
    wave_launch_url: z.string().optional(),
    last_payment_error: z.string().nullable().optional(),
  }),
});

// Schéma du payload envoyé par le provider OM (Orange Money)
const OMProviderWebhookSchema = z.object({
  partner: z
    .object({
      idType: z.string().optional(),
      id: z.string().optional(),
    })
    .optional(),
  customer: z
    .object({
      idType: z.string().optional(),
      id: z.string().optional(),
    })
    .optional(),
  amount: z.object({
    value: z.number(),
    unit: z.string().min(1),
  }),
  type: z.string().optional(), // e.g. MERCHANT_PAYMENT
  paymentMethod: z.string().optional(), // e.g. QRCODE
  channel: z.string().optional(), // e.g. MAXIT (provider)
  reference: z.string().optional(),
  transactionId: z.string().min(1),
  createdAt: z.string().optional(),
  status: z.string().min(1), // e.g. SUCCESS | FAILED | CANCELLED
  detail: z.string().nullable().optional(),
  metadata: z
    .object({
      orderNumber: z.string().optional(),
      clientName: z.string().optional(),
      clientNumber: z.string().optional(),
      paymentMethodId: z.string().optional(),
      successRedirectUrl: z.string().optional(),
      cancelRedirectUrl: z.string().optional(),
      Cause: z.string().optional(),
    })
    .optional(),
});

// Vérification de la signature Wave selon la documentation
function verifyWaveSignature(
  rawBody: string,
  waveSignature: string,
  webhookSecret: string
): boolean {
  try {
    // Parser le header Wave-Signature: t=timestamp,v1=signature1,v1=signature2
    const elements = waveSignature.split(",");
    let timestamp: string | null = null;
    const signatures: string[] = [];

    for (const element of elements) {
      const [prefix, value] = element.trim().split("=");
      if (prefix === "t") {
        timestamp = value;
      } else if (prefix === "v1") {
        signatures.push(value);
      }
    }

    if (!timestamp) {
      Logger.warn("Timestamp manquant dans Wave-Signature");
      return false;
    }

    // Vérifier que le timestamp n'est pas trop ancien (5 minutes)
    const timestampNum = parseInt(timestamp, 10);
    const currentTime = Math.floor(Date.now() / 1000);
    const timeDiff = Math.abs(currentTime - timestampNum);
    if (timeDiff > 300) {
      // 5 minutes
      Logger.warn("Timestamp trop ancien dans Wave-Signature", {
        timestamp: timestampNum,
        currentTime,
        diff: timeDiff,
      });
      return false;
    }

    // Construire le payload: timestamp + body
    const payload = timestamp + rawBody;

    // Calculer le HMAC attendu
    const expectedSignature = crypto
      .createHmac("sha256", webhookSecret)
      .update(payload)
      .digest("hex");

    // Vérifier si l'une des signatures correspond
    const isValid = signatures.some((sig) => {
      // Comparaison sécurisée pour éviter les attaques par timing
      // timingSafeEqual nécessite des buffers de même longueur
      if (expectedSignature.length !== sig.length) {
        return false;
      }
      try {
        return crypto.timingSafeEqual(
          Buffer.from(expectedSignature),
          Buffer.from(sig)
        );
      } catch {
        return false;
      }
    });

    return isValid;
  } catch (error) {
    Logger.error("Erreur lors de la vérification de la signature Wave", error as Error);
    return false;
  }
}

function mapWaveStatusToInternal(paymentStatus: string):
  | "completed"
  | "failed"
  | "cancelled"
  | "pending" {
  const s = paymentStatus.toLowerCase();
  if (s === "succeeded") return "completed";
  if (s === "failed") return "failed";
  if (s === "cancelled" || s === "canceled") return "cancelled";
  return "pending";
}

function mapProviderStatusToInternal(status: string):
  | "completed"
  | "failed"
  | "cancelled"
  | "pending" {
  const s = status.toUpperCase();
  if (s === "SUCCESS") return "completed";
  if (s === "FAILED") return "failed";
  if (s === "CANCELLED") return "cancelled";
  return "pending";
}

// POST /api/orders/webhook
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    await rateLimit(request, "general");
    Logger.info("Début POST /api/orders/webhook", context);

    // Récupérer le body brut pour la vérification de signature Wave
    const rawBody = await request.text();
    let body: any;
    try {
      body = JSON.parse(rawBody);
    } catch (error) {
      Logger.error("Erreur parsing JSON", error as Error, context);
      return ApiError.badRequest("Format JSON invalide");
    }

    // Détecter le provider: Wave a un header Wave-Signature et une structure différente
    const waveSignature = request.headers.get("wave-signature");
    const isWaveWebhook = !!waveSignature || (body.type && body.data);

    if (isWaveWebhook) {
      // Traitement du webhook Wave
      return await handleWaveWebhook(
        request,
        body,
        rawBody,
        waveSignature || "",
        context
      );
    } else {
      // Traitement du webhook OMProvider (Orange Money)
      return await handleOMProviderWebhook(request, body, context);
    }
  } catch (error) {
    Logger.error("Erreur POST /api/orders/webhook", error as Error, context);
    return ApiError.handle(error);
  }
}

// Handler pour les webhooks Wave
async function handleWaveWebhook(
  request: NextRequest,
  body: any,
  rawBody: string,
  waveSignature: string,
  context: any
) {
  // Valider le schéma Wave
  const waveWebhook = WaveWebhookSchema.parse(body);

  // Déterminer le numéro de commande depuis client_reference
  const orderNumber = waveWebhook.data.client_reference;
  if (!orderNumber) {
    Logger.warn("Webhook Wave sans orderNumber", context, {
      transactionId: waveWebhook.data.transaction_id,
      eventId: waveWebhook.id,
    });
    return ApiError.badRequest("orderNumber manquant dans client_reference");
  }

  // Charger la commande
  const order = await prisma.order.findUnique({
    where: { orderNumber },
    select: {
      id: true,
      orderNumber: true,
      status: true,
      paymentStatus: true,
      finalAmount: true,
      paymentMethodId: true,
    },
  });

  if (!order) {
    Logger.warn("Commande introuvable pour webhook Wave", context, { orderNumber });
    return ApiError.notFound("Commande introuvable");
  }

  // Résoudre paymentMethodId - chercher la méthode Wave avec sa config
  let paymentMethodId = order.paymentMethodId;
  let waveMethod = null;

  if (paymentMethodId) {
    // Vérifier que la méthode de paiement de la commande est bien Wave
    waveMethod = await prisma.paymentMethod.findUnique({
      where: { id: paymentMethodId },
      select: { id: true, provider: true, config: true },
    });
    if (waveMethod?.provider !== "Wave") {
      waveMethod = null;
    }
  }

  if (!waveMethod) {
    // Chercher la méthode Wave active
    waveMethod = await prisma.paymentMethod.findFirst({
      where: {
        provider: "Wave",
        isActive: true,
      },
      select: { id: true, provider: true, config: true },
    });
    if (waveMethod?.id) {
      paymentMethodId = waveMethod.id;
    }
  }

  if (!waveMethod || !paymentMethodId) {
    Logger.warn("Aucune méthode de paiement Wave trouvée", context, {
      orderNumber,
    });
    return ApiError.badRequest("Méthode de paiement Wave introuvable");
  }

  // Récupérer le webhook_secret depuis la configuration de la méthode de paiement
  const config = (waveMethod.config || {}) as {
    currency?: string;
    api_key?: string;
    webhook_secret?: string;
  };
  const webhookSecret = config.webhook_secret;

  // Vérifier la signature Wave
  if (!webhookSecret) {
    Logger.warn("webhook_secret non configuré dans la méthode de paiement Wave", context);
    // En développement, on peut continuer sans vérification
    // En production, il faudrait rejeter la requête
    // if (process.env.NODE_ENV === "production") {
      return ApiError.unauthorized("Configuration webhook Wave manquante (webhook_secret)");
    // }
  } else if (waveSignature) {
    const isValid = verifyWaveSignature(rawBody, waveSignature, webhookSecret);
    if (!isValid) {
      Logger.error("Signature Wave invalide", new Error("Invalid signature"), context);
      return ApiError.unauthorized("Signature webhook Wave invalide");
    }
    Logger.info("Signature Wave vérifiée avec succès", context);
  }

  // Mapper le statut Wave vers le statut interne
  const internalStatus = mapWaveStatusToInternal(
    waveWebhook.data.payment_status
  );

  // Chercher transaction existante par transactionId
  const existingTx = await prisma.paymentTransaction.findUnique({
    where: { transactionId: waveWebhook.data.transaction_id },
    select: { id: true, status: true, providerResponse: true },
  });

  // Construire les données de transaction
  const amount = parseFloat(waveWebhook.data.amount);
  const baseTxData = {
    amount,
    currency: waveWebhook.data.currency || "XOF",
    status: internalStatus,
    type: waveWebhook.type || "checkout.session.completed",
    processedAt:
      internalStatus === "completed" && waveWebhook.data.when_completed
        ? new Date(waveWebhook.data.when_completed)
        : internalStatus === "completed"
        ? new Date()
        : undefined,
    failureReason:
      internalStatus === "failed"
        ? waveWebhook.data.last_payment_error || undefined
        : undefined,
    providerResponse: {
      providerPayload: waveWebhook,
      receivedAt: new Date().toISOString(),
      provider: "Wave",
      eventId: waveWebhook.id,
      eventType: waveWebhook.type,
    } as any,
  };

  let txId = existingTx?.id;

  if (existingTx) {
    // Mise à jour de la transaction existante
    const updated = await prisma.paymentTransaction.update({
      where: { id: existingTx.id },
      data: {
        ...baseTxData,
        providerResponse: {
          ...(existingTx.providerResponse as object || {}),
          webhookUpdate: baseTxData.providerResponse,
        },
      },
      select: { id: true },
    });
    txId = updated.id;
  } else {
    // Création de la transaction si absente
    const created = await prisma.paymentTransaction.create({
      data: {
        transactionId: waveWebhook.data.transaction_id,
        orderId: order.id,
        paymentMethodId,
        ...baseTxData,
      },
      select: { id: true },
    });
    txId = created.id;
  }

  // Mise à jour du statut de la commande
  let orderUpdateData: Record<string, any> = {};
  switch (internalStatus) {
    case "completed":
      orderUpdateData.paymentStatus = "paid";
      if (order.status === "pending") {
        orderUpdateData.status = "confirmed";
      }
      break;
    case "failed":
      orderUpdateData.paymentStatus = "failed";
      break;
    case "cancelled":
      orderUpdateData.paymentStatus = "failed";
      break;
    case "pending":
      orderUpdateData.paymentStatus = "pending";
      break;
    default:
      break;
  }

  if (Object.keys(orderUpdateData).length > 0) {
    await prisma.order.update({ where: { id: order.id }, data: orderUpdateData });
  }

  Logger.info("Webhook Wave traité", context, {
    orderNumber: order.orderNumber,
    transactionId: waveWebhook.data.transaction_id,
    internalStatus,
    eventType: waveWebhook.type,
  });

  return ApiResponse.success({
    message: "Webhook Wave traité",
    order: {
      orderNumber: order.orderNumber,
      paymentStatus: orderUpdateData.paymentStatus || order.paymentStatus,
      status: orderUpdateData.status || order.status,
    },
    transaction: {
      transactionId: waveWebhook.data.transaction_id,
      status: internalStatus,
      currency: waveWebhook.data.currency,
      amount,
      id: txId,
    },
    redirectUrls: {
      success: waveWebhook.data.success_url,
      cancel: waveWebhook.data.error_url,
    },
  });
}

// Handler pour les webhooks OMProvider (Orange Money)
async function handleOMProviderWebhook(
  request: NextRequest,
  body: any,
  context: any
) {
  const webhook = OMProviderWebhookSchema.parse(body);

  const internalStatus = mapProviderStatusToInternal(webhook.status);

  // Déterminer le numéro de commande (orderNumber) depuis metadata.orderNumber
  const orderNumber = webhook.metadata?.orderNumber || webhook.reference;
  if (!orderNumber) {
    Logger.warn("Webhook OMProvider sans orderNumber", context, {
      transactionId: webhook.transactionId,
    });
    return ApiError.badRequest("orderNumber manquant dans metadata ou reference");
  }

  // Charger la commande
  const order = await prisma.order.findUnique({
    where: { orderNumber },
    select: {
      id: true,
      orderNumber: true,
      status: true,
      paymentStatus: true,
      finalAmount: true,
      paymentMethodId: true,
    },
  });

  if (!order) {
    Logger.warn("Commande introuvable pour webhook OMProvider", context, { orderNumber });
    return ApiError.notFound("Commande introuvable");
  }

  // Chercher transaction existante par transactionId
  const existingTx = await prisma.paymentTransaction.findUnique({
    where: { transactionId: webhook.transactionId },
    select: { id: true, status: true, providerResponse: true },
  });

  // Résoudre paymentMethodId
  let paymentMethodId = order.paymentMethodId || webhook.metadata?.paymentMethodId;

  if (!paymentMethodId) {
    Logger.warn("Aucune méthode de paiement résolue pour la transaction", context, {
      orderNumber,
      channel: webhook.channel,
      paymentMethod: webhook.paymentMethod,
    });
    return ApiError.badRequest("Méthode de paiement introuvable pour cette transaction");
  }

  // Construire les données de transaction
  const baseTxData = {
    amount: webhook.amount.value,
    currency: webhook.amount.unit || "XOF",
    status: internalStatus,
    type: webhook.type || webhook.channel || "",
    processedAt: internalStatus === "completed" ? new Date() : undefined,
    failureReason:
      internalStatus === "failed"
        ? webhook.detail || webhook.metadata?.Cause || undefined
        : undefined,
    providerResponse: {
      providerPayload: webhook,
      receivedAt: new Date().toISOString(),
      channel: webhook.channel,
      paymentMethod: webhook.paymentMethod,
    } as any,
  };

  let txId = existingTx?.id;

  if (existingTx) {
    // Mise à jour de la transaction existante
    const updated = await prisma.paymentTransaction.update({
      where: { id: existingTx.id },
      data: {
        ...baseTxData,
        providerResponse: {
          ...(existingTx.providerResponse as object || {}),
          webhookUpdate: baseTxData.providerResponse,
        },
      },
      select: { id: true },
    });
    txId = updated.id;
  } else {
    // Création de la transaction si absente
    const created = await prisma.paymentTransaction.create({
      data: {
        transactionId: webhook.transactionId,
        orderId: order.id,
        paymentMethodId,
        ...baseTxData,
      },
      select: { id: true },
    });
    txId = created.id;
  }

  // Mise à jour du statut de la commande
  let orderUpdateData: Record<string, any> = {};
  switch (internalStatus) {
    case "completed":
      orderUpdateData.paymentStatus = "paid";
      if (order.status === "pending") {
        orderUpdateData.status = "confirmed";
      }
      break;
    case "failed":
      orderUpdateData.paymentStatus = "failed";
      break;
    case "cancelled":
      orderUpdateData.paymentStatus = "failed";
      break;
    case "pending":
      orderUpdateData.paymentStatus = "pending";
      break;
    default:
      break;
  }

  if (Object.keys(orderUpdateData).length > 0) {
    await prisma.order.update({ where: { id: order.id }, data: orderUpdateData });
  }

  Logger.info("Webhook OMProvider traité", context, {
    orderNumber: order.orderNumber,
    transactionId: webhook.transactionId,
    internalStatus,
  });

  return ApiResponse.success({
    message: "Webhook traité",
    order: {
      orderNumber: order.orderNumber,
      paymentStatus: orderUpdateData.paymentStatus || order.paymentStatus,
      status: orderUpdateData.status || order.status,
    },
    transaction: {
      transactionId: webhook.transactionId,
      status: internalStatus,
      currency: webhook.amount.unit,
      amount: webhook.amount.value,
      id: txId,
    },
    redirectUrls: {
      success: webhook.metadata?.successRedirectUrl,
      cancel: webhook.metadata?.cancelRedirectUrl,
    },
  });
}

// OPTIONS /api/orders/webhook
export async function OPTIONS() {
  return ApiResponse.success({ ok: true });
}