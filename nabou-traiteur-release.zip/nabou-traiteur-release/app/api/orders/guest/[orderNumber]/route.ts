import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { ERROR_CODES } from "@/lib/error-codes";

// Validation schema for query parameters
const TrackingQuerySchema = z.object({
  token: z.string().optional(),
  email: z.string().email().optional(),
});

// GET /api/orders/guest/[orderNumber] - Suivre une commande (invité)
export async function GET(request: NextRequest, { params }: { params: Promise<{ orderNumber: string }> }) {
  try {
    // Rate limiting
    await rateLimit(request, "orders");

    const { searchParams } = new URL(request.url);
    const queryParams = {
      token: searchParams.get("token") || undefined,
      email: searchParams.get("email") || undefined,
    };

    const validatedQuery = TrackingQuerySchema.parse(queryParams);
    const { orderNumber } = await params;

    // Find the order
    const order = await prisma.order.findUnique({
      where: { orderNumber },
      include: {
        items: {
          include: {
            menuItem: {
              select: {
                id: true,
                name: true,
                description: true,
                image: true,
                category: {
                  select: {
                    id: true,
                    name: true,
                  },
                },
              },
            },
          },
        },
        deliveryZone: {
          select: {
            id: true,
            name: true,
            deliveryFee: true,
            areas: true,
          },
        },
        weeklyMenu: {
          select: {
            id: true,
            name: true,
            startDate: true,
            endDate: true,
          },
        },
        transactions: {
          select: {
            id: true,
            amount: true,
            status: true,
            transactionId: true,
            createdAt: true,
          },
          orderBy: {
            createdAt: "desc",
          },
        },
        promotionUsage: {
          include: {
            promotion: {
              select: {
                id: true,
                name: true,
                code: true,
                type: true,
                value: true,
              },
            },
          },
        },
        paymentMethod: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });

    if (!order) {
      return ApiError.notFound("Commande introuvable");
    }

    // Allow public access to order details
    // Optional: Add basic verification if email is provided
    if (validatedQuery.email) {
      // Could add email verification logic here if needed
      // For now, we allow access regardless
    }

    // Format the response
    const formattedOrder = {
      id: order.id,
      orderNumber: order.orderNumber,
      status: order.status,
      type: order.type,
      totalAmount: Number(order.totalAmount),
      deliveryFee: Number(order.deliveryFee),
      discountAmount: Number(order.discountAmount),
      finalAmount: Number(order.finalAmount),
      paymentStatus: order.paymentStatus,
      paymentMethod: order.paymentMethod
        ? {
            id: order.paymentMethod.id,
            name: order.paymentMethod.name,
          }
        : null,

      // Delivery information
      deliveryInfo: {
        address: order.deliveryAddress,
        city: order.deliveryCity,
        postalCode: order.deliveryPostalCode,
        phone: order.deliveryPhone,
        date: order.deliveryDate,
        time: order.deliveryTime,
        zone: order.deliveryZone
          ? {
              id: order.deliveryZone.id,
              name: order.deliveryZone.name,
              deliveryFee: Number(order.deliveryZone.deliveryFee),
              areas: order.deliveryZone.areas,
            }
          : null,
      },

      // Order items
      items: order.items.map((item) => ({
        id: item.id,
        quantity: item.quantity,
        unitPrice: Number(item.unitPrice),
        totalPrice: Number(item.totalPrice),
        options: item.options,
        notes: item.notes,
        menuItem: {
          id: item.menuItem.id,
          name: item.menuItem.name,
          description: item.menuItem.description,
          imageUrl: item.menuItem.image,
          category: item.menuItem.category,
        },
      })),

      // Weekly menu
      weeklyMenu: order.weeklyMenu
        ? {
            id: order.weeklyMenu.id,
            name: order.weeklyMenu.name,
            startDate: order.weeklyMenu.startDate,
            endDate: order.weeklyMenu.endDate,
          }
        : null,

      // Payment transactions
      paymentTransactions: order.transactions.map((transaction) => ({
        id: transaction.id,
        amount: Number(transaction.amount),
        status: transaction.status,
        transactionId: transaction.transactionId,
        createdAt: transaction.createdAt,
      })),

      // Promotions
      promotions: order.promotionUsage.map((usage) => ({
        id: usage.promotion.id,
        name: usage.promotion.name,
        code: usage.promotion.code,
        type: usage.promotion.type,
        value: Number(usage.promotion.value),
        discountAmount: Number(usage.discountAmount),
      })),

      // Timestamps
      createdAt: order.createdAt,
      updatedAt: order.updatedAt,

      // Customer notes
      customerNotes: order.customerNotes,

      // Status timeline (simplified)
      statusHistory: [
        {
          status: "pending",
          timestamp: order.createdAt,
          description: "Commande reçue",
        },
        ...(order.status !== "pending"
          ? [
              {
                status: order.status,
                timestamp: order.updatedAt,
                description: getStatusDescription(order.status),
              },
            ]
          : []),
      ],
    };

    return ApiResponse.success(formattedOrder, "Détails de la commande récupérés");
  } catch (error: any) {
    console.error("Error tracking guest order:", error);
    return ApiError.handle(error);
  }
}

// Helper function to get status description
function getStatusDescription(status: string): string {
  const descriptions: Record<string, string> = {
    pending: "Commande en attente",
    confirmed: "Commande confirmée",
    preparing: "Préparation en cours",
    ready: "Commande prête",
    out_for_delivery: "En cours de livraison",
    delivered: "Commande livrée",
    cancelled: "Commande annulée",
  };

  return descriptions[status] || "Statut inconnu";
}

// OPTIONS - CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
