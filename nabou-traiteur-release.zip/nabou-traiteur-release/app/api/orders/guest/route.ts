import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { generateGuestToken } from "@/lib/auth";
import { ERROR_CODES } from "@/lib/error-codes";
import { randomUUID } from "crypto";
import {
  sendWhatsAppNotification,
  sendClientWhatsAppNotification,
} from "@/lib/notifications";
import { validateAndCalculatePromoDiscount } from "@/lib/promo-validation-utils";

// Validation schemas
const GuestOrderSchema = z.object({
  // Customer information
  customerInfo: z.object({
    firstName: z.string().min(0).optional(),
    lastName: z.string().min(0).optional(),
    email: z.string().min(0).email().optional(),
    phone: z.string().min(0).optional(),
  }),

  // Order items
  items: z
    .array(
      z.object({
        menuItemId: z.string().min(1, "ID du plat requis"),
        quantity: z.number().int().min(1, "Quantité minimum 1"),
        options: z.record(z.any()).optional(),
        notes: z.string().optional(),
      })
    )
    .min(1, "Au moins un article requis"),

  // Delivery information
  deliveryInfo: z.object({
    type: z.enum(["delivery", "pickup"]),
    deliveryTime: z.string().min(0).optional(),
    deliveryZoneId: z.string().min(0).optional(),
    deliveryAddress: z.string().min(0).optional(),
  }),

  // Payment information - optional for employees
  paymentMethod: z.string().min(0).optional(),

  // Optional
  customerNotes: z.string().min(0).optional(),
  promotionCode: z.string().min(0).optional(),
  weeklyMenuId: z.string(),
  employeeId: z.string().min(0).optional(), // New field for employee orders
});

// Helper function to generate order number
function generateOrderNumber(): string {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const random = Math.floor(Math.random() * 9999)
    .toString()
    .padStart(4, "0");

  return `NAB-${year}${month}${day}-${random}`;
}

// Helper function to check stock availability
async function checkStockAvailability(
  items: any[],
  weeklyMenuId: string,
  deliveryDate: Date
) {
  const unavailableItems: Array<{
    menuItemId: string;
    menuItemName: string;
    requestedQuantity: number;
    availableQuantity: number;
  }> = [];

  // Determine day of week for delivery date
  let dayOfWeek = deliveryDate.getDay();

  // Group items by menuItemId to sum quantities
  const itemQuantities: Record<string, number> = {};
  for (const item of items) {
    itemQuantities[item.menuItemId] = (itemQuantities[item.menuItemId] || 0) + item.quantity;
  }

  // Check stock for each unique menu item
  for (const [menuItemId, totalQuantity] of Object.entries(itemQuantities)) {
    // Find the dish in the weekly menu
    const weeklyMenuDish = await prisma.weeklyMenuDish.findFirst({
      where: {
        weeklyMenuId,
        menuItemId,
        dayOfWeek,
        isAvailable: true,
      },
      include: {
        menuItem: {
          select: { name: true, isAvailable: true }
        }
      }
    });

    if (!weeklyMenuDish) {
      // Item not found in weekly menu or not available
      const menuItem = await prisma.menuItem.findUnique({
        where: { id: menuItemId },
        select: { name: true }
      });
      
      unavailableItems.push({
        menuItemId,
        menuItemName: menuItem?.name || "Plat inconnu",
        requestedQuantity: totalQuantity,
        availableQuantity: 0,
      });
      continue;
    }

    // Check if menu item is available
    if (!weeklyMenuDish.menuItem.isAvailable) {
      unavailableItems.push({
        menuItemId,
        menuItemName: weeklyMenuDish.menuItem.name,
        requestedQuantity: totalQuantity,
        availableQuantity: 0,
      });
      continue;
    }

    // Check if requested quantity exceeds available stock
    if (totalQuantity > weeklyMenuDish.quantity) {
      unavailableItems.push({
        menuItemId,
        menuItemName: weeklyMenuDish.menuItem.name,
        requestedQuantity: totalQuantity,
        availableQuantity: weeklyMenuDish.quantity,
      });
    }
  }

  return {
    isStockAvailable: unavailableItems.length === 0,
    unavailableItems,
  };
}

// Helper function to calculate order totals
async function calculateOrderTotals(
  items: any[],
  deliveryZoneId?: string,
  promotionCode?: string,
  isEmployeeOrder = false // New parameter to indicate employee order
) {
  let totalAmount = 0;
  let deliveryFee = 0;
  let discountAmount = 0;

  // Preload and compute each item unitPrice respecting selected options
  const itemsWithPrices = await Promise.all(
    items.map(async (item) => {
      const menuItem = await prisma.menuItem.findUnique({
        where: { id: item.menuItemId },
        include: { options: true },
      });

      if (!menuItem || !menuItem.isAvailable) {
        throw new Error(`Plat non disponible: ${item.menuItemId}`);
      }

      let unitPrice = Number(menuItem.price);
      if (
        item.options &&
        typeof item.options === "object" &&
        item.options !== null &&
        "size" in item.options
      ) {
        const sizeOption = menuItem.options.find((opt) => opt.type === "size");

        if (
          sizeOption &&
          sizeOption.values &&
          Array.isArray(sizeOption.values)
        ) {
          const selectedSize = sizeOption.values.find(
            (val: any) =>
              val.name.toLowerCase() === item.options.size.toLowerCase()
          );

          if (
            selectedSize &&
            typeof selectedSize === "object" &&
            selectedSize !== null &&
            "price" in selectedSize
          ) {
            unitPrice = Number(selectedSize.price);
          }
        }
      }

      const lineTotal = unitPrice * item.quantity;
      totalAmount += lineTotal;

      return {
        menuItemId: item.menuItemId,
        quantity: item.quantity,
        unitPrice,
      };
    })
  );

  // Calculate delivery fee - optional for employee orders
  if (deliveryZoneId && !isEmployeeOrder) {
    const deliveryZone = await prisma.deliveryZone.findUnique({
      where: { id: deliveryZoneId, isActive: true },
      select: { deliveryFee: true, minOrderAmount: true },
    });

    if (!deliveryZone) {
      throw new Error("Zone de livraison non disponible");
    }

    if (
      deliveryZone.minOrderAmount &&
      totalAmount < Number(deliveryZone.minOrderAmount)
    ) {
      throw new Error(
        `Montant minimum de commande non atteint: ${deliveryZone.minOrderAmount}€`
      );
    }

    deliveryFee = Number(deliveryZone.deliveryFee);
  }

  // const validation = await validateAndCalculatePromoDiscount({
  //   code: "RAKTAK",
  //   orderAmount: totalAmount,
  //   items: itemsWithPrices,
  // });

  // // Les promos ne s'appliquent pas à la livraison sauf si type === free_delivery
  // discountAmount = validation.discount.amount;

  // Apply promotion if provided
  if (promotionCode) {
    const validation = await validateAndCalculatePromoDiscount({
      code: promotionCode,
      orderAmount: totalAmount,
      items: itemsWithPrices,
    });

    if (!validation.isValid) {
      throw new Error(
        validation.error || "Code promo invalide ou non applicable"
      );
    }

    // Les promos ne s'appliquent pas à la livraison sauf si type === free_delivery
    discountAmount = validation.discount.amount;
    if (validation.discount.isFreeDelivery) {
      // free_delivery: réduction appliquée sur la livraison (plafonnée au deliveryFee)
      discountAmount = deliveryFee;
      // effect: deliveryFee effectively considered 0 at total level via subtracting discountAmount equal to deliveryFee below
    }
  }

  const finalAmount = totalAmount + deliveryFee - discountAmount;

  return {
    totalAmount,
    deliveryFee,
    discountAmount,
    finalAmount,
  };
}

// POST /api/orders/guest - Créer une commande (invité)
export async function POST(request: NextRequest) {
  try {
    // Rate limiting
    await rateLimit(request, "orders");

    const body = await request.json();
    const validatedData = GuestOrderSchema.parse(body);

    const {
      customerInfo,
      items,
      deliveryInfo,
      paymentMethod,
      customerNotes,
      promotionCode,
      weeklyMenuId,
      employeeId,
    } = validatedData;

    // Use the previously determined isEmployeeOrder value
    let employee = null;
    let companyLimits: any[] = [];

    if (employeeId) {
      // Validate employee exists and get company info
      employee = await prisma.user.findUnique({
        where: { id: employeeId },
        include: {
          company: {
            include: {
              limits: {
                include: {
                  category: true,
                },
              },
            },
          },
        },
      });

      if (employee && employee.company) {
        companyLimits = employee.company.limits;

        // Validate category quantity limits
        if (companyLimits.length > 0) {
          // Group items by category
          const menuItemIds = items.map((item) => item.menuItemId);
          const menuItems = await prisma.menuItem.findMany({
            where: { id: { in: menuItemIds } },
            include: { category: true },
          });

          const categoryQuantities: Record<string, number> = {};

          for (const item of items) {
            const menuItem = menuItems.find((mi) => mi.id === item.menuItemId);
            if (menuItem) {
              const categoryId = menuItem.categoryId;
              categoryQuantities[categoryId] =
                (categoryQuantities[categoryId] || 0) + item.quantity;
            }
          }

          // Check limits
          for (const [categoryId, totalQuantity] of Object.entries(
            categoryQuantities
          )) {
            const limit = companyLimits.find(
              (l) => l.categoryId === categoryId
            );
            if (limit && totalQuantity > limit.maxPerOrder) {
              const categoryName = limit.category.name;
              return ApiError.badRequest(
                `Limite de quantité dépassée pour la catégorie "${categoryName}": ${totalQuantity} commandés, maximum autorisé: ${limit.maxPerOrder}`
              );
            }
          }
        }
      }
    }

    // Calculate order totals
    const totals = await calculateOrderTotals(
      items,
      deliveryInfo.deliveryZoneId,
      promotionCode,
      Boolean(employeeId)
    );

    // Generate order number and session ID
    const orderNumber = generateOrderNumber();
    const sessionId = randomUUID();
    const deliveryDate = new Date();

    // Pre-fetch all menu items to avoid queries inside transaction
    const menuItemIds = items.map((item) => item.menuItemId);
    const menuItems = await prisma.menuItem.findMany({
      where: { id: { in: menuItemIds } },
      include: {
        options: true,
      },
    });

    // Validate all menu items exist
    for (const item of items) {
      const menuItem = menuItems.find((mi) => mi.id === item.menuItemId);
      if (!menuItem) {
        throw new Error(`Plat introuvable: ${item.menuItemId}`);
      }
    }

    // Validate weekly menu exists if provided
    if (weeklyMenuId) {
      const weeklyMenu = await prisma.weeklyMenu.findUnique({
        where: { id: weeklyMenuId, isActive: true },
        select: { id: true },
      });

      if (!weeklyMenu) {
        throw new Error(
          `Menu hebdomadaire introuvable ou inactif: ${weeklyMenuId}`
        );
      }

      // Check stock availability for all items
      const stockCheck = await checkStockAvailability(
        items,
        weeklyMenuId,
        deliveryDate
      );

      if (!stockCheck.isStockAvailable) {
        const errorMessages = stockCheck.unavailableItems.map(item => {
          if (item.availableQuantity === 0) {
            return `"${item.menuItemName}" n'est pas disponible`;
          } else {
            return `"${item.menuItemName}": ${item.requestedQuantity} demandés, seulement ${item.availableQuantity} disponibles`;
          }
        });

        return ApiError.badRequest(
          `Stock insuffisant pour les plats suivants: ${errorMessages.join(', ')}`
        );
      }
    }

    // Prepare order items data outside transaction
    const orderItemsData = items.map((item) => {
      const menuItem = menuItems.find((mi) => mi.id === item.menuItemId)!;

      // Calculate correct unit price based on selected option
      let unitPrice = Number(menuItem.price); // Default price

      if (
        item.options &&
        typeof item.options === "object" &&
        item.options !== null &&
        "size" in item.options
      ) {
        // Find the size option in MenuItemOption
        const sizeOption = menuItem.options.find((opt) => opt.type === "size");
        if (
          sizeOption &&
          sizeOption.values &&
          Array.isArray(sizeOption.values)
        ) {
          const itemOptionsSize = item.options.size;
          const selectedSize = sizeOption.values.find(
            (val: any) =>
              typeof val === "object" &&
              val !== null &&
              "name" in val &&
              val.name === itemOptionsSize
          );
          if (
            selectedSize &&
            typeof selectedSize === "object" &&
            selectedSize !== null &&
            "price" in selectedSize
          ) {
            unitPrice = Number(selectedSize.price);
          }
        }
      }

      const totalPrice = unitPrice * item.quantity;

      return {
        menuItemId: item.menuItemId,
        quantity: item.quantity,
        unitPrice,
        totalPrice,
        options: item.options || {},
        notes: item.notes,
      };
    });

    // Create order in transaction (now much faster) with extended timeout
    const result = await prisma.$transaction(
      async (tx) => {
        // Create the order
        const order = await tx.order.create({
          data: {
            orderNumber,
            status: "pending",
            type: deliveryInfo.type,
            totalAmount: totals.totalAmount,
            deliveryFee: totals.deliveryFee, //should be 0 if employee
            discountAmount: totals.discountAmount,
            finalAmount: totals.finalAmount,
            paymentStatus: employeeId ? "paid" : "pending",
            paymentMethodId: employeeId ? null : paymentMethod,
            deliveryAddress: employeeId
              ? "pickup"
              : deliveryInfo.deliveryAddress,
            deliveryCity: null,
            deliveryPostalCode: null,
            customerId: employeeId,
            deliveryPhone: employee ? employee.phone : customerInfo?.phone,
            deliveryDate: deliveryDate,
            deliveryTime: deliveryInfo.deliveryTime,
            customerNotes,
            guestFirstName: employeeId
              ? null
              : employeeId
              ? null
              : customerInfo?.firstName,
            guestLastName: employeeId ? null : customerInfo?.lastName,
            guestEmail: employeeId ? null : customerInfo?.email,
            deliveryZoneId: employeeId ? null : deliveryInfo.deliveryZoneId,
            weeklyMenuId,
          },
        });

        // Create order items in batch using createMany for better performance
        await tx.orderItem.createMany({
          data: orderItemsData.map((itemData) => ({
            orderId: order.id,
            ...itemData,
          })),
        });

        // Fetch created order items for response
        const orderItems = await tx.orderItem.findMany({
          where: { orderId: order.id },
        });

        // Mettre à jour les quantités disponibles dans le menu hebdomadaire
        if (weeklyMenuId) {
          // Pour chaque article commandé, réduire la quantité disponible
          for (const item of items) {
            // Trouver le jour de la semaine pour la date de livraison
            let dayOfWeek = 1; // Par défaut lundi
            dayOfWeek = deliveryDate.getDay();

            // Trouver le plat dans le menu hebdomadaire
            const weeklyMenuDish = await tx.weeklyMenuDish.findFirst({
              where: {
                weeklyMenuId,
                menuItemId: item.menuItemId,
                dayOfWeek,
              },
            });

            if (weeklyMenuDish) {
              // Réduire la quantité disponible
              await tx.weeklyMenuDish.update({
                where: { id: weeklyMenuDish.id },
                data: {
                  quantity: Math.max(
                    0,
                    weeklyMenuDish.quantity - item.quantity
                  ),
                },
              });
            }
          }
        }

        // Record promotion usage if applicable
        if (promotionCode && totals.discountAmount > 0) {
          const promotion = await tx.promotion.findUnique({
            where: { code: promotionCode },
          });

          if (promotion) {
            await tx.promotionUsage.create({
              data: {
                promotionId: promotion.id,
                orderId: order.id,
                discountAmount: totals.discountAmount,
              },
            });
          }
        }

        return { order, orderItems };
      },
      {
        timeout: 15000, // 15 seconds timeout instead of default 5 seconds
      }
    );

    // Generate guest token for order tracking
    const guestToken = await generateGuestToken(sessionId);


    // Récupérer les informations de la zone de livraison si applicable
    let deliveryZoneName = "-";
    let deliveryZoneAreas = "pickup";

    if (deliveryInfo.deliveryZoneId) {
      const deliveryZone = await prisma.deliveryZone.findUnique({
        where: { id: deliveryInfo.deliveryZoneId },
        select: { name: true, areas: true },
      });
      if (deliveryZone) {
        deliveryZoneName = deliveryZone.name;
        deliveryZoneAreas = deliveryZone.areas.join(", ");
      }
    }

    // Récupérer les noms des articles commandés
    const orderItemsWithNames = await Promise.all(
      result.orderItems.map(async (item) => {
        const menuItem = menuItems.find((mi) => mi.id === item.menuItemId);
        return {
          ...item,
          menuItemName: menuItem?.name || "Article sans nom",
        };
      })
    );

    // Envoyer une notification WhatsApp au client
    const orderArticlesText = orderItemsWithNames
      .map(
        (item) => {
          const sizeInfo = item.options && typeof item.options === 'object' && item.options !== null && 'size' in item.options 
            ? ` - ${item.options.size}` 
            : '';
          return `(${item.quantity}x${sizeInfo}) ${item.menuItemName}`;
        }
      )
      .join(", ");

    const deliveryAdress = result.order.deliveryAddress || deliveryZoneAreas;
    const deliveryTime = result.order.deliveryTime || "-";
    const deliveryZone = deliveryZoneName;

    const totalArticles = Number(result.order.totalAmount);
    const discountAmount = Number(result.order.discountAmount);
    const deliveryFees = Number(result.order.deliveryFee);

    const orderTotal = totalArticles - discountAmount + deliveryFees;
    const clientPhoneNumber = employee
      ? employee.phone || "-"
      : customerInfo?.phone || "-";
    const customerName = employee
      ? `${employee.firstName} ${employee.lastName}`
      : `${customerInfo.firstName} ${customerInfo.lastName}`;

    const notificationClient = {
      orderNumber: result.order.orderNumber,
      orderTotal: `${orderTotal} F`,
      orderArticles: orderArticlesText,
      clientPhoneNumber,
      deliveryFees: deliveryFees ? `${deliveryFees} F` : "Livraison gratuite",
      deliveryAdress,
      deliveryZone,
      deliveryTime,
      customerName,
      totalArticles: `${totalArticles} F`,
      discountAmount: `${discountAmount} F`,
    };

    // console.log("notificationClient", notificationClient);
    // Initialiser le paiement avant d'envoyer les notifications
    let paymentInit: any = null;
    try {
      // Ne pas initier le paiement pour les commandes employé (déjà payées)
      if (!employeeId && result.order.paymentMethodId) {
        const reqUrl = new URL(request.url);
        const protoHeader = request.headers.get("x-forwarded-proto");
        const proto = protoHeader ? protoHeader : reqUrl.protocol.replace(":", "");
        const host = request.headers.get("host") || reqUrl.host;
        const origin = `${proto}://${host}`;

        const initRes = await fetch(
          `${origin}/api/payments/init/${result.order.orderNumber}`,
          { method: "POST" }
        );
        const initJson = await initRes.json().catch(() => null);
        if (initRes.ok) {
          paymentInit = initJson?.data ?? initJson ?? null;
        } else {
          paymentInit = {
            error: initJson?.error?.message || "Échec de l'initialisation du paiement",
            code: initJson?.error?.code || "PAYMENT_INIT_ERROR",
          };
        }
      }
    } catch (e: any) {
      paymentInit = {
        error: e?.message || "Erreur lors de l'appel d'initialisation du paiement",
        code: "PAYMENT_INIT_NETWORK_ERROR",
      };
    }

    await sendClientWhatsAppNotification(notificationClient);

    // Envoyer une notification WhatsApp au manager
    await sendWhatsAppNotification(
      result.order.orderNumber,
      customerName,
      orderTotal,
      clientPhoneNumber,
      `${deliveryZoneName} (${deliveryAdress})`,
      orderItemsWithNames
    );

    return ApiResponse.created(
      {
        order: {
          id: result.order.id,
          orderNumber: result.order.orderNumber,
          status: result.order.status,
          totalAmount: result.order.totalAmount,
          deliveryFee: result.order.deliveryFee,
          discountAmount: result.order.discountAmount,
          finalAmount: result.order.finalAmount,
          paymentStatus: result.order.paymentStatus,
          deliveryDate: result.order.deliveryDate,
          deliveryTime: result.order.deliveryTime,
          createdAt: result.order.createdAt,
          paymentInit,
        },
        customerInfo,
        guestToken,
        trackingInfo: {
          orderNumber: result.order.orderNumber,
          trackingUrl: `/orders/${result.order.orderNumber}`,
        },
      },
      "Commande créée avec succès"
    );
  } catch (error: any) {
    console.error("Error creating guest order:", error);

    // Handle specific business errors
    if (
      error.message.includes("non disponible") ||
      error.message.includes("minimum") ||
      error.message.includes("introuvable")
    ) {
      return ApiError.badRequest(error.message);
    }

    return ApiError.handle(error);
  }
}

// OPTIONS - CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
