import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { requireAuth } from "@/lib/auth";
import { ERROR_CODES } from "@/lib/error-codes";

// Validation schema
const OrderStatusUpdateSchema = z.object({
  status: z.enum(["pending", "confirmed", "preparing", "ready", "delivered", "cancelled"]),
  adminNotes: z.string().optional(),
});

// PUT /api/orders/[id]/status - Changer le statut d'une commande (admin)
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    // Rate limiting
    await rateLimit(request, "general");

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check admin permissions
    // const hasPermission = await checkPermission(user.id, "orders.update_status");
    // if (!hasPermission) {
    //   return ApiError.forbidden("Permission insuffisante");
    // }

    const { id } = await params;
    const body = await request.json();
    const { status, adminNotes } = OrderStatusUpdateSchema.parse(body);

    // Check if order exists
    const existingOrder = await prisma.order.findUnique({
      where: { id },
      select: {
        id: true,
        orderNumber: true,
        status: true,
        paymentStatus: true,
        customerId: true,
        adminNotes: true,
        customer: {
          select: {
            email: true,
            firstName: true,
            lastName: true,
          },
        },
      },
    });

    if (!existingOrder) {
      return ApiError.notFound("Commande introuvable");
    }

    // Business rules validation
    const currentStatus = existingOrder.status;

    // Cannot change status of cancelled orders (except to cancelled)
    if (currentStatus === "cancelled" && status !== "cancelled") {
      return ApiError.badRequest(
        "Impossible de modifier le statut d'une commande annulée",
        ERROR_CODES.BUSINESS_ORDER_CANNOT_BE_CANCELLED
      );
    }

    // Cannot cancel delivered orders
    if (currentStatus === "delivered" && status === "cancelled") {
      return ApiError.badRequest(
        "Impossible d'annuler une commande déjà livrée",
        ERROR_CODES.BUSINESS_ORDER_CANNOT_BE_CANCELLED
      );
    }

    // // Status transition validation
    // const validTransitions: Record<string, string[]> = {
    //   pending: ["confirmed", "cancelled"],
    //   confirmed: ["preparing", "cancelled"],
    //   preparing: ["ready", "cancelled"],
    //   ready: ["delivered", "cancelled"],
    //   delivered: [], // No transitions from delivered
    //   cancelled: [], // No transitions from cancelled
    // };

    // if (!validTransitions[currentStatus].includes(status)) {
    //   return ApiError.badRequest(
    //     `Transition de statut invalide: ${currentStatus} → ${status}`,
    //     ERROR_CODES.BUSINESS_ORDER_CANNOT_BE_CANCELLED
    //   );
    // }

    // Prepare update data
    const updateData: any = {
      status,
      adminNotes: adminNotes || existingOrder.adminNotes,
      updatedAt: new Date(),
    };

    // If status is being set to 'delivered', automatically mark payment as 'paid'
    if (status === "delivered" || status === "confirmed") {
      updateData.paymentStatus = "paid";
    }

    // Récupérer les informations complètes de la commande avant la mise à jour
    const orderDetails = await prisma.order.findUnique({
      where: { id },
      include: {
        items: {
          include: {
            menuItem: true,
          },
        },
        weeklyMenu: true,
      },
    });

    // Mettre à jour le statut de la commande dans une transaction
    const updatedOrder = await prisma.$transaction(async (tx) => {
      // Mettre à jour la commande
      const updated = await tx.order.update({
        where: { id },
        data: updateData,
        include: {
          customer: {
            select: {
              id: true,
              email: true,
              firstName: true,
              lastName: true,
              phone: true,
            },
          },
          items: {
            include: {
              menuItem: {
                select: {
                  id: true,
                  name: true,
                  price: true,
                  image: true,
                },
              },
            },
          },
          weeklyMenu: {
            select: {
              id: true,
              name: true,
              startDate: true,
              endDate: true,
            },
          },
          deliveryZone: {
            select: {
              id: true,
              name: true,
              deliveryFee: true,
            },
          },
        },
      });

      // Si la commande est annulée, restaurer les quantités des plats
      if (status === "cancelled" && orderDetails?.weeklyMenu && orderDetails.items.length > 0) {
        const weeklyMenuId = orderDetails.weeklyMenu.id;

        // Pour chaque article de la commande
        for (const item of orderDetails.items) {
          // Déterminer le jour de la semaine pour la date de livraison
          let dayOfWeek = 1; // Par défaut lundi
          if (orderDetails.deliveryDate) {
            dayOfWeek = orderDetails.deliveryDate.getDay();
          }

          // Trouver le plat dans le menu hebdomadaire
          const weeklyMenuDish = await tx.weeklyMenuDish.findFirst({
            where: {
              weeklyMenuId,
              menuItemId: item.menuItemId,
              dayOfWeek,
            },
          });

          if (weeklyMenuDish) {
            // Restaurer la quantité disponible
            await tx.weeklyMenuDish.update({
              where: { id: weeklyMenuDish.id },
              data: {
                quantity: weeklyMenuDish.quantity + item.quantity,
              },
            });
          }
        }
      }

      return updated;
    });

    // TODO: Send notification to customer about status change
    // await sendOrderStatusNotification(updatedOrder);

    // Format response
    const formattedOrder = {
      id: updatedOrder.id,
      orderNumber: updatedOrder.orderNumber,
      status: updatedOrder.status,
      type: updatedOrder.type,
      totalAmount: updatedOrder.totalAmount,
      deliveryFee: updatedOrder.deliveryFee,
      discountAmount: updatedOrder.discountAmount,
      finalAmount: updatedOrder.finalAmount,
      paymentStatus: updatedOrder.paymentStatus,
      paymentMethodId: updatedOrder.paymentMethodId,
      deliveryAddress: updatedOrder.deliveryAddress,
      deliveryCity: updatedOrder.deliveryCity,
      deliveryPostalCode: updatedOrder.deliveryPostalCode,
      deliveryPhone: updatedOrder.deliveryPhone,
      deliveryDate: updatedOrder.deliveryDate,
      deliveryTime: updatedOrder.deliveryTime,
      customerNotes: updatedOrder.customerNotes,
      adminNotes: updatedOrder.adminNotes,
      createdAt: updatedOrder.createdAt,
      updatedAt: updatedOrder.updatedAt,
      customer: updatedOrder.customer,
      weeklyMenu: updatedOrder.weeklyMenu,
      deliveryZone: updatedOrder.deliveryZone,
      items: updatedOrder.items.map((item: any) => ({
        id: item.id,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        totalPrice: item.totalPrice,
        options: item.options,
        notes: item.notes,
        menuItem: {
          ...item.menuItem,
          imageUrl: item.menuItem.image,
        },
      })),
    };

    return ApiResponse.updated(formattedOrder, `Statut de la commande mis à jour: ${status}`);
  } catch (error) {
    console.error("Error updating order status:", error);
    return ApiError.handle(error);
  }
}

// OPTIONS - CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "PUT, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
