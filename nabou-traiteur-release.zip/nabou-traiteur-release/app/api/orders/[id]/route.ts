import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { requireAuth } from "@/lib/auth";
import { ERROR_CODES } from "@/lib/error-codes";

// Validation schemas
const OrderQuerySchema = z.object({
  startDate: z.string().optional(),
  endDate: z.string().optional(),
});

const OrderUpdateSchema = z.object({
  status: z
    .enum(["pending", "confirmed", "preparing", "ready", "delivered", "cancelled"])
    .optional(),
  paymentStatus: z.enum(["pending", "paid", "failed", "refunded"]).optional(),
  deliveryAddress: z.string().optional(),
  deliveryCity: z.string().optional(),
  deliveryPostalCode: z.string().optional(),
  deliveryPhone: z.string().optional(),
  deliveryDate: z.string().optional(),
  deliveryTime: z.string().optional(),
  customerNotes: z.string().optional(),
  adminNotes: z.string().optional(),
});

const OrderStatusUpdateSchema = z.object({
  status: z.enum(["pending", "confirmed", "preparing", "ready", "delivered", "cancelled"]),
  adminNotes: z.string().optional(),
});

// GET /api/orders/[id] - Détails d'une commande (admin)
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    // Rate limiting
    await rateLimit(request, "general");

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check admin permissions
    // const hasPermission = await checkPermission(user.id, "orders.read");
    // if (!hasPermission) {
    //   return ApiError.forbidden("Permission insuffisante");
    // }

    const { id } = await params;

    // Parse and validate query parameters for filtering
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());
    const validatedQuery = OrderQuerySchema.parse(queryParams);

    const { startDate, endDate } = validatedQuery;

    // Build include object based on query parameters
    const include: any = {
      paymentMethod: {
        select: {
          id: true,
          name: true,
          type: true,
        },
      },

      customer: {
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          phone: true,
        },
      },

      items: {
        include: {
          menuItem: {
            select: {
              id: true,
              name: true,
              description: true,
              price: true,
              image: true,
              category: {
                select: {
                  id: true,
                  name: true,
                },
              },
            },
          },
        },
      },

      weeklyMenu: {
        select: {
          id: true,
          name: true,
          startDate: true,
          endDate: true,
        },
      },

      deliveryZone: {
        select: {
          id: true,
          name: true,
          deliveryFee: true,
          areas: true,
          estimatedTime: true,
        },
      },

      transactions: {
        select: {
          id: true,
          transactionId: true,
          amount: true,
          currency: true,
          status: true,
          type: true,
          processedAt: true,
          createdAt: true,
        },
      },

      promotionUsage: {
        include: {
          promotion: {
            select: {
              id: true,
              name: true,
              code: true,
              type: true,
              value: true,
            },
          },
        },
      },
    };

    // Build where clause with date filters
    const where: any = { id };

    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0); // Début de la journée
        where.createdAt.gte = start;
      }
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999); // Fin de la journée
        where.createdAt.lte = end;
      }
    }

    // Get order with filtered related data
    const order = await prisma.order.findUnique({
      where,
      include,
    });

    if (!order) {
      return ApiError.notFound("Commande introuvable");
    }

    // Format response
    const formattedOrder = {
      id: order.id,
      orderNumber: order.orderNumber,
      status: order.status,
      type: order.type,
      totalAmount: Number(order.totalAmount),
      deliveryFee: order.deliveryFee ? Number(order.deliveryFee) : undefined,
      discountAmount: order.discountAmount ? Number(order.discountAmount) : undefined,
      finalAmount: Number(order.finalAmount),
      paymentStatus: order.paymentStatus,
      paymentMethod: order.paymentMethod?.name,
      deliveryAddress: order.deliveryAddress,
      deliveryCity: order.deliveryCity,
      deliveryPostalCode: order.deliveryPostalCode,
      deliveryPhone: order.deliveryPhone,
      deliveryDate: order.deliveryDate?.toISOString(),
      deliveryTime: order.deliveryTime,
      customerNotes: order.customerNotes,
      adminNotes: order.adminNotes,
      createdAt: order.createdAt.toISOString(),
      updatedAt: order.updatedAt.toISOString(),
      customer:
        order.customer ||
        (order.guestFirstName || order.guestLastName
          ? {
            id: null,
            email: order.guestEmail,
            firstName: order.guestFirstName,
            lastName: order.guestLastName,
            phone: order.deliveryPhone,
          }
          : null),
      weeklyMenu: order.weeklyMenu
        ? {
          id: order.weeklyMenu.id,
          name: order.weeklyMenu.name,
          startDate: order.weeklyMenu.startDate.toISOString(),
          endDate: order.weeklyMenu.endDate.toISOString(),
        }
        : undefined,
      deliveryZone: order.deliveryZone
        ? {
          id: order.deliveryZone.id,
          name: order.deliveryZone.name,
          deliveryFee: Number(order.deliveryZone.deliveryFee),
          areas: order.deliveryZone.areas,
        }
        : undefined,
      items: order.items.map((item: any) => ({
        id: item.id,
        quantity: item.quantity,
        unitPrice: Number(item.unitPrice),
        totalPrice: Number(item.totalPrice),
        options: item.options,
        notes: item.notes,
        menuItem: {
          ...item.menuItem,
          price: Number(item.menuItem.price),
          imageUrl: item.menuItem.image,
        },
      })),
      itemsCount: order.items.length,
      transactions: order.transactions,
      promotionUsage: order.promotionUsage,
    };

    return ApiResponse.success(formattedOrder);
  } catch (error) {
    console.error("Error fetching order:", error);
    return ApiError.handle(error);
  }
}

// PUT /api/orders/[id] - Modifier une commande (admin)
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    // Rate limiting
    await rateLimit(request, "general");

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check admin permissions
    // const hasPermission = await checkPermission(user.id, "orders.update");
    // if (!hasPermission) {
    //   return ApiError.forbidden("Permission insuffisante");
    // }

    const { id } = await params;
    const body = await request.json();
    const validatedData = OrderUpdateSchema.parse(body);

    // Check if order exists
    const existingOrder = await prisma.order.findUnique({
      where: { id },
      select: {
        id: true,
        status: true,
        paymentStatus: true,
      },
    });

    if (!existingOrder) {
      return ApiError.notFound("Commande introuvable");
    }

    // Business rules validation
    if (validatedData.status) {
      // Cannot change status of cancelled orders
      if (existingOrder.status === "cancelled" && validatedData.status !== "cancelled") {
        return ApiError.badRequest(
          "Impossible de modifier le statut d'une commande annulée",
          ERROR_CODES.BUSINESS_ORDER_CANNOT_BE_CANCELLED
        );
      }

      // Cannot cancel delivered orders
      if (existingOrder.status === "delivered" && validatedData.status === "cancelled") {
        return ApiError.badRequest(
          "Impossible d'annuler une commande déjà livrée",
          ERROR_CODES.BUSINESS_ORDER_CANNOT_BE_CANCELLED
        );
      }
    }

    // Prepare update data
    const updateData: any = {
      ...validatedData,
      updatedAt: new Date(),
    };

    // Convert deliveryDate string to Date if provided
    if (validatedData.deliveryDate) {
      updateData.deliveryDate = new Date(validatedData.deliveryDate);
    }

    // Update order
    const updatedOrder = await prisma.order.update({
      where: { id },
      data: updateData,
      include: {
        customer: {
          select: {
            id: true,
            email: true,
            firstName: true,
            lastName: true,
            phone: true,
          },
        },
        items: {
          include: {
            menuItem: {
              select: {
                id: true,
                name: true,
                price: true,
                image: true,
              },
            },
          },
        },
        weeklyMenu: {
          select: {
            id: true,
            name: true,
            startDate: true,
            endDate: true,
          },
        },
        deliveryZone: {
          select: {
            id: true,
            name: true,
            deliveryFee: true,
          },
        },
        transactions: {
          select: {
            id: true,
            amount: true,
            status: true,
            type: true,
            createdAt: true,
          },
        },
      },
    });

    // Format response
    const formattedOrder = {
      id: updatedOrder.id,
      orderNumber: updatedOrder.orderNumber,
      status: updatedOrder.status,
      type: updatedOrder.type,
      totalAmount: updatedOrder.totalAmount,
      deliveryFee: updatedOrder.deliveryFee,
      discountAmount: updatedOrder.discountAmount,
      finalAmount: updatedOrder.finalAmount,
      paymentStatus: updatedOrder.paymentStatus,
      paymentMethodId: updatedOrder.paymentMethodId,
      deliveryAddress: updatedOrder.deliveryAddress,
      deliveryCity: updatedOrder.deliveryCity,
      deliveryPostalCode: updatedOrder.deliveryPostalCode,
      deliveryPhone: updatedOrder.deliveryPhone,
      deliveryDate: updatedOrder.deliveryDate,
      deliveryTime: updatedOrder.deliveryTime,
      customerNotes: updatedOrder.customerNotes,
      adminNotes: updatedOrder.adminNotes,
      createdAt: updatedOrder.createdAt,
      updatedAt: updatedOrder.updatedAt,
      customer: updatedOrder.customer,
      weeklyMenu: updatedOrder.weeklyMenu,
      deliveryZone: updatedOrder.deliveryZone,
      items: updatedOrder.items.map((item: any) => ({
        id: item.id,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        totalPrice: item.totalPrice,
        options: item.options,
        notes: item.notes,
        menuItem: {
          ...item.menuItem,
          imageUrl: item.menuItem.image,
        },
      })),
      transactions: updatedOrder.transactions,
    };

    return ApiResponse.updated(formattedOrder, "Commande mise à jour avec succès");
  } catch (error) {
    console.error("Error updating order:", error);
    return ApiError.handle(error);
  }
}

// OPTIONS - CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, PUT, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
