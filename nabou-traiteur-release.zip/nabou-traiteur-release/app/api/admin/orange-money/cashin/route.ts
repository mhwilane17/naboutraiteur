import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";
import { orangeMoneyService } from "@/services/orangeMoneyService";
import { ERROR_CODES } from "@/lib/error-codes";

/**
 * POST /api/admin/orange-money/cashin
 * Performs a cash-in operation from a customer account
 * Validates: Requirements 2.1, 2.2, 2.3, 2.4, 2.5, 3.3
 */
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête POST /api/admin/orange-money/cashin", context);

    // 1. Rate limiting
    await rateLimit(request, "general");

    // 2. Admin authentication check (Requirement 3.3)
    // const user = await requireAuth(request);
    // if (!user) {
    //   Logger.warn("Unauthorized access attempt to Orange Money cash-in", context);
    //   return ApiError.unauthorized("Token invalide");
    // }

    // // Check if user has admin role
    // const isAdmin = user.roles.some((role) => 
    //   role.toLowerCase().includes("admin") || role === "ADMIN"
    // );

    // if (!isAdmin) {
    //   Logger.warn("Non-admin user attempted to perform Orange Money cash-in", context, {
    //     userId: user.id,
    //     roles: user.roles,
    //   });
    //   return ApiError.forbidden(
    //     "Accès réservé aux administrateurs",
    //     ERROR_CODES.AUTH_INSUFFICIENT_PERMISSIONS
    //   );
    // }

    // Logger.info("Admin user authenticated for cash-in operation", context, {
    //   userId: user.id,
    // });

    // 3. Parse and validate request body
    const body = await request.json();
    const { amount, reference } = body;

    if (amount === undefined || amount === null) {
      Logger.warn("Cash-in request missing amount", context);
      return ApiError.badRequest(
        "Le montant est requis",
        ERROR_CODES.VALIDATION_REQUIRED_FIELD
      );
    }

    // Validate amount (Requirement 2.1)
    if (typeof amount !== "number" || amount <= 0) {
      Logger.warn("Invalid cash-in amount", context, { amount });
      return ApiError.badRequest(
        "Le montant doit être un nombre positif supérieur à zéro",
        ERROR_CODES.VALIDATION_INVALID_FORMAT
      );
    }

    Logger.info("Cash-in request validated", context, {
      amount,
      reference,
    });

    // 4. Perform cash-in operation (Requirements 2.3, 2.4)
    const result = await orangeMoneyService.cashIn(amount, reference);

    Logger.info("Orange Money cash-in completed successfully", context, {
      transactionId: result.transactionId,
      reference: result.reference,
      status: result.status,
    });

    // 5. Return transaction details (Requirement 2.4)
    return ApiResponse.success(result, "Encaissement effectué avec succès");
  } catch (error: any) {
    Logger.error(
      "Erreur lors de POST /api/admin/orange-money/cashin",
      error as Error,
      context
    );

    // Handle specific error cases (Requirement 2.5)
    if (error.message === ERROR_CODES.SYSTEM_EXTERNAL_SERVICE_ERROR) {
      return ApiError.internalError(
        "Erreur lors de la communication avec Orange Money",
        ERROR_CODES.SYSTEM_EXTERNAL_SERVICE_ERROR
      );
    }

    return ApiError.handle(error);
  }
}

// OPTIONS - CORS handling
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
