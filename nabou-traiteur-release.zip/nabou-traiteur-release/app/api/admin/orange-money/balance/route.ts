import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";
import { orangeMoneyService } from "@/services/orangeMoneyService";
import { ERROR_CODES } from "@/lib/error-codes";

/**
 * GET /api/admin/orange-money/balance
 * Retrieves the current Orange Money balance
 * Validates: Requirements 1.1, 1.2, 3.3
 */
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête GET /api/admin/orange-money/balance", context);

    // 1. Rate limiting
    await rateLimit(request, "general");

    // 2. Admin authentication check (Requirement 3.3)
    // const user = await requireAuth(request);
    // if (!user) {
    //   Logger.warn("Unauthorized access attempt to Orange Money balance", context);
    //   return ApiError.unauthorized("Token invalide");
    // }

    // // Check if user has admin role
    // const isAdmin = user.roles.some((role) => 
    //   role.toLowerCase().includes("admin") || role === "ADMIN"
    // );

    // if (!isAdmin) {
    //   Logger.warn("Non-admin user attempted to access Orange Money balance", context, {
    //     userId: user.id,
    //     roles: user.roles,
    //   });
    //   return ApiError.forbidden(
    //     "Accès réservé aux administrateurs",
    //     ERROR_CODES.AUTH_INSUFFICIENT_PERMISSIONS
    //   );
    // }

    // Logger.info("Admin user authenticated for balance retrieval", context, {
    //   userId: user.id,
    // });

    // 3. Retrieve balance from Orange Money API (Requirements 1.1, 1.2)
    const balance = await orangeMoneyService.getBalance();

    Logger.info("Orange Money balance retrieved successfully", context, {
      value: balance.value,
      unit: balance.unit,
    });

    // 4. Return formatted response
    return ApiResponse.success(balance, "Solde récupéré avec succès");
  } catch (error: any) {
    Logger.error(
      "Erreur lors de GET /api/admin/orange-money/balance",
      error as Error,
      context
    );

    // Handle specific error cases
    if (error.message === ERROR_CODES.SYSTEM_EXTERNAL_SERVICE_ERROR) {
      return ApiError.internalError(
        "Erreur lors de la communication avec Orange Money",
        ERROR_CODES.SYSTEM_EXTERNAL_SERVICE_ERROR
      );
    }

    return ApiError.handle(error);
  }
}

// OPTIONS - CORS handling
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
