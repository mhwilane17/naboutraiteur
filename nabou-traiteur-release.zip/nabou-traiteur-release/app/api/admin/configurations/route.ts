import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { withDatabase } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";
import { ConfigurationService, ConfigurationUpdate } from "@/services/configurationService";

// Schéma de validation pour les mises à jour de configuration
const ConfigurationUpdateSchema = z.object({
  key: z.string().min(1, "La clé de configuration est requise"),
  value: z.string(), // Peut être vide pour certaines configurations optionnelles
});

const UpdateConfigurationsSchema = z.object({
  configurations: z.array(ConfigurationUpdateSchema).min(1, "Au moins une configuration doit être fournie"),
});

// GET /api/admin/configurations - Récupérer toutes les configurations
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête GET /api/admin/configurations", context);

    // 1. Rate limiting
    await rateLimit(request, 'general');

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'configurations.read'
    // await requirePermission('configurations.read')(request, user);

    // 3. Récupération des configurations via le service
    const result = await ConfigurationService.getAllConfigurations();

    if (!result.success) {
      Logger.error("Erreur lors de la récupération des configurations", new Error(result.error.message), context);
      return ApiError.internalError(
        result.error.message,
        result.error.code as any
      );
    }

    Logger.info("Configurations récupérées avec succès", context, {
      configurationCount: result.data.length
    });

    // 4. Réponse de succès
    return ApiResponse.success(result.data, result.message);

  } catch (error) {
    Logger.error("Erreur lors de GET /api/admin/configurations", error as Error, context);
    return ApiError.handle(error);
  }
}

// PUT /api/admin/configurations - Mettre à jour les configurations
export async function PUT(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête PUT /api/admin/configurations", context);

    // 1. Rate limiting
    await rateLimit(request, 'general');

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'configurations.update'
    // await requirePermission('configurations.update')(request, user);

    // 3. Validation du body
    const body = await request.json();
    const validatedData = UpdateConfigurationsSchema.parse(body);

    Logger.info("Mise à jour des configurations demandée", context, {
      configurationCount: validatedData.configurations.length,
      keys: validatedData.configurations.map(c => c.key)
    });

    // 4. Mise à jour des configurations via le service
    const result = await ConfigurationService.updateConfigurations(validatedData.configurations);

    if (!result.success) {
      // Gestion des erreurs de validation
      if (result.error.code === 'VALIDATION_ERROR') {
        Logger.warn("Erreurs de validation détectées", context, {
          validationErrors: result.error.details
        });
        return ApiError.badRequest(
          result.error.message,
          result.error.code as any,
          result.error.details
        );
      }

      // Autres erreurs
      Logger.error("Erreur lors de la mise à jour des configurations", new Error(result.error.message), context);
      return ApiError.internalError(
        result.error.message,
        result.error.code as any
      );
    }

    Logger.info("Configurations mises à jour avec succès", context, {
      updatedCount: result.data.length,
      updatedKeys: result.data.map(c => c.key)
    });

    // 5. Réponse de succès
    return ApiResponse.updated(result.data, result.message);

  } catch (error) {
    Logger.error("Erreur lors de PUT /api/admin/configurations", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS - Gestion CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, PUT, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}