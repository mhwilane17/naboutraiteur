import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { withDatabase, withTransaction } from "@/lib/db";
import { requireAuth, hasRole } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";

// Schéma de validation des paramètres de requête
const QuerySchema = z.object({
  page: z
    .string()
    .nullable()
    .optional()
    .transform((val) => (val ? parseInt(val, 10) : 1))
    .pipe(z.number().min(1)),
  limit: z
    .string()
    .nullable()
    .optional()
    .transform((val) => (val ? parseInt(val, 10) : 10))
    .pipe(z.number().min(1).max(100)),
  search: z.string().nullable().optional(),
  isActive: z
    .string()
    .nullable()
    .optional()
    .transform((val) => (val === null || val === undefined ? undefined : val === "true")),
});

// Nouveau: Schéma de création d'entreprise
const CreateCompanySchema = z.object({
  name: z.string().min(2, "Le nom doit contenir au moins 2 caractères").max(200),
  contactEmail: z.string().email("Email de contact invalide").optional(),
  isActive: z.boolean().optional(),
  limits: z
    .array(
      z.object({
        categoryId: z.string().min(1, "ID de catégorie requis"),
        maxPerOrder: z.number().int().min(1, "maxPerOrder doit être > 0"),
      })
    )
    .optional(),
});

// GET /api/companies - Liste des entreprises avec leurs employés et limites par catégorie
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête GET /api/companies", context);

    // 1. Rate limiting
    await rateLimit(request, "general");

    // 2. Authentification + contrôle des rôles (SUPER_ADMIN, ADMIN, MANAGER)
    // const user = await requireAuth(request);
    // if (!(hasRole(user, "SUPER_ADMIN") || hasRole(user, "ADMIN") || hasRole(user, "MANAGER"))) {
    //   Logger.auth("Access denied: insufficient role for GET /api/companies", user.id, false, {
    //     userRoles: user.roles,
    //   });
    //   return ApiError.forbidden("Rôle insuffisant");
    // }

    // 3. Validation des paramètres
    const { searchParams } = new URL(request.url);
    const query = QuerySchema.parse({
      page: searchParams.get("page"),
      limit: searchParams.get("limit"),
      search: searchParams.get("search"),
      isActive: searchParams.get("isActive"),
    });

    // 4. Construction des filtres
    const where: any = {};

    if (query.isActive !== undefined) {
      where.isActive = query.isActive;
    }

    if (query.search && query.search.trim().length > 0) {
      const search = query.search.trim();
      where.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { contactEmail: { contains: search, mode: "insensitive" } },
      ];
    }

    // 5. Récupération des entreprises + total
    const [companies, total] = await withDatabase(async (db) => {
      return Promise.all([
        (db as any).company.findMany({
          where,
          skip: (query.page - 1) * query.limit,
          take: query.limit,
          orderBy: { name: "asc" },
          include: {
            users: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                isActive: true,
                createdAt: true,
                updatedAt: true,
              },
            },
            limits: {
              include: {
                category: {
                  select: { id: true, name: true },
                },
              },
            },
          },
        }),
        (db as any).company.count({ where }),
      ]);
    });

    // 6. Formatage
    const formatted = companies.map((c: any) => ({
      id: c.id,
      name: c.name,
      contactEmail: c.contactEmail,
      isActive: c.isActive,
      createdAt: c.createdAt,
      updatedAt: c.updatedAt,
      users: c.users.map((u: any) => ({
        id: u.id,
        firstName: u.firstName,
        lastName: u.lastName,
        email: u.email,
        isActive: u.isActive,
        createdAt: u.createdAt,
        updatedAt: u.updatedAt,
      })),
      limits: c.limits.map((l: any) => ({
        categoryId: l.categoryId,
        maxPerOrder: l.maxPerOrder,
        category: l.category ? { id: l.category.id, name: l.category.name } : null,
      })),
      stats: {
        userCount: c.users.length,
        limitsCount: c.limits.length,
      },
    }));

    Logger.info("Requête GET /api/companies terminée avec succès", context, {
      companyCount: companies.length,
      total,
      page: query.page,
    });

    // 7. Réponse succès avec pagination
    return ApiResponse.success({
      data: formatted,
      pagination: {
        page: query.page,
        limit: query.limit,
        total,
        totalPages: Math.ceil(total / query.limit),
      },
    });
  } catch (error) {
    Logger.error("Erreur lors de GET /api/companies", error as Error, context);
    return ApiError.handle(error);
  }
}

// POST /api/companies - Créer une entreprise (+ limites optionnelles)
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête POST /api/companies", context);

    // 1. Rate limiting
    await rateLimit(request, "general");

    // 2. Authentification + contrôle des rôles (SUPER_ADMIN, ADMIN, MANAGER)
    // const user = await requireAuth(request);
    // if (!(hasRole(user, "SUPER_ADMIN") || hasRole(user, "ADMIN") || hasRole(user, "MANAGER"))) {
    //   Logger.auth("Access denied: insufficient role for POST /api/companies", user.id, false, {
    //     userRoles: user.roles,
    //   });
    //   return ApiError.forbidden("Rôle insuffisant");
    // }

    // 3. Validation du body
    const body = await request.json();
    const validated = CreateCompanySchema.parse(body);

    // 4. Valider l'existence des catégories si des limites sont fournies
    const providedLimits: { categoryId: string; maxPerOrder: number }[] = validated.limits ?? [];
    if (providedLimits.length > 0) {
      const categoryIds = [...new Set(providedLimits.map((l) => l.categoryId))];
      const categories = await withDatabase(async (db) =>
        (db as any).category.findMany({ where: { id: { in: categoryIds } }, select: { id: true } })
      );
      const existingIds = new Set(categories.map((c: any) => c.id));
      const missing = categoryIds.filter((id) => !existingIds.has(id));
      if (missing.length > 0) {
        return ApiError.badRequest(`Catégories inexistantes: ${missing.join(", ")}`);
      }
    }

    // 5. Transaction: créer l'entreprise + insérer les limites
    const created = await withTransaction(async (tx) => {
      const company = await (tx as any).company.create({
        data: {
          name: validated.name,
          contactEmail: validated.contactEmail ?? null,
          isActive: validated.isActive ?? true,
        },
      });

      if (providedLimits.length > 0) {
        for (const limit of providedLimits) {
          await (tx as any).companyCategoryLimit.create({
            data: {
              company: { connect: { id: company.id } },
              category: { connect: { id: limit.categoryId } },
              maxPerOrder: limit.maxPerOrder,
            },
          });
        }
      }

      // Retourner l'entreprise créée avec relations
      const full = await (tx as any).company.findUnique({
        where: { id: company.id },
        include: {
          users: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              isActive: true,
              createdAt: true,
              updatedAt: true,
            },
          },
          limits: { include: { category: { select: { id: true, name: true } } } },
        },
      });

      return full;
    });

    // 6. Formatage
    const formatted = created
      ? {
          id: created.id,
          name: created.name,
          contactEmail: created.contactEmail,
          isActive: created.isActive,
          createdAt: created.createdAt,
          updatedAt: created.updatedAt,
          users: (created as any).users.map((u: any) => ({
            id: u.id,
            firstName: u.firstName,
            lastName: u.lastName,
            email: u.email,
            isActive: u.isActive,
            createdAt: u.createdAt,
            updatedAt: u.updatedAt,
          })),
          limits: (created as any).limits.map((l: any) => ({
            categoryId: l.categoryId,
            maxPerOrder: l.maxPerOrder,
            category: l.category ? { id: l.category.id, name: l.category.name } : null,
          })),
          stats: {
            userCount: (created as any).users.length,
            limitsCount: (created as any).limits.length,
          },
        }
      : null;

    Logger.info("Entreprise créée avec succès", context, { companyId: created?.id });

    // 7. Réponse succès 201
    return ApiResponse.created(formatted);
  } catch (error) {
    Logger.error("Erreur lors de POST /api/companies", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS - CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, { status: 200 });
}