import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { withDatabase, withTransaction } from "@/lib/db";
import { requireAuth, hasRole } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";

// Schémas de validation
const UpdateCompanySchema = z.object({
  name: z.string().min(2, "Le nom doit contenir au moins 2 caractères").max(200).optional(),
  contactEmail: z.string().email("Email de contact invalide").optional(),
  isActive: z.boolean().optional(),
  limits: z
    .array(
      z.object({
        categoryId: z.string().min(1, "ID de catégorie requis"),
        maxPerOrder: z.number().int().min(1, "maxPerOrder doit être > 0"),
      })
    )
    .optional(),
});

const ParamsSchema = z.object({ id: z.string().min(1, "ID d'entreprise invalide") });

// PUT /api/companies/[id] - Mise à jour d'une entreprise + upsert des limites
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête PUT /api/companies/[id]", context);

    // 1. Rate limiting
    await rateLimit(request, "general");

    // 2. Authentification + contrôle des rôles (SUPER_ADMIN, ADMIN, MANAGER)
    // const user = await requireAuth(request);
    // if (!(hasRole(user, "SUPER_ADMIN") || hasRole(user, "ADMIN") || hasRole(user, "MANAGER"))) {
    //   Logger.auth("Access denied: insufficient role for PUT /api/companies/[id]", user.id, false, {
    //     userRoles: user.roles,
    //   });
    //   return ApiError.forbidden("Rôle insuffisant");
    // }

    const reqParams = await params;

    // 3. Validation des params
    const validatedParams = ParamsSchema.parse(reqParams);

    // 4. Validation du body
    const body = await request.json();
    const validatedData = UpdateCompanySchema.parse(body);

    // 5. Vérifier existence company
    const existingCompany = await withDatabase(async (db) =>
      (db as any).company.findUnique({ where: { id: validatedParams.id } })
    );

    if (!existingCompany) {
      return ApiError.notFound("Entreprise introuvable");
    }

    // 6. Si des limites sont fournies, valider l'existence des catégories
    const providedLimits: { categoryId: string; maxPerOrder: number }[] = validatedData.limits ?? [];
    if (providedLimits.length > 0) {
      const categoryIds = [...new Set(providedLimits.map((l) => l.categoryId))];
      const categories = await withDatabase(async (db) =>
        (db as any).category.findMany({ where: { id: { in: categoryIds } }, select: { id: true } })
      );
      const existingIds = new Set(categories.map((c: any) => c.id));
      const missing = categoryIds.filter((id) => !existingIds.has(id));
      if (missing.length > 0) {
        return ApiError.badRequest(`Catégories inexistantes: ${missing.join(", ")}`);
      }
    }

    // 7. Transaction: update company + upsert/delete limits
    const updated = await withTransaction(async (tx) => {
      // a) Mettre à jour les champs simples de l'entreprise
      const { name, contactEmail, isActive } = validatedData;
      if (name !== undefined || contactEmail !== undefined || isActive !== undefined) {
        await (tx as any).company.update({
          where: { id: validatedParams.id },
          data: {
            ...(name !== undefined ? { name } : {}),
            ...(contactEmail !== undefined ? { contactEmail } : {}),
            ...(isActive !== undefined ? { isActive } : {}),
          },
        });
      }

      // b) Upsert des limites + suppression des limites non incluses si 'limits' est fourni
      if (providedLimits.length > 0) {
        // Récupérer limites existantes
        const existingLimits = await (tx as any).companyCategoryLimit.findMany({
          where: { companyId: validatedParams.id },
          select: { categoryId: true },
        });
        const existingCategoryIds = new Set<string>(existingLimits.map((l: any) => l.categoryId));
        const providedCategoryIds = new Set<string>(providedLimits.map((l) => l.categoryId));

        // Upserts
        for (const limit of providedLimits) {
          await (tx as any).companyCategoryLimit.upsert({
            where: { companyId_categoryId: { companyId: validatedParams.id, categoryId: limit.categoryId } },
            update: { maxPerOrder: limit.maxPerOrder },
            create: {
              company: { connect: { id: validatedParams.id } },
              category: { connect: { id: limit.categoryId } },
              maxPerOrder: limit.maxPerOrder,
            },
          });
        }

        // Supprimer les limites non incluses dans la liste fournie
        const toDelete: string[] = [];
        for (const catId of existingCategoryIds) {
          if (!providedCategoryIds.has(catId)) {
            toDelete.push(catId);
          }
        }
        if (toDelete.length > 0) {
          await (tx as any).companyCategoryLimit.deleteMany({
            where: { companyId: validatedParams.id, categoryId: { in: toDelete } },
          });
        }
      }

      // c) Retourner l'entreprise mise à jour avec relations
      const updatedCompany = await (tx as any).company.findUnique({
        where: { id: validatedParams.id },
        include: {
          users: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              isActive: true,
              createdAt: true,
              updatedAt: true,
            },
          },
          limits: {
            include: {
              category: { select: { id: true, name: true } },
            },
          },
        },
      });

      return updatedCompany;
    });

    // 8. Formatage
    const formatted = updated
      ? {
          id: updated.id,
          name: updated.name,
          contactEmail: updated.contactEmail,
          isActive: updated.isActive,
          createdAt: updated.createdAt,
          updatedAt: updated.updatedAt,
          users: (updated as any).users.map((u: any) => ({
            id: u.id,
            firstName: u.firstName,
            lastName: u.lastName,
            email: u.email,
            isActive: u.isActive,
            createdAt: u.createdAt,
            updatedAt: u.updatedAt,
          })),
          limits: (updated as any).limits.map((l: any) => ({
            categoryId: l.categoryId,
            maxPerOrder: l.maxPerOrder,
            category: l.category ? { id: l.category.id, name: l.category.name } : null,
          })),
          stats: {
            userCount: (updated as any).users.length,
            limitsCount: (updated as any).limits.length,
          },
        }
      : null;

    Logger.info("Entreprise mise à jour avec succès", context, {
      companyId: validatedParams.id,
      updatedFields: Object.keys({
        ...(validatedData.name !== undefined ? { name: true } : {}),
        ...(validatedData.contactEmail !== undefined ? { contactEmail: true } : {}),
        ...(validatedData.isActive !== undefined ? { isActive: true } : {}),
        ...(validatedData.limits !== undefined ? { limits: true } : {}),
      }),
    });

    return ApiResponse.success(formatted);
  } catch (error) {
    Logger.error("Erreur lors de PUT /api/companies/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// DELETE /api/companies/[id] - Supprimer une entreprise
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête DELETE /api/companies/[id]", context);

    // 1. Rate limiting
    await rateLimit(request, "general");

    // 2. Authentification + contrôle des rôles (SUPER_ADMIN, ADMIN, MANAGER)
    // const user = await requireAuth(request);
    // if (!(hasRole(user, "SUPER_ADMIN") || hasRole(user, "ADMIN") || hasRole(user, "MANAGER"))) {
    //   Logger.auth("Access denied: insufficient role for DELETE /api/companies/[id]", user.id, false, {
    //     userRoles: user.roles,
    //   });
    //   return ApiError.forbidden("Rôle insuffisant");
    // }

    const reqParams = await params;

    // 3. Validation des params
    const validatedParams = ParamsSchema.parse(reqParams);

    // 4. Vérifier existence company
    const existingCompany = await withDatabase(async (db) =>
      (db as any).company.findUnique({ where: { id: validatedParams.id } })
    );

    if (!existingCompany) {
      return ApiError.notFound("Entreprise introuvable");
    }

    // 5. Suppression (les contraintes FK gèrent la cascade et le SET NULL côté Prisma)
    await withTransaction(async (tx) => {
      await (tx as any).company.delete({ where: { id: validatedParams.id } });
    });

    Logger.info("Entreprise supprimée avec succès", context, { companyId: validatedParams.id });

    // 6. Réponse succès
    return ApiResponse.deleted("Entreprise supprimée avec succès");
  } catch (error) {
    Logger.error("Erreur lors de DELETE /api/companies/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// GET /api/companies/[id] - Récupérer une entreprise (sans auth)
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête GET /api/companies/[id]", context);

    // 1. Rate limiting
    await rateLimit(request, "general");

    const reqParams = await params;

    // 2. Validation des params
    const validatedParams = ParamsSchema.parse(reqParams);

    // 3. Récupération de l'entreprise avec relations
    const company = await withDatabase(async (db) =>
      (db as any).company.findUnique({
        where: { id: validatedParams.id },
        include: {
          users: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              isActive: true,
              createdAt: true,
              updatedAt: true,
            },
          },
          limits: {
            include: {
              category: { select: { id: true, name: true } },
            },
          },
        },
      })
    );

    if (!company) {
      return ApiError.notFound("Entreprise introuvable");
    }

    // 4. Formatage de la réponse (même structure que PUT)
    const formatted = {
      id: (company as any).id,
      name: (company as any).name,
      contactEmail: (company as any).contactEmail,
      isActive: (company as any).isActive,
      createdAt: (company as any).createdAt,
      updatedAt: (company as any).updatedAt,
      users: (company as any).users.map((u: any) => ({
        id: u.id,
        firstName: u.firstName,
        lastName: u.lastName,
        email: u.email,
        isActive: u.isActive,
        createdAt: u.createdAt,
        updatedAt: u.updatedAt,
      })),
      limits: (company as any).limits.map((l: any) => ({
        categoryId: l.categoryId,
        maxPerOrder: l.maxPerOrder,
        category: l.category ? { id: l.category.id, name: l.category.name } : null,
      })),
      stats: {
        userCount: (company as any).users.length,
        limitsCount: (company as any).limits.length,
      },
    };

    Logger.info("GET /api/companies/[id] réussi", context, { companyId: validatedParams.id });

    return ApiResponse.success(formatted);
  } catch (error) {
    Logger.error("Erreur lors de GET /api/companies/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS - CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, { status: 200 });
}