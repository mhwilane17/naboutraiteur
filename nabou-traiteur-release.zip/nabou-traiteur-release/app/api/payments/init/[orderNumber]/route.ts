import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

const ParamsSchema = z.object({
  orderNumber: z.string().min(3),
});

type OrangeConfig = {
  client_id: string;
  client_secret: string;
  grant_type: string; // ex: "client_credentials"
  currency: string; // ex: "XOF"
  merchant_code: string;
  merchant_name: string;
  validity: number; // en secondes
  auth_url: string
  checkout_url: string
  
  encrypted_pin_code: string
  customer_msisdn: string
  partner_msisdn: string
  public_key: string
};

type WaveConfig = {
  currency?: string;
  api_key?: string;
  webhook_secret?: string;
  checkout_url: string
};

// IDs des méthodes de paiement spécifiées par le client
const ORANGE_METHOD_ID = "cmdm6dyh1003yi4yqe56zftjp";
const WAVE_METHOD_ID = "cmdm6dyjy003zi4yq7n88r4dp";

function onlyDigits(input?: string | null): string | undefined {
  if (!input) return undefined;
  const cleaned = String(input).replace(/\D+/g, "");
  return cleaned || undefined;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ orderNumber: string }> }
) {
  const context = Logger.createContext(request);

  try {
    await rateLimit(request, "general");
    const url = new URL(request.url);
    const resolvedParams = await params;
    const orderNumberCandidate =
      resolvedParams?.orderNumber || url.searchParams.get("orderNumber") || url.pathname.split("/").pop();

    if (!orderNumberCandidate) {
      return ApiError.badRequest("orderNumber manquant dans l'URL");
    }

    const { orderNumber } = ParamsSchema.parse({ orderNumber: orderNumberCandidate });

    Logger.info("Initialisation paiement par orderNumber", context, { orderNumber });

    // Récupérer la commande
    const order = await prisma.order.findUnique({
      where: { orderNumber },
      select: {
        id: true,
        orderNumber: true,
        status: true,
        paymentStatus: true,
        finalAmount: true,
        deliveryPhone: true,
        paymentMethodId: true,
      },
    });

    if (!order) {
      return ApiError.notFound("Commande introuvable");
    }

    if (!order.paymentMethodId) {
      return ApiError.badRequest("Aucune méthode de paiement associée à cette commande");
    }

    if (order.status === "cancelled") {
      return ApiError.badRequest("Impossible d'initialiser le paiement pour une commande annulée");
    }

    if (order.paymentStatus === "paid") {
      return ApiError.badRequest("Cette commande est déjà payée");
    }

    // Charger la méthode de paiement et sa config
    const paymentMethod = await prisma.paymentMethod.findUnique({
      where: { id: order.paymentMethodId },
      select: {
        id: true,
        name: true,
        type: true,
        provider: true,
        isActive: true,
        config: true,
      },
    });

    if (!paymentMethod) {
      return ApiError.notFound("Méthode de paiement introuvable");
    }

    if (!paymentMethod.isActive) {
      return ApiError.badRequest("Cette méthode de paiement n'est pas disponible");
    }

    // Cas WAVE: créer une session de checkout via l'API Wave
    if (paymentMethod.id === WAVE_METHOD_ID) {
      const cfg = (paymentMethod.config || {}) as WaveConfig;

      const missing = [
        "api_key",
        "currency",
        "checkout_url",
      ].filter((k) => !(cfg as any)[k]);

      if (missing.length) {
        return ApiError.badRequest(`Configuration incomplète pour Wave: ${missing.join(", ")}`);
      }

      const currency = cfg.currency || "XOF";
      const callbackBase = process.env.NEXT_PUBLIC_APP_URL;
      
      // Convertir le montant en string (Wave attend une string)
      const amount = Math.round(Number(order.finalAmount)).toString();

      // Créer la session de checkout Wave
      const checkoutPayload = {
        client_reference: order.orderNumber,
        amount: amount,
        currency: currency,
        error_url: `${callbackBase}/orders/${order.orderNumber}`,
        success_url: `${callbackBase}/orders/${order.orderNumber}`,
      };

      Logger.info("Création session checkout Wave", context, {
        orderNumber,
        amount,
        currency,
      });

      const checkoutRes = await fetch(cfg.checkout_url, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${cfg.api_key}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(checkoutPayload),
      });

      if (!checkoutRes.ok) {
        const errText = await checkoutRes.text().catch(() => "");
        Logger.error("Échec création session checkout Wave", new Error(errText || String(checkoutRes.status)), context);
        return ApiError.internalError("Échec de la création de la session de paiement Wave");
      }

      const checkoutJson = await checkoutRes.json();
      const waveLaunchUrl = checkoutJson?.wave_launch_url;

      if (!waveLaunchUrl) {
        Logger.error("wave_launch_url manquant dans la réponse Wave", new Error("Missing wave_launch_url"), context);
        return ApiError.internalError("Réponse invalide de l'API Wave");
      }

      Logger.info("Session checkout Wave créée avec succès", context, {
        orderNumber,
        checkoutId: checkoutJson?.id,
        waveLaunchUrl,
      });

      return ApiResponse.success({
        qrCode: "",
        payment_link: {
          WAVE: waveLaunchUrl,
        },
      });
    }

    // Cas ORANGE: initialiser le paiement via OAuth puis QRCode
    if (paymentMethod.id !== ORANGE_METHOD_ID) {
      return ApiError.badRequest("Méthode de paiement non supportée pour l'initialisation");
    }

    const cfg = (paymentMethod.config || {}) as OrangeConfig;
    const missing = [
      "client_id",
      "client_secret",
      "grant_type",
      "currency",
      "merchant_code",
      "merchant_name",
      "validity",
      "auth_url",
      "checkout_url",
    ].filter((k) => !(cfg as any)[k]);

    if (missing.length) {
      return ApiError.badRequest(
        `Configuration incomplète pour Orange: ${missing.join(", ")}`
      );
    }

    // 1) Authentification OAuth
    const tokenRes = await fetch(cfg.auth_url, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        client_id: cfg.client_id,
        client_secret: cfg.client_secret,
        grant_type: cfg.grant_type,
      }),
    });

    if (!tokenRes.ok) {
      const errText = await tokenRes.text().catch(() => "");
      Logger.error("Échec OAuth Orange", new Error(errText || String(tokenRes.status)), context);
      return ApiError.internalError("Échec de l'authentification Orange");
    }

    const tokenJson = await tokenRes.json();
    const accessToken: string | undefined = tokenJson?.access_token;
    if (!accessToken) {
      return ApiError.internalError("Token d'accès Orange manquant");
    }

    // 2) Initialisation du paiement (QRCode)
    const callbackBase = process.env.NEXT_PUBLIC_APP_URL || "";
    const payload = {
      amount: {
        unit: cfg.currency,
        value: Number(order.finalAmount),
      },
      code: cfg.merchant_code,
      metadata: {
        orderNumber: order.orderNumber,
        clientNumber: onlyDigits(order.deliveryPhone) || order.deliveryPhone,
        paymentMethodId: paymentMethod.id,
      },
      name: cfg.merchant_name,
      callbackCancelUrl: `${callbackBase}/orders/${order.orderNumber}`,
      callbackSuccessUrl: `${callbackBase}/orders/${order.orderNumber}`,
      validity: cfg.validity,
    };

    const webhookUrl = process.env.PAYMENT_WEBHOOK_URL || "";
    
    const initRes = await fetch(cfg.checkout_url, {
      method: "POST",
      headers: {
        "X-Callback-Url": webhookUrl,
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(payload),
    });

    if (!initRes.ok) {
      const errText = await initRes.text().catch(() => "");
      Logger.error("Échec initialisation QRCode Orange", new Error(errText || String(initRes.status)), context);
      return ApiError.internalError("Échec de l'initialisation du paiement Orange");
    }

    const initJson = await initRes.json();

    // Réponse attendue
    const response = {
      qrCode: initJson?.qrCode || "",
      payment_link: {
        MAXIT: initJson?.deepLinks?.MAXIT || undefined,
        OM: initJson?.deepLinks?.OM || undefined,
      },
    };

    Logger.info("Initialisation Orange réussie", context, {
      orderNumber,
      qrId: initJson?.qrId,
    });

    return ApiResponse.success(response);
  } catch (error) {
    Logger.error("Erreur POST /api/payments/init/[orderNumber]", error as Error, context);
    return ApiError.handle(error);
  }
}

export async function OPTIONS() {
  return ApiResponse.success({ ok: true });
}