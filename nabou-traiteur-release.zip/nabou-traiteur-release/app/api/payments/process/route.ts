import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";
import { requireAuth } from "@/lib/auth";

// Schéma de validation pour le traitement de paiement
const ProcessPaymentSchema = z.object({
  orderId: z.string().cuid("ID de commande invalide"),
  paymentMethodId: z.string().cuid("ID de méthode de paiement invalide"),
  amount: z.number().positive("Le montant doit être positif"),
  currency: z.string().default("EUR"),
  returnUrl: z.string().url().optional(),
  metadata: z.record(z.any()).optional(),
});

// POST /api/payments/process
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting
    await rateLimit(request, 'orders');

    Logger.info("Début de la requête POST /api/payments/process", context);

    // Authentification
    const user = await requireAuth(request);
    if (!user) {
      return ApiError.unauthorized("Token invalide");
    }

    context.userId = user.id;
    Logger.info("Utilisateur authentifié", context, { userId: user.id });

    // Validation du body
    const body = await request.json();
    const validatedData = ProcessPaymentSchema.parse(body);

    // Vérification de l'existence de la commande
    const order = await prisma.order.findUnique({
      where: { id: validatedData.orderId },
      include: {
        customer: {
          select: {
            id: true,
            email: true,
            firstName: true,
            lastName: true,
          },
        },
        items: {
          include: {
            menuItem: {
              select: {
                name: true,
                price: true,
              },
            },
          },
        },
      },
    });

    if (!order) {
      return ApiError.notFound("Commande introuvable");
    }

    // Vérification que l'utilisateur est propriétaire de la commande
    if (order.customerId !== user.id) {
      return ApiError.forbidden("Vous n'êtes pas autorisé à payer cette commande");
    }

    // Vérification du statut de la commande
    if (order.status === "cancelled") {
      return ApiError.badRequest("Impossible de payer une commande annulée");
    }

    if (order.paymentStatus === "paid") {
      return ApiError.badRequest("Cette commande a déjà été payée");
    }

    // Vérification du montant
    if (Math.abs(Number(validatedData.amount) - Number(order.finalAmount)) > 0.01) {
      return ApiError.badRequest("Le montant ne correspond pas au total de la commande");
    }

    // Vérification de l'existence de la méthode de paiement
    const paymentMethod = await prisma.paymentMethod.findUnique({
      where: { id: validatedData.paymentMethodId },
    });

    if (!paymentMethod) {
      return ApiError.notFound("Méthode de paiement introuvable");
    }

    if (!paymentMethod.isActive) {
      return ApiError.badRequest("Cette méthode de paiement n'est pas disponible");
    }

    // Vérification des limites de montant
    if (paymentMethod.minAmount && Number(validatedData.amount) < Number(paymentMethod.minAmount)) {
      return ApiError.badRequest(
        `Le montant minimum pour cette méthode de paiement est de ${paymentMethod.minAmount}€`
      );
    }

    if (paymentMethod.maxAmount && Number(validatedData.amount) > Number(paymentMethod.maxAmount)) {
      return ApiError.badRequest(
        `Le montant maximum pour cette méthode de paiement est de ${paymentMethod.maxAmount}€`
      );
    }

    // Génération d'un ID de transaction unique
    const transactionId = `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    // Création de la transaction de paiement
    const transaction = await prisma.paymentTransaction.create({
      data: {
        transactionId,
        amount: validatedData.amount,
        currency: validatedData.currency,
        status: "pending",
        type: "payment",
        orderId: validatedData.orderId,
        paymentMethodId: validatedData.paymentMethodId,
        providerResponse: {
          metadata: validatedData.metadata,
          returnUrl: validatedData.returnUrl,
          initiatedBy: user.id,
          initiatedAt: new Date().toISOString(),
        },
      },
      include: {
        order: {
          select: {
            orderNumber: true,
            finalAmount: true,
          },
        },
        paymentMethod: {
          select: {
            name: true,
            type: true,
            provider: true,
          },
        },
      },
    });

    // Simulation du traitement selon le type de méthode de paiement
    let paymentResponse: any = {
      transactionId: transaction.transactionId,
      status: "pending",
      amount: validatedData.amount,
      currency: validatedData.currency,
    };

    switch (paymentMethod.type) {
      case "CASH_ON_DELIVERY":
        // Pour le paiement à la livraison, marquer comme en attente
        paymentResponse.status = "pending";
        paymentResponse.message = "Paiement à la livraison confirmé";
        break;

      case "BANK_TRANSFER":
        // Pour le virement bancaire, fournir les instructions
        paymentResponse.status = "pending";
        paymentResponse.message = "Veuillez effectuer le virement bancaire";
        paymentResponse.instructions = {
          bankName: "Banque Example",
          accountNumber: "FR76 1234 5678 9012 3456 7890 123",
          reference: order.orderNumber,
          amount: validatedData.amount,
        };
        break;

      case "MOBILE_MONEY":
        // Pour le mobile money, simuler une redirection
        paymentResponse.status = "pending";
        paymentResponse.message = "Redirection vers le service de paiement mobile";
        paymentResponse.redirectUrl = `https://payment-provider.com/pay?ref=${transactionId}`;
        break;

      case "CARD":
        // Pour les cartes, simuler une redirection vers le processeur
        paymentResponse.status = "pending";
        paymentResponse.message = "Redirection vers le processeur de paiement";
        paymentResponse.redirectUrl = `https://payment-gateway.com/pay?ref=${transactionId}`;
        break;

      default:
        paymentResponse.status = "pending";
        paymentResponse.message = "Traitement du paiement en cours";
    }

    // Mise à jour de la transaction avec la réponse
    await prisma.paymentTransaction.update({
      where: { id: transaction.id },
      data: {
        providerResponse: {
          ...(transaction.providerResponse as object || {}),
          paymentResponse,
        },
      },
    });

    Logger.info("Transaction de paiement créée avec succès", context, {
      transactionId: transaction.transactionId,
      orderId: validatedData.orderId,
      amount: validatedData.amount,
      paymentMethod: paymentMethod.name,
    });

    return ApiResponse.created({
      transaction: {
        id: transaction.id,
        transactionId: transaction.transactionId,
        status: transaction.status,
        amount: transaction.amount,
        currency: transaction.currency,
      },
      payment: paymentResponse,
      order: {
        orderNumber: order.orderNumber,
        finalAmount: order.finalAmount,
      },
    }, "Transaction de paiement initiée avec succès");
  } catch (error) {
    Logger.error("Erreur lors de POST /api/payments/process", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/payments/process
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}