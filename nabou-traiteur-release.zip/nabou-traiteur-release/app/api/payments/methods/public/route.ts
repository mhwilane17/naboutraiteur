import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Schéma de validation pour les paramètres de requête
const GetPublicPaymentMethodsSchema = z.object({
  type: z.enum(["MOBILE_MONEY", "BANK_TRANSFER", "CASH_ON_DELIVERY", "CARD"]).optional(),
  minAmount: z.coerce.number().min(0).optional(),
  maxAmount: z.coerce.number().min(0).optional(),
});

// GET /api/payments/methods/public
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting pour les routes publiques
    await rateLimit(request, 'general');

    Logger.info("Début de la requête GET /api/payments/methods/public", context);

    // Validation des paramètres de requête
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());
    const validatedParams = GetPublicPaymentMethodsSchema.parse(queryParams);

    const { type, minAmount, maxAmount } = validatedParams;

    // Construction des filtres
    const where: any = {
      isActive: true, // Seulement les méthodes actives
    };

    if (type) {
      where.type = type;
    }

    // Filtrage par montant si spécifié
    if (minAmount !== undefined || maxAmount !== undefined) {
      where.AND = [];
      
      if (minAmount !== undefined) {
        where.AND.push({
          OR: [
            { minAmount: null },
            { minAmount: { lte: minAmount } }
          ]
        });
      }
      
      if (maxAmount !== undefined) {
        where.AND.push({
          OR: [
            { maxAmount: null },
            { maxAmount: { gte: maxAmount } }
          ]
        });
      }
    }

    // Récupération des méthodes de paiement publiques
    const methods = await prisma.paymentMethod.findMany({
      where,
      select: {
        id: true,
        name: true,
        type: true,
        provider: true,
        description: true,
        minAmount: true,
        maxAmount: true,
        fees: true,
        processingTime: true,
        isDefault: true,
      },
      orderBy: [
        { isDefault: "desc" },
        { name: "asc" },
      ],
    });

    Logger.info("Méthodes de paiement publiques récupérées avec succès", context, {
      count: methods.length,
      filters: { type, minAmount, maxAmount },
    });

    return ApiResponse.success({
      methods,
      meta: {
        total: methods.length,
        availableTypes: ["MOBILE_MONEY", "BANK_TRANSFER", "CASH_ON_DELIVERY", "CARD"],
      },
    });
  } catch (error) {
    Logger.error("Erreur lors de GET /api/payments/methods/public", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/payments/methods/public
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}