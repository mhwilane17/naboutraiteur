import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { requireAuth } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limiter";

// Schéma de validation pour les paramètres
const ParamsSchema = z.object({
  id: z.string().min(1, "ID de transaction requis"),
});

// GET /api/payments/transactions/[id]
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);
  const { id } = await params;
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête GET /api/payments/transactions/[id]", context);

    // Authentification
    const user = await requireAuth(request);
    context.userId = user.id;

    // Validation des paramètres
    const validatedParams = ParamsSchema.parse({ id });

    Logger.info("Récupération des détails de la transaction", context, {
      transactionId: validatedParams.id,
    });

    // Récupération de la transaction
    const transaction = await prisma.paymentTransaction.findUnique({
      where: { 
        transactionId: validatedParams.id,
      },
      include: {
        order: {
          select: {
            id: true,
            orderNumber: true,
            status: true,
            paymentStatus: true,
            finalAmount: true,
            customerId: true,

            createdAt: true,
          },
        },
        paymentMethod: {
          select: {
            id: true,
            name: true,
            type: true,
            provider: true,
            isActive: true,
          },
        },
      },
    });

    if (!transaction) {
      Logger.warn("Transaction introuvable", context, {
        transactionId: validatedParams.id,
      });
      return ApiError.notFound("Transaction introuvable");
    }

    // Vérification des permissions
    // L'utilisateur peut voir ses propres transactions ou les admins/managers peuvent voir toutes les transactions
    const isAdmin = user.roles.includes('ADMIN') || user.roles.includes('SUPER_ADMIN');
    const isManager = user.roles.includes('MANAGER');
    
    const canAccess = 
      transaction.order.customerId === user.id || // Sa propre commande
      isAdmin || // Admin peut voir toutes les transactions
      isManager; // Manager peut voir toutes les transactions

    if (!canAccess) {
      Logger.warn("Accès refusé à la transaction", context, {
        transactionId: validatedParams.id,
        userId: user.id,
        orderCustomerId: transaction.order.customerId,
      });
      return ApiError.forbidden("Accès refusé à cette transaction");
    }

    Logger.info("Transaction récupérée avec succès", context, {
      transactionId: transaction.transactionId,
      status: transaction.status,
      amount: transaction.amount,
    });

    // Formatage de la réponse
    const response = {
      id: transaction.id,
      transactionId: transaction.transactionId,
      amount: Number(transaction.amount),
      currency: transaction.currency,
      status: transaction.status,
      createdAt: transaction.createdAt,
      processedAt: transaction.processedAt,
      failureReason: transaction.failureReason,
      order: {
        id: transaction.order.id,
        orderNumber: transaction.order.orderNumber,
        status: transaction.order.status,
        paymentStatus: transaction.order.paymentStatus,
        finalAmount: Number(transaction.order.finalAmount),
        createdAt: transaction.order.createdAt,
      },
      paymentMethod: {
        id: transaction.paymentMethod.id,
        name: transaction.paymentMethod.name,
        type: transaction.paymentMethod.type,
        provider: transaction.paymentMethod.provider,
      },
      // Informations sensibles uniquement pour les admins/managers
      ...(isAdmin || isManager ? {
        providerResponse: transaction.providerResponse,
      } : {}),
    };

    return ApiResponse.success(response);
  } catch (error) {
    Logger.error("Erreur lors de la récupération de la transaction", error as Error, context);
    return ApiError.handle(error);
  }
}

// PUT /api/payments/transactions/[id] - Mise à jour du statut (admin seulement)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);
  const { id } = await params;
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête PUT /api/payments/transactions/[id]", context);

    // Authentification
    const user = await requireAuth(request);
    context.userId = user.id;

    // Vérification des permissions (admin/manager seulement)
    const isAdmin = user.roles.includes('ADMIN') || user.roles.includes('SUPER_ADMIN');
    const isManager = user.roles.includes('MANAGER');
    
    if (!isAdmin && !isManager) {
      Logger.warn("Tentative de modification de transaction sans permissions", context, {
        userRoles: user.roles,
      });
      return ApiError.forbidden("Permissions insuffisantes pour modifier une transaction");
    }

    // Validation des paramètres
    const validatedParams = ParamsSchema.parse({ id });

    // Validation du body
    const UpdateTransactionSchema = z.object({
      status: z.enum(["pending", "completed", "failed", "cancelled", "refunded"]).optional(),
      failureReason: z.string().optional(),
      adminNotes: z.string().optional(),
    });

    const body = await request.json();
    const validatedData = UpdateTransactionSchema.parse(body);

    Logger.info("Mise à jour de la transaction", context, {
      transactionId: validatedParams.id,
      updates: validatedData,
    });

    // Récupération de la transaction actuelle
    const currentTransaction = await prisma.paymentTransaction.findUnique({
      where: { transactionId: validatedParams.id },
      include: {
        order: {
          select: {
            id: true,
            orderNumber: true,
            status: true,
            paymentStatus: true,
          },
        },
      },
    });

    if (!currentTransaction) {
      return ApiError.notFound("Transaction introuvable");
    }

    // Vérification des règles business
    if (currentTransaction.status === "completed" && validatedData.status && validatedData.status !== "refunded") {
      return ApiError.badRequest("Une transaction complétée ne peut être modifiée qu'en remboursement");
    }

    if (currentTransaction.status === "refunded") {
      return ApiError.badRequest("Une transaction remboursée ne peut plus être modifiée");
    }

    // Mise à jour de la transaction
    const updatedTransaction = await prisma.paymentTransaction.update({
      where: { id: currentTransaction.id },
      data: {
        ...(validatedData.status && { status: validatedData.status }),
        ...(validatedData.failureReason && { failureReason: validatedData.failureReason }),
        ...(validatedData.status === "completed" && { processedAt: new Date() }),
        providerResponse: {
          ...(currentTransaction.providerResponse as object || {}),
          adminUpdate: {
            updatedBy: user.id,
            updatedAt: new Date().toISOString(),
            notes: validatedData.adminNotes,
            previousStatus: currentTransaction.status,
          },
        },
      },
      include: {
        order: {
          select: {
            id: true,
            orderNumber: true,
            status: true,
            paymentStatus: true,
          },
        },
        paymentMethod: {
          select: {
            name: true,
            provider: true,
          },
        },
      },
    });

    // Mise à jour du statut de la commande si nécessaire
    if (validatedData.status) {
      let orderUpdateData: any = {};

      switch (validatedData.status) {
        case "completed":
          orderUpdateData = {
            paymentStatus: "paid",
            status: currentTransaction.order.status === "pending" ? "confirmed" : currentTransaction.order.status,
          };
          break;

        case "failed":
        case "cancelled":
          orderUpdateData = {
            paymentStatus: "failed",
          };
          break;

        case "refunded":
          orderUpdateData = {
            paymentStatus: "refunded",
          };
          break;

        case "pending":
          orderUpdateData = {
            paymentStatus: "pending",
          };
          break;
      }

      if (Object.keys(orderUpdateData).length > 0) {
        await prisma.order.update({
          where: { id: currentTransaction.order.id },
          data: orderUpdateData,
        });
      }
    }

    Logger.info("Transaction mise à jour avec succès", context, {
      transactionId: updatedTransaction.transactionId,
      oldStatus: currentTransaction.status,
      newStatus: updatedTransaction.status,
      updatedBy: user.id,
    });

    // Formatage de la réponse
    const response = {
      id: updatedTransaction.id,
      transactionId: updatedTransaction.transactionId,
      amount: Number(updatedTransaction.amount),
      currency: updatedTransaction.currency,
      status: updatedTransaction.status,
      createdAt: updatedTransaction.createdAt,
      processedAt: updatedTransaction.processedAt,
      failureReason: updatedTransaction.failureReason,
      providerResponse: updatedTransaction.providerResponse,
      order: {
        id: updatedTransaction.order.id,
        orderNumber: updatedTransaction.order.orderNumber,
        status: updatedTransaction.order.status,
        paymentStatus: updatedTransaction.order.paymentStatus,
      },
      paymentMethod: {
        name: updatedTransaction.paymentMethod.name,
        provider: updatedTransaction.paymentMethod.provider,
      },
    };

    return ApiResponse.success(response);
  } catch (error) {
    Logger.error("Erreur lors de la mise à jour de la transaction", error as Error, context);
    return ApiError.handle(error);
  }
}