import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";
import { verifyGuestToken } from "@/lib/auth";

// Schéma de validation pour les paramètres
const ParamsSchema = z.object({
  orderNumber: z.string().min(1, "Numéro de commande requis"),
});

// Schéma de validation pour les query parameters
const QuerySchema = z.object({
  guestToken: z.string().optional(),
});

// GET /api/payments/status/[orderNumber]
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ orderNumber: string }> }
) {
  const context = Logger.createContext(request);
  const { orderNumber } = await params;
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête GET /api/payments/status/[orderNumber]", context);

    // Validation des paramètres
    const validatedParams = ParamsSchema.parse({ orderNumber });

    // Validation des query parameters
    const url = new URL(request.url);
    const queryParams = {
      guestToken: url.searchParams.get('guestToken') || undefined,
    };
    const validatedQuery = QuerySchema.parse(queryParams);

    Logger.info("Vérification du statut de paiement", context, {
      orderNumber: validatedParams.orderNumber,
      hasGuestToken: !!validatedQuery.guestToken,
    });

    // Récupération de la commande avec les transactions
    const order = await prisma.order.findUnique({
      where: { 
        orderNumber: validatedParams.orderNumber,
      },
      include: {
        transactions: {
          orderBy: {
            createdAt: 'desc',
          },
          include: {
            paymentMethod: {
              select: {
                name: true,
                type: true,
                provider: true,
              },
            },
          },
        },
        customer: {
          select: {
            id: true,
            email: true,
            firstName: true,
            lastName: true,
          },
        },
      },
    });

    if (!order) {
      Logger.warn("Commande introuvable", context, {
        orderNumber: validatedParams.orderNumber,
      });
      return ApiError.notFound("Commande introuvable");
    }

    // Vérification des permissions d'accès
    let hasAccess = false;
    let accessType = "unknown";

    // Si c'est une commande invité avec token
    if (!order.customerId && validatedQuery.guestToken) {
      try {
        const guestPayload = await verifyGuestToken(validatedQuery.guestToken);
        // Vérifier que le token correspond à cette commande (logique à adapter selon votre implémentation)
        hasAccess = true;
        accessType = "guest";
        context.sessionId = guestPayload.sessionId;
      } catch (error) {
        Logger.warn("Token invité invalide", context, {
          orderNumber: validatedParams.orderNumber,
        });
        return ApiError.unauthorized("Token invité invalide");
      }
    }
    // Si c'est une commande client, on peut permettre l'accès public au statut
    // (dans un vrai projet, vous pourriez vouloir authentifier l'utilisateur)
    else if (order.customerId) {
      hasAccess = true;
      accessType = "customer";
    }
    // Commande sans client et sans token valide
    else {
      hasAccess = false;
    }

    if (!hasAccess) {
      Logger.warn("Accès refusé au statut de paiement", context, {
        orderNumber: validatedParams.orderNumber,
        hasCustomer: !!order.customerId,
        hasGuestToken: !!validatedQuery.guestToken,
      });
      return ApiError.forbidden("Accès refusé au statut de cette commande");
    }

    // Récupération de la dernière transaction
    const latestTransaction = order.transactions[0];

    // Calcul du statut global
    let overallStatus = "unknown";
    let statusMessage = "Statut inconnu";
    let canRetry = false;

    if (!latestTransaction) {
      overallStatus = "no_payment";
      statusMessage = "Aucun paiement initié";
      canRetry = true;
    } else {
      switch (latestTransaction.status) {
        case "pending":
          overallStatus = "processing";
          statusMessage = "Paiement en cours de traitement";
          canRetry = false;
          break;
        case "completed":
          overallStatus = "success";
          statusMessage = "Paiement réussi";
          canRetry = false;
          break;
        case "failed":
          overallStatus = "failed";
          statusMessage = latestTransaction.failureReason || "Paiement échoué";
          canRetry = true;
          break;
        case "cancelled":
          overallStatus = "cancelled";
          statusMessage = "Paiement annulé";
          canRetry = true;
          break;
        case "refunded":
          overallStatus = "refunded";
          statusMessage = "Paiement remboursé";
          canRetry = false;
          break;
        default:
          overallStatus = "unknown";
          statusMessage = "Statut de paiement inconnu";
          canRetry = true;
      }
    }

    Logger.info("Statut de paiement récupéré avec succès", context, {
      orderNumber: order.orderNumber,
      paymentStatus: order.paymentStatus,
      orderStatus: order.status,
      transactionStatus: latestTransaction?.status,
      accessType,
    });

    // Formatage de la réponse
    const response = {
      order: {
        orderNumber: order.orderNumber,
        status: order.status,
        paymentStatus: order.paymentStatus,
        finalAmount: Number(order.finalAmount),
        createdAt: order.createdAt,
        deliveryDate: order.deliveryDate,
        deliveryTime: order.deliveryTime,
      },
      payment: {
        status: overallStatus,
        message: statusMessage,
        canRetry,
        lastUpdated: latestTransaction?.updatedAt || order.createdAt,
      },
      // Informations sur la dernière transaction (limitées)
      ...(latestTransaction ? {
        transaction: {
          id: latestTransaction.transactionId,
          amount: Number(latestTransaction.amount),
          currency: latestTransaction.currency,
          status: latestTransaction.status,
          createdAt: latestTransaction.createdAt,
          processedAt: latestTransaction.processedAt,
          paymentMethod: {
            name: latestTransaction.paymentMethod.name,
            type: latestTransaction.paymentMethod.type,
          },
          // Raison d'échec seulement si échec
          ...(latestTransaction.status === "failed" && latestTransaction.failureReason ? {
            failureReason: latestTransaction.failureReason,
          } : {}),
        },
      } : {}),
      // Informations client (limitées selon le type d'accès)
      ...(accessType === "customer" && order.customer ? {
        customer: {
          email: order.customer.email,
          name: `${order.customer.firstName} ${order.customer.lastName}`,
        },
      } : {}),
    };

    return ApiResponse.success(response);
  } catch (error) {
    Logger.error("Erreur lors de la vérification du statut de paiement", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/payments/status/[orderNumber]
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}