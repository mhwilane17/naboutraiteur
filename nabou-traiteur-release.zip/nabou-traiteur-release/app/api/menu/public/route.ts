import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Validation schemas
const PublicMenuQuerySchema = z.object({
  categoryId: z.string().optional(),
  search: z.string().optional(),
  isAvailable: z.string().transform(val => val === "true").default("true"),
  sortBy: z.enum(["name", "price", "category", "sortOrder"]).default("sortOrder"),
  sortOrder: z.enum(["asc", "desc"]).default("asc"),
  includeOptions: z.string().transform(val => val === "true").default("true"),
  includeReviews: z.string().transform(val => val === "true").default("false"),
});



// GET /api/menu/public - Get public menu (categories and items)
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête GET /api/menu/public", context);

    // Parse and validate query parameters
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());
    const {
      categoryId,
      search,
      isAvailable,
      sortBy,
      sortOrder,
      includeOptions,
      includeReviews,
    } = PublicMenuQuerySchema.parse(queryParams);

    // Get active categories
    const categories = await prisma.category.findMany({
      where: {
        isActive: true,
      },
      orderBy: {
        sortOrder: 'asc',
      },
      include: {
        menuItems: {
          where: {
            isActive: true,
            isAvailable: isAvailable,
            ...(categoryId ? { categoryId } : {}),
            ...(search ? {
              OR: [
                {
                  name: {
                    contains: search,
                    mode: "insensitive",
                  },
                },
                {
                  description: {
                    contains: search,
                    mode: "insensitive",
                  },
                },
              ],
            } : {}),
          },
          orderBy: sortBy === "category" ? { sortOrder: sortOrder } : { [sortBy]: sortOrder },
          include: {
            options: includeOptions ? {
              orderBy: {
                sortOrder: 'asc',
              },
            } : false,
            ...(includeReviews ? {
              reviews: {
                where: {
                  // Only include reviews with rating >= 3 for public view
                  rating: {
                    gte: 3,
                  },
                },
                include: {
                  user: {
                    select: {
                      firstName: true,
                      lastName: true,
                    },
                  },
                },
                orderBy: {
                  createdAt: 'desc',
                },
                take: 5, // Limit to 5 most recent reviews
              },
            } : {}),
          },
        },
      },
    });

    // Calculate statistics for each menu item
    const formattedCategories = categories.map(category => ({
      id: category.id,
      name: category.name,
      description: category.description,
      color: category.color,
      icon: category.icon,
      sortOrder: category.sortOrder,
      menuItems: category.menuItems.map(item => {
        const itemReviews = (item as any).reviews;
        const avgRating = includeReviews && itemReviews && itemReviews.length > 0 
          ? itemReviews.reduce((sum: number, review: any) => sum + review.rating, 0) / itemReviews.length
          : 0;

        return {
          id: item.id,
          name: item.name,
          description: item.description,
          price: Number(item.price),
          image: item.image,
          isAvailable: item.isAvailable,
          preparationTime: item.preparationTime,
          allergens: item.allergens,
          nutritionalInfo: item.nutritionalInfo,
          sortOrder: item.sortOrder,
          options: includeOptions ? item.options : undefined,
          reviews: includeReviews ? {
            items: itemReviews?.map((review: any) => ({
              id: review.id,
              rating: review.rating,
              comment: review.comment,
              createdAt: review.createdAt,
              user: {
                name: `${review.user.firstName} ${review.user.lastName.charAt(0)}.`,
              },
            })),
            averageRating: Math.round(avgRating * 10) / 10,
            totalCount: itemReviews?.length || 0,
          } : undefined,
        };
      }),
      itemsCount: category.menuItems.length,
    }));

    // Filter out categories with no items if search is applied
    const filteredCategories = search 
      ? formattedCategories.filter(category => category.itemsCount > 0)
      : formattedCategories;

    // Get total items count
    const totalItems = filteredCategories.reduce((sum, category) => sum + category.itemsCount, 0);

    Logger.info("Menu public récupéré avec succès", context, {
      categoriesCount: filteredCategories.length,
      totalItems,
    });

    return ApiResponse.success({
      categories: filteredCategories,
      stats: {
        categoriesCount: filteredCategories.length,
        totalItems,
      },
    });
  } catch (error) {
    Logger.error("Erreur lors de GET /api/menu/public", error as Error, context);
    return ApiError.handle(error);
  }
}



// OPTIONS /api/menu/public (CORS preflight)
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}