import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";
import { isOrderingTimeActive } from "@/lib/app-config";
import {
  getRakTakPromoDetails,
  resolveDishRakTak,
  computeRakTakDiscountFromDetails,
} from "@/services/promotionService";

// Validation schemas
const PublicWeeklyMenuQuerySchema = z.object({
  employee: z.string().min(0).optional(),
  includeDishes: z
    .string()
    .transform((val) => val === "true")
    .default("true"),
});

// Fonction déplacée vers lib/app-config.ts pour utiliser les configurations de la BDD

// GET /api/menu/public/weekly - Get public weekly menus
/**
 * Cette route renvoie les menus hebdomadaires publics avec les conditions suivantes pour qu'un plat soit commandable :
 * 1. Le plat doit être disponible pour le jour actuel (dayOfWeek == jour actuel)
 * 2. La quantité disponible du plat doit être supérieure à 0
 * 3. L'heure actuelle doit être entre 7h et 15h pour permettre la commande
 */
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête GET /api/menu/public/weekly", context);

    // Parse and validate query parameters
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());
    const { employee, includeDishes } =
      PublicWeeklyMenuQuerySchema.parse(queryParams);

    const now = new Date();
    // const now = new Date("2025-08-11T00:48:24.924Z")

    // Obtenir le début et la fin de la semaine courante
    const startOfWeek = new Date(now);
    startOfWeek.setDate(
      now.getDate() - now.getDay() + (now.getDay() === 0 ? -6 : 1),
    ); // Lundi de la semaine courante
    startOfWeek.setHours(0, 0, 0, 0);

    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6); // Dimanche de la semaine courante
    endOfWeek.setHours(23, 59, 59, 999);

    Logger.info(
      `Recherche des menus uniquement pour la semaine courante: du ${startOfWeek.toISOString()} au ${endOfWeek.toISOString()}`,
      context,
    );

    const where: any = {
      isActive: true,
      // Trouver uniquement les menus qui correspondent à la semaine courante
      AND: [
        { startDate: { lte: endOfWeek } },
        { endDate: { gte: startOfWeek } },
      ],
    };

    // Get weekly menus
    const weeklyMenus = await prisma.weeklyMenu.findMany({
      where,
      orderBy: [
        // Prioriser les menus qui commencent le plus près du début de la semaine courante
        {
          startDate: "desc",
        },
      ],
      // Limiter à 1 menu pour éviter les doublons si plusieurs menus correspondent
      take: 1,
      ...(includeDishes
        ? {
            include: {
              dishes: {
                where: {
                  isAvailable: true,
                },
                include: {
                  menuItem: {
                    include: {
                      category: {
                        select: {
                          id: true,
                          name: true,
                          color: true,
                          icon: true,
                          sortOrder: true,
                        },
                      },
                      options: {
                        orderBy: {
                          sortOrder: "asc",
                        },
                      },
                    },
                  },
                },
                orderBy: [{ dayOfWeek: "asc" }, { mealType: "asc" }],
              },
            },
          }
        : {}),
    });

    // Log des menus trouvés pour faciliter le débogage
    if (weeklyMenus.length > 0) {
      Logger.info(
        `Menu hebdomadaire trouvé: ID=${
          weeklyMenus[0].id
        }, période du ${new Date(
          weeklyMenus[0].startDate,
        ).toISOString()} au ${new Date(weeklyMenus[0].endDate).toISOString()}`,
        context,
      );
    } else {
      Logger.warn(
        `Aucun menu hebdomadaire trouvé pour la semaine courante`,
        context,
      );
    }

    // Précharger la promo RakTak si nécessaire (au moins un plat l'indique)
    const hasAnyRakTakDish = includeDishes
      ? weeklyMenus.some((menu) =>
          (menu as any).dishes?.some((dish: any) => dish.hasRakTakPromo),
        )
      : false;

    const rakTakDetails = hasAnyRakTakDish
      ? await getRakTakPromoDetails(now)
      : null;

    // Helper function to get day name in French
    const getDayNameInFrench = (dayOfWeek: number): string => {
      const dayNames = [
        "dimanche",
        "lundi",
        "mardi",
        "mercredi",
        "jeudi",
        "vendredi",
        "samedi",
      ];
      return dayNames[dayOfWeek] || "lundi";
    };

    // Vérifier si les commandes sont acceptées maintenant (une seule fois)
    const canOrderNow = await isOrderingTimeActive();

    // Récupérer les informations de l'employé et ses limites de catégorie si un ID employé est fourni
    let employeeData: any = null;
    let employeeCategoryLimits: any[] = [];
    let employeeTodayOrders: any[] = [];

    if (employee) {
      // Récupérer les informations de l'employé avec sa compagnie
      employeeData = await prisma.user.findUnique({
        where: { id: employee },
        include: {
          company: {
            include: {
              limits: {
                include: {
                  category: true,
                },
              },
            },
          },
        },
      });

      if (employeeData?.company) {
        employeeCategoryLimits = employeeData.company.limits;

        // Récupérer les commandes de l'employé pour la journée en cours
        const startOfDay = new Date(now);
        startOfDay.setHours(0, 0, 0, 0);

        const endOfDay = new Date(now);
        endOfDay.setHours(23, 59, 59, 999);

        employeeTodayOrders = await prisma.order.findMany({
          where: {
            customerId: employee,
            createdAt: {
              gte: startOfDay,
              lte: endOfDay,
            },
          },
          include: {
            items: {
              include: {
                menuItem: {
                  include: {
                    category: true,
                  },
                },
              },
            },
          },
        });
      }
    }

    // Format response to match MenuSection.tsx structure
    const weeklyMenuData: Record<string, any[]> = {};

    // Créer un map des catégories pour le tri
    const categoryOrderMap = new Map<string, number>();

    // Fonction helper pour vérifier les limites de catégorie d'un employé
    const checkEmployeeCategoryLimit = (
      categoryId: string,
    ): { canOrder: boolean; remainingQuantity: number } => {
      if (!employee || !employeeCategoryLimits.length) {
        return { canOrder: true, remainingQuantity: 999 }; // Pas de limite si pas d'employé ou pas de limites
      }

      // Trouver la limite pour cette catégorie
      const categoryLimit = employeeCategoryLimits.find(
        (limit) => limit.categoryId === categoryId,
      );
      if (!categoryLimit) {
        return { canOrder: true, remainingQuantity: 999 }; // Pas de limite pour cette catégorie
      }

      // Calculer combien l'employé a déjà commandé dans cette catégorie aujourd'hui
      const orderedQuantityToday = employeeTodayOrders.reduce(
        (total, order) => {
          return (
            total +
            order.items.reduce((itemTotal: number, item: any) => {
              if (item.menuItem.categoryId === categoryId) {
                return itemTotal + item.quantity;
              }
              return itemTotal;
            }, 0)
          );
        },
        0,
      );

      const remainingQuantity = Math.max(
        0,
        categoryLimit.maxPerOrder - orderedQuantityToday,
      );
      const canOrder = remainingQuantity > 0;

      return { canOrder, remainingQuantity };
    };

    weeklyMenus.forEach((menu) => {
      const menuDishes = (menu as any).dishes;

      if (includeDishes && menuDishes) {
        // Remplir le map des catégories avec leur sortOrder
        menuDishes.forEach((dish: any) => {
          if (dish.menuItem?.category) {
            categoryOrderMap.set(
              dish.menuItem.category.name,
              dish.menuItem.category.sortOrder,
            );
          }
        });

        menuDishes.forEach((dish: any) => {
          // Only include dishes with active and available menu items
          if (
            dish.menuItem &&
            dish.menuItem.isActive &&
            dish.menuItem.isAvailable
          ) {
            const dayKey = getDayNameInFrench(dish.dayOfWeek);

            if (!weeklyMenuData[dayKey]) {
              weeklyMenuData[dayKey] = [];
            }

            // Extract options from MenuItemOption.values JSON field
            const extractedOptions: { name: string; price: number }[] = [];

            dish.menuItem.options.forEach((option: any) => {
              if (option.values && Array.isArray(option.values)) {
                option.values.forEach((value: any) => {
                  if (value.name && typeof value.price === "number") {
                    extractedOptions.push({
                      name: value.name,
                      price: Number(value.price),
                    });
                  }
                });
              }
            });

            // Si aucune option valide trouvée, utiliser le prix de base du MenuItem
            let finalOptions =
              extractedOptions.length > 0
                ? extractedOptions
                : [{ name: "Classique", price: Number(dish.menuItem.price) }];

            // Vérifier si le plat est commandable selon les conditions
            const currentDayOfWeek = now.getDay(); // 0 = dimanche, 1 = lundi, etc.
            const isCurrentDay = dish.dayOfWeek === currentDayOfWeek;
            const hasAvailableQuantity = dish.quantity > 0; // Vérifier si la quantité est supérieure à 0
            // canOrderNow est déjà calculé avant la boucle

            // Vérifier les limites de catégorie d'entreprise pour l'employé
            const categoryLimitCheck = checkEmployeeCategoryLimit(
              dish.menuItem.categoryId,
            );
            const employeeCanOrder = categoryLimitCheck.canOrder;
            const employeeRemainingQuantity =
              categoryLimitCheck.remainingQuantity;

            // La quantité finale est le minimum entre la quantité disponible du plat et la quantité restante pour l'employé
            const finalQuantity = employee
              ? Math.min(dish.quantity, employeeRemainingQuantity)
              : dish.quantity;
            const finalHasAvailableQuantity = finalQuantity > 0;

            const { hasRakTakPromo, rakTakPromoCode } = resolveDishRakTak(
              dish.hasRakTakPromo,
              rakTakDetails
                ? { isActiveNow: true, code: rakTakDetails.code }
                : { isActiveNow: false, code: null },
            );

            // Déterminer le statut du plat
            let status: "available" | "unavailable" | "sold_out" =
              "unavailable";

            if (
              isCurrentDay &&
              finalHasAvailableQuantity &&
              canOrderNow &&
              (!employee || employeeCanOrder)
            ) {
              status = "available";
            } else if (!finalHasAvailableQuantity) {
              status = "sold_out";
            }

            // Calcul du montant de réduction net basé sur le prix minimum des options
            if (hasRakTakPromo && rakTakDetails) {
              // Appliquer la réduction sur chaque option et inclure discountAmount
              finalOptions = finalOptions.map((opt) => {
                const discount =
                  computeRakTakDiscountFromDetails(
                    rakTakDetails,
                    Number(opt.price),
                  ) || 0;
                const newPrice = Math.max(
                  0,
                  Math.round(Number(opt.price) - discount),
                );
                return {
                  name: opt.name,
                  price: Number(opt.price),
                  discountPrice: newPrice,
                  discountAmount: discount,
                };
              });
            }

            // Format dish to match MenuItem interface
            const menuItem = {
              name: dish.menuItem.name,
              options: finalOptions,
              image: dish.menuItem.image || "/placeholder.svg",

              status: status,
              canOrderNow: canOrderNow,
              // status: "available",
              // canOrderNow: true,

              day: dayKey.charAt(0).toUpperCase() + dayKey.slice(1),
              description: dish.menuItem.description,
              category: dish.menuItem.category.name,
              hasRakTakPromo,
              rakTakPromoCode,
              id: dish.id,
              menuItemId: dish.menuItem.id,
              weeklyMenuId: menu.id,
              dayOfWeek: dish.dayOfWeek,
              mealType: dish.mealType,
              isAvailable: dish.isAvailable && (!employee || employeeCanOrder),
              specialPrice: dish.specialPrice
                ? Number(dish.specialPrice)
                : null,
              preparationTime: dish.menuItem.preparationTime,
              quantity: finalQuantity,
              isCurrentDay: isCurrentDay,
              // allergens: dish.menuItem.allergens,
              // nutritionalInfo: dish.menuItem.nutritionalInfo
            };

            weeklyMenuData[dayKey].push(menuItem);
          }
        });
      }
    });

    // Trier les plats dans chaque jour par l'ordre des catégories (sortOrder)
    Object.keys(weeklyMenuData).forEach((dayKey) => {
      weeklyMenuData[dayKey].sort((a, b) => {
        const categoryA = a.category;
        const categoryB = b.category;

        // Utiliser le map des catégories pour récupérer le sortOrder
        const sortOrderA = categoryOrderMap.get(categoryA) || 999;
        const sortOrderB = categoryOrderMap.get(categoryB) || 999;

        return sortOrderA - sortOrderB;
      });
    });

    // Calculate stats
    const totalDishes = Object.values(weeklyMenuData).reduce(
      (sum, dishes) => sum + dishes.length,
      0,
    );
    const daysWithMeals = Object.keys(weeklyMenuData).length;

    Logger.info("Menus hebdomadaires publics récupérés avec succès", context, {
      menusCount: weeklyMenus.length,
      totalDishes,
      daysWithMeals,
    });

    return ApiResponse.success({
      weeklyMenu: weeklyMenuData,
      stats: {
        menusCount: weeklyMenus.length,
        totalDishes,
        daysWithMeals,
      },
    });
  } catch (error) {
    Logger.error(
      "Erreur lors de GET /api/menu/public/weekly",
      error as Error,
      context,
    );
    return ApiError.handle(error);
  }
}

// OPTIONS /api/menu/public/weekly (CORS preflight)
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}
