import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Validation schemas
const MenuItemOptionSchema = z.object({
  name: z.string().min(1).max(200),
  type: z.string().min(1).max(50),
  values: z.array(
    z.object({
      name: z.string().min(1).max(200),
      price: z.number().default(0),
      isAvailable: z.boolean().default(true),
    })
  ),
  isRequired: z.boolean().default(false),
  maxSelections: z.number().int().min(1).optional(),
  sortOrder: z.number().int().min(0).default(0),
});

const UpdateMenuItemSchema = z.object({
  name: z.string().min(2).max(200).optional(),
  description: z.string().max(1000).optional(),
  price: z.number().min(0).optional(),
  image: z.string().optional(),
  categoryId: z.string().optional(),
  isAvailable: z.boolean().optional(),
  isActive: z.boolean().optional(),
  isRakTakPromo: z.boolean().optional(),
  preparationTime: z.number().int().min(0).optional(),
  allergens: z.array(z.string()).optional(),
  nutritionalInfo: z.record(z.any()).optional(),
  sortOrder: z.number().int().min(0).optional(),
  options: z.array(MenuItemOptionSchema).optional(),
});

// GET /api/menu/items/[id]
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info(`Début de la requête GET /api/menu/items/${id}`, context);

    // Get menu item with all related data
    const menuItem = await prisma.menuItem.findUnique({
      where: { id },
      include: {
        category: {
          select: {
            id: true,
            name: true,
            color: true,
            icon: true,
          },
        },
        options: {
          orderBy: {
            sortOrder: "asc",
          },
        },
        reviews: {
          include: {
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
              },
            },
          },
          orderBy: {
            createdAt: "desc",
          },
        },
        orderItems: {
          select: {
            id: true,
            quantity: true,
            order: {
              select: {
                status: true,
                createdAt: true,
              },
            },
          },
        },
        weeklyMenuDishes: {
          include: {
            weeklyMenu: {
              select: {
                id: true,
                name: true,
                startDate: true,
                endDate: true,
                isActive: true,
              },
            },
          },
        },
      },
    });

    if (!menuItem) {
      return ApiError.notFound("Plat non trouvé");
    }

    // Calculate statistics
    const totalOrders = menuItem.orderItems.length;
    const totalQuantitySold = menuItem.orderItems.reduce((sum, item) => sum + item.quantity, 0);
    const avgRating =
      menuItem.reviews.length > 0
        ? menuItem.reviews.reduce((sum, review) => sum + review.rating, 0) / menuItem.reviews.length
        : 0;

    // Get recent orders (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const recentOrders = menuItem.orderItems.filter(
      (item) => new Date(item.order.createdAt) >= thirtyDaysAgo
    );

    const stats = {
      totalOrders,
      totalQuantitySold,
      recentOrders: recentOrders.length,
      reviewCount: menuItem.reviews.length,
      averageRating: Math.round(avgRating * 10) / 10,
      optionsCount: menuItem.options.length,
      weeklyMenusCount: menuItem.weeklyMenuDishes.length,
      activeWeeklyMenusCount: menuItem.weeklyMenuDishes.filter((dish) => dish.weeklyMenu.isActive)
        .length,
    };

    // Format response
    const formattedMenuItem = {
      id: menuItem.id,
      name: menuItem.name,
      description: menuItem.description,
      price: Number(menuItem.price),
      image: menuItem.image,
      isAvailable: menuItem.isAvailable,
      isActive: menuItem.isActive,
      preparationTime: menuItem.preparationTime,
      allergens: menuItem.allergens,
      nutritionalInfo: menuItem.nutritionalInfo,
      sortOrder: menuItem.sortOrder,
      createdAt: menuItem.createdAt,
      updatedAt: menuItem.updatedAt,
      category: menuItem.category,
      options: menuItem.options,
      reviews: menuItem.reviews.map((review) => ({
        id: review.id,
        rating: review.rating,
        comment: review.comment,
        createdAt: review.createdAt,
        user: review.user,
      })),
      weeklyMenus: menuItem.weeklyMenuDishes.map((dish) => ({
        id: dish.weeklyMenu.id,
        name: dish.weeklyMenu.name,
        startDate: dish.weeklyMenu.startDate,
        endDate: dish.weeklyMenu.endDate,
        isActive: dish.weeklyMenu.isActive,
        dayOfWeek: dish.dayOfWeek,
        mealType: dish.mealType,
      })),
      stats,
    };

    Logger.info(`Plat récupéré avec succès`, context, {
      menuItemId: menuItem.id,
      reviewsCount: menuItem.reviews.length,
      optionsCount: menuItem.options.length,
    });

    return ApiResponse.success(formattedMenuItem);
  } catch (error) {
Logger.error(`Erreur lors de GET /api/menu/items/${id}`, error as Error, context);
  }
}

// PUT /api/menu/items/[id]
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info(`Début de la requête PUT /api/menu/items/${id}`, context);

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check permission 'menu.update'
    // await requirePermission('menu.update')(request, user);

    // context.userId = user.id;

    // Parse and validate request body
    const body = await request.json();
    const validatedData = UpdateMenuItemSchema.parse(body);

    // Check if menu item exists
    const existingMenuItem = await prisma.menuItem.findUnique({
      where: { id },
    });

    if (!existingMenuItem) {
      return ApiError.notFound("Plat non trouvé");
    }

    // Check if category exists (if being updated)
    if (validatedData.categoryId) {
      const category = await prisma.category.findUnique({
        where: { id: validatedData.categoryId },
      });

      if (!category) {
        return ApiError.badRequest("Catégorie non trouvée");
      }
    }

    // Check if name is being updated and already exists in the same category
    if (validatedData.name) {
      const categoryId = validatedData.categoryId || existingMenuItem.categoryId;
      const nameConflict = await prisma.menuItem.findFirst({
        where: {
          name: {
            equals: validatedData.name,
            mode: "insensitive",
          },
          categoryId,
          id: {
            not: id,
          },
        },
      });

      if (nameConflict) {
        return ApiError.conflict("Un plat avec ce nom existe déjà dans cette catégorie");
      }
    }

    // Separate options and categoryId from other data
    const { options, categoryId, ...menuItemData } = validatedData;

    // Prepare update data with proper category relation
    const updateData: any = { ...menuItemData };
    if (categoryId) {
      updateData.category = {
        connect: { id: categoryId },
      };
    }

    // Update menu item
    const updatedMenuItem = await prisma.menuItem.update({
      where: { id },
      data: updateData,
      include: {
        category: {
          select: {
            id: true,
            name: true,
            color: true,
            icon: true,
          },
        },
        options: {
          orderBy: {
            sortOrder: "asc",
          },
        },
        reviews: {
          select: {
            rating: true,
          },
        },
      },
    });

    // Update options if provided
    if (options) {
      // Delete existing options
      await prisma.menuItemOption.deleteMany({
        where: { menuItemId: id },
      });

      // Create new options
      if (options.length > 0) {
        await prisma.menuItemOption.createMany({
          data: options.map((option) => ({
            ...option,
menuItemId: id,
            values: option.values,
          })),
        });
      }

      // Fetch updated menu item with new options
      const finalMenuItem = await prisma.menuItem.findUnique({
        where: { id },
        include: {
          category: {
            select: {
              id: true,
              name: true,
              color: true,
              icon: true,
            },
          },
          options: {
            orderBy: {
              sortOrder: "asc",
            },
          },
          reviews: {
            select: {
              rating: true,
            },
          },
        },
      });

      if (!finalMenuItem) {
        return ApiError.internalError("Erreur lors de la récupération du plat mis à jour");
      }

      // Use finalMenuItem for response
      const avgRating =
        finalMenuItem.reviews.length > 0
          ? finalMenuItem.reviews.reduce((sum: number, review: any) => sum + review.rating, 0) /
          finalMenuItem.reviews.length
          : 0;

      // Format response
      const formattedMenuItem = {
        id: finalMenuItem.id,
        name: finalMenuItem.name,
        description: finalMenuItem.description,
        price: Number(finalMenuItem.price),
        image: finalMenuItem.image,
        isAvailable: finalMenuItem.isAvailable,
        isActive: finalMenuItem.isActive,
        preparationTime: finalMenuItem.preparationTime,
        allergens: finalMenuItem.allergens,
        nutritionalInfo: finalMenuItem.nutritionalInfo,
        sortOrder: finalMenuItem.sortOrder,
        createdAt: finalMenuItem.createdAt,
        updatedAt: finalMenuItem.updatedAt,
        category: finalMenuItem.category,
        options: finalMenuItem.options,
        stats: {
          reviewCount: finalMenuItem.reviews.length,
          averageRating: Math.round(avgRating * 10) / 10,
          optionsCount: finalMenuItem.options.length,
        },
      };

      Logger.info("Plat mis à jour avec succès", context, {
        menuItemId: finalMenuItem.id,
        menuItemName: finalMenuItem.name,
      });

      return ApiResponse.success(formattedMenuItem);
    }

    // Calculate stats
    const avgRating =
      updatedMenuItem.reviews.length > 0
        ? updatedMenuItem.reviews.reduce((sum, review) => sum + review.rating, 0) /
        updatedMenuItem.reviews.length
        : 0;

    // Format response
    const formattedMenuItem = {
      id: updatedMenuItem.id,
      name: updatedMenuItem.name,
      description: updatedMenuItem.description,
      price: Number(updatedMenuItem.price),
      image: updatedMenuItem.image,
      isAvailable: updatedMenuItem.isAvailable,
      isActive: updatedMenuItem.isActive,
      preparationTime: updatedMenuItem.preparationTime,
      allergens: updatedMenuItem.allergens,
      nutritionalInfo: updatedMenuItem.nutritionalInfo,
      sortOrder: updatedMenuItem.sortOrder,
      createdAt: updatedMenuItem.createdAt,
      updatedAt: updatedMenuItem.updatedAt,
      category: updatedMenuItem.category,
      options: updatedMenuItem.options,
      stats: {
        reviewCount: updatedMenuItem.reviews.length,
        averageRating: Math.round(avgRating * 10) / 10,
        optionsCount: updatedMenuItem.options.length,
      },
    };

    Logger.info("Plat mis à jour avec succès", context, {
      menuItemId: updatedMenuItem.id,
      menuItemName: updatedMenuItem.name,
    });

    return ApiResponse.success(formattedMenuItem);
  } catch (error) {
Logger.error(`Erreur lors de PUT /api/menu/items/${id}`, error as Error, context);
  }
}

// DELETE /api/menu/items/[id]
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info(`Début de la requête DELETE /api/menu/items/${id}`, context);

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check permission 'menu.delete'
    // await requirePermission('menu.delete')(request, user);

    // context.userId = user.id;

    // Check if menu item exists and get related data
    const existingMenuItem = await prisma.menuItem.findUnique({
      where: { id },
      include: {
        orderItems: {
          select: { id: true },
        },
        weeklyMenuDishes: {
          select: { id: true },
        },
        reviews: {
          select: { id: true },
        },
      },
    });

    if (!existingMenuItem) {
      return ApiError.notFound("Plat non trouvé");
    }

    // Check if menu item has orders
    // if (existingMenuItem.orderItems.length > 0) {
    //   return ApiError.conflict(
    //     "Impossible de supprimer un plat qui a été commandé. Vous pouvez le désactiver à la place."
    //   );
    // }

    // Check if menu item is in weekly menus
    if (existingMenuItem.weeklyMenuDishes.length > 0) {
      return ApiError.conflict(
        "Impossible de supprimer un plat qui fait partie de menus hebdomadaires. Veuillez d'abord le retirer des menus."
      );
    }

    // Delete menu item (this will cascade delete options and reviews)
    await prisma.menuItem.delete({
      where: { id },
    });

    Logger.info("Plat supprimé avec succès", context, {
      menuItemId: id,
      menuItemName: existingMenuItem.name,
    });

    return ApiResponse.success({
      message: "Plat supprimé avec succès",
      deletedMenuItem: {
        id: existingMenuItem.id,
        name: existingMenuItem.name,
      },
    });
  } catch (error) {
    Logger.error(`Erreur lors de DELETE /api/menu/items/${id}`, error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/menu/items/[id] (CORS preflight)
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
