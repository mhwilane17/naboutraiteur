import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Validation schemas
const CreateMenuItemOptionSchema = z.object({
  name: z.string().min(2).max(200),
  type: z.string().min(1).max(50),
  values: z.array(z.object({
    name: z.string().min(1).max(200),
    price: z.number().default(0),
    isAvailable: z.boolean().default(true),
  })),
  isRequired: z.boolean().default(false),
  maxSelections: z.number().int().min(1).optional(),
  sortOrder: z.number().int().min(0).default(0),
});

const MenuItemOptionQuerySchema = z.object({
  page: z.string().transform(Number).pipe(z.number().int().min(1)).default("1"),
  limit: z.string().transform(Number).pipe(z.number().int().min(1).max(100)).default("20"),
  search: z.string().optional(),
  type: z.enum(["SINGLE_CHOICE", "MULTIPLE_CHOICE", "QUANTITY", "TEXT_INPUT"]).optional(),
  isRequired: z.string().transform(val => val === "true").optional(),
  sortBy: z.enum(["name", "type", "sortOrder", "createdAt"]).default("sortOrder"),
  sortOrder: z.enum(["asc", "desc"]).default("asc"),
  includeValues: z.string().transform(val => val === "true").default("true"),
});

// GET /api/menu/items/[id]/options
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info(`Début de la requête GET /api/menu/items/${id}/options`, context);

    // Parse and validate query parameters
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());
    const {
      page,
      limit,
      search,
      type,
      isRequired,
      sortBy,
      sortOrder,
      includeValues,
    } = MenuItemOptionQuerySchema.parse(queryParams);

    // Check if menu item exists
    const menuItem = await prisma.menuItem.findUnique({
      where: { id },
      select: { id: true, name: true },
    });

    if (!menuItem) {
      return ApiError.notFound("Plat non trouvé");
    }

    // Build where clause
    const where: any = {
      menuItemId: id,
    };

    if (search) {
      where.OR = [
        {
          name: {
            contains: search,
            mode: "insensitive",
          },
        },
        {
          description: {
            contains: search,
            mode: "insensitive",
          },
        },
      ];
    }

    if (type) {
      where.type = type;
    }

    if (isRequired !== undefined) {
      where.isRequired = isRequired;
    }

    // Build orderBy clause
    const orderBy: any = {};
    orderBy[sortBy] = sortOrder;

    // Get total count
    const totalCount = await prisma.menuItemOption.count({ where });

    // Calculate pagination
    const totalPages = Math.ceil(totalCount / limit);
    const skip = (page - 1) * limit;

    // Get options
    const options = await prisma.menuItemOption.findMany({
      where,
      orderBy,
      skip,
      take: limit,
    });

    // Format response
    const formattedOptions = options.map(option => ({
      id: option.id,
      name: option.name,
      type: option.type,
      values: includeValues ? option.values : undefined,
      isRequired: option.isRequired,
      maxSelections: option.maxSelections,
      sortOrder: option.sortOrder,
      createdAt: option.createdAt,
      updatedAt: option.updatedAt,
    }));

    const pagination = {
      page,
      limit,
      totalCount,
      totalPages,
      hasNextPage: page < totalPages,
      hasPreviousPage: page > 1,
    };

    Logger.info(`Options du plat récupérées avec succès`, context, {
      menuItemId: id,
      optionsCount: options.length,
      totalCount,
    });

    return ApiResponse.success({
      options: formattedOptions,
      pagination,
      menuItem: {
        id: menuItem.id,
        name: menuItem.name,
      },
    });
  } catch (error) {
Logger.error(`Erreur lors de GET /api/menu/items/${id}/options`, error as Error, context);
  }
}

// POST /api/menu/items/[id]/options
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info(`Début de la requête POST /api/menu/items/${id}/options`, context);

    // Authentication
    const user = await requireAuth(request);

    // TODO: Check permission 'menu.create'
    // await requirePermission('menu.create')(request, user);

    context.userId = user.id;

    // Check if menu item exists
    const menuItem = await prisma.menuItem.findUnique({
      where: { id },
      select: { id: true, name: true },
    });

    if (!menuItem) {
      return ApiError.notFound("Plat non trouvé");
    }

    // Parse and validate request body
    const body = await request.json();
    const validatedData = CreateMenuItemOptionSchema.parse(body);

    // Check if option name already exists for this menu item
    const existingOption = await prisma.menuItemOption.findFirst({
      where: {
        menuItemId: id,
        name: {
          equals: validatedData.name,
          mode: "insensitive",
        },
      },
    });

    if (existingOption) {
      return ApiError.conflict("Une option avec ce nom existe déjà pour ce plat");
    }

    // Validate values
    if (!validatedData.values || validatedData.values.length === 0) {
      return ApiError.badRequest("L'option doit avoir au moins une valeur");
    }

    // Check for duplicate value names
    const valueNames = validatedData.values.map(value => value.name.toLowerCase());
    const uniqueValueNames = new Set(valueNames);
    if (valueNames.length !== uniqueValueNames.size) {
      return ApiError.badRequest("Les noms des valeurs doivent être uniques");
    }

    // Validate max selections
    if (validatedData.maxSelections && validatedData.maxSelections > validatedData.values.length) {
      return ApiError.badRequest("Le nombre maximum de sélections ne peut pas dépasser le nombre de valeurs disponibles");
    }

    // Create option
    const newOption = await prisma.menuItemOption.create({
      data: {
        menuItemId: id,
        name: validatedData.name,
        type: validatedData.type,
        values: validatedData.values,
        isRequired: validatedData.isRequired,
        maxSelections: validatedData.maxSelections,
        sortOrder: validatedData.sortOrder,
      },
    });

    // Format response
    const formattedOption = {
      id: newOption.id,
      name: newOption.name,
      type: newOption.type,
      values: newOption.values,
      isRequired: newOption.isRequired,
      maxSelections: newOption.maxSelections,
      sortOrder: newOption.sortOrder,
      createdAt: newOption.createdAt,
      updatedAt: newOption.updatedAt,
      menuItem: {
        id: menuItem.id,
        name: menuItem.name,
      },
    };

    Logger.info("Option de plat créée avec succès", context, {
      optionId: newOption.id,
      optionName: newOption.name,
      menuItemId: id,
      valuesCount: Array.isArray(newOption.values) ? newOption.values.length.toString() : "0",
    });

    return ApiResponse.created(formattedOption, "Option de plat créée avec succès");
  } catch (error) {
    Logger.error(`Erreur lors de POST /api/menu/items/${id}/options`, error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/menu/items/[id]/options (CORS preflight)
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}