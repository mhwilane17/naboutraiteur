import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Validation schemas
const UpdateMenuItemOptionSchema = z.object({
  name: z.string().min(2).max(200).optional(),
  type: z.string().min(1).max(50).optional(),
  values: z.array(z.object({
    name: z.string().min(1).max(200),
    price: z.number().default(0),
    isAvailable: z.boolean().default(true),
  })).optional(),
  isRequired: z.boolean().optional(),
  maxSelections: z.number().int().min(1).optional(),
  sortOrder: z.number().int().min(0).optional(),
});

// GET /api/menu/items/[id]/options/[optionId]
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; optionId: string }> }
) {
  const { id, optionId } = await params;
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info(`Début de la requête GET /api/menu/items/${id}/options/${optionId}`, context);

    // Check if menu item exists
    const menuItem = await prisma.menuItem.findUnique({
      where: { id },
      select: { id: true, name: true },
    });

    if (!menuItem) {
      return ApiError.notFound("Plat non trouvé");
    }

    // Get option
    const option = await prisma.menuItemOption.findUnique({
      where: {
        id: optionId,
        menuItemId: id,
      },
    });

    if (!option) {
      return ApiError.notFound("Option non trouvée");
    }

    // Format response
    const formattedOption = {
      id: option.id,
      name: option.name,
      type: option.type,
      values: option.values,
      isRequired: option.isRequired,
      maxSelections: option.maxSelections,
      sortOrder: option.sortOrder,
      createdAt: option.createdAt,
      updatedAt: option.updatedAt,
      menuItem: {
        id: menuItem.id,
        name: menuItem.name,
      },
    };

    Logger.info(`Option récupérée avec succès`, context, {
      optionId: option.id,
      menuItemId: id,
    });

    return ApiResponse.success(formattedOption);
  } catch (error) {
    Logger.error(`Erreur lors de GET /api/menu/items/${id}/options/${optionId}`, error as Error, context);
    return ApiError.handle(error);
  }
}

// PUT /api/menu/items/[id]/options/[optionId]
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; optionId: string }> }
) {
  const { id, optionId } = await params;
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info(`Début de la requête PUT /api/menu/items/${id}/options/${optionId}`, context);

    // Authentication
    const user = await requireAuth(request);

    // TODO: Check permission 'menu.update'
    // await requirePermission('menu.update')(request, user);

    context.userId = user.id;

    // Check if menu item exists
    const menuItem = await prisma.menuItem.findUnique({
      where: { id },
      select: { id: true, name: true },
    });

    if (!menuItem) {
      return ApiError.notFound("Plat non trouvé");
    }

    // Check if option exists
    const existingOption = await prisma.menuItemOption.findUnique({
      where: {
        id: optionId,
        menuItemId: id,
      },
    });

    if (!existingOption) {
      return ApiError.notFound("Option non trouvée");
    }

    // Parse and validate request body
    const body = await request.json();
    const validatedData = UpdateMenuItemOptionSchema.parse(body);

    // Check if name is being updated and already exists
    if (validatedData.name) {
      const nameConflict = await prisma.menuItemOption.findFirst({
        where: {
          menuItemId: id,
          name: {
            equals: validatedData.name,
            mode: "insensitive",
          },
          id: {
            not: optionId,
          },
        },
      });

      if (nameConflict) {
        return ApiError.conflict("Une option avec ce nom existe déjà pour ce plat");
      }
    }

    // Validate values if provided
    if (validatedData.values) {
      if (validatedData.values.length === 0) {
        return ApiError.badRequest("L'option doit avoir au moins une valeur");
      }

      // Check for duplicate value names
      const valueNames = validatedData.values.map(value => value.name.toLowerCase());
      const uniqueValueNames = new Set(valueNames);
      if (valueNames.length !== uniqueValueNames.size) {
        return ApiError.badRequest("Les noms des valeurs doivent être uniques");
      }

      // Validate max selections
      const maxSelections = validatedData.maxSelections || existingOption.maxSelections;
      if (maxSelections && maxSelections > validatedData.values.length) {
        return ApiError.badRequest("Le nombre maximum de sélections ne peut pas dépasser le nombre de valeurs disponibles");
      }
    }

    // Update option
    const updatedOption = await prisma.menuItemOption.update({
      where: {
        id: optionId,
        menuItemId: id,
      },
      data: validatedData,
    });

    // Format response
    const formattedOption = {
      id: updatedOption.id,
      name: updatedOption.name,
      type: updatedOption.type,
      values: updatedOption.values,
      isRequired: updatedOption.isRequired,
      maxSelections: updatedOption.maxSelections,
      sortOrder: updatedOption.sortOrder,
      createdAt: updatedOption.createdAt,
      updatedAt: updatedOption.updatedAt,
      menuItem: {
        id: menuItem.id,
        name: menuItem.name,
      },
    };

    Logger.info("Option mise à jour avec succès", context, {
      optionId: updatedOption.id,
      optionName: updatedOption.name,
      menuItemId: id,
    });

    return ApiResponse.success(formattedOption);
  } catch (error) {
    Logger.error(`Erreur lors de PUT /api/menu/items/${id}/options/${optionId}`, error as Error, context);
    return ApiError.handle(error);
  }
}

// DELETE /api/menu/items/[id]/options/[optionId]
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; optionId: string }> }
) {
  const { id, optionId } = await params;
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info(`Début de la requête DELETE /api/menu/items/${id}/options/${optionId}`, context);

    // Authentication
    const user = await requireAuth(request);

    // TODO: Check permission 'menu.delete'
    // await requirePermission('menu.delete')(request, user);

    context.userId = user.id;

    // Check if menu item exists
    const menuItem = await prisma.menuItem.findUnique({
      where: { id },
      select: { id: true, name: true },
    });

    if (!menuItem) {
      return ApiError.notFound("Plat non trouvé");
    }

    // Check if option exists
    const existingOption = await prisma.menuItemOption.findUnique({
      where: {
        id: optionId,
        menuItemId: id,
      },
    });

    if (!existingOption) {
      return ApiError.notFound("Option non trouvée");
    }

    // Delete option
    await prisma.menuItemOption.delete({
      where: {
        id: optionId,
        menuItemId: id,
      },
    });

    Logger.info("Option supprimée avec succès", context, {
      optionId: optionId,
      optionName: existingOption.name,
      menuItemId: id,
    });

    return ApiResponse.success({
      message: "Option supprimée avec succès",
      deletedOption: {
        id: existingOption.id,
        name: existingOption.name,
      },
    });
  } catch (error) {
    Logger.error(`Erreur lors de DELETE /api/menu/items/${id}/options/${optionId}`, error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/menu/items/[id]/options/[optionId] (CORS preflight)
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}