import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Validation schemas
const QuerySchema = z.object({
  page: z.coerce.number().min(1).optional().default(1),
  limit: z.coerce.number().min(1).max(100).optional().default(10),
  search: z.string().nullable().optional(),
  categoryId: z.string().nullable().optional(),
  isAvailable: z.coerce.boolean().optional(),
  isActive: z.coerce.boolean().optional(),
  minPrice: z.coerce.number().min(0).optional(),
  maxPrice: z.coerce.number().min(0).optional(),
  allergens: z.string().nullable().optional(), // Comma-separated list
  sortBy: z
    .enum(["name", "price", "createdAt", "updatedAt", "preparationTime"])
    .nullable()
    .optional()
    .default("name"),
  sortOrder: z.enum(["asc", "desc"]).nullable().optional().default("asc"),
});

const MenuItemOptionValueSchema = z.object({
  name: z.string().min(1).max(100),
  price: z.number().min(0),
  description: z.string().optional(),
});

const MenuItemOptionSchema = z.object({
  name: z.string().min(1).max(100),
  type: z.string().min(1).max(50),
  isRequired: z.boolean().default(false),
  sortOrder: z.number().int().min(0).default(0),
  values: z.array(MenuItemOptionValueSchema).min(1),
});

const CreateMenuItemSchema = z.object({
  name: z.string().min(2).max(200),
  description: z.string().max(1000).optional(),
  price: z.number().min(0),
  image: z.string().url().optional(),
  categoryId: z.string(),
  isAvailable: z.boolean().default(true),
  isActive: z.boolean().default(true),
  preparationTime: z.number().int().min(0).optional(),
  allergens: z.array(z.string()).default([]),
  nutritionalInfo: z.record(z.any()).optional(),
  sortOrder: z.number().int().min(0).default(0),
  options: z.array(MenuItemOptionSchema).optional().default([]),
});

// GET /api/menu/items
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête GET /api/menu/items", context);

    // Parse query parameters
    const { searchParams } = new URL(request.url);
    const query = QuerySchema.parse({
      page: searchParams.get("page"),
      limit: searchParams.get("limit"),
      search: searchParams.get("search"),
      categoryId: searchParams.get("categoryId"),
      isAvailable: searchParams.get("isAvailable"),
      isActive: searchParams.get("isActive"),
      minPrice: searchParams.get("minPrice"),
      maxPrice: searchParams.get("maxPrice"),
      allergens: searchParams.get("allergens"),
      sortBy: searchParams.get("sortBy"),
      sortOrder: searchParams.get("sortOrder"),
    });

    // Build where clause
    const where: any = {};

    // if (query.search) {
    //   where.OR = [
    //     { name: { contains: query.search, mode: "insensitive" } },
    //     { description: { contains: query.search, mode: "insensitive" } },
    //   ];
    // }

    // if (query.categoryId) {
    //   where.categoryId = query.categoryId;
    // }

    // if (query.isAvailable !== undefined) {
    //   where.isAvailable = query.isAvailable;
    // }

    // if (query.isActive !== undefined) {
    //   where.isActive = query.isActive;
    // }

    // if (query.minPrice !== undefined || query.maxPrice !== undefined) {
    //   where.price = {};
    //   if (query.minPrice !== undefined) {
    //     where.price.gte = query.minPrice;
    //   }
    //   if (query.maxPrice !== undefined) {
    //     where.price.lte = query.maxPrice;
    //   }
    // }

    // Build order by clause
    // const orderBy: any = {};
    // const sortBy = query.sortBy || "name";
    // const sortOrder = query.sortOrder || "asc";
    // orderBy[sortBy] = sortOrder;

    // Get menu items with pagination
    const [menuItems, total] = await Promise.all([
      prisma.menuItem.findMany({
        where,
        orderBy: {
          sortOrder: "desc",
        },
        // skip: (query.page - 1) * query.limit,
        // take: query.limit,
        include: {
          category: {
            select: {
              id: true,
              name: true,
              color: true,
              icon: true,
            },
          },
          options: {
            select: {
              id: true,
              name: true,
              type: true,
              values: true,
              isRequired: true,
              sortOrder: true,
            },
            orderBy: {
              sortOrder: "asc",
            },
          },
          reviews: {
            select: {
              rating: true,
            },
          },
        },
      }),
      prisma.menuItem.count({ where }),
    ]);

    // Format response data
    const formattedMenuItems = menuItems.map((item) => {
      const avgRating =
        item.reviews.length > 0
          ? item.reviews.reduce((sum, review) => sum + review.rating, 0) / item.reviews.length
          : 0;

      return {
        id: item.id,
        name: item.name,
        description: item.description,
        price: Number(item.price),
        image: item.image,
        isAvailable: item.isAvailable,
        isActive: item.isActive,
        preparationTime: item.preparationTime,
        allergens: item.allergens,
        nutritionalInfo: item.nutritionalInfo,
        sortOrder: item.sortOrder,
        createdAt: item.createdAt,
        updatedAt: item.updatedAt,
        category: item.category,
        options: item.options,
        stats: {
          reviewCount: item.reviews.length,
          averageRating: Math.round(avgRating * 10) / 10,
          optionsCount: item.options.length,
        },
      };
    });

    Logger.info("Requête GET /api/menu/items terminée avec succès", context, {
      itemsCount: menuItems.length,
      total,
    });

    return ApiResponse.success({
      data: formattedMenuItems,
      pagination: {
        page: query.page,
        limit: query.limit,
        total,
        totalPages: Math.ceil(total / query.limit),
      },
    });
  } catch (error) {
    Logger.error("Erreur lors de GET /api/menu/items", error as Error, context);
    return ApiError.handle(error);
  }
}

// POST /api/menu/items
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête POST /api/menu/items", context);

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check permission 'menu.create'
    // await requirePermission('menu.create')(request, user);

    // context.userId = user.id;

    // Parse and validate request body
    const body = await request.json();
    const validatedData = CreateMenuItemSchema.parse(body);

    // Check if category exists
    const category = await prisma.category.findUnique({
      where: { id: validatedData.categoryId },
    });

    if (!category) {
      return ApiError.badRequest("Catégorie non trouvée");
    }

    // Check if menu item name already exists in the same category
    const existingItem = await prisma.menuItem.findFirst({
      where: {
        name: {
          equals: validatedData.name,
          mode: "insensitive",
        },
        categoryId: validatedData.categoryId,
      },
    });

    if (existingItem) {
      return ApiError.conflict("Un plat avec ce nom existe déjà dans cette catégorie");
    }

    // Separate options from main data
    const { options, ...menuItemData } = validatedData;

    // Create menu item with options in a transaction
    const menuItem = await prisma.$transaction(async (tx) => {
      // Create the menu item first
      const createdMenuItem = await tx.menuItem.create({
        data: menuItemData,
      });

      // Create options if provided
      if (options && options.length > 0) {
        await tx.menuItemOption.createMany({
          data: options.map((option) => ({
            menuItemId: createdMenuItem.id,
            name: option.name,
            type: option.type,
            values: option.values,
            isRequired: option.isRequired,
            sortOrder: option.sortOrder,
          })),
        });
      }

      // Return the created menu item with all relations
      return await tx.menuItem.findUnique({
        where: { id: createdMenuItem.id },
        include: {
          category: {
            select: {
              id: true,
              name: true,
              color: true,
              icon: true,
            },
          },
          options: {
            select: {
              id: true,
              name: true,
              type: true,
              values: true,
              isRequired: true,
              sortOrder: true,
            },
            orderBy: {
              sortOrder: "asc",
            },
          },
        },
      });
    });

    if (!menuItem) {
      return ApiError.internalError("Erreur lors de la création du plat");
    }

    // Format response
    const formattedMenuItem = {
      id: menuItem.id,
      name: menuItem.name,
      description: menuItem.description,
      price: Number(menuItem.price),
      image: menuItem.image,
      isAvailable: menuItem.isAvailable,
      isActive: menuItem.isActive,
      preparationTime: menuItem.preparationTime,
      allergens: menuItem.allergens,
      nutritionalInfo: menuItem.nutritionalInfo,
      sortOrder: menuItem.sortOrder,
      createdAt: menuItem.createdAt,
      updatedAt: menuItem.updatedAt,
      category: menuItem.category,
      options: menuItem.options,
      stats: {
        reviewCount: 0,
        averageRating: 0,
        optionsCount: menuItem.options?.length || 0,
      },
    };

    Logger.info("Plat créé avec succès", context, {
      menuItemId: menuItem.id,
      menuItemName: menuItem.name,
      categoryId: menuItem.categoryId,
    });

    return ApiResponse.created(formattedMenuItem);
  } catch (error) {
    Logger.error("Erreur lors de POST /api/menu/items", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/menu/items (CORS preflight)
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
