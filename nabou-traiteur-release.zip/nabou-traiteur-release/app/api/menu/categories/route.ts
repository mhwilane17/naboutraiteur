import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Validation schemas
const QuerySchema = z.object({
  // page: z.coerce.number().min(1).default(1),
  // limit: z.coerce.number().min(1).max(100).default(10),
  // search: z.string().optional(),
  // isActive: z.coerce.boolean().optional(),
  // sortBy: z.enum(["name", "createdAt", "updatedAt"]).default("name"),
  // sortOrder: z.enum(["asc", "desc"]).default("asc"),
});

const CreateCategorySchema = z.object({
  name: z.string().min(2).max(100),
  description: z.string().max(500).optional(),
  color: z.string().default("blue"),
  icon: z.string().default("utensils"),
  isActive: z.boolean().default(true),
  sortOrder: z.number().int().min(0).default(0),
});

// GET /api/menu/categories
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête GET /api/menu/categories", context);

    // Parse query parameters
    const { searchParams } = new URL(request.url);
    const query = QuerySchema.parse({
      // limit: searchParams.get("limit"),
    });

    // Build where clause
    const where: any = {};

    // Get categories with pagination
    const [categories, total] = await Promise.all([
      prisma.category.findMany({
        where,
        // take: query.limit,
        include: {
          menuItems: {
            select: {
              id: true,
              name: true,
              isActive: true,
            },
          },
        },
      }),
      prisma.category.count({ where }),
    ]);

    // Format response data
    const formattedCategories = categories.map((category) => ({
      id: category.id,
      name: category.name,
      description: category.description,
      color: category.color,
      icon: category.icon,
      isActive: category.isActive,
      sortOrder: category.sortOrder,
      stats: {
        totalMenuItems: category.menuItems.length,
        activeMenuItems: category.menuItems.filter((item) => item.isActive).length,
      },
      createdAt: category.createdAt,
      updatedAt: category.updatedAt,
    }));

    Logger.info("Requête GET /api/menu/categories terminée avec succès", context, {
      categoriesCount: categories.length,
      total,
    });

    return ApiResponse.success(formattedCategories);
  } catch (error) {
    Logger.error("Erreur lors de GET /api/menu/categories", error as Error, context);
    return ApiError.handle(error);
  }
}

// POST /api/menu/categories
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête POST /api/menu/categories", context);

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check permission 'categories.create'
    // await requirePermission('categories.create')(request, user);

    // context.userId = user.id;

    // Parse and validate request body
    const body = await request.json();
    const validatedData = CreateCategorySchema.parse(body);

    // Check if category ID or name already exists
    const existingCategory = await prisma.category.findFirst({
      where: {
        OR: [{ name: { equals: validatedData.name, mode: "insensitive" } }],
      },
    });

    if (existingCategory) {
      return ApiError.conflict("Une catégorie avec cet ID ou ce nom existe déjà");
    }

    // Create category
    const category = await prisma.category.create({
      data: validatedData,
      include: {
        menuItems: {
          select: {
            id: true,
            name: true,
            isActive: true,
          },
        },
      },
    });

    // Format response
    const formattedCategory = {
      id: category.id,
      name: category.name,
      description: category.description,
      color: category.color,
      icon: category.icon,
      isActive: category.isActive,
      sortOrder: category.sortOrder,
      stats: {
        totalMenuItems: category.menuItems.length,
        activeMenuItems: category.menuItems.filter((item) => item.isActive).length,
      },
      createdAt: category.createdAt,
      updatedAt: category.updatedAt,
    };

    Logger.info("Catégorie créée avec succès", context, {
      categoryId: category.id,
      categoryName: category.name,
    });

    return ApiResponse.created(formattedCategory);
  } catch (error) {
    Logger.error("Erreur lors de POST /api/menu/categories", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/menu/categories (CORS preflight)
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
