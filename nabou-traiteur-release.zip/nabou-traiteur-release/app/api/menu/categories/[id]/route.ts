import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Validation schemas
const UpdateCategorySchema = z.object({
  name: z.string().min(2).max(100).optional(),
  description: z.string().max(500).optional(),
  color: z.string().optional(),
  icon: z.string().optional(),
  isActive: z.boolean().optional(),
  sortOrder: z.number().int().min(0).optional(),
});

// GET /api/menu/categories/[id]
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const context = Logger.createContext(request);
  const { id } = await params;

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info(`Début de la requête GET /api/menu/categories/${id}`, context);

    // Get category with menu items
    const category = await prisma.category.findUnique({
      where: { id },
      include: {
        menuItems: {
          select: {
            id: true,
            name: true,
            price: true,
            image: true,
            isAvailable: true,
            isActive: true,
            preparationTime: true,
            createdAt: true,
          },
          orderBy: {
            sortOrder: "asc",
          },
        },
      },
    });

    if (!category) {
      return ApiError.notFound("Catégorie non trouvée");
    }

    // Calculate statistics
    const stats = {
      totalMenuItems: category.menuItems.length,
      activeMenuItems: category.menuItems.filter((item) => item.isActive).length,
      availableMenuItems: category.menuItems.filter((item) => item.isAvailable && item.isActive)
        .length,
      averagePrice:
        category.menuItems.length > 0
          ? category.menuItems.reduce((sum, item) => sum + Number(item.price), 0) /
            category.menuItems.length
          : 0,
    };

    // Format response
    const formattedCategory = {
      id: category.id,
      name: category.name,
      description: category.description,
      color: category.color,
      icon: category.icon,
      isActive: category.isActive,
      sortOrder: category.sortOrder,
      createdAt: category.createdAt,
      updatedAt: category.updatedAt,
      menuItems: category.menuItems,
      stats,
    };

    Logger.info(`Catégorie récupérée avec succès`, context, {
      categoryId: category.id,
      menuItemsCount: category.menuItems.length,
    });

    return ApiResponse.success(formattedCategory);
  } catch (error) {
    Logger.error(`Erreur lors de GET /api/menu/categories/${id}`, error as Error, context);
    return ApiError.handle(error);
  }
}

// PUT /api/menu/categories/[id]
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const context = Logger.createContext(request);
  const { id } = await params;

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info(`Début de la requête PUT /api/menu/categories/${id}`, context);

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check permission 'categories.update'
    // await requirePermission('categories.update')(request, user);

    // context.userId = user.id;

    // Parse and validate request body
    const body = await request.json();
    const validatedData = UpdateCategorySchema.parse(body);

    // Check if category exists
    const existingCategory = await prisma.category.findUnique({
      where: { id },
    });

    if (!existingCategory) {
      return ApiError.notFound("Catégorie non trouvée");
    }

    // Check if name is being updated and already exists
    if (validatedData.name) {
      const nameConflict = await prisma.category.findFirst({
        where: {
          name: {
            equals: validatedData.name,
            mode: "insensitive",
          },
          id: {
            not: id,
          },
        },
      });

      if (nameConflict) {
        return ApiError.conflict("Une catégorie avec ce nom existe déjà");
      }
    }

    // Update category
    const updatedCategory = await prisma.category.update({
      where: { id },
      data: validatedData,
      include: {
        menuItems: {
          select: {
            id: true,
            name: true,
            isActive: true,
          },
        },
      },
    });

    // Format response
    const formattedCategory = {
      id: updatedCategory.id,
      name: updatedCategory.name,
      description: updatedCategory.description,
      color: updatedCategory.color,
      icon: updatedCategory.icon,
      isActive: updatedCategory.isActive,
      sortOrder: updatedCategory.sortOrder,
      createdAt: updatedCategory.createdAt,
      updatedAt: updatedCategory.updatedAt,
      stats: {
        totalMenuItems: updatedCategory.menuItems.length,
        activeMenuItems: updatedCategory.menuItems.filter((item) => item.isActive).length,
      },
    };

    Logger.info("Catégorie mise à jour avec succès", context, {
      categoryId: updatedCategory.id,
      categoryName: updatedCategory.name,
    });

    return ApiResponse.success(formattedCategory);
  } catch (error) {
    Logger.error(`Erreur lors de PUT /api/menu/categories/${id}`, error as Error, context);
    return ApiError.handle(error);
  }
}

// DELETE /api/menu/categories/[id]
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const context = Logger.createContext(request);
  const { id } = await params;

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info(`Début de la requête DELETE /api/menu/categories/${id}`, context);

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check permission 'categories.delete'
    // await requirePermission('categories.delete')(request, user);

    // context.userId = user.id;

    // Check if category exists
    const existingCategory = await prisma.category.findUnique({
      where: { id },
      include: {
        menuItems: {
          select: { id: true },
        },
      },
    });

    if (!existingCategory) {
      return ApiError.notFound("Catégorie non trouvée");
    }

    // Check if category has menu items
    if (existingCategory.menuItems.length > 0) {
      return ApiError.conflict(
        "Impossible de supprimer une catégorie qui contient des plats. Veuillez d'abord supprimer ou déplacer les plats."
      );
    }

    // Delete category
    await prisma.category.delete({
      where: { id },
    });

    Logger.info("Catégorie supprimée avec succès", context, {
      categoryId: id,
      categoryName: existingCategory.name,
    });

    return ApiResponse.success({
      message: "Catégorie supprimée avec succès",
      deletedCategory: {
        id: existingCategory.id,
        name: existingCategory.name,
      },
    });
  } catch (error) {
    Logger.error(
      `Erreur lors de DELETE /api/menu/categories/${id}`,
      error as Error,
      context
    );
    return ApiError.handle(error);
  }
}

// OPTIONS /api/menu/categories/[id] (CORS preflight)
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
