import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiResponse } from "@/lib/api-response";
import { ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// GET /api/menu/categories/public - Récupérer les catégories actives triées par sortOrder
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête GET /api/menu/categories/public", context);

    // Récupérer uniquement les catégories actives, triées par sortOrder
    const categories = await prisma.category.findMany({
      where: {
        isActive: true,
      },
      orderBy: {
        sortOrder: "asc",
      },
      select: {
        id: true,
        name: true,
        description: true,
        color: true,
        icon: true,
        sortOrder: true,
      },
    });

    Logger.info("Requête GET /api/menu/categories/public terminée avec succès", context, {
      categoriesCount: categories.length,
    });

    return ApiResponse.success(categories);
  } catch (error) {
    Logger.error("Erreur lors de GET /api/menu/categories/public", error as Error, context);
    return ApiError.handle(error);
  }
}