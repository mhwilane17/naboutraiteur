import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Validation schemas
const CreateWeeklyMenuSchema = z.object({
  name: z.string().min(2).max(200),
  description: z.string().max(1000).optional(),
  startDate: z.string().datetime(),
  endDate: z.string().datetime(),
  isActive: z.boolean().default(true),
  isPublished: z.boolean().default(false),
  totalPrice: z.number().min(0).optional(),
  dishes: z.array(z.object({
    menuItemId: z.string(),
    dayOfWeek: z.number().int().min(1).max(7),
    mealType: z.enum(["lunch", "dinner"]),
    isAvailable: z.boolean().default(true),
    specialPrice: z.number().min(0).optional(),
    hasRakTakPromo: z.boolean().default(false),
    quantity: z.number().min(1).optional(),
  })).optional(),
});

const WeeklyMenuQuerySchema = z.object({
  page: z.string().transform(Number).pipe(z.number().int().min(1)).default("1"),
  limit: z.string().transform(Number).pipe(z.number().int().min(1).max(100)).default("20"),
  search: z.string().optional(),
  isActive: z.string().transform(val => val === "true").optional(),
  isPublished: z.string().transform(val => val === "true").optional(),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  sortBy: z.enum(["name", "startDate", "endDate", "createdAt"]).default("startDate"),
  sortOrder: z.enum(["asc", "desc"]).default("desc"),
  includeDishes: z.string().transform(val => val === "true").default("true"),
  includeStats: z.string().transform(val => val === "true").default("false"),
});

// GET /api/menu/weekly
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête GET /api/menu/weekly", context);

    // Parse and validate query parameters
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());
    const {
      page,
      limit,
      search,
      isActive,
      isPublished,
      startDate,
      endDate,
      sortBy,
      sortOrder,
      includeDishes,
      includeStats,
    } = WeeklyMenuQuerySchema.parse(queryParams);

    // Build where clause
    const where: any = {};

    if (search) {
      where.OR = [
        {
          name: {
            contains: search,
            mode: "insensitive",
          },
        },
        {
          description: {
            contains: search,
            mode: "insensitive",
          },
        },
      ];
    }

    if (isActive !== undefined) {
      where.isActive = isActive;
    }

    if (isPublished !== undefined) {
      where.isPublished = isPublished;
    }

    if (startDate) {
      where.startDate = {
        gte: new Date(startDate),
      };
    }

    if (endDate) {
      where.endDate = {
        lte: new Date(endDate),
      };
    }

    // Build orderBy clause
    const orderBy: any = {};
    orderBy[sortBy] = sortOrder;

    // Get total count
    const totalCount = await prisma.weeklyMenu.count({ where });

    // Calculate pagination
    const totalPages = Math.ceil(totalCount / limit);
    const skip = (page - 1) * limit;

    // Build include clause
    const include: any = {};
    if (includeDishes) {
      include.dishes = {
        include: {
          menuItem: {
            select: {
              id: true,
              name: true,
              price: true,
              image: true,
              isAvailable: true,
              category: {
                select: {
                  id: true,
                  name: true,
                  color: true,
                  icon: true,
                },
              },
            },
          },
        },
        orderBy: [
          { dayOfWeek: 'asc' },
          { mealType: 'asc' },
        ],
      };
    }
    if (includeStats) {
      include.orders = {
        select: {
          id: true,
          status: true,
          finalAmount: true,
        },
      };
    }

    // Get weekly menus
    const weeklyMenus = await prisma.weeklyMenu.findMany({
      where,
      orderBy,
      skip,
      take: limit,
      include: Object.keys(include).length > 0 ? include : undefined,
    });

    // Format response
    const formattedWeeklyMenus = weeklyMenus.map((menu: any) => {
      const stats = includeStats && menu.orders ? {
        totalOrders: menu.orders.length,
        totalRevenue: menu.orders
          .filter((order: any) => order.status !== 'cancelled')
          .reduce((sum: number, order: any) => sum + Number(order.finalAmount), 0),
        completedOrders: menu.orders.filter((order: any) => order.status === 'delivered').length,
        pendingOrders: menu.orders.filter((order: any) => ['pending', 'confirmed', 'preparing', 'ready'].includes(order.status)).length,
      } : undefined;

      return {
        id: menu.id,
        name: menu.name,
        description: menu.description,
        startDate: menu.startDate,
        endDate: menu.endDate,
        isActive: menu.isActive,
        isPublished: menu.isPublished,
        totalPrice: menu.totalPrice ? Number(menu.totalPrice) : null,
        createdAt: menu.createdAt,
        updatedAt: menu.updatedAt,
        dishes: includeDishes ? menu.dishes?.map((dish: any) => ({
          id: dish.id,
          dayOfWeek: dish.dayOfWeek,
          mealType: dish.mealType,
          isAvailable: dish.isAvailable,
          specialPrice: dish.specialPrice ? Number(dish.specialPrice) : null,
          hasRakTakPromo: dish.hasRakTakPromo,
          quantity: dish.quantity || 10,
          menuItem: {
            id: dish.menuItem.id,
            name: dish.menuItem.name,
            price: Number(dish.menuItem.price),
            image: dish.menuItem.image,
            isAvailable: dish.menuItem.isAvailable,
            category: dish.menuItem.category,
          },
        })) : undefined,
        stats,
      };
    });

    const pagination = {
      page,
      limit,
      totalCount,
      totalPages,
      hasNextPage: page < totalPages,
      hasPreviousPage: page > 1,
    };

    Logger.info("Menus hebdomadaires récupérés avec succès", context, {
      menusCount: weeklyMenus.length,
      totalCount,
    });

    return ApiResponse.success({
      weeklyMenus: formattedWeeklyMenus,
      pagination,
    });
  } catch (error) {
    Logger.error("Erreur lors de GET /api/menu/weekly", error as Error, context);
    return ApiError.handle(error);
  }
}

// POST /api/menu/weekly
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête POST /api/menu/weekly", context);

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check permission 'menu.create'
    // await requirePermission('menu.create')(request, user);

    // context.userId = user.id;

    // Parse and validate request body
    const body = await request.json();
    const validatedData = CreateWeeklyMenuSchema.parse(body);

    // Validate dates
    const startDate = new Date(validatedData.startDate);
    const endDate = new Date(validatedData.endDate);

    if (startDate >= endDate) {
      return ApiError.badRequest("La date de fin doit être postérieure à la date de début");
    }

    // Check for overlapping weekly menus
    const overlappingMenu = await prisma.weeklyMenu.findFirst({
      where: {
        OR: [
          {
            AND: [
              { startDate: { lte: startDate } },
              { endDate: { gte: startDate } },
            ],
          },
          {
            AND: [
              { startDate: { lte: endDate } },
              { endDate: { gte: endDate } },
            ],
          },
          {
            AND: [
              { startDate: { gte: startDate } },
              { endDate: { lte: endDate } },
            ],
          },
        ],
        isActive: true,
      },
    });

    if (overlappingMenu) {
      return ApiError.conflict(
        `Un menu hebdomadaire actif existe déjà pour cette période (${overlappingMenu.name})`
      );
    }

    // Validate dishes if provided
    if (validatedData.dishes && validatedData.dishes.length > 0) {
      // Check if all menu items exist
      const menuItemIds = validatedData.dishes.map(dish => dish.menuItemId);
      const existingMenuItems = await prisma.menuItem.findMany({
        where: {
          id: { in: menuItemIds },
          isActive: true,
        },
        select: { id: true },
      });

      const existingIds = existingMenuItems.map(item => item.id);
      const missingIds = menuItemIds.filter(id => !existingIds.includes(id));

      if (missingIds.length > 0) {
        return ApiError.badRequest(
          `Les plats suivants n'existent pas ou ne sont pas actifs: ${missingIds.join(', ')}`
        );
      }

      // Check for duplicate dishes (same menuItem, day, and mealType)
      const dishKeys = validatedData.dishes.map(dish => 
        `${dish.menuItemId}-${dish.dayOfWeek}-${dish.mealType}`
      );
      const uniqueDishKeys = new Set(dishKeys);
      if (dishKeys.length !== uniqueDishKeys.size) {
        return ApiError.badRequest(
          "Un plat ne peut pas être assigné plusieurs fois au même jour et type de repas"
        );
      }
    }

    // Create weekly menu with dishes
    const newWeeklyMenu = await prisma.weeklyMenu.create({
      data: {
        name: validatedData.name,
        description: validatedData.description,
        startDate,
        endDate,
        isActive: validatedData.isActive,
        isPublished: validatedData.isPublished,
        totalPrice: validatedData.totalPrice,
        dishes: validatedData.dishes ? {
          create: validatedData.dishes.map(dish => ({
            menuItemId: dish.menuItemId,
            dayOfWeek: dish.dayOfWeek,
            mealType: dish.mealType,
            isAvailable: dish.isAvailable,
            specialPrice: dish.specialPrice,
            hasRakTakPromo: dish.hasRakTakPromo,
            quantity: dish.quantity || 10, // Valeur par défaut de 10 si non spécifiée
          })),
        } : undefined,
      },
      include: {
        dishes: {
          include: {
            menuItem: {
              select: {
                id: true,
                name: true,
                price: true,
                image: true,
                category: {
                  select: {
                    id: true,
                    name: true,
                    color: true,
                    icon: true,
                  },
                },
              },
            },
          },
          orderBy: [
            { dayOfWeek: 'asc' },
            { mealType: 'asc' },
          ],
        },
      },
    });

    // Format response
    const formattedWeeklyMenu = {
      id: newWeeklyMenu.id,
      name: newWeeklyMenu.name,
      description: newWeeklyMenu.description,
      startDate: newWeeklyMenu.startDate,
      endDate: newWeeklyMenu.endDate,
      isActive: newWeeklyMenu.isActive,
      isPublished: newWeeklyMenu.isPublished,
      totalPrice: newWeeklyMenu.totalPrice ? Number(newWeeklyMenu.totalPrice) : null,
      createdAt: newWeeklyMenu.createdAt,
      updatedAt: newWeeklyMenu.updatedAt,
      dishes: newWeeklyMenu.dishes?.map(dish => ({
        id: dish.id,
        dayOfWeek: dish.dayOfWeek,
        mealType: dish.mealType,
        isAvailable: dish.isAvailable,
        specialPrice: dish.specialPrice ? Number(dish.specialPrice) : null,
        hasRakTakPromo: dish.hasRakTakPromo,
        quantity: dish.quantity || 10,
        menuItem: {
          id: dish.menuItem.id,
          name: dish.menuItem.name,
          price: Number(dish.menuItem.price),
          image: dish.menuItem.image,
          category: dish.menuItem.category,
        },
      })),
    };

    Logger.info("Menu hebdomadaire créé avec succès", context, {
      weeklyMenuId: newWeeklyMenu.id,
      weeklyMenuName: newWeeklyMenu.name,
      dishesCount: newWeeklyMenu.dishes?.length || 0,
    });

    return ApiResponse.created(formattedWeeklyMenu, "Menu hebdomadaire créé avec succès");
  } catch (error) {
    Logger.error("Erreur lors de POST /api/menu/weekly", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/menu/weekly (CORS preflight)
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}