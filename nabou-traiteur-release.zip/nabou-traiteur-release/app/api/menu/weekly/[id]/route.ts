import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Validation schemas
const WeeklyMenuDishSchema = z
  .object({
    id: z.string().optional(),
    menuItemId: z.string().optional(),
    dayOfWeek: z.number().min(0).max(6),
    mealType: z.enum(["lunch", "dinner"]),
    isAvailable: z.boolean().default(true),
    specialPrice: z.number().min(0).optional().nullable(),
    hasRakTakPromo: z.boolean().default(false),
    quantity: z.number().min(1).optional(),
    menuItem: z
      .object({
        id: z.string(),
        // name: z.string().optional(),
        // description: z.string().optional(),
        // price: z.number().optional(),
        // image: z.string().optional().nullable(),
        isAvailable: z.boolean().optional(),
        // category: z.object({
        //   id: z.string(),
        //   name: z.string(),
        //   color: z.string().optional(),
        //   icon: z.string().optional(),
        // }).optional(),
        // options: z.array(z.any()).optional(),
      })
      .optional(),
  })
  .refine((data) => data.menuItemId || data.menuItem?.id, {
    message: "Either menuItemId or menuItem.id must be provided",
    path: ["menuItemId"],
  });

const UpdateWeeklyMenuSchema = z.object({
  name: z.string().min(2).max(200).optional(),
  description: z.string().max(1000).optional(),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  isActive: z.boolean().optional(),
  isPublished: z.boolean().optional(),
  totalPrice: z.number().min(0).optional(),
  dishes: z.array(WeeklyMenuDishSchema).optional(),
});

// GET /api/menu/weekly/[id]
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const context = Logger.createContext(request);
  const { id } = await params;

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info(`Début de la requête GET /api/menu/weekly/${id}`, context);

    // Get weekly menu with all related data
    const weeklyMenu = await prisma.weeklyMenu.findUnique({
      where: { id },
      include: {
        dishes: {
          include: {
            menuItem: {
              include: {
                category: {
                  select: {
                    id: true,
                    name: true,
                    color: true,
                    icon: true,
                  },
                },
                options: {
                  orderBy: {
                    sortOrder: "asc",
                  },
                },
              },
            },
          },
          orderBy: [{ dayOfWeek: "asc" }, { mealType: "asc" }],
        },
        orders: {
          select: {
            id: true,
            orderNumber: true,
            status: true,
            finalAmount: true,
            createdAt: true,
            customer: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
              },
            },
          },
          orderBy: {
            createdAt: "desc",
          },
        },
      },
    });

    if (!weeklyMenu) {
      return ApiError.notFound("Menu hebdomadaire non trouvé");
    }

    // Calculate statistics
    const totalOrders = weeklyMenu.orders.length;
    const totalRevenue = weeklyMenu.orders
      .filter((order) => order.status !== "cancelled")
      .reduce((sum, order) => sum + Number(order.finalAmount), 0);
    const completedOrders = weeklyMenu.orders.filter(
      (order) => order.status === "delivered"
    ).length;
    const pendingOrders = weeklyMenu.orders.filter((order) =>
      ["pending", "confirmed", "preparing", "ready"].includes(order.status)
    ).length;
    const cancelledOrders = weeklyMenu.orders.filter(
      (order) => order.status === "cancelled"
    ).length;

    // Group dishes by day and meal type
    const dishesByDay: { [key: number]: { lunch?: any[]; dinner?: any[] } } = {};
    weeklyMenu.dishes.forEach((dish) => {
      if (!dishesByDay[dish.dayOfWeek]) {
        dishesByDay[dish.dayOfWeek] = {};
      }
      if (!dishesByDay[dish.dayOfWeek][dish.mealType as "lunch" | "dinner"]) {
        dishesByDay[dish.dayOfWeek][dish.mealType as "lunch" | "dinner"] = [];
      }
      dishesByDay[dish.dayOfWeek][dish.mealType as "lunch" | "dinner"]!.push({
        id: dish.id,
        isAvailable: dish.isAvailable,
        specialPrice: dish.specialPrice ? Number(dish.specialPrice) : null,
        menuItem: {
          id: dish.menuItem.id,
          name: dish.menuItem.name,
          description: dish.menuItem.description,
          price: Number(dish.menuItem.price),
          image: dish.menuItem.image,
          isAvailable: dish.menuItem.isAvailable,
          preparationTime: dish.menuItem.preparationTime,
          allergens: dish.menuItem.allergens,
          nutritionalInfo: dish.menuItem.nutritionalInfo,
          category: dish.menuItem.category,
          options: dish.menuItem.options,
        },
      });
    });

    // Format response
    const formattedWeeklyMenu = {
      id: weeklyMenu.id,
      name: weeklyMenu.name,
      description: weeklyMenu.description,
      startDate: weeklyMenu.startDate,
      endDate: weeklyMenu.endDate,
      isActive: weeklyMenu.isActive,
      isPublished: weeklyMenu.isPublished,
      totalPrice: weeklyMenu.totalPrice ? Number(weeklyMenu.totalPrice) : null,
      createdAt: weeklyMenu.createdAt,
      updatedAt: weeklyMenu.updatedAt,
      dishes: weeklyMenu.dishes.map((dish) => ({
        id: dish.id,
        dayOfWeek: dish.dayOfWeek,
        mealType: dish.mealType,
        isAvailable: dish.isAvailable,
        specialPrice: dish.specialPrice ? Number(dish.specialPrice) : null,
        hasRakTakPromo: dish.hasRakTakPromo || false,
        quantity: dish.quantity || 10,
        menuItem: {
          id: dish.menuItem.id,
          name: dish.menuItem.name,
          description: dish.menuItem.description,
          price: Number(dish.menuItem.price),
          image: dish.menuItem.image,
          isAvailable: dish.menuItem.isAvailable,
          preparationTime: dish.menuItem.preparationTime,
          allergens: dish.menuItem.allergens,
          nutritionalInfo: dish.menuItem.nutritionalInfo,
          category: dish.menuItem.category,
          options: dish.menuItem.options,
        },
      })),
      dishesByDay,
      orders: weeklyMenu.orders.map((order) => ({
        id: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
        finalAmount: Number(order.finalAmount),
        createdAt: order.createdAt,
        customer: order.customer,
      })),
      stats: {
        totalOrders,
        totalRevenue,
        completedOrders,
        pendingOrders,
        cancelledOrders,
        dishesCount: weeklyMenu.dishes.length,
        averageOrderValue: totalOrders > 0 ? totalRevenue / totalOrders : 0,
      },
    };

    Logger.info(`Menu hebdomadaire récupéré avec succès`, context, {
      weeklyMenuId: weeklyMenu.id,
      dishesCount: weeklyMenu.dishes.length,
      ordersCount: weeklyMenu.orders.length,
    });

    return ApiResponse.success(formattedWeeklyMenu);
  } catch (error) {
    Logger.error(`Erreur lors de GET /api/menu/weekly/${id}`, error as Error, context);
    return ApiError.handle(error);
  }
}

// PUT /api/menu/weekly/[id]
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const context = Logger.createContext(request);
  const { id } = await params;

  try {
    // Rate limiting
    await rateLimit(request, "general");


    Logger.info(`Début de la requête PUT /api/menu/weekly/${id}`, context);

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check permission 'menu.update'
    // await requirePermission('menu.update')(request, user);

    // context.userId = user.id;

    // Check if weekly menu exists
    const existingWeeklyMenu = await prisma.weeklyMenu.findUnique({
      where: { id },
      include: {
        orders: {
          select: { id: true, status: true },
        },
      },
    });

    if (!existingWeeklyMenu) {
      return ApiError.notFound("Menu hebdomadaire non trouvé");
    }

    // Check if menu has active orders
    const hasActiveOrders = existingWeeklyMenu.orders.some((order) =>
      ["pending", "confirmed", "preparing", "ready"].includes(order.status)
    );

    // Parse and validate request body
    const body = await request.json();
    const validatedData = UpdateWeeklyMenuSchema.parse(body);

    // Validate dates if provided
    if (validatedData.startDate || validatedData.endDate) {
      const startDate = validatedData.startDate
        ? new Date(validatedData.startDate)
        : existingWeeklyMenu.startDate;
      const endDate = validatedData.endDate
        ? new Date(validatedData.endDate)
        : existingWeeklyMenu.endDate;

      if (startDate >= endDate) {
        return ApiError.badRequest("La date de fin doit être postérieure à la date de début");
      }

      // Check for overlapping weekly menus (excluding current menu)
      const overlappingMenu = await prisma.weeklyMenu.findFirst({
        where: {
          id: { not: id },
          OR: [
            {
              AND: [{ startDate: { lte: startDate } }, { endDate: { gte: startDate } }],
            },
            {
              AND: [{ startDate: { lte: endDate } }, { endDate: { gte: endDate } }],
            },
            {
              AND: [{ startDate: { gte: startDate } }, { endDate: { lte: endDate } }],
            },
          ],
          isActive: true,
        },
      });

      if (overlappingMenu) {
        return ApiError.conflict(
          `Un menu hebdomadaire actif existe déjà pour cette période (${overlappingMenu.name})`
        );
      }
    }

    // Prevent deactivation if there are active orders
    if (validatedData.isActive === false && hasActiveOrders) {
      return ApiError.conflict(
        "Impossible de désactiver un menu hebdomadaire avec des commandes actives"
      );
    }

    // Handle dishes update if provided
    if (validatedData.dishes) {
      // Delete existing dishes for this weekly menu
      await prisma.weeklyMenuDish.deleteMany({
        where: { weeklyMenuId: id },
      });

      // Create new dishes
      if (validatedData.dishes.length > 0) {
        await prisma.weeklyMenuDish.createMany({
          data: validatedData.dishes.map((dish) => ({
            weeklyMenuId: id,
            menuItemId: dish.menuItemId || dish.menuItem?.id || "",
            dayOfWeek: dish.dayOfWeek,
            mealType: dish.mealType,
            isAvailable: dish.isAvailable,
            specialPrice: dish.specialPrice,
            hasRakTakPromo: dish.hasRakTakPromo,
            quantity: dish.quantity || 10, // Valeur par défaut de 10 si non spécifiée
          })),
        });
      }
    }

    // Update weekly menu
    const updatedWeeklyMenu = await prisma.weeklyMenu.update({
      where: { id },
      data: {
        name: validatedData.name,
        description: validatedData.description,
        startDate: validatedData.startDate ? new Date(validatedData.startDate) : undefined,
        endDate: validatedData.endDate ? new Date(validatedData.endDate) : undefined,
        isActive: validatedData.isActive,
        isPublished: validatedData.isPublished,
        totalPrice: validatedData.totalPrice,
      },
      include: {
        dishes: {
          include: {
            menuItem: {
              include: {
                category: {
                  select: {
                    id: true,
                    name: true,
                    color: true,
                    icon: true,
                  },
                },
                options: {
                  orderBy: {
                    sortOrder: "asc",
                  },
                },
              },
            },
          },
          orderBy: [{ dayOfWeek: "asc" }, { mealType: "asc" }],
        },
      },
    });

    // Format response
    const formattedWeeklyMenu = {
      id: updatedWeeklyMenu.id,
      name: updatedWeeklyMenu.name,
      description: updatedWeeklyMenu.description,
      startDate: updatedWeeklyMenu.startDate,
      endDate: updatedWeeklyMenu.endDate,
      isActive: updatedWeeklyMenu.isActive,
      isPublished: updatedWeeklyMenu.isPublished,
      totalPrice: updatedWeeklyMenu.totalPrice ? Number(updatedWeeklyMenu.totalPrice) : null,
      createdAt: updatedWeeklyMenu.createdAt,
      updatedAt: updatedWeeklyMenu.updatedAt,
      dishes: updatedWeeklyMenu.dishes.map((dish) => ({
        id: dish.id,
        dayOfWeek: dish.dayOfWeek,
        mealType: dish.mealType,
        isAvailable: dish.isAvailable,
        specialPrice: dish.specialPrice ? Number(dish.specialPrice) : null,
        hasRakTakPromo: dish.hasRakTakPromo || false,
        quantity: dish.quantity || 10,
        menuItem: {
          id: dish.menuItem.id,
          name: dish.menuItem.name,
          description: dish.menuItem.description,
          price: Number(dish.menuItem.price),
          image: dish.menuItem.image,
          isAvailable: dish.menuItem.isAvailable,
          preparationTime: dish.menuItem.preparationTime,
          allergens: dish.menuItem.allergens,
          nutritionalInfo: dish.menuItem.nutritionalInfo,
          category: dish.menuItem.category,
          options: dish.menuItem.options,
        },
      })),
    };

    Logger.info("Menu hebdomadaire mis à jour avec succès", context, {
      weeklyMenuId: updatedWeeklyMenu.id,
      weeklyMenuName: updatedWeeklyMenu.name,
    });

    return ApiResponse.success(formattedWeeklyMenu);
  } catch (error) {
    Logger.error(`Erreur lors de PUT /api/menu/weekly/${id}`, error as Error, context);
    return ApiError.handle(error);
  }
}

// DELETE /api/menu/weekly/[id]
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const context = Logger.createContext(request);
  const { id } = await params;

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info(`Début de la requête DELETE /api/menu/weekly/${id}`, context);

    // Authentication
    // const user = await requireAuth(request);

    // TODO: Check permission 'menu.delete'
    // await requirePermission('menu.delete')(request, user);

    // context.userId = user.id;

    // Check if weekly menu exists and get related data
    const existingWeeklyMenu = await prisma.weeklyMenu.findUnique({
      where: { id },
      include: {
        orders: {
          select: { id: true, status: true },
        },
        dishes: {
          select: { id: true },
        },
      },
    });

    if (!existingWeeklyMenu) {
      return ApiError.notFound("Menu hebdomadaire non trouvé");
    }

    // Check if menu has any orders
    // if (existingWeeklyMenu.orders.length > 0) {
    //   return ApiError.conflict(
    //     "Impossible de supprimer un menu hebdomadaire qui a des commandes. Vous pouvez le désactiver à la place."
    //   );
    // }

    // Delete weekly menu (this will cascade delete dishes)
    await prisma.weeklyMenu.delete({
      where: { id },
    });

    Logger.info("Menu hebdomadaire supprimé avec succès", context, {
      weeklyMenuId: id,
      weeklyMenuName: existingWeeklyMenu.name,
      dishesCount: existingWeeklyMenu.dishes.length,
    });

    return ApiResponse.success({
      message: "Menu hebdomadaire supprimé avec succès",
      deletedWeeklyMenu: {
        id: existingWeeklyMenu.id,
        name: existingWeeklyMenu.name,
        dishesCount: existingWeeklyMenu.dishes.length,
      },
    });
  } catch (error) {
    Logger.error(`Erreur lors de DELETE /api/menu/weekly/${id}`, error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/menu/weekly/[id] (CORS preflight)
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
