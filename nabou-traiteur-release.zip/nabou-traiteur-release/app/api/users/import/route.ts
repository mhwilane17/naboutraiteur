
import { NextRequest, NextResponse } from "next/server";
import { withDatabase, withTransaction } from "@/lib/db";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { generateStrongPassword, hashPassword } from "@/lib/utils";
import { sendUserCredentialsEmail } from "@/lib/notifications";
import * as XLSX from 'xlsx';

// Force dynamic to allow reading request body
export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de l'import des utilisateurs", context);

    // 1. Récupération du formulaire
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const companyId = formData.get('companyId') as string;

    if (!file) {
      return ApiError.badRequest("Aucun fichier fourni");
    }

    // Validation de l'entreprise si un ID est fourni
    if (companyId) {
      const company = await withDatabase(async (db) => {
        return (db as any).company.findUnique({ where: { id: companyId } });
      });

      if (!company) {
        return ApiError.notFound("Entreprise introuvable");
      }
    }

    // 2. Lecture du fichier Excel
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rows: any[] = XLSX.utils.sheet_to_json(sheet);

    if (!rows || rows.length === 0) {
      return ApiError.badRequest("Le fichier est vide");
    }

    // 3. Récupération du rôle CLIENT
    const clientRole = await withDatabase(async (db) => {
      return db.role.findUnique({
        where: { id: 'CUSTOMER' }
      });
    });

    if (!clientRole) {
      return ApiError.internalError("Rôle client introuvable");
    }

    const results = {
      success: 0,
      failed: 0,
      errors: [] as string[]
    };

    // 4. Traitement des utilisateurs
    for (const [index, row] of rows.entries()) {
      try {
        // Mapping des colonnes
        const firstName = row['PRENOMS'] || row['Prénom'] || row['First Name'];
        const lastName = row['NOMS'] || row['Nom'] || row['Last Name'];
        const email = row['EMAIL'] || row['Email'];
        const phone = row['TELEPHONE'] || row['Téléphone'] || row['Telephone'] || row['Phone'];
        const matricule = row['MATRICULE'] || row['Matricule'];
        const filiale = row['FILIALE'] || row['Filiale'];

        if (!firstName || !lastName || !email) {
          results.failed++;
          results.errors.push(`Ligne ${index + 2}: Données manquantes (Prénom, Nom ou Email)`);
          continue;
        }

        // Nettoyage de l'email
        const cleanEmail = String(email).trim().toLowerCase();

        // Vérification existence
        const existingUser = await withDatabase(async (db) => {
          return db.user.findUnique({ where: { email: cleanEmail } });
        });

        if (existingUser) {
            // Si companyId est fourni, on vérifie/met à jour l'association
            if (companyId) {
                if (existingUser.companyId === companyId) {
                    // Si l'utilisateur est déjà dans la bonne entreprise, on met à jour matricule et filiale si manquant
                    if (!existingUser.matricule && matricule || !existingUser.filiale && filiale) {
                        await withDatabase(async (db) => {
                            return db.user.update({
                                where: { id: existingUser.id },
                                data: { 
                                    matricule: matricule ? String(matricule).trim() : undefined,
                                    filiale: filiale ? String(filiale).trim() : undefined
                                }
                            });
                        });
                        results.success++;
                        continue;
                    }
                    results.failed++;
                    results.errors.push(`Ligne ${index + 2}: L'utilisateur ${cleanEmail} existe déjà dans cette entreprise`);
                    continue;
                } else if (existingUser.companyId) {
                    results.failed++;
                    results.errors.push(`Ligne ${index + 2}: L'utilisateur ${cleanEmail} appartient déjà à une autre entreprise`);
                    continue;
                } else {
                    // On assigne l'entreprise et on met à jour les infos
                    await withDatabase(async (db) => {
                        return db.user.update({
                            where: { id: existingUser.id },
                            data: { 
                                companyId: companyId,
                                matricule: matricule ? String(matricule).trim() : undefined,
                                filiale: filiale ? String(filiale).trim() : undefined
                            }
                        });
                    });
                    results.success++;
                    continue;
                }
            } else {
                // Si pas de companyId, on met à jour les infos si nécessaire
                if (matricule || filiale) {
                     await withDatabase(async (db) => {
                        return db.user.update({
                            where: { id: existingUser.id },
                            data: { 
                                matricule: matricule ? String(matricule).trim() : undefined,
                                filiale: filiale ? String(filiale).trim() : undefined
                            }
                        });
                    });
                    results.success++;
                    continue;
                }
                results.failed++;
                results.errors.push(`Ligne ${index + 2}: L'utilisateur ${cleanEmail} existe déjà`);
                continue;
            }
        }

        // Création du nouvel utilisateur
        const temporaryPassword = generateStrongPassword();
        const passwordHash = await hashPassword(temporaryPassword);

        await withTransaction(async (tx) => {
          const newUser = await tx.user.create({
            data: {
              firstName: String(firstName).trim(),
              lastName: String(lastName).trim(),
              email: cleanEmail,
              phone: phone ? String(phone).trim() : undefined,
              matricule: matricule ? String(matricule).trim() : undefined,
              filiale: filiale ? String(filiale).trim() : undefined,
              passwordHash: passwordHash,
              isActive: true,
              ...(companyId ? { company: { connect: { id: companyId } } } : {})
            }
          });

          await tx.userRole.create({
            data: {
              userId: newUser.id,
              roleId: clientRole.id
            }
          });
        });

        // Envoi email
        try {
          await sendUserCredentialsEmail(
            String(firstName).trim(),
            String(lastName).trim(),
            cleanEmail,
            temporaryPassword
          );
        } catch (emailError) {
          Logger.error(`Erreur envoi email pour ${cleanEmail}`, emailError as Error, context);
        }

        results.success++;

      } catch (err) {
        Logger.error(`Erreur lors de l'import de la ligne ${index + 2}`, err as Error, context);
        results.failed++;
        results.errors.push(`Ligne ${index + 2}: Erreur interne`);
      }
    }

    return ApiResponse.success({
      data: results,
      message: `Import terminé: ${results.success} ajoutés, ${results.failed} échoués`
    });

  } catch (error) {
    Logger.error("Erreur globale lors de l'import", error as Error, context);
    return ApiError.handle(error);
  }
}
