import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { withDatabase, withTransaction } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";

// Schémas de validation
const UpdateUserSchema = z.object({
  firstName: z.string().min(2, "Le prénom doit contenir au moins 2 caractères").max(50).optional(),
  lastName: z.string().min(2, "Le nom doit contenir au moins 2 caractères").max(50).optional(),
  email: z.string().email("Email invalide").optional(),
  phone: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  postalCode: z.string().optional(),
  isActive: z.boolean().optional(),
  roleIds: z.array(z.string()).optional(), // IDs des rôles à assigner
});

const ParamsSchema = z.object({
  id: z.string().cuid("ID utilisateur invalide"),
});

// GET /api/users/[id] - Détails d'un utilisateur
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);
  
  try {
    // Attendre la résolution des paramètres
    const resolvedParams = await params;
    Logger.info("Début de la requête GET /api/users/[id]", context, { userId: resolvedParams.id });

    // 1. Rate limiting
    await rateLimit(request, 'general');

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'users.read'
    // await requirePermission('users.read')(request, user);

    // 3. Validation des paramètres
    const validatedParams = ParamsSchema.parse(resolvedParams);

    // 4. Récupération de l'utilisateur avec gestion des connexions
    const targetUser = await withDatabase(async (db) => {
      return db.user.findUnique({
        where: { id: validatedParams.id },
        include: {
          roles: {
            include: {
              role: {
                select: {
                  id: true,
                  name: true,
                  description: true,
                }
              }
            }
          }
        }
      });
    });

    if (!targetUser) {
      return ApiError.notFound("Utilisateur introuvable");
    }

    // 5. Formatage des données
    const formattedUser = {
      ...targetUser,
      roles: targetUser.roles.map(ur => ur.role)
    };

    Logger.info("Utilisateur récupéré avec succès", context, {
      targetUserId: targetUser.id,
      email: targetUser.email
    });

    // 6. Réponse de succès
    return ApiResponse.success(formattedUser);

  } catch (error) {
    Logger.error("Erreur lors de GET /api/users/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// PUT /api/users/[id] - Modifier un utilisateur
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);
  
  try {
    // Attendre la résolution des paramètres
    const resolvedParams = await params;
    Logger.info("Début de la requête PUT /api/users/[id]", context, { userId: resolvedParams.id });

    // 1. Rate limiting
    await rateLimit(request, 'general');

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'users.update'
    // await requirePermission('users.update')(request, user);

    // 3. Validation des paramètres
    const validatedParams = ParamsSchema.parse(resolvedParams);

    // 4. Validation du body
    const body = await request.json();
    const validatedData = UpdateUserSchema.parse(body);

    // 5. Vérification de l'existence de l'utilisateur avec gestion des connexions
    const existingUser = await withDatabase(async (db) => {
      return db.user.findUnique({
        where: { id: validatedParams.id }
      });
    });

    if (!existingUser) {
      return ApiError.notFound("Utilisateur introuvable");
    }

    // 6. Vérification de l'unicité de l'email si modifié
    if (validatedData.email && validatedData.email !== existingUser.email) {
      const emailExists = await withDatabase(async (db) => {
        return db.user.findUnique({
          where: { email: validatedData.email }
        });
      });

      if (emailExists) {
        return ApiError.conflict("Un utilisateur avec cet email existe déjà");
      }
    }

    // 7. Mise à jour avec transaction et gestion des connexions
    const updatedUser = await withTransaction(async (tx) => {
      // Extraire les données utilisateur (sans roleIds)
      const { roleIds, ...userData } = validatedData;

      // Mettre à jour les données utilisateur
      const user = await tx.user.update({
        where: { id: validatedParams.id },
        data: userData
      });

      // Mettre à jour les rôles si spécifiés
      if (roleIds !== undefined) {
        // Supprimer les anciens rôles
        await tx.userRole.deleteMany({
          where: { userId: validatedParams.id }
        });

        // Ajouter les nouveaux rôles
        if (roleIds.length > 0) {
          await tx.userRole.createMany({
            data: roleIds.map(roleId => ({
              userId: validatedParams.id,
              roleId
            }))
          });
        }
      }

      // Retourner l'utilisateur avec ses rôles
      return await tx.user.findUnique({
        where: { id: validatedParams.id },
        include: {
          roles: {
            include: {
              role: {
                select: {
                  id: true,
                  name: true,
                  description: true,
                }
              }
            }
          }
        }
      });
    });

    // 8. Formatage des données de réponse
    const formattedUser = {
      ...updatedUser!,
      roles: updatedUser!.roles.map(ur => ur.role)
    };

    Logger.info("Utilisateur mis à jour avec succès", context, {
      targetUserId: updatedUser!.id,
      email: updatedUser!.email,
      updatedFields: Object.keys(validatedData)
    });

    // 9. Réponse de succès
    return ApiResponse.success(formattedUser);

  } catch (error) {
    Logger.error("Erreur lors de PUT /api/users/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// DELETE /api/users/[id] - Supprimer un utilisateur
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);
  
  try {
    // Attendre la résolution des paramètres
    const resolvedParams = await params;
    Logger.info("Début de la requête DELETE /api/users/[id]", context, { userId: resolvedParams.id });

    // 1. Rate limiting
    await rateLimit(request, 'general');

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'users.delete'
    // await requirePermission('users.delete')(request, user);

    // 3. Validation des paramètres
    const validatedParams = ParamsSchema.parse(resolvedParams);

    // 4. Vérification de l'existence de l'utilisateur avec gestion des connexions
    const existingUser = await withDatabase(async (db) => {
      return db.user.findUnique({
        where: { id: validatedParams.id },
        include: {
          orders: { select: { id: true } },
          reviews: { select: { id: true } }
        }
      });
    });

    if (!existingUser) {
      return ApiError.notFound("Utilisateur introuvable");
    }

    // 5. Vérification des contraintes métier
    // Empêcher la suppression si l'utilisateur a des commandes ou des avis
    if (existingUser.orders.length > 0) {
      return ApiError.conflict(
        "Impossible de supprimer cet utilisateur car il a des commandes associées"
      );
    }

    if (existingUser.reviews.length > 0) {
      return ApiError.conflict(
        "Impossible de supprimer cet utilisateur car il a des avis associés"
      );
    }

    // 6. Empêcher l'auto-suppression
    // if (user.id === validatedParams.id) {
    //   return ApiError.conflict("Vous ne pouvez pas supprimer votre propre compte");
    // }

    // 7. Suppression avec transaction et gestion des connexions
    await withTransaction(async (tx) => {
      // Supprimer les relations UserRole
      await tx.userRole.deleteMany({
        where: { userId: validatedParams.id }
      });

      // Supprimer l'utilisateur
      await tx.user.delete({
        where: { id: validatedParams.id }
      });
    });

    Logger.info("Utilisateur supprimé avec succès", context, {
      deletedUserId: validatedParams.id,
      deletedEmail: existingUser.email
    });

    // 8. Réponse de succès
    return ApiResponse.success({
      message: "Utilisateur supprimé avec succès",
      deletedId: validatedParams.id
    });

  } catch (error) {
    Logger.error("Erreur lors de DELETE /api/users/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS - Gestion CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}