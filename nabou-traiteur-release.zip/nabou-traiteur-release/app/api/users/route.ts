import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { withDatabase, withTransaction } from "@/lib/db";
import { requireAuth, hasRole } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";
import { generateStrongPassword, hashPassword } from "@/lib/utils";
import { sendUserCredentialsEmail } from "@/lib/notifications";

// Schémas de validation
const CreateUserSchema = z.object({
  firstName: z.string().min(2, "Le prénom doit contenir au moins 2 caractères").max(50),
  lastName: z.string().min(2, "Le nom doit contenir au moins 2 caractères").max(50),
  email: z.string().email("Email invalide"),
  phone: z.string().optional(),
  roleIds: z.array(z.string()).optional(), // IDs des rôles à assigner
  companyId: z.string().optional(),
});

const QuerySchema = z.object({
  page: z.string().nullable().optional().transform(val => val ? parseInt(val, 10) : 1).pipe(z.number().min(1)),
  limit: z.string().nullable().optional().transform(val => val ? parseInt(val, 10) : 10).pipe(z.number().min(1).max(100)),
  search: z.string().nullable().optional(),
  role: z.string().nullable().optional(),
  status: z.string().nullable().optional(),
});

// GET /api/users - Liste des utilisateurs avec pagination
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête GET /api/users", context);

    // 1. Rate limiting
    await rateLimit(request, 'general');

    // 2. Authentification et vérification des permissions
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // TODO: Vérifier la permission 'users.read'
    // await requirePermission('users.read')(request, user);

    // 3. Validation des paramètres de requête
    const { searchParams } = new URL(request.url);
    const query = QuerySchema.parse({
      page: searchParams.get("page"),
      limit: searchParams.get("limit"),
      search: searchParams.get("search"),
      role: searchParams.get("role"),
      status: searchParams.get("status"),
    });

    // 4. Construction des filtres
    const where: any = {
      // Exclure les utilisateurs avec le rôle CUSTOMER
      NOT: {
        roles: {
          some: {
            role: {
              id: "CUSTOMER"
            }
          }
        }
      }
    };

    if (query.search) {
      where.OR = [
        { firstName: { contains: query.search, mode: "insensitive" } },
        { lastName: { contains: query.search, mode: "insensitive" } },
        { email: { contains: query.search, mode: "insensitive" } },
      ];
    }

    if (query.role) {
      where.roles = {
        some: {
          role: {
            OR: [
              { name: { equals: query.role, mode: "insensitive" } },
              { id: { equals: query.role, mode: "insensitive" } }
            ]
          }
        }
      };
    }

    if (query.status) {
      // Gestion des différents statuts
      if (query.status === 'active') {
        where.isActive = true;
      } else if (query.status === 'inactive') {
        where.isActive = false;
      } else if (query.status === 'suspended') {
        // Pour suspended, on peut ajouter une logique spécifique
        // Pour l'instant, on considère que suspended = inactive
        where.isActive = false;
      } else {
        // Si le statut n'est pas reconnu, on retourne une liste vide
        where.id = 'non-existent-id';
      }
    }

    // 5. Récupération des utilisateurs avec gestion des connexions
    const [users, total] = await withDatabase(async (db) => {
      return Promise.all([
        db.user.findMany({
          where,
          skip: (query.page - 1) * query.limit,
          take: query.limit,
          include: {
            roles: {
              include: {
                role: {
                  select: {
                    id: true,
                    name: true,
                    description: true,
                  }
                }
              }
            }
          },
          orderBy: {
            createdAt: 'desc'
          }
        }),
        db.user.count({ where })
      ]);
    });

    // 6. Formatage des données utilisateur
    const formattedUsers = users.map(user => ({
      ...user,
      roles: user.roles.map(ur => ur.role)
    }));

    Logger.info("Requête GET /api/users terminée avec succès", context, {
      userCount: users.length,
      total,
      page: query.page
    });

    // 7. Réponse avec pagination
    return ApiResponse.success({
      data: formattedUsers,
      pagination: {
        page: query.page,
        limit: query.limit,
        total,
        totalPages: Math.ceil(total / query.limit),
      },
    });

  } catch (error) {
    Logger.error("Erreur lors de GET /api/users", error as Error, context);
    return ApiError.handle(error);
  }
}

// POST /api/users - Créer un nouvel utilisateur
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    Logger.info("Début de la requête POST /api/users", context);

    // 1. Rate limiting
    await rateLimit(request, 'general');

    // 2. Authentification et vérification des permissions (Admin/Manager/Super Admin uniquement)
    // const currentUser = await requireAuth(request);
    // const isAllowed = hasRole(currentUser, 'ADMIN') || hasRole(currentUser, 'SUPER_ADMIN') || hasRole(currentUser, 'MANAGER');
    // if (!isAllowed) {
    //   Logger.warn("Accès refusé: tentative de création d'utilisateur sans droits suffisants", {
    //     ...context,
    //     userId: currentUser.id,
    //     roles: currentUser.roles,
    //   });
    //   return ApiError.forbidden("Accès refusé. Permissions administrateur ou manager requises.");
    // }

    // 3. Validation du body
    const body = await request.json();
    const validatedData = CreateUserSchema.parse(body);

    // 4. Vérification de l'unicité de l'email avec gestion des connexions
    const existingUser = await withDatabase(async (db) => {
      return db.user.findUnique({
        where: { email: validatedData.email }
      });
    });

    if (existingUser) {
      return ApiError.conflict("Un utilisateur avec cet email existe déjà");
    }

    // 5. Si un companyId est fourni, vérifier l'existence de l'entreprise
    if (validatedData.companyId) {
      const company = await withDatabase(async (db) => {
        return (db as any).company.findUnique({ where: { id: validatedData.companyId! } });
      });
      if (!company) {
        return ApiError.notFound("Entreprise introuvable");
      }
    }

    // 5. Récupération des rôles par défaut si non spécifiés
    let roleIds = validatedData.roleIds;
    if (!roleIds || roleIds.length === 0) {
      const defaultRole = await withDatabase(async (db) => {
        return db.role.findFirst({
          where: { name: "client" }
        });
      });
      if (defaultRole) {
        roleIds = [defaultRole.id];
      }
    }

    // 6. Génération du mot de passe fort
    const temporaryPassword = generateStrongPassword();
    const passwordHash = await hashPassword(temporaryPassword);

    // 7. Création de l'utilisateur avec transaction et gestion des connexions
    const newUser = await withTransaction(async (tx) => {
      // Créer l'utilisateur avec le mot de passe hashé
      const user = await tx.user.create({
        data: {
          firstName: validatedData.firstName,
          lastName: validatedData.lastName,
          email: validatedData.email,
          phone: validatedData.phone,
          passwordHash: passwordHash,
          ...(validatedData.companyId
            ? { company: { connect: { id: validatedData.companyId } } }
            : {}),
        }
      });

      // Assigner les rôles
      if (roleIds && roleIds.length > 0) {
        await tx.userRole.createMany({
          data: roleIds.map(roleId => ({
            userId: user.id,
            roleId
          }))
        });
      }

      return user;
    });

    // 8. Envoi d'un email avec les identifiants temporaires (si nécessaire)
    await sendUserCredentialsEmail(
      validatedData.firstName,
      validatedData.lastName,
      validatedData.email,
      temporaryPassword
    );

    Logger.info("Utilisateur créé avec succès via POST /api/users", context, { newUserId: newUser.id });

    // 9. Réponse avec succès
    return ApiResponse.success({
      data: {
        id: newUser.id,
        email: newUser.email,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        companyId: validatedData.companyId || null,
      },
      message: "Utilisateur créé avec succès",
    });

  } catch (error) {
    Logger.error("Erreur lors de POST /api/users", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS - Gestion CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}