import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Schéma de validation pour les paramètres de requête
const QuerySchema = z.object({
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  promotionId: z.string().optional(),
  type: z.enum(["percentage", "fixed_amount", "free_delivery"]).optional(),
});

// GET /api/promotions/stats
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête GET /api/promotions/stats", context);

    // Authentification
    const user = await requireAuth(request);
    if (!user) {
      return ApiError.unauthorized("Token invalide");
    }

    Logger.info("Utilisateur authentifié", context, { userId: user.id });

    // Vérification des permissions (admin ou manager)
    const isAdmin = user.roles.includes('ADMIN') || user.roles.includes('SUPER_ADMIN');
    const isManager = user.roles.includes('MANAGER');
    
    if (!isAdmin && !isManager) {
      Logger.warn("Tentative d'accès non autorisé à GET /api/promotions/stats", context, {
        userId: user.id,
        roles: user.roles,
      });
      return ApiError.forbidden("Accès refusé. Permissions administrateur ou manager requises.");
    }

    // Validation des paramètres de requête
    const { searchParams } = new URL(request.url);
    const queryParams = {
      startDate: searchParams.get('startDate') || undefined,
      endDate: searchParams.get('endDate') || undefined,
      promotionId: searchParams.get('promotionId') || undefined,
      type: searchParams.get('type') || undefined,
    };

    const { startDate, endDate, promotionId, type } = QuerySchema.parse(queryParams);

    // Construction des filtres
    const dateFilter: any = {};
    if (startDate) {
      dateFilter.gte = new Date(startDate);
    }
    if (endDate) {
      dateFilter.lte = new Date(endDate);
    }

    const promotionFilter: any = {
      ...(promotionId && { id: promotionId }),
      ...(type && { type }),
    };

    const usageFilter: any = {
      ...(Object.keys(dateFilter).length > 0 && { usedAt: dateFilter }),
      promotion: promotionFilter,
    };

    // Statistiques globales des promotions
    const [totalPromotions, activePromotions, expiredPromotions] = await Promise.all([
      prisma.promotion.count(promotionFilter),
      prisma.promotion.count({
        ...promotionFilter,
        isActive: true,
        endDate: {
          gte: new Date(),
        },
      }),
      prisma.promotion.count({
        ...promotionFilter,
        endDate: {
          lt: new Date(),
        },
      }),
    ]);

    // Statistiques d'utilisation
    const [totalUsages, totalDiscountGiven] = await Promise.all([
      prisma.promotionUsage.count({
        where: usageFilter,
      }),
      prisma.promotionUsage.aggregate({
        where: usageFilter,
        _sum: {
          discountAmount: true,
        },
      }),
    ]);

    // Top 10 des promotions les plus utilisées
    const topPromotions = await prisma.promotion.findMany({
      where: promotionFilter,
      include: {
        _count: {
          select: {
            usage: true,
          },
        },
        usage: {
          where: Object.keys(dateFilter).length > 0 ? {
            usedAt: dateFilter,
          } : undefined,
          select: {
            discountAmount: true,
          },
        },
      },
      orderBy: {
        usage: {
          _count: 'desc',
        },
      },
      take: 10,
    });

    // Formatage des top promotions avec calculs
    const formattedTopPromotions = topPromotions.map(promotion => {
      const filteredUsages = promotion.usage || [];
      const totalDiscountForPromotion = filteredUsages.reduce(
        (sum, usage) => sum + Number(usage.discountAmount),
        0
      );
      
      return {
        id: promotion.id,
        name: promotion.name,
        code: promotion.code,
        type: promotion.type,
        totalUsages: promotion._count.usage,
        filteredUsages: filteredUsages.length,
        totalDiscount: totalDiscountForPromotion,
        isActive: promotion.isActive,
        isExpired: new Date() > new Date(promotion.endDate),
      };
    });

    // Statistiques par type de promotion
    const statsByType = await prisma.promotion.groupBy({
      by: ['type'],
      where: promotionFilter,
      _count: {
        id: true,
      },
    });

    // Statistiques d'utilisation par mois (6 derniers mois)
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const monthlyUsage = await prisma.promotionUsage.groupBy({
      by: ['usedAt'],
      where: {
        ...usageFilter,
        usedAt: {
          gte: startDate ? new Date(startDate) : sixMonthsAgo,
          ...(endDate && { lte: new Date(endDate) }),
        },
      },
      _count: {
        id: true,
      },
      _sum: {
        discountAmount: true,
      },
    });

    // Groupement par mois
    const monthlyStats = monthlyUsage.reduce((acc: any, usage) => {
      const month = new Date(usage.usedAt).toISOString().slice(0, 7); // YYYY-MM
      
      if (!acc[month]) {
        acc[month] = {
          month,
          usageCount: 0,
          totalDiscount: 0,
        };
      }
      
      acc[month].usageCount += usage._count.id;
      acc[month].totalDiscount += Number(usage._sum.discountAmount || 0);
      
      return acc;
    }, {});

    const monthlyStatsArray = Object.values(monthlyStats).sort((a: any, b: any) => 
      a.month.localeCompare(b.month)
    );

    // Calcul du taux de conversion (promotions utilisées vs créées)
    const usedPromotionsCount = await prisma.promotion.count({
      where: {
        ...promotionFilter,
        usage: {
          some: Object.keys(dateFilter).length > 0 ? {
            usedAt: dateFilter,
          } : {},
        },
      },
    });

    const conversionRate = totalPromotions > 0 ? (usedPromotionsCount / totalPromotions) * 100 : 0;

    const stats = {
      overview: {
        totalPromotions,
        activePromotions,
        expiredPromotions,
        totalUsages,
        totalDiscountGiven: Number(totalDiscountGiven._sum.discountAmount || 0),
        conversionRate: Math.round(conversionRate * 100) / 100,
      },
      topPromotions: formattedTopPromotions,
      statsByType,
      monthlyStats: monthlyStatsArray,
      filters: {
        startDate,
        endDate,
        promotionId,
        type,
      },
    };

    Logger.info("Statistiques des promotions récupérées avec succès", context, {
      totalPromotions,
      totalUsages,
      filtersApplied: Object.keys(queryParams).filter(key => queryParams[key as keyof typeof queryParams]),
    });

    return ApiResponse.success(stats);
  } catch (error) {
    Logger.error("Erreur lors de GET /api/promotions/stats", error as Error, context);
    return ApiError.handle(error);
  }
}