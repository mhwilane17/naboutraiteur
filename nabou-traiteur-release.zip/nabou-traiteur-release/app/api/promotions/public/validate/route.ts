import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";
import { verifyGuestToken } from "@/lib/auth";

// Schéma de validation
const ValidatePromotionSchema = z.object({
  code: z.string().min(1, "Code promo requis"),
  orderAmount: z.number().positive("Montant de commande invalide"),
  categoryIds: z.array(z.string()).optional(),
  menuItemIds: z.array(z.string()).optional(),
  items: z
    .array(
      z.object({
        menuItemId: z.string(),
        quantity: z.number().positive(),
        unitPrice: z.number().positive(),
      })
    )
    .optional(),
  guestToken: z.string().optional(),
});

// POST /api/promotions/public/validate
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête POST /api/promotions/validate", context);

    // Validation du body
    const body = await request.json();
    const { code, orderAmount, categoryIds, menuItemIds, items, guestToken } =
      ValidatePromotionSchema.parse(body);

    // Endpoint public: pas d'authentification requise
    // Support facultatif du token invité (pour d'éventuels contrôles par utilisateur)
    let userId: string | null = null;
    // if (guestToken) {
    //   try {
    //     const guestData = await verifyGuestToken(guestToken);
    //     Logger.info("Token invité validé", context, { guestData });
    //     // Optionnel: si le token contient un identifiant utilisateur, on pourrait l'utiliser
    //     // userId = guestData?.userId ?? null;
    //   } catch (error) {
    //     return ApiError.unauthorized("Token invité invalide");
    //   }
    // }

    // Recherche de la promotion par code
    const promotion = await prisma.promotion.findFirst({
      where: {
        code: {
          equals: code,
          mode: "insensitive",
        },
        isActive: true,
        startDate: {
          lte: new Date(),
        },
        endDate: {
          gte: new Date(),
        },
      },
      include: {
        usage: {
          where: userId
            ? {
                userId: userId,
              }
            : undefined,
        },
        _count: {
          select: {
            usage: true,
          },
        },
      },
    });

    if (!promotion) {
      Logger.warn("Code promo invalide ou expiré", context, { code });
      return ApiError.badRequest("Code promo invalide ou expiré");
    }

    // Vérification de la fenêtre horaire si définie (HH:mm comparé à l'heure locale serveur)
    if (promotion.activeStartTime && promotion.activeEndTime) {
      const now = new Date();
      const currentHHMM = now.toTimeString().slice(0, 5); // HH:mm
      if (!(currentHHMM >= promotion.activeStartTime && currentHHMM <= promotion.activeEndTime)) {
        Logger.warn("Promotion hors plage horaire", context, {
          code,
          activeStartTime: promotion.activeStartTime,
          activeEndTime: promotion.activeEndTime,
          current: currentHHMM,
        });
        return ApiError.badRequest("Cette promotion n'est pas active à cette heure");
      }
    }

    // Vérification de la limite d'utilisation globale
    if (promotion.usageLimit && promotion._count.usage >= promotion.usageLimit) {
      Logger.warn("Limite d'utilisation globale atteinte", context, {
        code,
        usageLimit: promotion.usageLimit,
        currentUsage: promotion._count.usage,
      });
      return ApiError.badRequest("Ce code promo a atteint sa limite d'utilisation");
    }

    // Vérification de la limite d'utilisation par utilisateur
    if (userId && promotion.usagePerUser && promotion.usage.length >= promotion.usagePerUser) {
      Logger.warn("Limite d'utilisation par utilisateur atteinte", context, {
        code,
        userId,
        usagePerUser: promotion.usagePerUser,
        userUsage: promotion.usage.length,
      });
      return ApiError.badRequest(
        "Vous avez déjà utilisé ce code promo le nombre maximum de fois autorisé"
      );
    }

    // Vérification du montant minimum de commande
    if (promotion.minOrderAmount && orderAmount < Number(promotion.minOrderAmount)) {
      Logger.warn("Montant minimum non atteint", context, {
        code,
        minOrderAmount: promotion.minOrderAmount,
        orderAmount,
      });
      return ApiError.badRequest(
        `Montant minimum de commande non atteint. Minimum requis: ${promotion.minOrderAmount}€`
      );
    }

    // Vérification du nombre minimum d'articles
    if (promotion.minOrderItem && items) {
      const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
      if (totalItems < promotion.minOrderItem) {
        Logger.warn("Nombre minimum d'articles non atteint", context, {
          code,
          minOrderItem: promotion.minOrderItem,
          totalItems,
        });
        return ApiError.badRequest(
          `Nombre minimum d'articles non atteint. Minimum requis: ${promotion.minOrderItem} article(s)`
        );
      }
    }

    // Vérification de l'applicabilité aux catégories
    if (promotion.applicableCategories.length > 0 && categoryIds) {
      const hasApplicableCategory = categoryIds.some((categoryId) =>
        promotion.applicableCategories.includes(categoryId)
      );

      if (!hasApplicableCategory) {
        Logger.warn("Aucune catégorie applicable trouvée", context, {
          code,
          applicableCategories: promotion.applicableCategories,
          orderCategories: categoryIds,
        });
        return ApiError.badRequest(
          "Ce code promo n'est pas applicable aux articles de votre commande"
        );
      }
    }

    // Vérification de l'applicabilité aux plats
    if (menuItemIds && menuItemIds.length > 0) {
      if (promotion.id === "cmdm6dysg0041i4yqts3j3iie") {
        // Cas spécial RakTak: vérifier que le plat du weekly menu porte le flag hasRakTakPromo
        const countEligible = await prisma.weeklyMenuDish.count({
          where: {
            menuItemId: { in: menuItemIds },
            hasRakTakPromo: true,
          },
        });
        if (countEligible === 0) {
          Logger.warn("RakTak: plat non éligible (hasRakTakPromo=false)", context, {
            code,
            menuItemIds,
          });
          return ApiError.badRequest("Cette promo Rak Tak n'est pas applicable à cet article");
        }
      } else if (promotion.applicableMenuItems.length > 0) {
        const hasApplicableMenuItem = menuItemIds.some((menuItemId) =>
          promotion.applicableMenuItems.includes(menuItemId)
        );

        if (!hasApplicableMenuItem) {
          Logger.warn("Aucun plat applicable trouvé", context, {
            code,
            applicableMenuItems: promotion.applicableMenuItems,
            orderMenuItems: menuItemIds,
          });
          return ApiError.badRequest(
            "Ce code promo n'est pas applicable aux articles de votre commande"
          );
        }
      }
    }

    // Calcul de la réduction
    let discountAmount = 0;

    switch (promotion.type) {
      case "percentage":
        discountAmount = (orderAmount * Number(promotion.value)) / 100;
        break;
      case "fixed_amount":
        discountAmount = Number(promotion.value);
        break;
      case "free_delivery":
        // Pour la livraison gratuite, on retourne une valeur symbolique
        // La logique de livraison gratuite sera gérée côté client
        discountAmount = 0;
        break;
      default:
        return ApiError.badRequest("Type de promotion non supporté");
    }

    // Application de la limite de réduction maximale
    if (promotion.maxDiscountAmount && discountAmount > Number(promotion.maxDiscountAmount)) {
      discountAmount = Number(promotion.maxDiscountAmount);
    }

    // S'assurer que la réduction ne dépasse pas le montant de la commande
    if (discountAmount > orderAmount) {
      discountAmount = orderAmount;
    }

    const validationResult = {
      isValid: true,
      promotion: {
        name: promotion.name,
        description: promotion.description,
        code: promotion.code,
        type: promotion.type,
        value: promotion.value,
      },
      discount: {
        amount: discountAmount,
        type: promotion.type,
        isFreeDelivery: promotion.type === "free_delivery",
      },
      usage: {
        remainingGlobalUsage: promotion.usageLimit
          ? promotion.usageLimit - promotion._count.usage
          : null,
        remainingUserUsage:
          userId && promotion.usagePerUser ? promotion.usagePerUser - promotion.usage.length : null,
      },
    };

    Logger.info("Code promo validé avec succès", context, {
      code,
      discountAmount,
      promotionType: promotion.type,
      userId,
    });

    return ApiResponse.success(validationResult, "Code promo valide");
  } catch (error) {
    Logger.error("Erreur lors de POST /api/promotions/validate", error as Error, context);
    return ApiError.handle(error);
  }
}
