import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Rate limiting sera appliqué directement dans les handlers

// Schémas de validation
const CreatePromotionSchema = z
  .object({
    name: z.string().min(2).max(100),
    description: z.string().optional(),
    code: z
      .string()
      .min(3)
      .max(20)
      .regex(
        /^[A-Z0-9_-]+$/,
        "Le code doit contenir uniquement des lettres majuscules, chiffres, tirets et underscores"
      ),
    type: z.enum(["percentage", "fixed_amount", "free_delivery"]),
    value: z.number().min(0),
    minOrderAmount: z.number().min(0).optional(),
    minOrderItem: z.number().min(0).optional(),
    maxDiscountAmount: z.number().min(0).optional(),
    usageLimit: z.number().int().min(0).optional(),
    usagePerUser: z.number().int().min(0).optional(),
    startDate: z.string().datetime(),
    endDate: z.string().datetime(),
    isActive: z.boolean().default(true),
    applicableCategories: z.array(z.string()).default([]),
    applicableMenuItems: z.array(z.string()).default([]),
    activeStartTime: z
      .string()
      .regex(/^\d{2}:\d{2}$/)
      .optional(),
    activeEndTime: z
      .string()
      .regex(/^\d{2}:\d{2}$/)
      .optional(),
  })
  .refine((data) => new Date(data.endDate) > new Date(data.startDate), {
    message: "La date de fin doit être postérieure à la date de début",
    path: ["endDate"],
  })
  .refine(
    (data) => {
      if (data.activeStartTime && data.activeEndTime) {
        return data.activeEndTime > data.activeStartTime;
      }
      return true;
    },
    { message: "L'heure de fin doit être après l'heure de début", path: ["activeEndTime"] }
  );

const QuerySchema = z.object({
  // page: z.coerce.number().min(1).default(1),
  // limit: z.coerce.number().min(1).max(100).default(10),
  // search: z.string().optional(),
  // type: z.enum(["percentage", "fixed_amount", "free_delivery"]).optional(),
  // isActive: z.coerce.boolean().optional(),
  // includeExpired: z.coerce.boolean().default(false),
});

// GET /api/promotions - Liste des promotions
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    // // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // // Vérification des permissions (admin/manager)
    // const isAdmin = user.roles.includes("ADMIN") || user.roles.includes("SUPER_ADMIN");
    // const isManager = user.roles.includes("MANAGER");

    // if (!isAdmin && !isManager) {
    //   Logger.warn("Tentative d'accès non autorisé aux promotions", {
    //     ...context,
    //     userId: user.id,
    //     userRoles: user.roles,
    //   });
    //   return ApiError.forbidden("Permissions insuffisantes");
    // }

    // Validation des paramètres
    const { searchParams } = new URL(request.url);
    const query = QuerySchema.parse({
      page: searchParams.get("page"),
      limit: searchParams.get("limit"),
      search: searchParams.get("search"),
      type: searchParams.get("type"),
      isActive: searchParams.get("isActive"),
      includeExpired: searchParams.get("includeExpired"),
    });

    Logger.info("Récupération de la liste des promotions", {
      ...context,
      query,
    });

    // Construction des filtres
    const where: any = {};

    // if (query.search) {
    //   where.OR = [
    //     { name: { contains: query.search, mode: "insensitive" } },
    //     { code: { contains: query.search, mode: "insensitive" } },
    //     { description: { contains: query.search, mode: "insensitive" } },
    //   ];
    // }

    // if (query.type) {
    //   where.type = query.type;
    // }

    // if (query.isActive !== undefined) {
    //   where.isActive = query.isActive;
    // }

    // if (!query.includeExpired) {
    //   where.endDate = {
    //     gte: new Date(),
    //   };
    // }

    // Récupération des promotions
    const [promotions, total] = await Promise.all([
      prisma.promotion.findMany({
        where,
        // skip: (query.page - 1) * query.limit,
        // take: query.limit,
        orderBy: [{ isActive: "desc" }, { startDate: "desc" }],
        include: {
          usage: {
            select: {
              id: true,
              discountAmount: true,
              usedAt: true,
            },
          },
          _count: {
            select: {
              usage: true,
            },
          },
        },
      }),
      prisma.promotion.count({ where }),
    ]);

    // Calcul des statistiques d'utilisation
    const promotionsWithStats = promotions.map((promotion) => {
      const totalUsage = promotion._count.usage;
      const totalDiscount = promotion.usage.reduce(
        (sum, usage) => sum + Number(usage.discountAmount),
        0
      );

      return {
        ...promotion,
        stats: {
          totalUsage,
          totalDiscount,
          remainingUsage: promotion.usageLimit ? promotion.usageLimit - totalUsage : null,
        },
        usage: undefined, // Supprimer les détails d'utilisation de la réponse
        _count: undefined,
      };
    });

    Logger.info("Liste des promotions récupérée avec succès", {
      ...context,
      promotionsCount: promotions.length,
      total,
    });

    return ApiResponse.success({
      data: promotionsWithStats,
      pagination: {
        // page: query.page,
        // limit: query.limit,
        total,
        // totalPages: Math.ceil(total / query.limit),
      },
    });
  } catch (error) {
    Logger.error("Erreur lors de la récupération des promotions", error as Error, {
      ...context,
    });
    return ApiError.handle(error);
  }
}

// POST /api/promotions - Créer une promotion
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    // // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // // Vérification des permissions (admin/manager)
    // const isAdmin = user.roles.includes("ADMIN") || user.roles.includes("SUPER_ADMIN");
    // const isManager = user.roles.includes("MANAGER");

    // if (!isAdmin && !isManager) {
    //   Logger.warn("Tentative de création de promotion non autorisée", {
    //     ...context,
    //     userId: user.id,
    //     userRoles: user.roles,
    //   });
    //   return ApiError.forbidden("Permissions insuffisantes");
    // }

    // Validation du body
    const body = await request.json();
    const validatedData = CreatePromotionSchema.parse(body);

    Logger.info("Création d'une nouvelle promotion", {
      ...context,
      promotionCode: validatedData.code,
    });

    // Vérification de l'unicité du code
    const existingPromotion = await prisma.promotion.findUnique({
      where: { code: validatedData.code },
    });

    if (existingPromotion) {
      return ApiError.conflict("Ce code promo existe déjà");
    }

    // Validation des catégories et plats applicables
    if (validatedData.applicableCategories.length > 0) {
      const categories = await prisma.category.findMany({
        where: {
          id: { in: validatedData.applicableCategories },
        },
      });

      if (categories.length !== validatedData.applicableCategories.length) {
        return ApiError.badRequest("Certaines catégories spécifiées n'existent pas");
      }
    }

    if (validatedData.applicableMenuItems.length > 0) {
      const menuItems = await prisma.menuItem.findMany({
        where: {
          id: { in: validatedData.applicableMenuItems },
        },
      });

      if (menuItems.length !== validatedData.applicableMenuItems.length) {
        return ApiError.badRequest("Certains plats spécifiés n'existent pas");
      }
    }

    // Création de la promotion
    const promotion = await prisma.promotion.create({
      data: {
        ...validatedData,
        startDate: new Date(validatedData.startDate),
        endDate: new Date(validatedData.endDate),
        activeStartTime: validatedData.activeStartTime,
        activeEndTime: validatedData.activeEndTime,
      },
      include: {
        _count: {
          select: {
            usage: true,
          },
        },
      },
    });

    Logger.info("Promotion créée avec succès", {
      ...context,
      promotionId: promotion.id,
      promotionCode: promotion.code,
    });

    return ApiResponse.created({
      ...promotion,
      stats: {
        totalUsage: 0,
        totalDiscount: 0,
        remainingUsage: promotion.usageLimit || null,
      },
      _count: undefined,
    });
  } catch (error) {
    Logger.error("Erreur lors de la création de la promotion", error as Error, {
      ...context,
    });
    return ApiError.handle(error);
  }
}
