import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { rateLimit } from "@/lib/rate-limiter";

// Schémas de validation
const UpdatePromotionSchema = z
  .object({
    name: z.string().min(2).max(100).optional(),
    description: z.string().optional(),
    code: z
      .string()
      .min(3)
      .max(20)
      .regex(
        /^[A-Z0-9_-]+$/,
        "Le code doit contenir uniquement des lettres majuscules, chiffres, tirets et underscores"
      )
      .optional(),
    type: z.enum(["percentage", "fixed_amount", "free_delivery"]).optional(),
    value: z.number().min(0).optional(),
    minOrderAmount: z.number().min(0).optional(),
    minOrderItem: z.number().min(0).optional(),
    maxDiscountAmount: z.number().min(0).optional(),
    usageLimit: z.number().int().min(0).optional(),
    usagePerUser: z.number().int().min(0).optional(),
    startDate: z.string().datetime().optional(),
    endDate: z.string().datetime().optional(),
    isActive: z.boolean().optional(),
    applicableCategories: z.array(z.string()).optional(),
    applicableMenuItems: z.array(z.string()).optional(),
    activeStartTime: z
      .string()
      .regex(/^\d{2}:\d{2}$/)
      .optional(),
    activeEndTime: z
      .string()
      .regex(/^\d{2}:\d{2}$/)
      .optional(),
  })
  .refine(
    (data) => {
      if (data.startDate && data.endDate) {
        return new Date(data.endDate) > new Date(data.startDate);
      }
      return true;
    },
    {
      message: "La date de fin doit être postérieure à la date de début",
      path: ["endDate"],
    }
  )
  .refine(
    (data) => {
      if (data.activeStartTime && data.activeEndTime) {
        return data.activeEndTime > data.activeStartTime;
      }
      return true;
    },
    { message: "L'heure de fin doit être après l'heure de début", path: ["activeEndTime"] }
  );

const ParamsSchema = z.object({
  id: z.string().min(1, "ID de promotion requis"),
});

// GET /api/promotions/[id]
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête GET /api/promotions/[id]", context);

    // Validation des paramètres
    const resolvedParams = await params;
    const { id } = ParamsSchema.parse(resolvedParams);

    // Récupération de la promotion
    const promotion = await prisma.promotion.findUnique({
      where: { id },
      include: {
        usage: {
          select: {
            id: true,
            discountAmount: true,
            usedAt: true,
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
              },
            },
            order: {
              select: {
                id: true,
                orderNumber: true,
                totalAmount: true,
              },
            },
          },
          orderBy: {
            usedAt: "desc",
          },
        },
        _count: {
          select: {
            usage: true,
          },
        },
      },
    });

    if (!promotion) {
      return ApiError.notFound("Promotion non trouvée");
    }

    // Calcul des statistiques
    const totalUsages = promotion._count?.usage || 0;
    const totalDiscountGiven =
      promotion.usage?.reduce((sum: number, usage: any) => sum + Number(usage.discountAmount), 0) ||
      0;

    const promotionWithStats = {
      ...promotion,
      statistics: {
        totalUsages,
        totalDiscountGiven,
        remainingUsages: promotion.usageLimit ? promotion.usageLimit - totalUsages : null,
        isExpired: new Date() > new Date(promotion.endDate),
        isActive: promotion.isActive && new Date() <= new Date(promotion.endDate),
      },
    };

    Logger.info("Requête GET /api/promotions/[id] terminée avec succès", context, {
      promotionId: id,
      totalUsages,
    });

    return ApiResponse.success(promotionWithStats);
  } catch (error) {
    Logger.error("Erreur lors de GET /api/promotions/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// PUT /api/promotions/[id]
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête PUT /api/promotions/[id]", context);

    // // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    Logger.info("Utilisateur authentifié", context);

    // // Vérification des permissions (admin ou manager)
    // const isAdmin = user.roles.includes('ADMIN') || user.roles.includes('SUPER_ADMIN');
    // const isManager = user.roles.includes('MANAGER');

    // if (!isAdmin && !isManager) {
    //   Logger.warn("Tentative d'accès non autorisé à PUT /api/promotions/[id]", context, {
    //     userId: user.id,
    //     roles: user.roles,
    //   });
    //   return ApiError.forbidden("Accès refusé. Permissions administrateur ou manager requises.");
    // }

    // Validation des paramètres
    const resolvedParams = await params;
    const { id } = ParamsSchema.parse(resolvedParams);

    // Validation du body
    const body = await request.json();

    const validatedData = UpdatePromotionSchema.parse(body);

    // Vérification que la promotion existe
    const existingPromotion = await prisma.promotion.findUnique({
      where: { id },
    });

    if (!existingPromotion) {
      return ApiError.notFound("Promotion non trouvée");
    }

    // Vérification de l'unicité du code si modifié
    if (validatedData.code && validatedData.code !== existingPromotion.code) {
      const codeExists = await prisma.promotion.findFirst({
        where: {
          code: {
            equals: validatedData.code,
            mode: "insensitive",
          },
          id: {
            not: id,
          },
        },
      });

      if (codeExists) {
        return ApiError.conflict("Une promotion avec ce code existe déjà");
      }
    }

    // Validation des catégories applicables si fournies
    if (validatedData.applicableCategories && validatedData.applicableCategories.length > 0) {
      const categoriesCount = await prisma.category.count({
        where: {
          id: {
            in: validatedData.applicableCategories,
          },
        },
      });

      if (categoriesCount !== validatedData.applicableCategories.length) {
        return ApiError.badRequest("Une ou plusieurs catégories spécifiées n'existent pas");
      }
    }

    // Validation des plats applicables si fournis
    if (validatedData.applicableMenuItems && validatedData.applicableMenuItems.length > 0) {
      const menuItemsCount = await prisma.menuItem.count({
        where: {
          id: {
            in: validatedData.applicableMenuItems,
          },
        },
      });

      if (menuItemsCount !== validatedData.applicableMenuItems.length) {
        return ApiError.badRequest("Un ou plusieurs plats spécifiés n'existent pas");
      }
    }

    // Mise à jour de la promotion
    const updatedPromotion = await prisma.promotion.update({
      where: { id },
      data: {
        ...validatedData,
        startDate: validatedData.startDate ? new Date(validatedData.startDate) : undefined,
        endDate: validatedData.endDate ? new Date(validatedData.endDate) : undefined,
        applicableCategories: validatedData.applicableCategories,
        applicableMenuItems: validatedData.applicableMenuItems,
        activeStartTime: validatedData.activeStartTime,
        activeEndTime: validatedData.activeEndTime,
      },
      include: {
        _count: {
          select: {
            usage: true,
          },
        },
      },
    });

    Logger.info("Promotion mise à jour avec succès", context, {
      promotionId: id,
      updatedFields: Object.keys(validatedData),
    });

    return ApiResponse.success(updatedPromotion, "Promotion mise à jour avec succès");
  } catch (error) {
    Logger.error("Erreur lors de PUT /api/promotions/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// DELETE /api/promotions/[id]
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting
    await rateLimit(request, "general");

    Logger.info("Début de la requête DELETE /api/promotions/[id]", context);

    // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    Logger.info("Utilisateur authentifié", context);

    // // Vérification des permissions (admin seulement)
    // const isAdmin = user.roles.includes('ADMIN') || user.roles.includes('SUPER_ADMIN');

    // if (!isAdmin) {
    //   Logger.warn("Tentative d'accès non autorisé à DELETE /api/promotions/[id]", context, {
    //     userId: user.id,
    //     roles: user.roles,
    //   });
    //   return ApiError.forbidden("Accès refusé. Permissions administrateur requises.");
    // }

    // Validation des paramètres
    const resolvedParams = await params;
    const { id } = ParamsSchema.parse(resolvedParams);

    // Vérification que la promotion existe
    const existingPromotion = await prisma.promotion.findUnique({
      where: { id },
      include: {
        _count: {
          select: {
            usage: true,
          },
        },
      },
    });

    if (!existingPromotion) {
      return ApiError.notFound("Promotion non trouvée");
    }

    // Vérification si la promotion a été utilisée
    if (existingPromotion._count.usage > 0) {
      Logger.warn("Tentative de suppression d'une promotion utilisée", context, {
        promotionId: id,
        usageCount: existingPromotion._count.usage,
      });
      return ApiError.badRequest(
        "Impossible de supprimer une promotion qui a déjà été utilisée. Vous pouvez la désactiver à la place."
      );
    }

    // Suppression de la promotion
    await prisma.promotion.delete({
      where: { id },
    });

    Logger.info("Promotion supprimée avec succès", context, {
      promotionId: id,
      promotionCode: existingPromotion.code,
    });

    return ApiResponse.success(null, "Promotion supprimée avec succès");
  } catch (error) {
    Logger.error("Erreur lors de DELETE /api/promotions/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}
