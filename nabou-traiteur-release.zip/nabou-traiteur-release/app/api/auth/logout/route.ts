import { NextRequest, NextResponse } from 'next/server'
import { ApiResponse, ApiError } from '@/lib/api-response'
import { Logger } from '@/lib/logger'
import { requireAuth } from '@/lib/auth'

/**
 * POST /api/auth/logout
 * Déconnecte un utilisateur et invalide ses tokens
 */
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request)
  
  try {
    // Vérification de l'authentification
    const user = await requireAuth(request)
    
    Logger.apiRequest('POST', '/api/auth/logout', context)
    
    // Note: Pour l'instant, nous n'avons pas de table RefreshToken dans le schéma
    // Le logout se contente de supprimer le cookie côté client
    // TODO: Implémenter une blacklist des tokens ou une table RefreshToken
    
    // Optionnel : Ajouter le token à une blacklist (pour une sécurité renforcée)
    // Cette partie peut être implémentée plus tard avec Redis ou une table dédiée
    
    Logger.auth('User logout successful', user.id, true, {
      email: user.email
    })
    
    const response = ApiResponse.success(null, 'Déconnexion réussie')
    
    // Suppression du cookie refresh token
    const nextResponse = NextResponse.json(response)
    nextResponse.cookies.delete('refreshToken')
    
    return nextResponse
    
  } catch (error) {
    Logger.apiError('POST', '/api/auth/logout', error as Error, context)
    return ApiError.handle(error)
  }
}

/**
 * OPTIONS /api/auth/logout
 * Gestion des requêtes CORS preflight
 */
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  })
}