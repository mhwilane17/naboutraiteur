import { NextRequest, NextResponse } from 'next/server'
import { ApiResponse, ApiError } from '../../../../lib/api-response'
import { Logger } from '../../../../lib/logger'
import { verifyUserToken, verifyGuestToken, getUserWithPermissions } from '../../../../lib/auth'
import { rateLimit } from '../../../../lib/rate-limiter'

/**
 * POST /api/auth/verify
 * Vérifie la validité d'un token (utilisateur ou invité)
 */
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request)
  
  try {
    // Rate limiting général
    await rateLimit(request, 'general')
    
    Logger.apiRequest('POST', '/api/auth/verify', context)
    
    // Récupération du token depuis le body ou l'header
    const body = await request.json().catch(() => ({}))
    const { token: bodyToken, type } = body
    
    const authHeader = request.headers.get('authorization')
    const headerToken = authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : null
    
    const token = bodyToken || headerToken
    
    if (!token) {
      throw ApiError.badRequest('Token requis')
    }
    
    let responseData: any
    
    // Vérification selon le type spécifié ou détection automatique
    if (type === 'guest') {
      // Vérification d'un token invité
      const guestPayload = await verifyGuestToken(token)
      responseData = {
        valid: true,
        type: 'guest',
        payload: guestPayload
      }
      
      Logger.auth('Guest token verified successfully', '', true, {
        sessionId: guestPayload.sessionId
      })
    } else {
      // Vérification d'un token utilisateur (par défaut)
      try {
        const userPayload = await verifyUserToken(token)
        
        // Récupération des informations utilisateur à jour
        const user = await getUserWithPermissions(userPayload.userId)
        if (!user) {
          throw ApiError.unauthorized('Utilisateur non trouvé')
        }
        
        responseData = {
          valid: true,
          type: 'user',
          payload: userPayload,
          user: {
            id: user.id,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            roles: user.roles,
            permissions: user.permissions
          }
        }
        
        Logger.auth('User token verified successfully', user.id, true, {
          email: user.email,
          roles: user.roles
        })
      } catch (userError) {
        // Si la vérification utilisateur échoue, essayer en tant qu'invité
        if (!type) {
          try {
            const guestPayload = await verifyGuestToken(token)
            responseData = {
              valid: true,
              type: 'guest',
              payload: guestPayload
            }
            
            Logger.auth('Guest token verified successfully (fallback)', '', true, {
              sessionId: guestPayload.sessionId
            })
          } catch (guestError) {
            throw userError // Retourner l'erreur utilisateur originale
          }
        } else {
          throw userError
        }
      }
    }
    
    return NextResponse.json(ApiResponse.success(responseData, 'Token vérifié avec succès'))
    
  } catch (error) {
    Logger.apiError('POST', '/api/auth/verify', error as Error, context)
    return ApiError.handle(error)
  }
}

/**
 * OPTIONS /api/auth/verify
 * Gestion des requêtes CORS preflight
 */
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  })
}