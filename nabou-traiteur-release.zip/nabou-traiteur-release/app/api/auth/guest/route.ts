import { NextRequest, NextResponse } from 'next/server'
import { ApiResponse, ApiError } from '../../../../lib/api-response'
import { Logger } from '../../../../lib/logger'
import { generateGuestToken } from '../../../../lib/auth'
import { rateLimit } from '../../../../lib/rate-limiter'

/**
 * POST /api/auth/guest
 * Génère un token pour un utilisateur invité (non connecté)
 */
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request)
  
  try {
    // Rate limiting général
    await rateLimit(request, 'general')
    
    Logger.apiRequest('POST', '/api/auth/guest', context)
    
    // Récupération des informations optionnelles de l'invité
    const body = await request.json().catch(() => ({}))
    const { sessionId, deviceInfo } = body
    
    // Génération du token invité
    const sessionIdToUse = sessionId || crypto.randomUUID()
    const guestToken = await generateGuestToken(sessionIdToUse)
    
    // Préparation de la réponse
    const responseData = {
      guestToken,
      expiresIn: 3600, // 1 heure en secondes
      sessionId: sessionIdToUse
    }
    
    Logger.auth('Guest token generated successfully', '', true, {
      sessionId: sessionIdToUse
    })
    
    return NextResponse.json(ApiResponse.success(responseData, 'Token invité généré avec succès'))
    
  } catch (error) {
    Logger.apiError('POST', '/api/auth/guest', error as Error, context)
    return ApiError.handle(error)
  }
}

/**
 * OPTIONS /api/auth/guest
 * Gestion des requêtes CORS preflight
 */
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  })
}