import { NextRequest, NextResponse } from 'next/server'
import { ApiResponse, ApiError } from '../../../../lib/api-response'
import { Logger } from '../../../../lib/logger'
import { verifyRefreshToken, generateUserToken, getUserWithPermissions } from '../../../../lib/auth'
import { rateLimitAuth } from '../../../../lib/rate-limiter'

/**
 * POST /api/auth/refresh
 * Renouvelle un token d'accès à partir d'un refresh token
 */
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request)
  
  try {
    // Rate limiting pour l'authentification
    await rateLimitAuth(request)
    
    Logger.apiRequest('POST', '/api/auth/refresh', context)
    
    // Récupération du refresh token depuis le cookie ou le body
    let refreshToken = request.cookies.get('refreshToken')?.value
    
    if (!refreshToken) {
      const body = await request.json().catch(() => ({}))
      refreshToken = body.refreshToken
    }
    
    if (!refreshToken) {
      Logger.auth('Refresh token missing', '', false)
      throw ApiError.unauthorized('Refresh token requis')
    }
    
    // Vérification du refresh token
    const payload = await verifyRefreshToken(refreshToken)
    
    // Récupération des informations utilisateur à jour
    const user = await getUserWithPermissions(payload.userId)
    if (!user) {
      Logger.auth('User not found during refresh', payload.userId, false)
      throw ApiError.unauthorized('Utilisateur non trouvé')
    }
    
    // Génération d'un nouveau token d'accès
    const newAccessToken = await generateUserToken(user)
    
    // Préparation de la réponse
    const responseData = {
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        roles: user.roles,
        permissions: user.permissions
      },
      tokens: {
        accessToken: newAccessToken,
        expiresIn: 900 // 15 minutes en secondes
      }
    }
    
    Logger.auth('Token refresh successful', user.id, true, {
      email: user.email
    })
    
    return NextResponse.json(ApiResponse.success(responseData, 'Token renouvelé avec succès'))
    
  } catch (error) {
    Logger.apiError('POST', '/api/auth/refresh', error as Error, context)
    return ApiError.handle(error)
  }
}

/**
 * OPTIONS /api/auth/refresh
 * Gestion des requêtes CORS preflight
 */
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  })
}