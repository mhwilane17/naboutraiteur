import { NextRequest, NextResponse } from 'next/server'
import { ApiResponse, ApiError } from '../../../../lib/api-response'
import { Logger } from '../../../../lib/logger'
import { requireAuth } from '../../../../lib/auth'

/**
 * GET /api/auth/me
 * Récupère les informations du profil utilisateur connecté
 */
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request)
  
  try {
    // Vérification de l'authentification
    const user = await requireAuth(request)
    
    Logger.apiRequest('GET', '/api/auth/me', context)
    
    // Préparation de la réponse avec les informations utilisateur
    const responseData = {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      roles: user.roles,
      permissions: user.permissions
    }
    
    Logger.auth('Profile retrieved successfully', user.id, true)
    
    return NextResponse.json(ApiResponse.success(responseData, 'Profil récupéré avec succès'))
    
  } catch (error) {
    Logger.apiError('GET', '/api/auth/me', error as Error, context)
    return ApiError.handle(error)
  }
}

/**
 * OPTIONS /api/auth/me
 * Gestion des requêtes CORS preflight
 */
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  })
}