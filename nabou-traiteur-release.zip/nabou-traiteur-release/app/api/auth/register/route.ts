import { NextRequest, NextResponse } from 'next/server'
import { ApiResponse, ApiError } from '../../../../lib/api-response'
import { Logger } from '../../../../lib/logger'
import { RegisterSchema } from '../../../../lib/validations/auth'
import { hashPassword, generateUserToken, generateRefreshToken } from '../../../../lib/auth'
import { rateLimitAuth } from '../../../../lib/rate-limiter'
import { prisma } from '../../../../lib/prisma'

/**
 * POST /api/auth/register
 * Enregistre un nouveau utilisateur
 */
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request)
  
  try {
    // Rate limiting pour l'authentification
    await rateLimitAuth(request)
    
    // Validation des données d'entrée
    const body = await request.json()
    const validatedData = RegisterSchema.parse(body)
    
    Logger.apiRequest('POST', '/api/auth/register', context)
    
    // Vérification si l'utilisateur existe déjà
    const existingUser = await prisma.user.findUnique({
      where: { email: validatedData.email }
    })
    
    if (existingUser) {
      Logger.auth('Registration failed - user already exists', '', false, {
        email: validatedData.email
      })
      throw ApiError.conflict('Un utilisateur avec cet email existe déjà')
    }
    
    // TODO: Ajouter le champ password au modèle User
    // const hashedPassword = await hashPassword(validatedData.password)
    
    // Séparation du nom complet en prénom et nom
    const nameParts = validatedData.name.split(' ')
    const firstName = nameParts[0] || ''
    const lastName = nameParts.slice(1).join(' ') || ''
    
    // Création de l'utilisateur
    const newUser = await prisma.user.create({
      data: {
        email: validatedData.email,
        firstName,
        lastName,
        phone: validatedData.phone,
        isActive: true
        // password: hashedPassword // TODO: Ajouter quand le champ sera disponible
      }
    })
    
    // Attribution du rôle CUSTOMER par défaut
    await prisma.userRole.create({
      data: {
        userId: newUser.id,
        roleId: 'CUSTOMER'
      }
    })
    
    Logger.database('CREATE', 'users', context, undefined)
    Logger.database('CREATE', 'user_roles', context, undefined)
    
    // Récupération de l'utilisateur avec ses rôles et permissions
    const userWithRoles = await prisma.user.findUnique({
      where: { id: newUser.id },
      include: {
        roles: {
          include: {
            role: {
              include: {
                permissions: {
                  include: {
                    permission: true
                  }
                }
              }
            }
          }
        }
      }
    })
    
    if (!userWithRoles) {
      throw ApiError.internalError('Erreur lors de la création de l\'utilisateur')
    }
    
    // Collecter tous les rôles et permissions
    const roles = userWithRoles.roles.map((ur: any) => ur.role.id) as string[]
    const permissions = userWithRoles.roles.flatMap((ur: any) => 
      ur.role.permissions.map((rp: any) => rp.permission.id)
    ) as string[]
    const uniquePermissions = [...new Set(permissions)]
    
    const authenticatedUser = {
      id: userWithRoles.id,
      email: userWithRoles.email,
      firstName: userWithRoles.firstName,
      lastName: userWithRoles.lastName,
      roles,
      permissions: uniquePermissions
    }
    
    // Génération des tokens
    const accessToken = await generateUserToken(authenticatedUser)
    const refreshToken = await generateRefreshToken(newUser.id)
    
    // Préparation de la réponse
    const responseData = {
      user: {
        id: authenticatedUser.id,
        email: authenticatedUser.email,
        firstName: authenticatedUser.firstName,
        lastName: authenticatedUser.lastName,
        roles: authenticatedUser.roles,
        permissions: authenticatedUser.permissions
      },
      tokens: {
        accessToken,
        refreshToken,
        expiresIn: 900 // 15 minutes en secondes
      }
    }
    
    Logger.auth('User registration successful', newUser.id, true, {
      email: newUser.email,
      roles: authenticatedUser.roles
    })
    
    const response = ApiResponse.created(responseData, 'Inscription réussie')
    
    // Configuration du cookie refresh token
    const nextResponse = NextResponse.json(response)
    nextResponse.cookies.set('refreshToken', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60, // 7 jours
      path: '/'
    })
    
    return nextResponse
    
  } catch (error) {
    Logger.apiError('POST', '/api/auth/register', error as Error, context)
    return ApiError.handle(error)
  }
}

/**
 * OPTIONS /api/auth/register
 * Gestion des requêtes CORS preflight
 */
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  })
}