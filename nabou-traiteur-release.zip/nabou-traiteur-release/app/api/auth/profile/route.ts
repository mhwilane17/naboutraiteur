import { NextRequest, NextResponse } from 'next/server'
import { ApiResponse, ApiError } from '../../../../lib/api-response'
import { Logger } from '../../../../lib/logger'
import { UpdateProfileSchema } from '../../../../lib/validations/auth'
import { requireAuth, authenticateUser, hashPassword } from '../../../../lib/auth'
import { rateLimit } from '../../../../lib/rate-limiter'
import { prisma } from '../../../../lib/prisma'

/**
 * PUT /api/auth/profile
 * Met à jour le profil de l'utilisateur connecté
 */
export async function PUT(request: NextRequest) {
  const context = Logger.createContext(request)
  
  try {
    // Vérification de l'authentification
    const user = await requireAuth(request)
    
    // Rate limiting général
    await rateLimit(request, 'general')
    
    // Validation des données d'entrée
    const body = await request.json()
    const validatedData = UpdateProfileSchema.parse(body)
    
    Logger.apiRequest('PUT', '/api/auth/profile', context)
    
    // Préparation des données à mettre à jour
    const updateData: any = {}
    
    if (validatedData.name) {
      // Séparation du nom complet en prénom et nom
      const nameParts = validatedData.name.split(' ')
      updateData.firstName = nameParts[0] || ''
      updateData.lastName = nameParts.slice(1).join(' ') || ''
    }
    
    if (validatedData.phone !== undefined) {
      updateData.phone = validatedData.phone
    }
    
    // Gestion du changement de mot de passe
    if (validatedData.newPassword && validatedData.currentPassword) {
      // Vérification du mot de passe actuel
      try {
        await authenticateUser(user.email, validatedData.currentPassword)
      } catch (error) {
        throw ApiError.badRequest('Mot de passe actuel incorrect')
      }
      
      // Hachage du nouveau mot de passe
      // TODO: Implémenter hashPassword et ajouter le champ password au schéma
      // updateData.password = await hashPassword(validatedData.newPassword)
      
      Logger.auth('Password change requested', user.id, true, {
        email: user.email
      })
    }
    
    // Mise à jour en base de données
    const updatedUser = await prisma.user.update({
      where: { id: user.id },
      data: updateData,
      include: {
        roles: {
          include: {
            role: {
              include: {
                permissions: {
                  include: {
                    permission: true
                  }
                }
              }
            }
          }
        }
      }
    })
    
    // Préparation de la réponse avec les informations mises à jour
    const roles = updatedUser.roles.map(ur => ur.role.name)
    const permissions = updatedUser.roles.flatMap(ur => 
      ur.role.permissions.map(rp => rp.permission.name)
    )
    const uniquePermissions = [...new Set(permissions)]
    
    const responseData = {
      id: updatedUser.id,
      email: updatedUser.email,
      firstName: updatedUser.firstName,
      lastName: updatedUser.lastName,
      phone: updatedUser.phone,
      roles,
      permissions: uniquePermissions
    }
    
    Logger.auth('Profile updated successfully', user.id, true, {
      email: user.email,
      fieldsUpdated: Object.keys(updateData)
    })
    
    return NextResponse.json(ApiResponse.success(responseData, 'Profil mis à jour avec succès'))
    
  } catch (error) {
    Logger.apiError('PUT', '/api/auth/profile', error as Error, context)
    return ApiError.handle(error)
  }
}

/**
 * OPTIONS /api/auth/profile
 * Gestion des requêtes CORS preflight
 */
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'PUT, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  })
}