import { NextRequest, NextResponse } from "next/server";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { Logger } from "@/lib/logger";
import { LoginSchema } from "@/lib/validations/auth";
import { authenticateUser, generateUserToken, generateRefreshToken } from "@/lib/auth";
import { rateLimitAuth } from "@/lib/rate-limiter";

/**
 * POST /api/auth/login
 * Authentifie un utilisateur avec email et mot de passe
 */
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);

  try {
    // Rate limiting pour l'authentification
    await rateLimitAuth(request);

    // Validation des données d'entrée
    const body = await request.json();
    const validatedData = LoginSchema.parse(body);

    Logger.apiRequest("POST", "/api/auth/login", context);

    // Authentification de l'utilisateur
    const user = await authenticateUser(validatedData.email, validatedData.password);

    // Génération des tokens
    const accessToken = await generateUserToken(user);
    const refreshToken = await generateRefreshToken(user.id);

    // Préparation de la réponse
    const responseData = {
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        roles: user.roles,
        permissions: user.permissions,
        companyId: (user as any).companyId,
      },
      tokens: {
        accessToken,
        refreshToken,
        expiresIn: 900, // 15 minutes en secondes
      },
    };

    Logger.auth("User login successful", user.id, true, {
      email: user.email,
      roles: user.roles,
    });

    const response = ApiResponse.success(responseData, "Connexion réussie");

    // Configuration des cookies pour le refresh token si "Se souvenir de moi" est activé
    // if (validatedData.rememberMe) {
    const nextResponse = NextResponse.json(response);
    nextResponse.cookies.set("refreshToken", refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 7 * 24 * 60 * 60, // 7 jours
      path: "/",
    });
    //   return nextResponse;
    // }

    return NextResponse.json(responseData);
  } catch (error) {
    Logger.apiError("POST", "/api/auth/login", error as Error, context);
    return ApiError.handle(error);
  }
}

/**
 * OPTIONS /api/auth/login
 * Gestion des requêtes CORS preflight
 */
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}
