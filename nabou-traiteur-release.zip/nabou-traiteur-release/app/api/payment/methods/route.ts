import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";

// Schémas de validation
const CreatePaymentMethodSchema = z.object({
  name: z.string().min(2).max(100),
  type: z.enum(["card", "cash", "transfer", "mobile"]),
  provider: z.string().optional(),
  fees: z.number().min(0).max(100).optional(), // Pourcentage
  isActive: z.boolean().default(true),
  isDefault: z.boolean().default(false),
  minAmount: z.number().min(0).optional(),
  maxAmount: z.number().min(0).optional(),
  processingTime: z.string().optional(),
  config: z.record(z.any()).optional(), // Configuration JSON
});

const GetPaymentMethodsSchema = z.object({
  type: z.enum(["card", "cash", "transfer", "mobile"]).optional(),
  isActive: z.coerce.boolean().optional(),
  provider: z.string().optional(),
  page: z.coerce.number().min(1).default(1),
  limit: z.coerce.number().min(1).max(100).default(20),
});

// GET /api/payment/methods
export async function GET(request: NextRequest) {
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête GET /api/payment/methods", context);

    // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // Logger.info("Utilisateur authentifié", context, { userId: user.id });

    // Validation des paramètres de requête
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());
    const validatedParams = GetPaymentMethodsSchema.parse(queryParams);

    const { type, isActive, provider, page, limit } = validatedParams;
    const skip = (page - 1) * limit;

    // Construction des filtres
    const where: any = {};

    if (type) {
      where.type = type;
    }

    if (isActive !== undefined) {
      where.isActive = isActive;
    }

    if (provider) {
      where.provider = {
        contains: provider,
        mode: "insensitive",
      };
    }

    // Récupération des méthodes de paiement
    const [methods, total] = await Promise.all([
      prisma.paymentMethod.findMany({
        where,
        include: {
          _count: {
            select: {
              transactions: true,
            },
          },
        },
        orderBy: [
          { isDefault: "desc" },
          { name: "asc" },
        ],
        skip,
        take: limit,
      }),
      prisma.paymentMethod.count({ where }),
    ]);

    const pagination = {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
      hasNext: page < Math.ceil(total / limit),
      hasPrev: page > 1,
    };

    Logger.info("Méthodes de paiement récupérées avec succès", context, {
      count: methods.length,
      total,
      filters: { type, isActive, provider },
    });

    return ApiResponse.success({
      methods,
      pagination,
    });
  } catch (error) {
    Logger.error("Erreur lors de GET /api/payment/methods", error as Error, context);
    return ApiError.handle(error);
  }
}

// POST /api/payment/methods
export async function POST(request: NextRequest) {
  const context = Logger.createContext(request);
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête POST /api/payment/methods", context);

    // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // Logger.info("Utilisateur authentifié", context, { userId: user.id });

    // Validation du body
    const body = await request.json();
    const validatedData = CreatePaymentMethodSchema.parse(body);

    // Vérification de l'unicité du nom
    const nameExists = await prisma.paymentMethod.findFirst({
      where: {
        name: {
          equals: validatedData.name,
          mode: "insensitive",
        },
      },
    });

    if (nameExists) {
      return ApiError.conflict("Une méthode de paiement avec ce nom existe déjà");
    }

    // Si cette méthode est définie comme par défaut, désactiver les autres
    if (validatedData.isDefault) {
      await prisma.paymentMethod.updateMany({
        where: { isDefault: true },
        data: { isDefault: false },
      });
    }

    // Validation des montants
    if (validatedData.minAmount && validatedData.maxAmount) {
      if (validatedData.minAmount >= validatedData.maxAmount) {
        return ApiError.badRequest("Le montant minimum doit être inférieur au montant maximum");
      }
    }

    // Création de la méthode de paiement
    const newMethod = await prisma.paymentMethod.create({
      data: validatedData,
      include: {
        _count: {
          select: {
            transactions: true,
          },
        },
      },
    });

    Logger.info("Méthode de paiement créée avec succès", context, {
      methodId: newMethod.id,
      methodName: newMethod.name,
      type: newMethod.type,
    });

    return ApiResponse.created(newMethod, "Méthode de paiement créée avec succès");
  } catch (error) {
    Logger.error("Erreur lors de POST /api/payment/methods", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/payment/methods
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}