import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { ApiResponse, ApiError } from "@/lib/api-response";
import { rateLimit } from "@/lib/rate-limiter";
import { Logger } from "@/lib/logger";

// Schémas de validation
const UpdatePaymentMethodSchema = z.object({
  name: z.string().min(2).max(100).optional(),
  type: z.enum(["card", "cash", "transfer", "mobile"]).optional(),
  provider: z.string().optional(),
  fees: z.number().min(0).max(100).optional(),
  isActive: z.boolean().optional(),
  isDefault: z.boolean().optional(),
  minAmount: z.number().min(0).optional(),
  maxAmount: z.number().min(0).optional(),
  processingTime: z.string().optional(),
  config: z.record(z.any()).optional(),
}).refine(
  (data) => Object.keys(data).length > 0,
  {
    message: "Au moins un champ doit être fourni pour la mise à jour",
  }
);

// GET /api/payment/methods/[id]
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);
  const { id } = await params;
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête GET /api/payment/methods/[id]", context);

    // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // Logger.info("Utilisateur authentifié", context, { userId: user.id });

    // Récupération de la méthode de paiement
    const method = await prisma.paymentMethod.findUnique({
      where: { id },
      include: {
        _count: {
          select: {
            transactions: true,
          },
        },
        transactions: {
          select: {
            id: true,
            amount: true,
            status: true,
            createdAt: true,
          },
          orderBy: { createdAt: "desc" },
          take: 10, // Dernières 10 transactions
        },
      },
    });

    if (!method) {
      return ApiError.notFound("Méthode de paiement introuvable");
    }

    Logger.info("Méthode de paiement récupérée avec succès", context, {
      methodId: method.id,
      methodName: method.name,
    });

    return ApiResponse.success(method);
  } catch (error) {
    Logger.error("Erreur lors de GET /api/payment/methods/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// PUT /api/payment/methods/[id]
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);
  const { id } = await params;
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête PUT /api/payment/methods/[id]", context);

    // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // Logger.info("Utilisateur authentifié", context, { userId: user.id });

    // Validation du body
    const body = await request.json();
    const validatedData = UpdatePaymentMethodSchema.parse(body);

    // Vérification de l'existence de la méthode
    const existingMethod = await prisma.paymentMethod.findUnique({
      where: { id },
    });

    if (!existingMethod) {
      return ApiError.notFound("Méthode de paiement introuvable");
    }

    // Vérification de l'unicité du nom (si modifié)
    if (validatedData.name && validatedData.name !== existingMethod.name) {
      const nameExists = await prisma.paymentMethod.findFirst({
        where: {
          name: {
            equals: validatedData.name,
            mode: "insensitive",
          },
          id: { not: id },
        },
      });

      if (nameExists) {
        return ApiError.conflict("Une méthode de paiement avec ce nom existe déjà");
      }
    }

    // Validation des montants
    const minAmount = validatedData.minAmount ?? existingMethod.minAmount;
    const maxAmount = validatedData.maxAmount ?? existingMethod.maxAmount;
    
    if (minAmount && maxAmount && minAmount >= maxAmount) {
      return ApiError.badRequest("Le montant minimum doit être inférieur au montant maximum");
    }

    // Si cette méthode est définie comme par défaut, désactiver les autres
    if (validatedData.isDefault && !existingMethod.isDefault) {
      await prisma.paymentMethod.updateMany({
        where: { 
          isDefault: true,
          id: { not: id },
        },
        data: { isDefault: false },
      });
    }

    // Mise à jour de la méthode de paiement
    const updatedMethod = await prisma.paymentMethod.update({
      where: { id },
      data: validatedData,
      include: {
        _count: {
          select: {
            transactions: true,
          },
        },
      },
    });

    Logger.info("Méthode de paiement mise à jour avec succès", context, {
      methodId: updatedMethod.id,
      methodName: updatedMethod.name,
    });

    return ApiResponse.updated(updatedMethod, "Méthode de paiement mise à jour avec succès");
  } catch (error) {
    Logger.error("Erreur lors de PUT /api/payment/methods/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// DELETE /api/payment/methods/[id]
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const context = Logger.createContext(request);
  const { id } = await params;
  
  try {
    // Rate limiting
    await rateLimit(request, 'general');

    Logger.info("Début de la requête DELETE /api/payment/methods/[id]", context);

    // Authentification
    // const user = await requireAuth(request);
    // if (!user) {
    //   return ApiError.unauthorized("Token invalide");
    // }

    // Logger.info("Utilisateur authentifié", context, { userId: user.id });

    // Vérification de l'existence de la méthode
    const existingMethod = await prisma.paymentMethod.findUnique({
      where: { id },
      include: {
        _count: {
          select: {
            transactions: true,
          },
        },
      },
    });

    if (!existingMethod) {
      return ApiError.notFound("Méthode de paiement introuvable");
    }

    // Vérification des contraintes métier
    if (existingMethod._count.transactions > 0) {
      return ApiError.conflict(
        "Impossible de supprimer cette méthode de paiement car elle est utilisée dans des transactions"
      );
    }

    // Vérification si c'est la méthode par défaut
    if (existingMethod.isDefault) {
      const otherMethods = await prisma.paymentMethod.count({
        where: {
          id: { not: id },
          isActive: true,
        },
      });

      if (otherMethods === 0) {
        return ApiError.conflict(
          "Impossible de supprimer la méthode de paiement par défaut. Veuillez d'abord définir une autre méthode comme par défaut."
        );
      }
    }

    // Suppression de la méthode de paiement
    await prisma.paymentMethod.delete({
      where: { id },
    });

    Logger.info("Méthode de paiement supprimée avec succès", context, {
      methodId: id,
      methodName: existingMethod.name,
    });

    return ApiResponse.deleted("Méthode de paiement supprimée avec succès");
  } catch (error) {
    Logger.error("Erreur lors de DELETE /api/payment/methods/[id]", error as Error, context);
    return ApiError.handle(error);
  }
}

// OPTIONS /api/payment/methods/[id]
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}