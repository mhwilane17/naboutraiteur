"use client";

import { useState, useEffect } from "react";
import { useParams, useSearchParams } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { useIsMobile } from "@/hooks/use-mobile";
import { unifiedOrderService } from "@/services/unifiedOrderService";
import {
  Loader2,
  Package,
  MapPin,
  CreditCard,
  Clock,
  CheckCircle,
  XCircle,
} from "lucide-react";

interface OrderItem {
  id: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  options: any;
  notes?: string;
  menuItem: {
    id: string;
    name: string;
    description: string;
    imageUrl?: string;
    category: {
      id: string;
      name: string;
    };
  };
}

interface OrderDetails {
  id: string;
  orderNumber: string;
  status: string;
  type: string;
  totalAmount: number;
  deliveryFee: number;
  discountAmount: number;
  finalAmount: number;
  paymentStatus: string;
  paymentMethod: {
    id: string;
    name: string;
  };
  deliveryInfo: {
    address: string;
    city: string;
    postalCode: string;
    phone: string;
    date: string;
    time: string;
    zone: {
      id: string;
      name: string;
      deliveryFee: number;
      areas: string[];
    } | null;
  };
  items: OrderItem[];
  weeklyMenu: {
    id: string;
    name: string;
    startDate: string;
    endDate: string;
  } | null;
  paymentTransactions: Array<{
    id: string;
    amount: number;
    status: string;
    transactionId: string;
    createdAt: string;
  }>;
  promotions: Array<{
    id: string;
    name: string;
    code: string;
    type: string;
    value: number;
    discountAmount: number;
  }>;
  createdAt: string;
  updatedAt: string;
  customerNotes?: string;
  statusHistory: Array<{
    status: string;
    timestamp: string;
    description: string;
  }>;
}

const statusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800",
  confirmed: "bg-blue-100 text-blue-800",
  preparing: "bg-orange-100 text-orange-800",
  ready: "bg-green-100 text-green-800",
  out_for_delivery: "bg-purple-100 text-purple-800",
  delivered: "bg-green-100 text-green-800",
  cancelled: "bg-red-100 text-red-800",
};

const statusLabels: Record<string, string> = {
  pending: "En attente",
  confirmed: "Confirmée",
  preparing: "En préparation",
  ready: "Prête",
  out_for_delivery: "En livraison",
  delivered: "Livrée",
  cancelled: "Annulée",
};

export default function OrderTrackingPage() {
  const params = useParams();
  const { toast } = useToast();
  const isMobile = useIsMobile();

  const [order, setOrder] = useState<OrderDetails | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [email, setEmail] = useState("");
  const [showEmailForm, setShowEmailForm] = useState(false);
  
  // États pour les modals de paiement
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [selectionModalOpen, setSelectionModalOpen] = useState(false);
  const [paymentOptions, setPaymentOptions] = useState<
    Array<{ label: string; url: string }>
  >([]);

  const orderNumber = params.orderNumber as string;

  useEffect(() => {
    fetchOrderDetails();
  }, [orderNumber]);

  const fetchOrderDetails = async (userEmail?: string) => {
    setLoading(true);
    setError(null);

    try {
      const params = new URLSearchParams();
      if (userEmail) params.append("email", userEmail);

      const response = await fetch(
        `/api/orders/guest/${orderNumber}?${params}`
      );
      const data = await response.json();

      if (!response.ok) {
        if (response.status === 401 && !userEmail) {
          setShowEmailForm(true);
          return;
        }
        throw new Error(
          data.message || "Erreur lors de la récupération de la commande"
        );
      }

      setOrder(data.data);
      setShowEmailForm(false);
    } catch (err: any) {
      setError(err.message);
      if (!userEmail) {
        setShowEmailForm(true);
      } else {
        toast({
          title: "Erreur",
          description: err.message,
          variant: "destructive",
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      fetchOrderDetails(email);
    }
  };

  // Fonction helper pour ouvrir un lien de manière compatible avec iOS Safari
  const openPaymentLink = (url: string): boolean => {
    try {
      // Créer un lien <a> et le cliquer (fonctionne mieux avec Safari iOS)
      const link = document.createElement("a");
      link.href = url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.style.display = "none";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      return true;
    } catch (e) {
      try {
        // Fallback sur window.open
        const win = window.open(url, "_blank", "noopener,noreferrer");
        if (win) {
          return true;
        }
      } catch (e2) {
        // Dernier recours - redirection directe
        window.location.href = url;
        return true;
      }
    }
    return false;
  };

  const handlePayNow = async () => {
    if (!order) return;

    setPaymentLoading(true);
    try {
      const response = await fetch(`/api/payments/init/${orderNumber}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Erreur lors de l'initialisation du paiement");
      }

      const paymentInit = data.data;
      const qrCode = paymentInit?.qrCode;
      const paymentLinks = unifiedOrderService.extractPaymentLinks({
        paymentInit,
      } as any);

      // Desktop et QR disponible: afficher modal QR en priorité
      const shouldPrioritizeQr = unifiedOrderService.shouldPrioritizeQr(
        { paymentInit } as any,
        isMobile
      );

      if (shouldPrioritizeQr && qrCode) {
        setQrCode(qrCode);
        setQrModalOpen(true);
      } else if (paymentLinks.length > 0) {
        // Toujours afficher le modal d'alerte avec les liens disponibles (1 ou plusieurs)
        setPaymentOptions(paymentLinks);
        setSelectionModalOpen(true);
      } else {
        toast({
          title: "Erreur",
          description: "Aucun lien de paiement disponible",
          variant: "destructive",
        });
      }
    } catch (err: any) {
      console.error("Erreur lors de l'initialisation du paiement:", err);
      toast({
        title: "Erreur",
        description: err.message || "Erreur lors de l'initialisation du paiement",
        variant: "destructive",
      });
    } finally {
      setPaymentLoading(false);
    }
  };

  const handleSelectPayment = (url: string) => {
    const opened = openPaymentLink(url);
    if (opened) {
      setSelectionModalOpen(false);
      toast({
        title: "Paiement",
        description: "Le lien de paiement a été ouvert",
      });
    } else {
      toast({
        title: "Erreur",
        description: "Impossible d'ouvrir le lien de paiement",
        variant: "destructive",
      });
    }
  };

  const handleCloseQrModal = () => {
    setQrModalOpen(false);
    setQrCode(null);
  };

  if (showEmailForm) {
    return <div className="min-h-screen bg-gray-50 py-12"></div>;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Chargement des détails de la commande...</p>
        </div>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-md mx-auto">
          <Card>
            <CardContent className="pt-6 text-center">
              <XCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h2 className="text-lg font-semibold mb-2">
                Commande introuvable
              </h2>
              <p className="text-gray-600 mb-4">
                {error || "Impossible de trouver cette commande."}
              </p>
              <Button onClick={() => setShowEmailForm(true)}>Réessayer</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-4 sm:py-8">
      <div className="max-w-7xl mx-auto px-2 sm:px-4">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900 mb-2">
            Commande #{order.orderNumber}
          </h1>
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
            <Badge className={statusColors[order.status]}>
              {statusLabels[order.status]}
            </Badge>
            <span className="text-xs sm:text-sm text-gray-600">
              Commandée le{" "}
              {new Date(order.createdAt).toLocaleDateString("fr-FR")}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-4 sm:space-y-6">
            {/* Status Timeline */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                  <Clock className="h-4 w-4 sm:h-5 sm:w-5" />
                  Suivi de la commande
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 sm:space-y-4">
                  {order.statusHistory.map((status, index) => (
                    <div
                      key={index}
                      className="flex items-start sm:items-center gap-3 sm:gap-4"
                    >
                      <div className="flex-shrink-0 mt-1 sm:mt-0">
                        <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-green-500" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm sm:text-base">
                          {status.description}
                        </p>
                        <p className="text-xs sm:text-sm text-gray-600">
                          {new Date(status.timestamp).toLocaleString("fr-FR")}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Order Items */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                  <Package className="h-4 w-4 sm:h-5 sm:w-5" />
                  Articles commandés
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 sm:space-y-4">
                  {order.items.map((item) => (
                    <div
                      key={item.id}
                      className="flex flex-col sm:flex-row items-start gap-3 sm:gap-4 p-3 sm:p-4 border rounded-lg"
                    >
                      {item.menuItem.imageUrl && (
                        <img
                          src={item.menuItem.imageUrl}
                          alt={item.menuItem.name}
                          className="w-12 h-12 sm:w-16 sm:h-16 object-cover rounded flex-shrink-0"
                        />
                      )}
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm sm:text-base">
                          {item.menuItem.name}
                        </h4>
                        <p className="text-xs sm:text-sm text-gray-600 line-clamp-2">
                          {item.menuItem.description}
                        </p>
                        <p className="text-xs sm:text-sm text-gray-500">
                          Opt: {item.options.size}
                        </p>
                        {item.notes && (
                          <p className="text-xs sm:text-sm text-gray-600 mt-1">
                            Note: {item.notes}
                          </p>
                        )}
                      </div>
                      <div className="text-right flex-shrink-0 w-full sm:w-auto">
                        <div className="flex justify-between sm:block">
                          <span className="text-sm sm:hidden text-gray-600">
                            Quantité:
                          </span>
                          <p className="font-medium text-sm sm:text-base">
                            {item.quantity}x
                          </p>
                        </div>
                        <div className="flex justify-between sm:block">
                          <span className="text-sm sm:hidden text-gray-600">
                            Prix unitaire:
                          </span>
                          <p className="text-xs sm:text-sm text-gray-600">
                            {item.unitPrice.toFixed(2)} FCFA
                          </p>
                        </div>
                        <div className="flex justify-between sm:block">
                          <span className="text-sm sm:hidden text-gray-600">
                            Total:
                          </span>
                          <p className="font-semibold text-sm sm:text-base">
                            {item.totalPrice.toFixed(2)} FCFA
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-4 sm:space-y-6">
            {/* Order Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base sm:text-lg">
                  Résumé de la commande
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 sm:space-y-3">
                <div className="flex justify-between text-sm sm:text-base">
                  <span>Sous-total</span>
                  <span>{order.totalAmount.toFixed(2)} FCFA</span>
                </div>
                <div className="flex justify-between text-sm sm:text-base">
                  <span>Livraison</span>
                  <span>{order.deliveryFee.toFixed(2)} FCFA</span>
                </div>
                {order.discountAmount > 0 && (
                  <div className="flex justify-between text-green-600 text-sm sm:text-base">
                    <span>Réduction</span>
                    <span>-{order.discountAmount.toFixed(2)} FCFA</span>
                  </div>
                )}
                <Separator />
                <div className="flex justify-between font-semibold text-base sm:text-lg">
                  <span>Total</span>
                  <span>{order.finalAmount.toFixed(2)} FCFA</span>
                </div>
              </CardContent>
            </Card>

            {/* Delivery Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                  <MapPin className="h-4 w-4 sm:h-5 sm:w-5" />
                  Informations de livraison
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="font-medium text-sm sm:text-base">
                  {order.deliveryInfo.address}
                </p>
                <p className="text-sm sm:text-base">
                  {order.deliveryInfo.city} {order.deliveryInfo.postalCode}
                </p>
                <p className="text-sm sm:text-base">
                  Téléphone: {order.deliveryInfo.phone}
                </p>
                <Separator className="my-3" />
                {/* <p>
                  <strong>Date:</strong>{" "}
                  {new Date(order.deliveryInfo.date).toLocaleDateString("fr-FR")}
                </p> */}
                {order.deliveryInfo.zone && (
                  <div className="text-sm sm:text-base">
                    <p>
                      <strong>Zone:</strong> {order.deliveryInfo.zone.name}
                    </p>
                    <span className="text-xs text-gray-500">
                      ({order.deliveryInfo.zone.areas.join(", ")})
                    </span>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Payment Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                  <CreditCard className="h-4 w-4 sm:h-5 sm:w-5" />
                  Paiement
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {order.paymentMethod && (
                    <div className="flex justify-between text-sm sm:text-base">
                      <span>Méthode:</span>
                      <span className="capitalize">
                        {order.paymentMethod.name}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between items-center">
                    <span className="text-sm sm:text-base">Statut:</span>
                    <Badge
                      variant={
                        order.paymentStatus === "paid" ? "default" : "secondary"
                      }
                    >
                      {order.paymentStatus === "paid" ? "Payé" : "En attente"}
                    </Badge>
                  </div>
                  {order.paymentStatus !== "paid" && (
                    <div className="pt-2">
                      <Button
                        onClick={handlePayNow}
                        disabled={paymentLoading}
                        className="w-full bg-orange-600 hover:bg-orange-700 text-white"
                        size="sm"
                      >
                        {paymentLoading ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Initialisation...
                          </>
                        ) : (
                          <>
                            <CreditCard className="h-4 w-4 mr-2" />
                            Payer maintenant
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Modal QR Code */}
      <Dialog open={qrModalOpen} onOpenChange={setQrModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Scanner le QR Code pour payer</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col items-center space-y-4 py-4">
            {qrCode ? (
              <img
                src={`data:image/png;base64,${qrCode}`}
                alt="QR Code de paiement"
                className="w-72 h-72 object-contain border rounded-md"
              />
            ) : (
              <div className="text-sm text-red-600">QR Code indisponible</div>
            )}
            <div className="text-xs text-gray-600 text-center">
              Scannez ce QR Code avec votre application Orange Money ou Maxit pour finaliser.
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleCloseQrModal} variant="outline">
              Fermer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal Sélection Paiement */}
      <Dialog open={selectionModalOpen} onOpenChange={setSelectionModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {paymentOptions.length === 1
                ? "Payer maintenant"
                : "Choisir une méthode de paiement"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-4">
            {paymentOptions.map((opt) => (
              <Button
                key={opt.label}
                onClick={() => handleSelectPayment(opt.url)}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white justify-center"
              >
                <span className="font-medium">{opt.label}</span>
              </Button>
            ))}
            {paymentOptions.length === 0 && (
              <div className="text-sm text-gray-600 text-center">
                Aucun lien de paiement disponible.
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              onClick={() => setSelectionModalOpen(false)}
              variant="outline"
            >
              Annuler
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
