"use client";

import { useEffect, useState } from "react";
import { ProtectedRoute } from "@/components/admin/ProtectedRoute";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { AddUserDialog } from "@/components/admin/users/AddUserDialog";
import { EditUserDialog } from "@/components/admin/users/EditUserDialog";
import { ViewUserDialog } from "@/components/admin/users/ViewUserDialog";
import { DeleteUserDialog } from "@/components/admin/users/DeleteUserDialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Users,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Eye,
  UserCheck,
  UserX,
  AlertTriangle,
} from "lucide-react";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { ErrorDisplay } from "@/components/ui/error-display";
import { FadeIn } from "@/components/ui/fade-in";
import { TableSkeleton } from "@/components/ui/table-skeleton";
import { useUsersStore } from "@/stores/usersStore";
import { User, UserStatus } from "@/types/users";
import { useToast } from "@/components/ui/use-toast";
import { UsersPagination } from "@/components/admin/users/UsersPagination";
import { ProtectedView } from "@/components/ProtectedView";

// Status options for filtering
const statuses = [
  { value: UserStatus.ACTIVE, label: "Actif" },
  { value: UserStatus.SUSPENDED, label: "Suspendu" },
];

export default function UsersPage() {
  const {
    users,
    roles,
    loading,
    error,
    operationLoading,
    filters,
    pagination,
    fetchUsers,
    fetchRoles,
    fetchStats,
    openEditDialog,
    openViewDialog,
    openDeleteDialog,
    setSearchFilter,
    setImmediateFilter,
    suspendUser,
    reactivateUser,

    cleanup,
    setError,
  } = useUsersStore();

  const { toast } = useToast();
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const [userToToggle, setUserToToggle] = useState<User | null>(null);
  const [statusActionLoading, setStatusActionLoading] = useState(false);

  // Load data on component mount
  useEffect(() => {
    // Load all necessary data
    const loadData = async () => {
      await Promise.all([
        fetchUsers(),
        fetchRoles()
      ]);
    };

    loadData();

    // Cleanup on unmount
    return () => {
      cleanup();
    };
  }, [fetchUsers, fetchRoles, cleanup]);

  // Get filtered users
  const displayedUsers = users; // Users are already filtered by the store

  // Utility functions
  const getUserFullName = (user: User) => {
    return `${user.firstName} ${user.lastName}`;
  };

  const getStatusLabel = (isActive: boolean) => {
    return isActive ? "Actif" : "Suspendu";
  };

  const getStatusColor = (isActive: boolean) => {
    return isActive
      ? "bg-green-100 text-green-800"
      : "bg-red-100 text-red-800";
  };

  const getRoleColor = (roleName: string) => {
    switch (roleName.toLowerCase()) {
      case "admin":
        return "bg-purple-100 text-purple-800";
      case "manager":
        return "bg-blue-100 text-blue-800";
      case "employee":
        return "bg-orange-100 text-orange-800";
      case "client":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatLastLogin = (lastLogin?: string) => {
    if (!lastLogin) return "Jamais connecté";

    const date = new Date(lastLogin);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));

    if (diffInHours < 1) return "Il y a moins d'une heure";
    if (diffInHours < 24) return `Il y a ${diffInHours} heure${diffInHours > 1 ? 's' : ''}`;

    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `Il y a ${diffInDays} jour${diffInDays > 1 ? 's' : ''}`;

    const diffInWeeks = Math.floor(diffInDays / 7);
    return `Il y a ${diffInWeeks} semaine${diffInWeeks > 1 ? 's' : ''}`;
  };

  const handleSuspendUser = (user: User) => {
    setUserToToggle(user);
    setStatusDialogOpen(true);
  };

  const confirmStatusToggle = async () => {
    if (!userToToggle) return;

    setStatusActionLoading(true);
    try {
      const success = userToToggle.isActive
        ? await suspendUser(userToToggle.id)
        : await reactivateUser(userToToggle.id);

      if (success) {
        toast({
          title: "Succès",
          description: userToToggle.isActive
            ? `L'utilisateur ${userToToggle.firstName} ${userToToggle.lastName} a été suspendu avec succès`
            : `L'utilisateur ${userToToggle.firstName} ${userToToggle.lastName} a été réactivé avec succès`,
          variant: "default",
        });
        setStatusDialogOpen(false);
        setUserToToggle(null);
      }
    } catch (error) {
      console.error('Erreur lors de la modification du statut:', error);
    } finally {
      setStatusActionLoading(false);
    }
  };

  const handleRetryLoadData = async () => {
    setError(null);
    await Promise.all([
      fetchUsers(),
      fetchRoles()
    ]);
  };

  const cancelStatusToggle = () => {
    setStatusDialogOpen(false);
    setUserToToggle(null);
  };

  // Filter handlers
  const handleSearchChange = (value: string) => {
    setSearchFilter(value);
  };

  const handleRoleFilterChange = (value: string) => {
    setImmediateFilter({ role: value === "all" ? "" : value });
  };

  const handleStatusFilterChange = (value: string) => {
    setImmediateFilter({ status: value });
  };

  return (
    <ProtectedRoute>
      <AdminLayout>
        <div className="space-y-6">
          {/* En-tête */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Gestion de la direction</h1>
              <p className="text-muted-foreground">
                Gérez les membres de la direction
              </p>
            </div>
            {/* <ProtectedView permissions={["CREATE_USER"]}>*/}
              <AddUserDialog />
            {/* </ProtectedView> */}
          </div>

          {/* Error Alert */}
          {error && (
            <FadeIn>
              <ErrorDisplay
                error={error}
                onRetry={handleRetryLoadData}
                retryText="Recharger les données"
              />
            </FadeIn>
          )}

          {/* Filtres et recherche */}
          <FadeIn delay={200}>
            <Card className="transition-all duration-200 hover:shadow-sm">
              <CardHeader>
                <CardTitle>Filtres et recherche</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Rechercher par nom ou email..."
                        value={filters.search}
                        onChange={(e) => handleSearchChange(e.target.value)}
                        className="pl-8 transition-all duration-200 focus:ring-2"
                        disabled={operationLoading.fetchUsers}
                      />
                    </div>
                  </div>
                  <Select
                    value={filters.role || "all"}
                    onValueChange={handleRoleFilterChange}
                    disabled={operationLoading.fetchUsers || operationLoading.fetchRoles}
                  >
                    <SelectTrigger className="w-full sm:w-[180px] transition-all duration-200">
                      <SelectValue placeholder="Filtrer par rôle" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous les rôles</SelectItem>
                      {roles.map((role) => (
                        <SelectItem key={role.id} value={role.id}>
                          {role.name || role.description}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select
                    value={filters.status}
                    onValueChange={handleStatusFilterChange}
                    disabled={operationLoading.fetchUsers}
                  >
                    <SelectTrigger className="w-full sm:w-[180px] transition-all duration-200">
                      <SelectValue placeholder="Filtrer par statut" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={UserStatus.ALL}>Tous les statuts</SelectItem>
                      {statuses.map((status) => (
                        <SelectItem key={status.value} value={status.value}>
                          {status.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </FadeIn>

          {/* Tableau des utilisateurs - Vue Desktop */}
          <div className="hidden md:block">
            <FadeIn delay={300}>
              <Card className="transition-all duration-200 hover:shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    Liste des utilisateurs
                    {operationLoading.fetchUsers && <LoadingSpinner size="sm" />}
                  </CardTitle>
                  <CardDescription>
                    {loading || operationLoading.fetchUsers ? "Chargement..." : `${pagination.total} utilisateur(s) au total`}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loading || operationLoading.fetchUsers ? (
                    <TableSkeleton rows={pagination.limit || 10} columns={6} />
                  ) : displayedUsers.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground">
                      <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p className="text-lg font-medium mb-2">Aucun utilisateur trouvé</p>
                      <p className="text-sm">Essayez de modifier vos critères de recherche</p>
                    </div>
                  ) : (
                    <>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Utilisateur</TableHead>
                              <TableHead>Contact</TableHead>
                              <TableHead>Rôles</TableHead>
                              <TableHead>Statut</TableHead>
                              <TableHead>Dernière connexion</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {displayedUsers.map((user, index) => (
                              <TableRow
                                key={user.id}
                                className="transition-all duration-200 hover:bg-muted/50"
                                style={{ animationDelay: `${index * 50}ms` }}
                              >
                                <TableCell>
                                  <div>
                                    <div className="font-medium">{getUserFullName(user)}</div>
                                    <div className="text-sm text-muted-foreground">{user.email}</div>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="text-sm">{user.phone || "Non renseigné"}</div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex flex-wrap gap-1">
                                    {user.roles.map((role) => (
                                      <Badge key={role.id} className={getRoleColor(role.name)}>
                                        {role.description || role.name}
                                      </Badge>
                                    ))}
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <Badge className={getStatusColor(user.isActive)}>
                                    {getStatusLabel(user.isActive)}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <div className="text-sm">{formatLastLogin(user.lastLogin)}</div>
                                </TableCell>
                                <TableCell className="text-right">
                                  <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        className="h-8 w-8 p-0 transition-all duration-200 hover:bg-muted"
                                        disabled={loading || Object.values(operationLoading).some(Boolean)}
                                      >
                                        <span className="sr-only">Ouvrir le menu</span>
                                        <MoreHorizontal className="h-4 w-4" />
                                      </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end">
                                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                      <DropdownMenuItem onClick={() => openViewDialog(user)}>
                                        <Eye className="mr-2 h-4 w-4" />
                                        Voir les détails
                                      </DropdownMenuItem>
                                      <DropdownMenuItem onClick={() => openEditDialog(user)}>
                                        <Edit className="mr-2 h-4 w-4" />
                                        Modifier
                                      </DropdownMenuItem>
                                      <DropdownMenuSeparator />
                                      <DropdownMenuItem
                                        className={user.isActive ? "text-orange-600" : "text-green-600"}
                                        onClick={() => handleSuspendUser(user)}
                                      >
                                        {user.isActive ? (
                                          <>
                                            <UserX className="mr-2 h-4 w-4" />
                                            Suspendre
                                          </>
                                        ) : (
                                          <>
                                            <UserCheck className="mr-2 h-4 w-4" />
                                            Réactiver
                                          </>
                                        )}
                                      </DropdownMenuItem>
                                      <ProtectedView permissions={["DELETE_USER"]}>
                                        <DropdownMenuItem
                                          className="text-red-600"
                                          onClick={() => openDeleteDialog(user)}
                                        >
                                          <Trash2 className="mr-2 h-4 w-4" />
                                          Supprimer
                                        </DropdownMenuItem>
                                      </ProtectedView>
                                    </DropdownMenuContent>
                                  </DropdownMenu>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>

                      {/* Pagination */}
                      <div className="mt-6">
                        <UsersPagination />
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </FadeIn>
          </div>

          {/* Vue Mobile - Cartes des utilisateurs */}
          <div className="md:hidden space-y-4">
            {loading || operationLoading.fetchUsers ? (
              <Card>
                <CardContent className="flex items-center justify-center py-8">
                  <LoadingSpinner size="sm" />
                  <span className="ml-2 text-muted-foreground">Chargement...</span>
                </CardContent>
              </Card>
            ) : displayedUsers.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8 text-muted-foreground">
                  <Users className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="font-medium mb-1">Aucun utilisateur trouvé</p>
                  <p className="text-sm">Modifiez vos critères de recherche</p>
                </CardContent>
              </Card>
            ) : (
              <>
                {displayedUsers.map((user, index) => (
                  <FadeIn key={user.id} delay={index * 50}>
                    <Card className="overflow-hidden">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <div className="min-w-0 flex-1">
                            <h3 className="font-medium text-sm truncate">{getUserFullName(user)}</h3>
                            <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                            {user.phone && (
                              <p className="text-xs text-muted-foreground">{user.phone}</p>
                            )}
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                variant="ghost"
                                className="h-8 w-8 p-0 flex-shrink-0"
                                disabled={loading || Object.values(operationLoading).some(Boolean)}
                              >
                                <span className="sr-only">Ouvrir le menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => openViewDialog(user)}>
                                <Eye className="mr-2 h-4 w-4" />
                                Voir les détails
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => openEditDialog(user)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Modifier
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                className={user.isActive ? "text-orange-600" : "text-green-600"}
                                onClick={() => handleSuspendUser(user)}
                              >
                                {user.isActive ? (
                                  <>
                                    <UserX className="mr-2 h-4 w-4" />
                                    Suspendre
                                  </>
                                ) : (
                                  <>
                                    <UserCheck className="mr-2 h-4 w-4" />
                                    Réactiver
                                  </>
                                )}
                              </DropdownMenuItem>
                              <ProtectedView permissions={["DELETE_USER"]}>
                                <DropdownMenuItem
                                  className="text-red-600"
                                  onClick={() => openDeleteDialog(user)}
                                >
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Supprimer
                                </DropdownMenuItem>
                              </ProtectedView>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>

                        <div className="flex flex-wrap items-center gap-2 mb-3">
                          {user.roles.map((role) => (
                            <Badge key={role.id} className={`${getRoleColor(role.name)} text-xs`}>
                              {role.description || role.name}
                            </Badge>
                          ))}
                          <Badge className={`${getStatusColor(user.isActive)} text-xs`}>
                            {getStatusLabel(user.isActive)}
                          </Badge>
                        </div>

                        <div className="text-xs text-muted-foreground">
                          <div>
                            Dernière connexion: {formatLastLogin(user.lastLogin)}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </FadeIn>
                ))}

                {/* Pagination Mobile */}
                <div className="mt-6">
                  <UsersPagination />
                </div>
              </>
            )}
          </div>

          {/* Dialogs */}
          <EditUserDialog />
          <ViewUserDialog />
          <DeleteUserDialog />

          {/* Status Toggle Confirmation Dialog */}
          <Dialog open={statusDialogOpen} onOpenChange={(open) => !open && cancelStatusToggle()}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-orange-600" />
                  {userToToggle?.isActive ? "Suspendre l'utilisateur" : "Réactiver l'utilisateur"}
                </DialogTitle>
                <DialogDescription>
                  {userToToggle?.isActive
                    ? "Êtes-vous sûr de vouloir suspendre cet utilisateur ? Il ne pourra plus se connecter à son compte."
                    : "Êtes-vous sûr de vouloir réactiver cet utilisateur ? Il pourra à nouveau se connecter à son compte."
                  }
                </DialogDescription>
              </DialogHeader>
              {userToToggle && (
                <div className="py-4">
                  <div className={`border rounded-lg p-4 ${userToToggle.isActive
                    ? "bg-orange-50 border-orange-200"
                    : "bg-green-50 border-green-200"
                    }`}>
                    <div className="flex items-center gap-2 mb-2">
                      {userToToggle.isActive ? (
                        <UserX className="h-4 w-4 text-orange-600" />
                      ) : (
                        <UserCheck className="h-4 w-4 text-green-600" />
                      )}
                      <span className={`font-medium ${userToToggle.isActive ? "text-orange-800" : "text-green-800"
                        }`}>
                        Utilisateur à {userToToggle.isActive ? "suspendre" : "réactiver"} :
                      </span>
                    </div>
                    <div className={`text-sm ${userToToggle.isActive ? "text-orange-700" : "text-green-700"
                      }`}>
                      <p><strong>Nom :</strong> {userToToggle.firstName} {userToToggle.lastName}</p>
                      <p><strong>Email :</strong> {userToToggle.email}</p>
                      <p><strong>Statut actuel :</strong> {userToToggle.isActive ? "Actif" : "Suspendu"}</p>
                    </div>
                  </div>
                </div>
              )}
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={cancelStatusToggle}
                  disabled={statusActionLoading || operationLoading.suspend || operationLoading.reactivate}
                  className="transition-all duration-200"
                >
                  Annuler
                </Button>
                <Button
                  variant={userToToggle?.isActive ? "destructive" : "default"}
                  onClick={confirmStatusToggle}
                  disabled={statusActionLoading || operationLoading.suspend || operationLoading.reactivate}
                  className="transition-all duration-200"
                >
                  {statusActionLoading || operationLoading.suspend || operationLoading.reactivate ? (
                    <>
                      <LoadingSpinner size="sm" />
                      <span className="ml-2">
                        {userToToggle?.isActive ? "Suspension..." : "Réactivation..."}
                      </span>
                    </>
                  ) : (
                    userToToggle?.isActive ? "Suspendre" : "Réactiver"
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </AdminLayout>
    </ProtectedRoute>
  );
}