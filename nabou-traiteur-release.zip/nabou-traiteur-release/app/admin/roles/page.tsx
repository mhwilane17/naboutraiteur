"use client";

import { useEffect } from "react";
import { ProtectedRoute } from "@/components/admin/ProtectedRoute";
import { AdminLayout } from "@/components/admin/AdminLayout";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
// Import des composants Dialog personnalisés
import {
  AddRoleDialog,
  EditRoleDialog,
  ViewRoleDialog,
  DeleteRoleDialog,
} from "@/components/admin/roles";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { ErrorDisplay } from "@/components/ui/error-display";
import { useRolesStore } from "@/stores/rolesStore";

import {
  Search,
  Plus,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Lock,
  Unlock,
  UserCheck,
  Settings,
} from "lucide-react";



export default function RolesPage() {
  const {
    roles,
    loading,
    error,
    operationLoading,
    filters,
    fetchRoles,
    fetchPermissions,
    toggleRoleStatus,
    openAddDialog,
    openEditDialog,
    openViewDialog,
    openDeleteDialog,
    setSearchFilter,
    setImmediateFilter,
    cleanup,
  } = useRolesStore();

  // Initialize data on component mount
  useEffect(() => {
    fetchRoles();
    fetchPermissions();

    // Cleanup on unmount
    return () => {
      cleanup();
    };
  }, [fetchRoles, fetchPermissions, cleanup]);

  // Handle search input change
  const handleSearchChange = (value: string) => {
    setSearchFilter(value);
  };

  // Handle status filter change
  const handleStatusChange = (status: string) => {
    setImmediateFilter({ status: status as 'all' | 'active' | 'inactive' });
  };

  // Handle role status toggle
  const handleToggleStatus = async (roleId: string) => {
    await toggleRoleStatus(roleId);
  };

  // Handle retry for errors
  const handleRetry = () => {
    fetchRoles();
    fetchPermissions();
  };

  return (
    <ProtectedRoute>
      <AdminLayout>
        <div className="space-y-6">
          {/* En-tête */}
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Gestion des rôles
              </h1>
              <p className="text-gray-600 mt-2">
                Gérez les rôles et leurs permissions
              </p>
            </div>
            <Button 
              onClick={openAddDialog}
              disabled={operationLoading.create || loading}
            >
              <Plus className="h-4 w-4 mr-2" />
              Créer un rôle
            </Button>
          </div>

          {/* Error Display */}
          {error && (
            <ErrorDisplay 
              error={error} 
              onRetry={handleRetry}
              retryText="Recharger les données"
            />
          )}

          {/* Filtres et recherche */}
          <Card>
            <CardHeader>
              <CardTitle>Filtres et recherche</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Rechercher un rôle..."
                      value={filters.search}
                      onChange={(e) => handleSearchChange(e.target.value)}
                      className="pl-8"
                      disabled={loading}
                    />
                  </div>
                </div>
                <Select
                  value={filters.status}
                  onValueChange={handleStatusChange}
                  disabled={loading}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filtrer par statut" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous les statuts</SelectItem>
                    <SelectItem value="active">Actifs</SelectItem>
                    <SelectItem value="inactive">Inactifs</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Tableau des rôles */}
          <Card>
            <CardHeader>
              <CardTitle>Liste des rôles</CardTitle>
              <CardDescription>
                {roles?.length || 0} rôle(s) trouvé(s)
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading && operationLoading.fetchRoles ? (
                <div className="flex justify-center items-center py-8">
                  <LoadingSpinner text="Chargement des rôles..." />
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Rôle</TableHead>
                      <TableHead>Permissions</TableHead>
                      <TableHead>Utilisateurs</TableHead>
                      <TableHead>Statut</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {!roles || roles.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          Aucun rôle trouvé
                        </TableCell>
                      </TableRow>
                    ) : (
                      roles.map((role) => (
                        <TableRow key={role.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{role.name}</div>
                              <div className="text-sm text-muted-foreground">
                                {role.description || "Aucune description"}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <Settings className="h-4 w-4 mr-1 text-muted-foreground" />
                              {role.permissions?.length || 0} permission(s)
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <UserCheck className="h-4 w-4 mr-1 text-muted-foreground" />
                              {role.userCount || 0} utilisateur(s)
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={
                                role.isActive
                                  ? "bg-green-100 text-green-800"
                                  : "bg-red-100 text-red-800"
                              }
                            >
                              {role.isActive ? "Actif" : "Inactif"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button 
                                  variant="ghost" 
                                  className="h-8 w-8 p-0"
                                  disabled={operationLoading.delete || operationLoading.update || operationLoading.toggleStatus}
                                >
                                  <span className="sr-only">Ouvrir le menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem
                                  onClick={() => openViewDialog(role)}
                                  disabled={operationLoading.delete || operationLoading.update}
                                >
                                  <Eye className="mr-2 h-4 w-4" />
                                  Voir les détails
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => openEditDialog(role)}
                                  disabled={operationLoading.delete || operationLoading.update}
                                >
                                  <Edit className="mr-2 h-4 w-4" />
                                  Modifier
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  onClick={() => handleToggleStatus(role.id)}
                                  disabled={operationLoading.toggleStatus || operationLoading.delete || operationLoading.update}
                                >
                                  {operationLoading.toggleStatus ? (
                                    <LoadingSpinner size="sm" className="mr-2" />
                                  ) : role.isActive ? (
                                    <Lock className="mr-2 h-4 w-4" />
                                  ) : (
                                    <Unlock className="mr-2 h-4 w-4" />
                                  )}
                                  {operationLoading.toggleStatus 
                                    ? "Modification..." 
                                    : role.isActive ? "Désactiver" : "Activer"
                                  }
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  className="text-red-600"
                                  onClick={() => openDeleteDialog(role)}
                                  disabled={operationLoading.delete || operationLoading.update || operationLoading.toggleStatus}
                                >
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Supprimer
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {/* Dialog components - now using store directly */}
          <AddRoleDialog />
          <EditRoleDialog />
          <ViewRoleDialog />
          <DeleteRoleDialog />
        </div>
      </AdminLayout>
    </ProtectedRoute>
  );
}
