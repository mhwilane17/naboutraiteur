"use client";

import { useState, useEffect } from "react";
import { ProtectedRoute } from "@/components/admin/ProtectedRoute";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tag,
  Search,
  Plus,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Percent,
  Calendar,
  Archive,
  ArchiveRestore,
} from "lucide-react";
import { usePromotionsStore } from "@/stores/promotionsStore";
import { AddPromoDialog } from "@/components/admin/promotions/AddPromoDialog";
import { EditPromoDialog } from "@/components/admin/promotions/EditPromoDialog";
import { ViewPromoDialog } from "@/components/admin/promotions/ViewPromoDialog";
import { DeletePromoDialog } from "@/components/admin/promotions/DeletePromoDialog";
import { ProtectedView } from "@/components/ProtectedView";

export default function PromosPage() {
  const {
    searchTerm,
    setSearchTerm,
    selectedStatus,
    setSelectedStatus,
    selectedType,
    setSelectedType,
    openAddDialog,
    openEditDialog,
    openViewDialog,
    openDeleteDialog,
    togglePromoStatus,
    getFilteredPromos,
    getStats,
    formatValue,
    isExpired,
    fetchPromos,
    isLoading,
    error,
  } = usePromotionsStore();

  const filteredPromos = getFilteredPromos();
  const stats = getStats();

  // Charger les promotions au montage du composant
  useEffect(() => {
    fetchPromos();
  }, [fetchPromos]);

  return (
    <ProtectedRoute>
      <AdminLayout>
        <div className="space-y-6">
          {/* En-tête */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Gestion des promotions</h1>
              <p className="text-muted-foreground">
                Créez et gérez vos codes promotionnels et offres spéciales
              </p>
            </div>
            {/* <ProtectedView permissions={["CREATE_PROMOTION"]}>*/}
              <Button onClick={openAddDialog} className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Nouvelle promotion
              </Button>
            {/* </ProtectedView> */}
          </div>

          {/* Statistiques */}
          {/* <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total promotions</CardTitle>
                <Tag className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.total}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Promotions actives</CardTitle>
                <Percent className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{stats.active}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Promotions expirées</CardTitle>
                <Calendar className="h-4 w-4 text-orange-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-orange-600">{stats.expired}</div>
              </CardContent>
            </Card>
          </div> */}

          {/* Filtres */}
          <Card>
            <CardHeader>
              <CardTitle>Filtres</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Rechercher par nom, code ou description..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                </div>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <SelectValue placeholder="Statut" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Toutes</SelectItem>
                    <SelectItem value="active">Actives</SelectItem>
                    <SelectItem value="inactive">Inactives</SelectItem>
                    <SelectItem value="expired">Expirées</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous les types</SelectItem>
                    <SelectItem value="percentage">Pourcentage</SelectItem>
                    <SelectItem value="fixed_amount">Montant fixe</SelectItem>
                    <SelectItem value="free_delivery">Livraison gratuite</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Tableau des promotions - Vue Desktop */}
          <div className="hidden md:block">
            <Card>
              <CardHeader>
                <CardTitle>Promotions ({filteredPromos.length})</CardTitle>
                <CardDescription>
                  Liste de toutes les promotions et codes de réduction
                </CardDescription>
              </CardHeader>
              <CardContent>
                {error && (
                  <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
                    <p className="text-red-600 text-sm">{error}</p>
                  </div>
                )}
                {isLoading ? (
                  <div className="flex justify-center items-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
                    <span className="ml-2 text-muted-foreground">Chargement...</span>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Promotion</TableHead>
                          <TableHead>Code</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Valeur</TableHead>
                          <TableHead>Période</TableHead>
                          <TableHead>Statut</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredPromos.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center py-8">
                              <div className="flex flex-col items-center gap-2">
                                <Tag className="h-8 w-8 text-muted-foreground" />
                                <p className="text-muted-foreground">Aucune promotion trouvée</p>
                              </div>
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredPromos.map((promo) => {
                            const expired = isExpired(promo.endDate);
                            return (
                              <TableRow key={promo.id}>
                                <TableCell>
                                  <div>
                                    <div className="font-medium">{promo.name}</div>
                                    <div className="text-sm text-muted-foreground max-w-xs truncate">
                                      {promo.description}
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <Badge variant="outline" className="font-mono">
                                    {promo.code}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <Badge
                                    variant={promo.type === "percentage" ? "default" : "secondary"}
                                  >
                                    {promo.type === "percentage"
                                      ? "Pourcentage"
                                      : promo.type === "fixed_amount"
                                      ? "Montant fixe"
                                      : "Livraison gratuite"}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <div className="font-medium">{formatValue(promo)}</div>
                                  {promo.minOrderAmount && promo.minOrderAmount > 0 && (
                                    <div className="text-sm text-muted-foreground">
                                      Min: {promo.minOrderAmount} FCFA
                                    </div>
                                  )}
                                </TableCell>
                                <TableCell>
                                  <div className="text-sm">
                                    <div>
                                      {new Date(promo.startDate).toLocaleDateString("fr-FR")}
                                    </div>
                                    <div
                                      className={expired ? "text-red-600" : "text-muted-foreground"}
                                    >
                                      {new Date(promo.endDate).toLocaleDateString("fr-FR")}
                                    </div>
                                    {promo.activeStartTime && promo.activeEndTime && (
                                      <div className="text-xs text-muted-foreground">
                                        Heures: {promo.activeStartTime} - {promo.activeEndTime}
                                      </div>
                                    )}
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex flex-col gap-1">
                                    <Badge variant={promo.isActive ? "default" : "secondary"}>
                                      {promo.isActive ? "Active" : "Inactive"}
                                    </Badge>
                                    {expired && (
                                      <Badge variant="destructive" className="text-xs">
                                        Expirée
                                      </Badge>
                                    )}
                                  </div>
                                </TableCell>
                                <TableCell className="text-right">
                                  <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                      <Button variant="ghost" className="h-8 w-8 p-0">
                                        <MoreHorizontal className="h-4 w-4" />
                                      </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end">
                                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                      <DropdownMenuItem onClick={() => openViewDialog(promo)}>
                                        <Eye className="mr-2 h-4 w-4" />
                                        Voir
                                      </DropdownMenuItem>
                                      <DropdownMenuItem onClick={() => openEditDialog(promo)}>
                                        <Edit className="mr-2 h-4 w-4" />
                                        Modifier
                                      </DropdownMenuItem>
                                      <DropdownMenuSeparator />
                                      <DropdownMenuItem onClick={() => togglePromoStatus(promo.id)}>
                                        {promo.isActive ? (
                                          <>
                                            <Archive className="mr-2 h-4 w-4" />
                                            Désactiver
                                          </>
                                        ) : (
                                          <>
                                            <ArchiveRestore className="mr-2 h-4 w-4" />
                                            Activer
                                          </>
                                        )}
                                      </DropdownMenuItem>
                                      <DropdownMenuSeparator />
                                      <ProtectedView permissions={["DELETE_PROMOTION"]}>
                                        <DropdownMenuItem
                                          onClick={() => openDeleteDialog(promo)}
                                          className="text-red-600"
                                        >
                                          <Trash2 className="mr-2 h-4 w-4" />
                                          Supprimer
                                        </DropdownMenuItem>
                                      </ProtectedView>
                                    </DropdownMenuContent>
                                  </DropdownMenu>
                                </TableCell>
                              </TableRow>
                            );
                          })
                        )}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Vue Mobile - Cartes des promotions */}
          <div className="md:hidden space-y-4">
            {isLoading ? (
              <Card>
                <CardContent className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
                  <span className="ml-2 text-muted-foreground">Chargement...</span>
                </CardContent>
              </Card>
            ) : filteredPromos.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8 text-muted-foreground">
                  Aucune promotion trouvée
                </CardContent>
              </Card>
            ) : (
              filteredPromos.map((promo) => {
                const expired = isExpired(promo.endDate);
                return (
                  <Card key={promo.id} className="overflow-hidden">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="min-w-0">
                          <h3 className="font-medium text-sm truncate">{promo.name}</h3>
                          <p className="text-xs text-muted-foreground line-clamp-2">
                            {promo.description}
                          </p>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0 flex-shrink-0">
                              <span className="sr-only">Ouvrir le menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => openViewDialog(promo)}>
                              <Eye className="mr-2 h-4 w-4" />
                              Voir
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openEditDialog(promo)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Modifier
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => togglePromoStatus(promo.id)}>
                              {promo.isActive ? (
                                <>
                                  <Archive className="mr-2 h-4 w-4" />
                                  Désactiver
                                </>
                              ) : (
                                <>
                                  <ArchiveRestore className="mr-2 h-4 w-4" />
                                  Activer
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <ProtectedView permissions={["DELETE_PROMOTION"]}>
                              <DropdownMenuItem
                                onClick={() => openDeleteDialog(promo)}
                                className="text-red-600"
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Supprimer
                              </DropdownMenuItem>
                            </ProtectedView>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 mb-3">
                        <Badge variant="outline" className="text-xs font-mono">
                          {promo.code}
                        </Badge>
                        <Badge
                          variant={promo.type === "percentage" ? "default" : "secondary"}
                          className="text-xs"
                        >
                          {promo.type === "percentage"
                            ? "Pourcentage"
                            : promo.type === "fixed_amount"
                            ? "Montant fixe"
                            : "Livraison gratuite"}
                        </Badge>
                        <Badge
                          className="text-xs"
                          variant={promo.isActive ? "default" : "secondary"}
                        >
                          {promo.isActive ? "Active" : "Inactive"}
                        </Badge>
                        {expired && (
                          <Badge variant="destructive" className="text-xs">
                            Expirée
                          </Badge>
                        )}
                      </div>
                      <div className="text-xs space-y-1">
                        <div>
                          Valeur:{" "}
                          <span className="font-semibold text-primary">{formatValue(promo)}</span>
                          {promo.minOrderAmount && promo.minOrderAmount > 0 && (
                            <span className="text-muted-foreground">
                              {" "}
                              · Min {promo.minOrderAmount} FCFA
                            </span>
                          )}
                        </div>
                        <div>
                          Période: {new Date(promo.startDate).toLocaleDateString("fr-FR")} →{" "}
                          {new Date(promo.endDate).toLocaleDateString("fr-FR")}
                        </div>
                        {promo.activeStartTime && promo.activeEndTime && (
                          <div className="text-muted-foreground">
                            Heures: {promo.activeStartTime} - {promo.activeEndTime}
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
        </div>

        {/* Composants Dialog */}
        <AddPromoDialog />
        <EditPromoDialog />
        <ViewPromoDialog />
        <DeletePromoDialog />
      </AdminLayout>
    </ProtectedRoute>
  );
}
