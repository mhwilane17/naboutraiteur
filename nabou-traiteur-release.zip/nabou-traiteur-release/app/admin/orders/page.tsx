"use client";

import { useEffect } from "react";
import { ProtectedRoute } from "@/components/admin/ProtectedRoute";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Search,
  MoreHorizontal,
  Eye,
  Truck,
  CheckCircle,
  XCircle,
  Package,
  RefreshCw,
  Loader2,
} from "lucide-react";
import type { Order } from "@/types/orders"
import { useOrdersStore } from "@/stores/ordersStore";
import { ProtectedView } from "@/components/ProtectedView";
import { ViewOrderDialog } from "@/components/admin/orders";

// Configuration des statuts
const orderStatuses = [
  { value: "pending", label: "En attente", color: "bg-yellow-100 text-yellow-800" },
  { value: "confirmed", label: "Confirmée", color: "bg-blue-100 text-blue-800" },
  { value: "preparing", label: "En préparation", color: "bg-orange-100 text-orange-800" },
  { value: "ready", label: "Prête", color: "bg-purple-100 text-purple-800" },
  { value: "delivering", label: "En livraison", color: "bg-indigo-100 text-indigo-800" },
  { value: "delivered", label: "Livrée", color: "bg-green-100 text-green-800" },
  { value: "cancelled", label: "Annulée", color: "bg-red-100 text-red-800" },
];

const paymentStatuses = [
  { value: "pending", label: "En attente", color: "bg-yellow-100 text-yellow-800" },
  { value: "paid", label: "Payée", color: "bg-green-100 text-green-800" },
  { value: "failed", label: "Échouée", color: "bg-red-100 text-red-800" },
  { value: "refunded", label: "Remboursée", color: "bg-gray-100 text-gray-800" },
];

export default function OrdersPage() {
  // Utilisation du store Zustand
  const {
    // Data
    orders,
    loading,
    error,
    pagination,
    // Filters
    searchTerm,
    selectedStatus,
    selectedPaymentStatus,
    selectedStartDate,
    selectedEndDate,
    // UI State
    isViewDialogOpen,
    selectedOrder,
    isUpdating,
    isInitialized,
    isViewLoading,
    // Actions
    setSearchTerm,
    setSelectedStatus,
    setSelectedPaymentStatus,
    setSelectedStartDate,
    setSelectedEndDate,
    refetch,
    updateOrderStatus,
    openViewDialog,
    closeViewDialog,
    initialize,
  } = useOrdersStore();

  // Initialisation au montage
  useEffect(() => {
    if (!isInitialized) {
      initialize();
    }
  }, [isInitialized, initialize]);

  // Fonctions utilitaires
  const getStatusLabel = (status: string) => {
    return orderStatuses.find((s) => s.value === status)?.label || status;
  };

  const getStatusColor = (status: string) => {
    return orderStatuses.find((s) => s.value === status)?.color || "bg-gray-100 text-gray-800";
  };

  const getPaymentStatusLabel = (status: string) => {
    return paymentStatuses.find((s) => s.value === status)?.label || status;
  };

  const getPaymentStatusColor = (status: string) => {
    return paymentStatuses.find((s) => s.value === status)?.color || "bg-gray-100 text-gray-800";
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("fr-FR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("fr-FR", {
      style: "currency",
      currency: "XOF",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const getCustomerName = (order: Order) => {
    if (order.customer) {
      return `${order.customer.firstName} ${order.customer.lastName}`;
    }
    return "Client invité";
  };

  const getCustomerPhone = (order: Order) => {
    return order.customer?.phone || order.deliveryPhone || "N/A";
  };

  // Gestion des commandes
  const handleUpdateOrderStatus = async (orderId: string, newStatus: Order["status"]) => {
    try {
      await updateOrderStatus(orderId, newStatus);
    } catch (error) {
      console.error("Erreur lors de la mise à jour:", error);
    }
  };

  // Statistiques
  const stats = {
    total: orders.length,
    pending: orders.filter((o) => o.status === "pending").length,
    confirmed: orders.filter((o) => o.status === "confirmed").length,
    preparing: orders.filter((o) => o.status === "preparing").length,
    delivered: orders.filter((o) => o.status === "delivered").length,
    totalRevenue: orders
      .filter((o) => o.paymentStatus === "paid")
      .reduce((sum, o) => sum + o.finalAmount, 0),
  };

  if (error) {
    return (
      <ProtectedRoute>
        <AdminLayout>
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <p className="text-red-600 mb-4">Erreur lors du chargement des commandes</p>
              <Button onClick={refetch} variant="outline">
                <RefreshCw className="mr-2 h-4 w-4" />
                Réessayer
              </Button>
            </div>
          </div>
        </AdminLayout>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute>
      <AdminLayout>
        <div className="space-y-6">
          {/* En-tête */}
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Gestion des commandes</h1>
              <p className="text-gray-600 mt-2">
                Suivez et gérez toutes les commandes de vos clients
              </p>
            </div>
            <Button onClick={refetch} variant="outline" disabled={loading}>
              {loading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="mr-2 h-4 w-4" />
              )}
              Actualiser
            </Button>
          </div>

          {/* Statistiques */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold">{stats.total}</div>
                <p className="text-xs text-muted-foreground">Total commandes</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
                <p className="text-xs text-muted-foreground">En attente</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-blue-600">{stats.confirmed}</div>
                <p className="text-xs text-muted-foreground">Confirmées</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-orange-600">{stats.preparing}</div>
                <p className="text-xs text-muted-foreground">En préparation</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-green-600">{stats.delivered}</div>
                <p className="text-xs text-muted-foreground">Livrées</p>
              </CardContent>
            </Card>
          </div>

          {/* Filtres et recherche */}
          <Card>
            <CardHeader>
              <CardTitle>Filtres et recherche</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Rechercher par numéro, nom ou téléphone..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                </div>
                <div className="w-[180px]">
                  <Input
                    type="date"
                    value={selectedStartDate}
                    onChange={(e) => setSelectedStartDate(e.target.value)}
                    className="w-full"
                  />
                </div>
                <div className="w-[180px]">
                  <Input
                    type="date"
                    value={selectedEndDate}
                    onChange={(e) => setSelectedEndDate(e.target.value)}
                    className="w-full"
                  />
                </div>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filtrer par statut" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous les statuts</SelectItem>
                    {orderStatuses.map((status) => (
                      <SelectItem key={status.value} value={status.value}>
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedPaymentStatus} onValueChange={setSelectedPaymentStatus}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filtrer par paiement" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous les paiements</SelectItem>
                    {paymentStatuses.map((status) => (
                      <SelectItem key={status.value} value={status.value}>
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Tableau des commandes */}
          <Card>
            <CardHeader>
              <CardTitle>Liste des commandes</CardTitle>
              <CardDescription>
                {loading ? "Chargement..." : `${orders.length} commande(s) trouvée(s)`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center h-32">
                  <Loader2 className="h-8 w-8 animate-spin" />
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Commande</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Montant</TableHead>
                      <TableHead>Promotion</TableHead>
                      <TableHead>Statut</TableHead>
                      <TableHead>Paiement</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{order.orderNumber}</div>
                            <div className="text-sm text-muted-foreground">
                              {order.itemsCount} article(s)
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{getCustomerName(order)}</div>
                            <div className="text-sm text-muted-foreground">
                              {getCustomerPhone(order)}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{formatCurrency(order.finalAmount)}</div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">
                            {order.promotionUsage && order.promotionUsage?.length > 0 ? order.promotionUsage?.map((usage) => (
                              <div key={usage.promotion.id}>
                                {usage.promotion.name} ({usage.promotion.code})
                              </div>
                            )) : "-"}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(order.status)}>
                            {getStatusLabel(order.status)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={getPaymentStatusColor(order.paymentStatus)}>
                            {getPaymentStatusLabel(order.paymentStatus)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">{formatDate(order.createdAt)}</div>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                variant="ghost"
                                className="h-8 w-8 p-0"
                                disabled={isUpdating === order.id}
                              >
                                <span className="sr-only">Ouvrir le menu</span>
                                {isUpdating === order.id ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <MoreHorizontal className="h-4 w-4" />
                                )}
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => openViewDialog(order)}>
                                <Eye className="mr-2 h-4 w-4" />
                                Voir les détails
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              {/* <ProtectedView permissions={["UPDATE_ORDER"]}>*/}
                              <DropdownMenuItem
                                onClick={() => handleUpdateOrderStatus(order.id, "confirmed")}
                                disabled={
                                  order.status === "confirmed" || order.status === "cancelled"
                                }
                              >
                                <CheckCircle className="mr-2 h-4 w-4" />
                                Confirmer
                              </DropdownMenuItem>
                              {/* </ProtectedView> */}
                              {/* <ProtectedView permissions={["UPDATE_ORDER"]}>*/}
                              <DropdownMenuItem
                                onClick={() => handleUpdateOrderStatus(order.id, "preparing")}
                                disabled={
                                  order.status === "preparing" || order.status === "cancelled"
                                }
                              >
                                <Package className="mr-2 h-4 w-4" />
                                Préparer
                              </DropdownMenuItem>
                              {/* </ProtectedView> */}
                              {/* <ProtectedView permissions={["UPDATE_ORDER"]}> */}
                              <DropdownMenuItem
                                onClick={() => handleUpdateOrderStatus(order.id, "delivered")}
                                disabled={
                                  order.status === "delivered" || order.status === "cancelled"
                                }
                              >
                                <Truck className="mr-2 h-4 w-4" />
                                Livrer
                              </DropdownMenuItem>
                              {/* </ProtectedView> */}
                              <DropdownMenuSeparator />
                              {/* <ProtectedView permissions={["CANCEL_ORDER"]}> */}
                              <DropdownMenuItem
                                className="text-red-600"
                                onClick={() => handleUpdateOrderStatus(order.id, "cancelled")}
                                disabled={
                                  order.status === "delivered" || order.status === "cancelled"
                                }
                              >
                                <XCircle className="mr-2 h-4 w-4" />
                                Annuler
                              </DropdownMenuItem>
                              {/* </ProtectedView> */}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {/* Dialog de visualisation */}
          <ViewOrderDialog
            open={isViewDialogOpen}
            onClose={closeViewDialog}
            order={selectedOrder}
            loading={isViewLoading}
          />
        </div>
      </AdminLayout>
    </ProtectedRoute>
  );
}
