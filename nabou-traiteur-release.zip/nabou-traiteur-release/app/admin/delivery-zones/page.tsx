'use client'

import { useState, useEffect } from 'react'
import { ProtectedRoute } from '@/components/admin/ProtectedRoute'
import { AdminLayout } from '@/components/admin/AdminLayout'
import { ProtectedView } from '@/components/ProtectedView'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { Skeleton } from '@/components/ui/skeleton'
import { Plus, Search, Edit, Trash2, Eye, MapPin, Clock, Truck, MoreHorizontal, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { useDeliveryZones, type DeliveryZone, type CreateDeliveryZoneData, type UpdateDeliveryZoneData } from '@/hooks/useDeliveryZones'

export default function DeliveryZonesPage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [selectedZone, setSelectedZone] = useState<DeliveryZone | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    areas: '',
    deliveryFee: '',
    estimatedTime: '',
    isActive: true
  })
  const [formLoading, setFormLoading] = useState(false)

  // Hook pour gérer les zones de livraison
  const {
    zones,
    pagination,
    loading,
    error,
    fetchZones,
    createZone,
    updateZone,
    deleteZone,
    toggleZoneStatus,
  } = useDeliveryZones({
    search: searchTerm,
    isActive: statusFilter === 'all' ? undefined : statusFilter === 'active',
    limit: 50 // Augmenter la limite pour éviter la pagination pour l'instant
  })

  // Statistiques
  const stats = {
    totalZones: zones.length,
    activeZones: zones.filter(zone => zone.isActive).length,
    inactiveZones: zones.filter(zone => !zone.isActive).length,
    averageDeliveryFee: zones.length > 0 ? Math.round(zones.reduce((sum, zone) => sum + zone.deliveryFee, 0) / zones.length) : 0
  }

  // Les zones sont déjà filtrées par le hook
  const filteredZones = zones

  // Fonctions de gestion
  const handleAddZone = async () => {
    if (!formData.name || !formData.deliveryFee) {
      toast.error('Veuillez remplir tous les champs obligatoires')
      return
    }

    setFormLoading(true)
    try {
      const zoneData: CreateDeliveryZoneData = {
        name: formData.name,
        description: formData.description || undefined,
        deliveryFee: parseInt(formData.deliveryFee),
        estimatedTime: formData.estimatedTime || undefined,
        isActive: formData.isActive,
        areas: formData.areas ? formData.areas.split(',').map(area => area.trim()).filter(area => area.length > 0) : []
      }

      const result = await createZone(zoneData)
      if (result) {
        setIsAddDialogOpen(false)
        resetForm()
      }
    } finally {
      setFormLoading(false)
    }
  }

  const handleEditZone = async () => {
    if (!selectedZone || !formData.name || !formData.deliveryFee) {
      toast.error('Veuillez remplir tous les champs obligatoires')
      return
    }

    setFormLoading(true)
    try {
      const updateData: UpdateDeliveryZoneData = {
        name: formData.name,
        description: formData.description || undefined,
        deliveryFee: parseInt(formData.deliveryFee),
        estimatedTime: formData.estimatedTime || undefined,
        isActive: formData.isActive,
        areas: formData.areas ? formData.areas.split(',').map(area => area.trim()).filter(area => area.length > 0) : []
      }

      const result = await updateZone(selectedZone.id, updateData)
      if (result) {
        setIsEditDialogOpen(false)
        setSelectedZone(null)
        resetForm()
      }
    } finally {
      setFormLoading(false)
    }
  }

  const handleDeleteZone = async () => {
    if (!selectedZone) return

    setFormLoading(true)
    try {
      const result = await deleteZone(selectedZone.id)
      if (result) {
        setIsDeleteDialogOpen(false)
        setSelectedZone(null)
      }
    } finally {
      setFormLoading(false)
    }
  }

  const handleToggleZoneStatus = async (zoneId: string) => {
    try {
      await toggleZoneStatus(zoneId)
      toast.success('Statut mis à jour avec succès')
    } catch (error) {
      toast.error('Erreur lors de la mise à jour du statut')
    }
  }

  // Fonctions d'ouverture des dialogues
  const openAddDialog = () => {
    resetForm()
    setIsAddDialogOpen(true)
  }

  const openEditDialog = (zone: DeliveryZone) => {
    setSelectedZone(zone)
    setFormData({
      name: zone.name,
      description: zone.description || '',
      areas: zone.areas?.join(', ') || '',
      deliveryFee: zone.deliveryFee.toString(),
      estimatedTime: zone.estimatedTime || '',
      isActive: zone.isActive
    })
    setIsEditDialogOpen(true)
  }

  const openViewDialog = (zone: DeliveryZone) => {
    setSelectedZone(zone)
    setIsViewDialogOpen(true)
  }

  const openDeleteDialog = (zone: DeliveryZone) => {
    setSelectedZone(zone)
    setIsDeleteDialogOpen(true)
  }

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      areas: '',
      deliveryFee: '',
      estimatedTime: '',
      isActive: true
    })
  }

  const formatCurrency = (amount: number) => {
    return `${amount.toLocaleString()} FCFA`
  }

  return (
    <ProtectedRoute>
      <AdminLayout>
        <div className="space-y-6">
      {/* En-tête */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Zones de livraison</h1>
          <p className="text-muted-foreground">
            Gérez les zones de livraison et leurs tarifs
          </p>
        </div>
        {/* <ProtectedView permission="CREATE_DELIVERY_ZONE"> */}
          <Button onClick={openAddDialog}>
            <Plus className="mr-2 h-4 w-4" />
            Ajouter une zone
          </Button>
        {/* </ProtectedView> */}
      </div>

      {/* Statistiques */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total zones</CardTitle>
            <MapPin className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalZones}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Zones actives</CardTitle>
            <Truck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.activeZones}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Zones inactives</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.inactiveZones}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filtres */}
      <Card>
        <CardHeader>
          <CardTitle>Filtres</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Rechercher par nom, description ou quartier..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="active">Actives</SelectItem>
                <SelectItem value="inactive">Inactives</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tableau des zones */}
      <Card>
        <CardHeader>
          <CardTitle>Liste des zones ({filteredZones.length})</CardTitle>
          <CardDescription>
            Gérez vos zones de livraison et leurs paramètres
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Zone</TableHead>
                <TableHead>Quartiers</TableHead>
                <TableHead>Frais de livraison</TableHead>
                <TableHead>Temps estimé</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                // Skeleton loading
                Array.from({ length: 3 }).map((_, index) => (
                  <TableRow key={index}>
                    <TableCell>
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-3 w-48" />
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Skeleton className="h-5 w-16" />
                        <Skeleton className="h-5 w-16" />
                      </div>
                    </TableCell>
                    <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-16" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-8" /></TableCell>
                  </TableRow>
                ))
              ) : filteredZones.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8">
                    {error ? 'Erreur lors du chargement' : 'Aucune zone de livraison trouvée'}
                  </TableCell>
                </TableRow>
              ) : (
                filteredZones.map((zone) => (
                  <TableRow key={zone.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{zone.name}</div>
                        <div className="text-sm text-muted-foreground">{zone.description || 'Aucune description'}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {zone.areas?.slice(0, 2).map((area, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {area}
                          </Badge>
                        ))}
                        {(zone.areas?.length || 0) > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{(zone.areas?.length || 0) - 2}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">
                      {formatCurrency(zone.deliveryFee)}
                    </TableCell>
                    <TableCell>{zone.estimatedTime}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {/* <ProtectedView permission="ACTIVATE_DELIVERY_ZONE" fallback={
                          <Badge variant={zone.isActive ? 'default' : 'secondary'}>
                            {zone.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                        }> */}
                          <Switch
                            checked={zone.isActive}
                            onCheckedChange={() => handleToggleZoneStatus(zone.id)}
                            disabled={loading}
                          />
                          <Badge variant={zone.isActive ? 'default' : 'secondary'}>
                            {zone.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                        {/* </ProtectedView> */}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Ouvrir le menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => openViewDialog(zone)}>
                            <Eye className="mr-2 h-4 w-4" />
                            Voir les détails
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openEditDialog(zone)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Modifier
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <ProtectedView permission="DELETE_DELIVERY_ZONE">
                            <DropdownMenuItem 
                              onClick={() => openDeleteDialog(zone)}
                              className="text-red-600"
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Supprimer
                            </DropdownMenuItem>
                          </ProtectedView>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Dialog Ajouter */}
      {/* <ProtectedView permission="CREATE_DELIVERY_ZONE"> */}
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Ajouter une zone de livraison</DialogTitle>
              <DialogDescription>
                Créez une nouvelle zone de livraison avec ses paramètres
              </DialogDescription>
            </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="add-name">Nom de la zone *</Label>
                <Input
                  id="add-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Centre-ville"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="add-estimatedTime">Temps estimé *</Label>
                <Input
                  id="add-estimatedTime"
                  value={formData.estimatedTime}
                  onChange={(e) => setFormData({ ...formData, estimatedTime: e.target.value })}
                  placeholder="30-45 min"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="add-description">Description *</Label>
              <Textarea
                id="add-description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Description de la zone de livraison"
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="add-areas">Quartiers (séparés par des virgules) *</Label>
              <Textarea
                id="add-areas"
                value={formData.areas}
                onChange={(e) => setFormData({ ...formData, areas: e.target.value })}
                placeholder="Plateau, Rebeuss, Médina, Gueule Tapée"
                rows={2}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="add-deliveryFee">Frais de livraison (FCFA) *</Label>
                <Input
                  id="add-deliveryFee"
                  type="number"
                  value={formData.deliveryFee}
                  onChange={(e) => setFormData({ ...formData, deliveryFee: e.target.value })}
                  placeholder="1500"
                  step="100"
                />
              </div>

            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="add-isActive"
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
              />
              <Label htmlFor="add-isActive">Zone active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Annuler
            </Button>
            <Button onClick={handleAddZone} disabled={formLoading}>
              {formLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Ajouter la zone
            </Button>
          </DialogFooter>
          </DialogContent>
         </Dialog>
       {/* </ProtectedView> */}

      {/* Dialog Modifier */}
      {/* <ProtectedView permission="UPDATE_DELIVERY_ZONE">*/}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Modifier la zone de livraison</DialogTitle>
              <DialogDescription>
                Modifiez les paramètres de la zone de livraison
              </DialogDescription>
            </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Nom de la zone *</Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Centre-ville"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-estimatedTime">Temps estimé *</Label>
                <Input
                  id="edit-estimatedTime"
                  value={formData.estimatedTime}
                  onChange={(e) => setFormData({ ...formData, estimatedTime: e.target.value })}
                  placeholder="30-45 min"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-description">Description *</Label>
              <Textarea
                id="edit-description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Description de la zone de livraison"
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-areas">Quartiers (séparés par des virgules) *</Label>
              <Textarea
                id="edit-areas"
                value={formData.areas}
                onChange={(e) => setFormData({ ...formData, areas: e.target.value })}
                placeholder="Plateau, Rebeuss, Médina, Gueule Tapée"
                rows={2}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-deliveryFee">Frais de livraison (FCFA) *</Label>
                <Input
                  id="edit-deliveryFee"
                  type="number"
                  value={formData.deliveryFee}
                  onChange={(e) => setFormData({ ...formData, deliveryFee: e.target.value })}
                  placeholder="1500"
                  step="100"
                />
              </div>

            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="edit-isActive"
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
              />
              <Label htmlFor="edit-isActive">Zone active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Annuler
            </Button>
            <Button onClick={handleEditZone} disabled={formLoading}>
              {formLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Modifier la zone
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* </ProtectedView> */}

      {/* Dialog Voir */}
      {/* <ProtectedView permission="READ_DELIVERY_ZONE">*/}
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Détails de la zone de livraison</DialogTitle>
              <DialogDescription>
                Informations complètes sur la zone de livraison
              </DialogDescription>
            </DialogHeader>
          {selectedZone && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Nom</Label>
                  <p className="text-sm">{selectedZone.name}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Temps estimé</Label>
                  <p className="text-sm">{selectedZone.estimatedTime}</p>
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Description</Label>
                <p className="text-sm">{selectedZone.description}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Quartiers couverts</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {selectedZone.areas && selectedZone.areas.length > 0 ? (
                    selectedZone.areas.map((area, index) => (
                      <Badge key={index} variant="outline">
                        {area}
                      </Badge>
                    ))
                  ) : (
                    <span className="text-muted-foreground">Aucun quartier défini</span>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Frais de livraison</Label>
                  <p className="text-sm font-medium">{formatCurrency(selectedZone.deliveryFee)}</p>
                </div>

              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Statut</Label>
                  <div className="mt-1">
                    <Badge variant={selectedZone.isActive ? 'default' : 'secondary'}>
                      {selectedZone.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Dernière mise à jour</Label>
                  <p className="text-sm">{new Date(selectedZone.updatedAt).toLocaleDateString('fr-FR')}</p>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
              Fermer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* </ProtectedView> */}

      {/* Dialog Supprimer */}
      <ProtectedView permission="DELETE_DELIVERY_ZONE">
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Supprimer la zone de livraison</AlertDialogTitle>
              <AlertDialogDescription>
                Êtes-vous sûr de vouloir supprimer la zone "{selectedZone?.name}" ?
                Cette action est irréversible.
              </AlertDialogDescription>
            </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteZone} disabled={formLoading} className="bg-red-600 hover:bg-red-700">
              {formLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </ProtectedView>
        </div>
      </AdminLayout>
    </ProtectedRoute>
  )
}