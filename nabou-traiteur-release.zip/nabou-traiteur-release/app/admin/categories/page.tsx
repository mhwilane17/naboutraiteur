"use client";

import { useState, useEffect } from "react";
import { ProtectedRoute } from "@/components/admin/ProtectedRoute";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  FolderOpen,
  Search,
  Plus,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Archive,
  ArchiveRestore,
} from "lucide-react";
import {
  AddCategoryDialog,
  EditCategoryDialog,
  ViewCategoryDialog,
  DeleteCategoryDialog,
} from "@/components/admin/categories";
import { useCategoriesStore } from "@/stores/categoriesStore";
import { availableColors } from "@/types/categories";
import { ProtectedView } from "@/components/ProtectedView";

export default function CategoriesPage() {
  const {
    categories,
    loading,
    error,
    fetchCategories,
    updateCategory,
    openAddDialog,
    openEditDialog,
    openViewDialog,
    openDeleteDialog,
  } = useCategoriesStore();

  const toggleCategoryStatus = async (categoryId: string) => {
    const category = categories.find((c) => c.id === categoryId);
    if (category) {
      await updateCategory(categoryId, { isActive: !category.isActive });
    }
  };

  // Charger les catégories au montage du composant
  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  // États locaux pour la recherche et le filtrage
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");

  // Filtrage des catégories
  const filteredCategories = categories.filter((category) => {
    const matchesSearch =
      category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (category.description || "").toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      selectedStatus === "all" ||
      (selectedStatus === "active" && category.isActive) ||
      (selectedStatus === "inactive" && !category.isActive);
    return matchesSearch && matchesStatus;
  });

  return (
    <ProtectedRoute>
      <AdminLayout>
        <div className="space-y-6">
          {/* En-tête */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Gestion des catégories</h1>
              <p className="text-sm md:text-base text-muted-foreground">
                Organisez vos plats par catégories pour faciliter la navigation
              </p>
            </div>
            {/* <ProtectedView permissions={["CREATE_CATEGORY"]}>*/}
              <Button onClick={openAddDialog} className="flex items-center gap-2 w-full sm:w-auto">
                <Plus className="h-4 w-4" />
                Nouvelle catégorie
              </Button>
            {/* </ProtectedView> */}
          </div>

          {/* Filtres */}
          <Card>
            <CardContent className="p-4 md:p-6">
              <div className="flex flex-col gap-4 md:flex-row md:items-center">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Rechercher une catégorie..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                  <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                    <SelectTrigger className="w-full sm:w-[140px]">
                      <SelectValue placeholder="Statut" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="active">Actives</SelectItem>
                      <SelectItem value="inactive">Inactives</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Vue Desktop - Tableau des catégories */}
          <div className="hidden md:block">
            <Card>
              <CardHeader>
                <CardTitle>Catégories ({filteredCategories.length})</CardTitle>
                <CardDescription>Liste de toutes les catégories de plats</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex flex-col items-center justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4"></div>
                    <p className="text-muted-foreground">Chargement des catégories...</p>
                  </div>
                ) : error ? (
                  <div className="flex flex-col items-center justify-center py-12">
                    <div className="text-red-500 mb-4">
                      <svg className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <p className="text-muted-foreground mb-4">Erreur lors du chargement des catégories</p>
                    <Button onClick={fetchCategories} variant="outline">
                      Réessayer
                    </Button>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Catégorie</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Couleur</TableHead>
                        <TableHead>Plats</TableHead>
                        <TableHead>Statut</TableHead>
                        <TableHead>Créée le</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredCategories.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center py-8">
                            <div className="flex flex-col items-center gap-2">
                              <FolderOpen className="h-8 w-8 text-muted-foreground" />
                              <p className="text-muted-foreground">Aucune catégorie trouvée</p>
                            </div>
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredCategories.map((category) => {
                          const colorClass =
                            availableColors.find((c) => c.value === category.color)?.class ||
                            "bg-gray-500";
                          return (
                            <TableRow key={category.id}>
                              <TableCell>
                                <div className="flex items-center gap-3">
                                  <div className={`w-4 h-4 rounded-full ${colorClass}`} />
                                  <div>
                                    <div className="font-medium">{category.name}</div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <div className="max-w-xs truncate">{category.description}</div>
                              </TableCell>
                              <TableCell>
                                <Badge
                                  variant="outline"
                                  className={`${colorClass} text-white border-transparent`}
                                >
                                  {availableColors.find((c) => c.value === category.color)?.label}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge variant="secondary">{category.stats?.totalMenuItems || 0}</Badge>
                              </TableCell>
                              <TableCell>
                                <Badge variant={category.isActive ? "default" : "secondary"}>
                                  {category.isActive ? "Active" : "Inactive"}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {new Date(category.createdAt).toLocaleDateString("fr-FR")}
                              </TableCell>
                              <TableCell className="text-right">
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" className="h-8 w-8 p-0">
                                      <MoreHorizontal className="h-4 w-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                    <DropdownMenuItem onClick={() => openViewDialog(category)}>
                                      <Eye className="mr-2 h-4 w-4" />
                                      Voir
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => openEditDialog(category)}>
                                      <Edit className="mr-2 h-4 w-4" />
                                      Modifier
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem onClick={() => toggleCategoryStatus(category.id)}>
                                      {category.isActive ? (
                                        <>
                                          <Archive className="mr-2 h-4 w-4" />
                                          Désactiver
                                        </>
                                      ) : (
                                        <>
                                          <ArchiveRestore className="mr-2 h-4 w-4" />
                                          Activer
                                        </>
                                      )}
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <ProtectedView permissions={["DELETE_CATEGORY"]}>
                                      <DropdownMenuItem
                                        onClick={() => openDeleteDialog(category)}
                                        className="text-red-600"
                                      >
                                        <Trash2 className="mr-2 h-4 w-4" />
                                        Supprimer
                                      </DropdownMenuItem>
                                    </ProtectedView>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Vue Mobile - Cartes des catégories */}
          <div className="md:hidden space-y-4">
            {loading ? (
              <Card>
                <CardContent className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4"></div>
                  <span className="ml-2 text-muted-foreground">Chargement...</span>
                </CardContent>
              </Card>
            ) : error ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-8">
                  <div className="text-red-500 mb-4">
                    <svg className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <p className="text-muted-foreground mb-4 text-center">Erreur lors du chargement des catégories</p>
                  <Button onClick={fetchCategories} variant="outline">
                    Réessayer
                  </Button>
                </CardContent>
              </Card>
            ) : filteredCategories.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8 text-muted-foreground">
                  <div className="flex flex-col items-center gap-2">
                    <FolderOpen className="h-8 w-8 text-muted-foreground" />
                    <p>Aucune catégorie trouvée</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              filteredCategories.map((category) => {
                const colorClass =
                  availableColors.find((c) => c.value === category.color)?.class ||
                  "bg-gray-500";
                return (
                  <Card key={category.id} className="overflow-hidden">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <div className={`w-3 h-3 rounded-full ${colorClass} flex-shrink-0`} />
                            <h3 className="font-medium text-sm truncate">{category.name}</h3>
                          </div>
                          <p className="text-xs text-muted-foreground line-clamp-2">
                            {category.description || "Aucune description"}
                          </p>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0 flex-shrink-0">
                              <span className="sr-only">Ouvrir le menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => openViewDialog(category)}>
                              <Eye className="mr-2 h-4 w-4" />
                              Voir
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openEditDialog(category)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Modifier
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => toggleCategoryStatus(category.id)}>
                              {category.isActive ? (
                                <>
                                  <Archive className="mr-2 h-4 w-4" />
                                  Désactiver
                                </>
                              ) : (
                                <>
                                  <ArchiveRestore className="mr-2 h-4 w-4" />
                                  Activer
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <ProtectedView permissions={["DELETE_CATEGORY"]}>
                              <DropdownMenuItem
                                onClick={() => openDeleteDialog(category)}
                                className="text-red-600"
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Supprimer
                              </DropdownMenuItem>
                            </ProtectedView>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 mb-3">
                        <Badge
                          variant="outline"
                          className={`${colorClass} text-white border-transparent text-xs`}
                        >
                          {availableColors.find((c) => c.value === category.color)?.label}
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          {category.stats?.totalMenuItems || 0} plats
                        </Badge>
                        <Badge
                          variant={category.isActive ? "default" : "secondary"}
                          className="text-xs"
                        >
                          {category.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Créée le {new Date(category.createdAt).toLocaleDateString("fr-FR")}
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
        </div>

        {/* Dialogs */}
        <AddCategoryDialog />
        <EditCategoryDialog />
        <ViewCategoryDialog />
        <DeleteCategoryDialog />
      </AdminLayout>
    </ProtectedRoute>
  );
}
