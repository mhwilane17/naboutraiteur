import type { Metadata } from "next";
import { AdminProvider } from "@/components/admin/AdminProvider";
import "../globals.css";
import { ToastContainer } from "react-toastify";

export const metadata: Metadata = {
  title: "Admin - Nabou Traiteur",
  description: "Interface d'administration pour Nabou Traiteur",
};

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="bg-gray-50 min-h-screen">
      <ToastContainer />
      <AdminProvider>{children}</AdminProvider>
    </div>
  );
}
