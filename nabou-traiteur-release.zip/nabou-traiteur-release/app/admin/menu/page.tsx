"use client";

import { useState, useEffect } from "react";
import { ProtectedRoute } from "@/components/admin/ProtectedRoute";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { WeeklyMenuTab } from "./components/WeeklyMenuTab";
import DishesTab from "./components/DishesTab";
import { Calendar, UtensilsCrossed } from "lucide-react";
import { CreateDishModal } from "@/components/admin/menus/CreateDishModal";
import { CreateWeeklyMenuModal } from "@/components/admin/menus/CreateWeeklyMenuModal";
import { useMenuItemsStore } from "@/stores/menuItemsStore";
import { toast } from "sonner";
import { ProtectedView } from "@/components/ProtectedView";

export default function MenuPage() {
  const [activeTab, setActiveTab] = useState("weekly");

  // Utilisation du store Zustand pour les plats
  const { menuItems, error: menuItemsError, fetchMenuItems } = useMenuItemsStore();

  // Charger les menu items au montage du composant
  useEffect(() => {
    fetchMenuItems();
  }, [fetchMenuItems]);

  // Afficher les erreurs
  useEffect(() => {
    if (menuItemsError) {
      toast.error(`Erreur lors du chargement des plats: ${menuItemsError}`);
    }
  }, [menuItemsError]);

  return (
    <ProtectedRoute>
      <AdminLayout>
        <div className="space-y-6">
          {/* En-tête */}
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Gestion du menu</h1>
              <p className="text-gray-600 mt-2">
                Gérez vos menus de la semaine et vos plats par catégorie
              </p>
            </div>
            {/* <ProtectedView permissions={["CREATE_WEEKLY_MENU"]}> */}
            {activeTab === "weekly" && <CreateWeeklyMenuModal availableDishes={menuItems} />}
            {/* </ProtectedView> */}
            {/* <ProtectedView permissions={["CREATE_DISH"]}> */}
            {activeTab === "dishes" && <CreateDishModal />}
            {/* </ProtectedView> */}
          </div>

          {/* Onglets principaux */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-fit grid-cols-2">
              <TabsTrigger value="weekly" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Menus de la semaine
              </TabsTrigger>
              <TabsTrigger value="dishes" className="flex items-center gap-2">
                <UtensilsCrossed className="h-4 w-4" />
                Plats par catégorie
              </TabsTrigger>
            </TabsList>

            {/* Onglet Menus de la semaine */}
            <TabsContent value="weekly" className="space-y-6">
              <WeeklyMenuTab />
            </TabsContent>

            {/* Onglet Plats par catégorie */}
            <TabsContent value="dishes" className="space-y-6">
              <DishesTab />
            </TabsContent>
          </Tabs>
        </div>
      </AdminLayout>
    </ProtectedRoute>
  );
}
