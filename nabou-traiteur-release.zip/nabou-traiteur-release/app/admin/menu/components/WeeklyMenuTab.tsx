"use client";
import { useEffect, useState } from "react";
import { ViewWeeklyMenuModal } from "@/components/admin/menus/ViewWeeklyMenuModal";
import { EditWeeklyMenuModal } from "@/components/admin/menus/EditWeeklyMenuModal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Calendar,
  Clock,
  Users,
  TrendingUp,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { WeeklyMenu, WeeklyMenuDish } from "@/types/weeklyMenu";
import { useWeeklyMenuStore } from "@/stores/weeklyMenuStore";
import { useMenuItemsStore } from "@/stores/menuItemsStore";
import { toast } from "sonner";
import { ProtectedView } from "@/components/ProtectedView";

interface WeeklyMenuTabProps {
  // Plus besoin de props, on utilise le store
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "XOF",
    minimumFractionDigits: 0,
  }).format(amount);
};

export function WeeklyMenuTab({}: WeeklyMenuTabProps) {
  const { weeklyMenus, loading, fetchWeeklyMenus, deleteWeeklyMenu } = useWeeklyMenuStore();
  const { menuItems, fetchMenuItems } = useMenuItemsStore();
  const [editMenu, setEditMenu] = useState<WeeklyMenu | null>(null);
  const [openEditModal, setOpenEditModal] = useState(false);

  useEffect(() => {
    fetchWeeklyMenus({ includeDishes: true });
    fetchMenuItems();
  }, [fetchWeeklyMenus, fetchMenuItems]);

  const handleDeleteMenu = async (menu: WeeklyMenu) => {
    if (confirm(`Êtes-vous sûr de vouloir supprimer le menu "${menu.name}" ?`)) {
      try {
        toast.loading("Suppression du menu en cours...", { id: "delete-menu" });
        await deleteWeeklyMenu(menu.id);
        toast.success("Menu hebdomadaire supprimé avec succès", { id: "delete-menu" });
      } catch (error) {
        // Extraire le message d'erreur de la réponse API
        let errorMessage = "Erreur lors de la suppression du menu";

        if (error instanceof Error) {
          errorMessage = error.message;
        } else if (typeof error === "object" && error !== null) {
          // Essayer d'extraire le message d'erreur si c'est un objet
          if ("message" in error && typeof (error as { message: unknown }).message === "string") {
            errorMessage = (error as { message: string }).message;
          } else if ("error" in error) {
            const errorObj = error as { error: unknown };
            if (typeof errorObj.error === "string") {
              errorMessage = errorObj.error;
            } else if (
              typeof errorObj.error === "object" &&
              errorObj.error !== null &&
              "message" in errorObj.error &&
              typeof (errorObj.error as { message: unknown }).message === "string"
            ) {
              errorMessage = (errorObj.error as { message: string }).message;
            }
          }
        }

        toast.error(errorMessage, { id: "delete-menu" });
      }
    }
  };

  // Statistiques
  const allWeeklyDishes = weeklyMenus.flatMap((menu: WeeklyMenu) => menu.dishes);
  const weeklyStats = {
    total: allWeeklyDishes.length,
    available: allWeeklyDishes.filter((dish: WeeklyMenuDish) => dish.isAvailable).length,
    unavailable: allWeeklyDishes.filter((dish: WeeklyMenuDish) => !dish.isAvailable).length,
  };

  return (
    <div className="space-y-6">
      {/* Statistiques */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Plats</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{weeklyStats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Disponibles</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{weeklyStats.available}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Non disponibles</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{weeklyStats.unavailable}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Semaines actives</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {weeklyMenus.filter((menu) => menu.isActive).length}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chargement */}
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <div className="text-muted-foreground">Chargement des menus...</div>
        </div>
      ) : (
        <>
          {/* Vue Desktop - Tableau des menus */}
          <div className="hidden md:block">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Menus hebdomadaires</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Semaine</TableHead>
                        <TableHead>Période</TableHead>
                        <TableHead>Nombre de plats</TableHead>
                        <TableHead>Statut</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {weeklyMenus.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                            Aucun menu trouvé
                          </TableCell>
                        </TableRow>
                      ) : (
                        weeklyMenus.map((menu: WeeklyMenu) => (
                          <TableRow key={menu.id}>
                            <TableCell className="font-medium">{menu.name}</TableCell>
                            <TableCell>
                              {new Date(menu.startDate).toLocaleDateString("fr-FR")} -{" "}
                              {new Date(menu.endDate).toLocaleDateString("fr-FR")}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{menu.dishes.length} plats</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant={menu.isActive ? "default" : "secondary"}>
                                {menu.isActive ? "Actif" : "Inactif"}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" className="h-8 w-8 p-0">
                                    <span className="sr-only">Ouvrir le menu</span>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <ViewWeeklyMenuModal
                                    menuId={menu.id}
                                    trigger={
                                      <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                        <Eye className="mr-2 h-4 w-4" />
                                        Voir les détails
                                      </DropdownMenuItem>
                                    }
                                  />
                                  {/* <ProtectedView permissions={["UPDATE_WEEKLY_MENU"]}> */}
                                    <DropdownMenuItem
                                      onSelect={() => {
                                        // Assurons-nous que chaque plat a une quantité définie
                                        const menuWithQuantities = {
                                          ...menu,
                                          dishes: menu.dishes.map((dish) => ({
                                            ...dish,
                                            quantity: dish.quantity || 10,
                                          })),
                                        };
                                        console.log(menuWithQuantities);
                                        
                                        setEditMenu(menuWithQuantities);
                                        setOpenEditModal(true);
                                      }}
                                    >
                                      <Edit className="mr-2 h-4 w-4" />
                                      Modifier
                                    </DropdownMenuItem>
                                  {/* </ProtectedView> */}
                                  <DropdownMenuSeparator />
                                  <ProtectedView permissions={["DELETE_WEEKLY_MENU"]}>
                                    <DropdownMenuItem
                                      className="text-red-600"
                                      onClick={() => handleDeleteMenu(menu)}
                                    >
                                      <Trash2 className="mr-2 h-4 w-4" />
                                      Supprimer
                                    </DropdownMenuItem>
                                  </ProtectedView>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Vue Mobile - Cartes des menus */}
          <div className="md:hidden space-y-4">
            {weeklyMenus.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8 text-muted-foreground">
                  Aucun menu trouvé
                </CardContent>
              </Card>
            ) : (
              weeklyMenus.map((menu: WeeklyMenu) => (
                <Card key={menu.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-sm truncate pr-2">{menu.name}</h3>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(menu.startDate).toLocaleDateString("fr-FR")} -{" "}
                          {new Date(menu.endDate).toLocaleDateString("fr-FR")}
                        </p>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0 flex-shrink-0">
                            <span className="sr-only">Ouvrir le menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <ViewWeeklyMenuModal
                            menuId={menu.id}
                            trigger={
                              <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                <Eye className="mr-2 h-4 w-4" />
                                Voir les détails
                              </DropdownMenuItem>
                            }
                          />
                          {/* <ProtectedView permissions={["UPDATE_WEEKLY_MENU"]}> */}
                            <DropdownMenuItem
                              onSelect={() => {
                                // Assurons-nous que chaque plat a une quantité définie
                                const menuWithQuantities = {
                                  ...menu,
                                  dishes: menu.dishes.map((dish) => ({
                                    ...dish,
                                    quantity: dish.quantity || 10,
                                  })),
                                };
                                setEditMenu(menuWithQuantities);
                                setOpenEditModal(true);
                              }}
                            >
                              <Edit className="mr-2 h-4 w-4" />
                              Modifier
                            </DropdownMenuItem>
                          {/* </ProtectedView> */}
                          <DropdownMenuSeparator />
                          <ProtectedView permissions={["DELETE_WEEKLY_MENU"]}>
                            <DropdownMenuItem
                              className="text-red-600"
                              onClick={() => handleDeleteMenu(menu)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Supprimer
                            </DropdownMenuItem>
                          </ProtectedView>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className="text-xs">
                        {menu.dishes.length} plats
                      </Badge>
                      <Badge variant={menu.isActive ? "default" : "secondary"} className="text-xs">
                        {menu.isActive ? "Actif" : "Inactif"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </>
      )}

      {openEditModal && (
        <EditWeeklyMenuModal
          menu={editMenu}
          availableDishes={menuItems}
          open={openEditModal}
          onClose={setOpenEditModal}
        />
      )}

      {/* Les modales sont maintenant intégrées directement dans les triggers */}
    </div>
  );
}
