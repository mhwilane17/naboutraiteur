"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  UtensilsCrossed,
  Clock,
  Users,
  TrendingUp,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Search,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { ViewDishModal } from "@/components/admin/menus/ViewDishModal";
import EditDishModal from "@/components/admin/menus/EditDishModal";
import { toast } from "sonner";
import { useCategories } from "@/hooks/useCategories";
import { MenuItem } from "@/types/menu";
import { useMenuItemsStore } from "@/stores/menuItemsStore";
import { ProtectedView } from "@/components/ProtectedView";

interface DishesTabProps {}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "XOF",
    minimumFractionDigits: 0,
  }).format(amount);
};

export default function DishesTab({}: DishesTabProps) {
  // Utilisation du store Zustand
  const { menuItems: dishes, updateMenuItem, deleteMenuItem } = useMenuItemsStore();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [editingDish, setEditingDish] = useState<MenuItem | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const handleEditDish = (dish: MenuItem) => {
    setEditingDish(dish);
    setIsEditModalOpen(true);
  };

  const handleCloseEditModal = () => {
    setEditingDish(null);
    setIsEditModalOpen(false);
  };

  const { categories: apiCategories, loading: categoriesLoading } = useCategories();

  // Créer la liste des catégories avec l'option "Toutes les catégories"
  const categories = [
    { id: "all", name: "Toutes les catégories" },
    ...apiCategories.map((cat) => ({ id: cat.id, name: cat.name })),
  ];

  // Filtrage des plats par catégorie et recherche
  const filteredMenuItems = dishes
    .filter((item: MenuItem) => selectedCategory === "all" || item.category.id === selectedCategory)
    .filter(
      (item: MenuItem) =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description.toLowerCase().includes(searchTerm.toLowerCase())
    );

  const handleDeleteDish = async (dishId: string) => {
    if (confirm("Êtes-vous sûr de vouloir supprimer ce plat ?")) {
      try {
        await deleteMenuItem(dishId);
        toast.success("Plat supprimé avec succès!");
      } catch (error) {
        console.error("Erreur lors de la suppression du plat:", error);
        toast.error("Erreur lors de la suppression du plat");
      }
    }
  };

  // Statistiques
  const menuStats = {
    total: dishes.length,
    available: dishes.filter((item: MenuItem) => item.isAvailable).length,
    unavailable: dishes.filter((item: MenuItem) => !item.isAvailable).length,
  };

  return (
    <div className="space-y-6">
      {/* Statistiques */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Plats</CardTitle>
            <UtensilsCrossed className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{menuStats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Disponibles</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{menuStats.available}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Non disponibles</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{menuStats.unavailable}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Catégories</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{categories.length - 1}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filtres */}
      <Card>
        <CardHeader>
          <CardTitle>Filtres</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Rechercher un plat..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Filtrer par catégorie" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Vue Desktop - Tableau des plats */}
      <div className="hidden md:block">
        <Card>
          <CardHeader>
            <CardTitle>Plats</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Image</TableHead>
                    <TableHead>Nom</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Catégorie</TableHead>
                    <TableHead>Prix</TableHead>
                    <TableHead>Statut</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMenuItems.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                        Aucun plat trouvé pour cette catégorie
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredMenuItems.map((item: MenuItem) => (
                      <TableRow key={item.id}>
                        <TableCell>
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-12 h-12 object-cover rounded-md"
                          />
                        </TableCell>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell className="max-w-xs truncate">{item.description}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-nowrap">
                            {item.category.name}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            {item.options.map((option: any, index: number) => {
                              // option.values est déjà un tableau d'objets
                              const values = option.values;
                              return values.map((value: any, valueIndex: number) => (
                                <div key={`${index}-${valueIndex}`} className="text-sm">
                                  <span className="font-medium">{value.name}:</span>{" "}
                                  {formatCurrency(value.price)}
                                </div>
                              ));
                            })}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={item.isAvailable ? "default" : "secondary"}>
                            {item.isAvailable ? "Disponible" : "Indisponible"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Ouvrir le menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <ViewDishModal
                                dish={item}
                                trigger={
                                  <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                    <Eye className="mr-2 h-4 w-4" />
                                    Voir les détails
                                  </DropdownMenuItem>
                                }
                              />
                              {/* <ProtectedView permissions={["UPDATE_DISH"]}> */}
                                <DropdownMenuItem onClick={() => handleEditDish(item)}>
                                  <Edit className="mr-2 h-4 w-4" />
                                  Modifier
                                </DropdownMenuItem>
                              {/* </ProtectedView> */}
                              <DropdownMenuSeparator />
                              <ProtectedView permissions={["DELETE_DISH"]}>
                                <DropdownMenuItem
                                  className="text-red-600"
                                  onClick={() => handleDeleteDish(item.id)}
                                >
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Supprimer
                                </DropdownMenuItem>
                              </ProtectedView>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Vue Mobile - Cartes des plats */}
      <div className="md:hidden space-y-4">
        {filteredMenuItems.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8 text-muted-foreground">
              Aucun plat trouvé pour cette catégorie
            </CardContent>
          </Card>
        ) : (
          filteredMenuItems.map((item: MenuItem) => (
            <Card key={item.id} className="overflow-hidden">
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-16 object-cover rounded-md flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-medium text-sm truncate pr-2">{item.name}</h3>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0 flex-shrink-0">
                            <span className="sr-only">Ouvrir le menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <ViewDishModal
                            dish={item}
                            trigger={
                              <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                <Eye className="mr-2 h-4 w-4" />
                                Voir les détails
                              </DropdownMenuItem>
                            }
                          />
                          {/* <ProtectedView permissions={["UPDATE_DISH"]}> */}
                            <DropdownMenuItem onClick={() => handleEditDish(item)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Modifier
                            </DropdownMenuItem>
                          {/* </ProtectedView> */}
                          <DropdownMenuSeparator />
                          <ProtectedView permissions={["DELETE_DISH"]}>
                            <DropdownMenuItem
                              className="text-red-600"
                              onClick={() => handleDeleteDish(item.id)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Supprimer
                            </DropdownMenuItem>
                          </ProtectedView>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{item.description}</p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="outline" className="text-xs">
                        {item.category.name}
                      </Badge>
                      <Badge variant={item.isAvailable ? "default" : "secondary"} className="text-xs">
                        {item.isAvailable ? "Disponible" : "Indisponible"}
                      </Badge>
                    </div>
                    <div className="space-y-1">
                      {item.options.map((option: any, index: number) => {
                        // option.values est déjà un tableau d'objets
                        const values = option.values;
                        return values.map((value: any, valueIndex: number) => (
                          <div key={`${index}-${valueIndex}`} className="text-xs">
                            <span className="font-medium">{value.name}:</span>{" "}
                            <span className="text-primary font-semibold">{formatCurrency(value.price)}</span>
                          </div>
                        ));
                      })}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Modal d'édition */}
      {editingDish && (
        <EditDishModal dish={editingDish} open={isEditModalOpen} onClose={handleCloseEditModal} />
      )}
    </div>
  );
}
