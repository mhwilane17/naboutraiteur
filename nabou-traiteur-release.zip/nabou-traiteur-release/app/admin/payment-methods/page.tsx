'use client'

import { useState, useEffect } from 'react'
import { ProtectedRoute } from '@/components/admin/ProtectedRoute'
import { AdminLayout } from '@/components/admin/AdminLayout'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { Search, Edit, Eye, CreditCard, Smartphone, Banknote, MoreHorizontal, Loader2 } from 'lucide-react'
import { toast } from 'sonner'

// Types
interface PaymentMethod {
  id: string
  name: string
  type: 'mobile' | 'card' | 'cash' | 'bank_transfer'
  description: string | null
  provider: string | null
  fees: number
  isActive: boolean
  isDefault: boolean
  minAmount: number
  maxAmount: number
  processingTime: string | null
  config: any
  createdAt: string
  updatedAt: string
}

export default function PaymentMethodsPage() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [updatingStatusId, setUpdatingStatusId] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [typeFilter, setTypeFilter] = useState<string>('all')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    type: 'mobile' as PaymentMethod['type'],
    description: '',
    provider: '',
    fees: '',
    minAmount: '',
    maxAmount: '',
    processingTime: '',
    config: '',
    isActive: true,
    isDefault: false
  })

  // Fetch methods
  const fetchPaymentMethods = async () => {
    try {
      setIsLoading(true)
      const response = await fetch('/api/payment/methods')
      const data = await response.json()
      
      if (data.success) {
        // Ensure numeric values are properly converted
        const formattedMethods = data.data.methods.map((method: any) => ({
          ...method,
          fees: Number(method.fees) || 0,
          minAmount: Number(method.minAmount) || 0,
          maxAmount: Number(method.maxAmount) || 0
        }))
        setPaymentMethods(formattedMethods)
      } else {
        toast.error(data.message || 'Erreur lors du chargement des modes de paiement')
      }
    } catch (error) {
      toast.error('Erreur lors du chargement des modes de paiement')
      console.error(error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchPaymentMethods()
  }, [])

  // Statistiques
  const stats = {
    totalMethods: paymentMethods.length,
    activeMethods: paymentMethods.filter(method => method.isActive).length,
    inactiveMethods: paymentMethods.filter(method => !method.isActive).length,
    defaultMethod: paymentMethods.find(method => method.isDefault)?.name || 'Aucun'
  }

  // Filtrage
  const filteredMethods = paymentMethods.filter(method => {
    const matchesSearch = method.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (method.provider?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
                         (method.description?.toLowerCase() || '').includes(searchTerm.toLowerCase())
    const matchesType = typeFilter === 'all' || method.type === typeFilter
    const matchesStatus = statusFilter === 'all' || 
                         (statusFilter === 'active' && method.isActive) ||
                         (statusFilter === 'inactive' && !method.isActive)
    return matchesSearch && matchesType && matchesStatus
  })

  // Fonctions utilitaires
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'XOF',
      minimumFractionDigits: 0
    }).format(amount).replace('XOF', 'FCFA')
  }

  const getTypeIcon = (type: PaymentMethod['type']) => {
    switch (type) {
      case 'mobile': return <Smartphone className="h-4 w-4" />
      case 'card': return <CreditCard className="h-4 w-4" />
      case 'cash': return <Banknote className="h-4 w-4" />
      case 'bank_transfer': return <CreditCard className="h-4 w-4" />
      default: return <CreditCard className="h-4 w-4" />
    }
  }

  const getTypeLabel = (type: PaymentMethod['type']) => {
    switch (type) {
      case 'mobile': return 'Mobile Money'
      case 'card': return 'Carte bancaire'
      case 'cash': return 'Espèces'
      case 'bank_transfer': return 'Virement bancaire'
      default: return type
    }
  }

  const getTypeColor = (type: PaymentMethod['type']) => {
    switch (type) {
      case 'mobile': return 'bg-blue-100 text-blue-800'
      case 'card': return 'bg-purple-100 text-purple-800'
      case 'cash': return 'bg-green-100 text-green-800'
      case 'bank_transfer': return 'bg-orange-100 text-orange-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  // Fonctions de gestion
  const handleEditMethod = async () => {
    if (!selectedMethod || !formData.name) {
      toast.error('Veuillez remplir les champs obligatoires')
      return
    }

    setIsSaving(true)
    try {
      let configJson = null
      if (formData.config) {
        try {
          configJson = JSON.parse(formData.config)
        } catch (e) {
          toast.error('Le format JSON de la configuration est invalide')
          setIsSaving(false)
          return
        }
      }

      const payload = {
        name: formData.name,
        type: formData.type,
        description: formData.description,
        provider: formData.provider,
        fees: parseFloat(formData.fees) || 0,
        minAmount: parseInt(formData.minAmount, 10) || 0,
        maxAmount: parseInt(formData.maxAmount, 10) || 0,
        processingTime: formData.processingTime,
        isActive: formData.isActive,
        isDefault: formData.isDefault,
        config: configJson
      }

      const response = await fetch(`/api/payment/methods/${selectedMethod.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Mode de paiement modifié avec succès')
        setIsEditDialogOpen(false)
        setSelectedMethod(null)
        fetchPaymentMethods()
      } else {
        toast.error(data.message || 'Erreur lors de la modification')
      }
    } catch (error) {
      toast.error('Erreur lors de la modification')
      console.error(error)
    } finally {
      setIsSaving(false)
    }
  }

  const toggleMethodStatus = async (methodId: string, currentStatus: boolean) => {
    setUpdatingStatusId(methodId)
    try {
      const response = await fetch(`/api/payment/methods/${methodId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ isActive: !currentStatus })
      })

      const data = await response.json()
      if (data.success) {
        toast.success('Statut mis à jour')
        fetchPaymentMethods()
      } else {
        toast.error(data.message || 'Erreur lors de la mise à jour')
      }
    } catch (error) {
      toast.error('Erreur lors de la mise à jour')
    } finally {
      setUpdatingStatusId(null)
    }
  }

  const setAsDefault = async (methodId: string) => {
    try {
      const response = await fetch(`/api/payment/methods/${methodId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ isDefault: true })
      })

      const data = await response.json()
      if (data.success) {
        toast.success('Mode de paiement par défaut mis à jour')
        fetchPaymentMethods()
      } else {
        toast.error(data.message || 'Erreur lors de la mise à jour')
      }
    } catch (error) {
      toast.error('Erreur lors de la mise à jour')
    }
  }

  // Fonctions de dialog
  const openViewDialog = (method: PaymentMethod) => {
    setSelectedMethod(method)
    setIsViewDialogOpen(true)
  }

  const openEditDialog = (method: PaymentMethod) => {
    setSelectedMethod(method)
    setFormData({
      name: method.name,
      type: method.type,
      description: method.description || '',
      provider: method.provider || '',
      fees: method.fees.toString(),
      minAmount: method.minAmount.toString(),
      maxAmount: method.maxAmount.toString(),
      processingTime: method.processingTime || '',
      config: method.config ? JSON.stringify(method.config, null, 2) : '',
      isActive: method.isActive,
      isDefault: method.isDefault
    })
    setIsEditDialogOpen(true)
  }

  return (
    <ProtectedRoute>
      <AdminLayout>
        <div className="space-y-6">
          {/* En-tête */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">
                Modes de paiement
              </h1>
              <p className="text-muted-foreground">
                Gérez les modes de paiement acceptés par votre restaurant
              </p>
            </div>
          </div>

          {/* Statistiques */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total</CardTitle>
                <CreditCard className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalMethods}</div>
                <p className="text-xs text-muted-foreground">modes de paiement</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Actifs</CardTitle>
                <CreditCard className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{stats.activeMethods}</div>
                <p className="text-xs text-muted-foreground">modes actifs</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Inactifs</CardTitle>
                <CreditCard className="h-4 w-4 text-red-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{stats.inactiveMethods}</div>
                <p className="text-xs text-muted-foreground">modes inactifs</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Par défaut</CardTitle>
                <CreditCard className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold text-blue-600">{stats.defaultMethod}</div>
                <p className="text-xs text-muted-foreground">mode principal</p>
              </CardContent>
            </Card>
          </div>

          {/* Liste des modes de paiement */}
          <Card>
            <CardHeader>
              <CardTitle>Liste des modes de paiement</CardTitle>
              <CardDescription>
                Gérez vos modes de paiement et leurs paramètres
              </CardDescription>
            </CardHeader>
            <CardContent>

              {/* Table */}
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Mode de paiement</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Fournisseur</TableHead>
                    <TableHead>Frais</TableHead>
                    <TableHead>Limites</TableHead>
                    <TableHead>Statut</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        <div className="flex items-center justify-center">
                          <Loader2 className="h-6 w-6 animate-spin mr-2" />
                          Chargement...
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : filteredMethods.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8">
                        Aucun mode de paiement trouvé
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredMethods.map((method) => (
                      <TableRow key={method.id}>
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            {getTypeIcon(method.type)}
                            <div>
                              <div className="font-medium flex items-center gap-2">
                                {method.name}
                                {method.isDefault && (
                                  <Badge variant="outline" className="text-xs">
                                    Par défaut
                                  </Badge>
                                )}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {method.description}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getTypeColor(method.type)}>
                            {getTypeLabel(method.type)}
                          </Badge>
                        </TableCell>
                        <TableCell>{method.provider}</TableCell>
                        <TableCell>
                          {method.fees > 0 ? `${method.fees}%` : 'Gratuit'}
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <div>Min: {formatCurrency(method.minAmount)}</div>
                            <div>Max: {formatCurrency(method.maxAmount)}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {updatingStatusId === method.id ? (
                              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                            ) : (
                              <Switch
                                checked={method.isActive}
                                onCheckedChange={() => toggleMethodStatus(method.id, method.isActive)}
                                disabled={updatingStatusId !== null}
                              />
                            )}
                            <Badge variant={method.isActive ? 'default' : 'secondary'}>
                              {method.isActive ? 'Actif' : 'Inactif'}
                            </Badge>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Ouvrir le menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => openViewDialog(method)}>
                                <Eye className="mr-2 h-4 w-4" />
                                Voir les détails
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => openEditDialog(method)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Modifier
                              </DropdownMenuItem>
                              {!method.isDefault && (
                                <DropdownMenuItem onClick={() => setAsDefault(method.id)}>
                                  <CreditCard className="mr-2 h-4 w-4" />
                                  Définir par défaut
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuSeparator />
                              {/* <DropdownMenuItem 
                                onClick={() => openDeleteDialog(method)}
                                className="text-red-600"
                                disabled={method.isDefault}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Supprimer
                              </DropdownMenuItem> */}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        {/* Dialog Modifier */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Modifier le mode de paiement</DialogTitle>
              <DialogDescription>
                Modifiez les paramètres du mode de paiement
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Nom du mode *</Label>
                  <Input
                    id="edit-name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Orange Money"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-type">Type *</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value: PaymentMethod['type']) => setFormData({ ...formData, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mobile">Mobile Money</SelectItem>
                      <SelectItem value="card">Carte bancaire</SelectItem>
                      <SelectItem value="cash">Espèces</SelectItem>
                      <SelectItem value="bank_transfer">Virement bancaire</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-description">Description *</Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Description du mode de paiement"
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-provider">Fournisseur *</Label>
                  <Input
                    id="edit-provider"
                    value={formData.provider}
                    onChange={(e) => setFormData({ ...formData, provider: e.target.value })}
                    placeholder="Orange, Wave, etc."
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-fees">Frais (%)</Label>
                  <Input
                    id="edit-fees"
                    type="number"
                    value={formData.fees}
                    onChange={(e) => setFormData({ ...formData, fees: e.target.value })}
                    placeholder="0"
                    step="0.1"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-minAmount">Montant minimum (FCFA)</Label>
                  <Input
                    id="edit-minAmount"
                    type="number"
                    value={formData.minAmount}
                    onChange={(e) => setFormData({ ...formData, minAmount: e.target.value })}
                    placeholder="500"
                    step="100"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-maxAmount">Montant maximum (FCFA)</Label>
                  <Input
                    id="edit-maxAmount"
                    type="number"
                    value={formData.maxAmount}
                    onChange={(e) => setFormData({ ...formData, maxAmount: e.target.value })}
                    placeholder="500000"
                    step="1000"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-processingTime">Temps de traitement *</Label>
                <Input
                  id="edit-processingTime"
                  value={formData.processingTime}
                  onChange={(e) => setFormData({ ...formData, processingTime: e.target.value })}
                  placeholder="Instantané, 1-3 minutes, etc."
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-config">Configuration (JSON)</Label>
                <Textarea
                  id="edit-config"
                  value={formData.config}
                  onChange={(e) => setFormData({ ...formData, config: e.target.value })}
                  placeholder="{}"
                  rows={5}
                  className="font-mono text-sm"
                />
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-isActive"
                    checked={formData.isActive}
                    onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                  />
                  <Label htmlFor="edit-isActive">Mode actif</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-isDefault"
                    checked={formData.isDefault}
                    onCheckedChange={(checked) => setFormData({ ...formData, isDefault: checked })}
                  />
                  <Label htmlFor="edit-isDefault">Mode par défaut</Label>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} disabled={isSaving}>
                Annuler
              </Button>
              <Button onClick={handleEditMethod} disabled={isSaving}>
                {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Modifier le mode
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Dialog Voir */}
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Détails du mode de paiement</DialogTitle>
              <DialogDescription>
                Informations complètes sur le mode de paiement
              </DialogDescription>
            </DialogHeader>
            {selectedMethod && (
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Nom</Label>
                    <p className="text-sm font-medium">{selectedMethod.name}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Type</Label>
                    <div className="mt-1">
                      <Badge className={getTypeColor(selectedMethod.type)}>
                        {getTypeLabel(selectedMethod.type)}
                      </Badge>
                    </div>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Description</Label>
                  <p className="text-sm">{selectedMethod.description}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Fournisseur</Label>
                    <p className="text-sm">{selectedMethod.provider}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Frais</Label>
                    <p className="text-sm font-medium">
                      {selectedMethod.fees > 0 ? `${selectedMethod.fees}%` : 'Gratuit'}
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Montant minimum</Label>
                    <p className="text-sm font-medium">{formatCurrency(selectedMethod.minAmount)}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Montant maximum</Label>
                    <p className="text-sm font-medium">{formatCurrency(selectedMethod.maxAmount)}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Temps de traitement</Label>
                    <p className="text-sm">{selectedMethod.processingTime}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Statut</Label>
                    <div className="mt-1 flex items-center gap-2">
                      <Badge variant={selectedMethod.isActive ? 'default' : 'secondary'}>
                        {selectedMethod.isActive ? 'Actif' : 'Inactif'}
                      </Badge>
                      {selectedMethod.isDefault && (
                        <Badge variant="outline">
                          Par défaut
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Créé le</Label>
                    <p className="text-sm">{new Date(selectedMethod.createdAt).toLocaleDateString('fr-FR')}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Dernière mise à jour</Label>
                    <p className="text-sm">{new Date(selectedMethod.updatedAt).toLocaleDateString('fr-FR')}</p>
                  </div>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                Fermer
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Dialog Supprimer */}
      </AdminLayout>
    </ProtectedRoute>
  )
}