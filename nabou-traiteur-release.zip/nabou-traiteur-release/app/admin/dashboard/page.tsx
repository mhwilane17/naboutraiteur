"use client";

import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import { AdminWrapper } from "@/components/admin/AdminWrapper";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Users,
  ShoppingCart,
  UtensilsCrossed,
  TrendingUp,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Star,
  CreditCard,
  Package,
  RefreshCw,
  Loader2,
} from "lucide-react";
import { useDashboard } from "@/hooks/useDashboard";
import { DashboardFilters } from "@/components/admin/dashboard/DashboardFilters";

// Import dynamique d'ApexCharts pour éviter les erreurs SSR
const ReactApexChart = dynamic(() => import("react-apexcharts"), {
  ssr: false,
});

// Fonction pour formater les montants en FCFA
const formatAmount = (amount: number) => {
  return (
    new Intl.NumberFormat("fr-FR", {
      style: "decimal",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount) + " FCFA"
  );
};

// Fonction pour formater les dates relatives
const formatRelativeTime = (dateString: string) => {
  const date = new Date(dateString);
  const now = new Date();
  const diffInMinutes = Math.floor(
    (now.getTime() - date.getTime()) / (1000 * 60)
  );

  if (diffInMinutes < 1) return "À l'instant";
  if (diffInMinutes < 60) return `Il y a ${diffInMinutes} min`;

  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) return `Il y a ${diffInHours}h`;

  const diffInDays = Math.floor(diffInHours / 24);
  return `Il y a ${diffInDays}j`;
};

const getStatusIcon = (status: string) => {
  switch (status) {
    case "completed":
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    case "pending":
      return <Clock className="h-4 w-4 text-yellow-500" />;
    case "preparing":
      return <AlertCircle className="h-4 w-4 text-blue-500" />;
    case "cancelled":
      return <XCircle className="h-4 w-4 text-red-500" />;
    default:
      return <Clock className="h-4 w-4 text-gray-500" />;
  }
};

const getStatusLabel = (status: string) => {
  switch (status) {
    case "completed":
      return "Terminée";
    case "pending":
      return "En attente";
    case "preparing":
      return "En préparation";
    case "cancelled":
      return "Annulée";
    default:
      return status;
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case "completed":
      return "bg-green-100 text-green-800";
    case "pending":
      return "bg-yellow-100 text-yellow-800";
    case "preparing":
      return "bg-blue-100 text-blue-800";
    case "cancelled":
      return "bg-red-100 text-red-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
};

export default function DashboardPage() {
  // Définir une période par défaut de 30 jours
  const getDefaultDates = () => {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - 30);

    return {
      startDate: startDate.toISOString().split("T")[0],
      endDate: endDate.toISOString().split("T")[0],
    };
  };

  const defaultDates = getDefaultDates();
  const [startDate, setStartDate] = useState(defaultDates.startDate);
  const [endDate, setEndDate] = useState(defaultDates.endDate);
  const [selectedCompanyIds, setSelectedCompanyIds] = useState<string[]>([]);
  const { data, loading, error, fetchData } = useDashboard();

  // Charger les données par défaut au montage du composant avec la période de 30 jours
  useEffect(() => {
    fetchData(defaultDates.startDate, defaultDates.endDate, []);
  }, []);

  const handleDateRangeChange = (newStartDate: string, newEndDate: string) => {
    setStartDate(newStartDate);
    setEndDate(newEndDate);
  };

  const handleCompanyIdsChange = (companyIds: string[]) => {
    setSelectedCompanyIds(companyIds);
  };

  const handleApplyFilters = () => {
    fetchData(startDate, endDate, selectedCompanyIds);
  };

  const handleReset = () => {
    const newDefaultDates = getDefaultDates();
    setStartDate(newDefaultDates.startDate);
    setEndDate(newDefaultDates.endDate);
    setSelectedCompanyIds([]);
    // Récupérer les données par défaut après reset avec la période de 30 jours
    fetchData(newDefaultDates.startDate, newDefaultDates.endDate, []);
  };

  const stats = [
    {
      title: "Commandes totales",
      value: data?.stats?.totalOrders?.count?.toLocaleString() || "N/A",
      change: `${data?.stats?.totalOrders?.change > 0 ? "+" : ""}${
        data?.stats?.totalOrders?.change || "N/A"
      }%`,
      changeType: data?.stats?.totalOrders?.changeType || "N/A",
      icon: Package,
    },
    {
      title: "Commandes aujourd'hui",
      value: data?.stats?.todayOrders?.count?.toLocaleString() || "N/A",
      change: `${data?.stats?.todayOrders?.change > 0 ? "+" : ""}${
        data?.stats?.todayOrders?.change || "N/A"
      }%`,
      changeType: data?.stats?.todayOrders?.changeType || "N/A",
      icon: ShoppingCart,
    },
    {
      title: "Revenus de la journée",
      value: formatAmount(data?.stats?.todayRevenue?.amount || 0),
      change: `${data?.stats?.todayRevenue?.change > 0 ? "+" : ""}${
        data?.stats?.todayRevenue?.change || "N/A"
      }%`,
      changeType: data?.stats?.todayRevenue?.changeType || "N/A",
      icon: TrendingUp,
    },
    {
      title: "Total sur la periode",
      value: formatAmount(data?.stats?.totalRevenue?.amount || 0),
      change: `${data?.stats?.totalRevenue?.change > 0 ? "+" : ""}${
        data?.stats?.totalRevenue?.change || "N/A"
      }%`,
      changeType: data?.stats?.totalRevenue?.changeType || "N/A",
      icon: TrendingUp,
    },
  ];

  return (
    <AdminWrapper>
      <div className="space-y-6">
        {/* En-tête */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600 mt-2">
              Aperçu général de votre activité
            </p>
          </div>
          <Button
            onClick={() => fetchData(startDate, endDate, selectedCompanyIds)}
            variant="outline"
            size="sm"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Actualiser
          </Button>
        </div>

        {/* Filtres */}
        <DashboardFilters
          startDate={startDate}
          endDate={endDate}
          selectedCompanyIds={selectedCompanyIds}
          onDateRangeChange={handleDateRangeChange}
          onCompanyIdsChange={handleCompanyIdsChange}
          onApplyFilters={handleApplyFilters}
          onReset={handleReset}
        />

        {loading ? (
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="flex items-center space-x-2">
              <Loader2 className="h-6 w-6 animate-spin" />
              <span>Chargement des données...</span>
            </div>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
            <div className="text-red-600 text-center">
              <AlertCircle className="h-12 w-12 mx-auto mb-2" />
              <p className="text-lg font-semibold">Erreur de chargement</p>
              <p className="text-sm">{error}</p>
            </div>
            <Button
              onClick={() => fetchData(startDate, endDate, selectedCompanyIds)}
              variant="outline"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Réessayer
            </Button>
          </div>
        ) : !data ? (
          <div className="flex items-center justify-center min-h-[400px]">
            <p>Aucune donnée disponible</p>
          </div>
        ) : (
          <>
            {/* Statistiques */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <Card key={index}>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium text-gray-600">
                        {stat.title}
                      </CardTitle>
                      <Icon className="h-4 w-4 text-gray-400" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-gray-900">
                        {stat.value}
                      </div>
                      {/* <p className={`text-xs mt-1 ${
                      stat.changeType === 'positive' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {stat.change} par rapport {stat.title === "Revenus de la journée" ? "à hier" : "au mois dernier"}
                    </p> */}
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Graphiques */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Ventes par jour de la semaine */}
              <Card>
                <CardHeader>
                  <CardTitle>Ventes par jour de la semaine</CardTitle>
                  <CardDescription>
                    Répartition des ventes sur 7 jours
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ReactApexChart
                    options={{
                      chart: {
                        type: "area",
                        height: 350,
                        zoom: {
                          enabled: false,
                        },
                        toolbar: {
                          show: false,
                        },
                      },
                      dataLabels: {
                        enabled: false,
                      },
                      stroke: {
                        curve: "smooth",
                        width: 2,
                      },
                      fill: {
                        type: "gradient",
                        gradient: {
                          shadeIntensity: 1,
                          opacityFrom: 0.7,
                          opacityTo: 0.3,
                          stops: [0, 90, 100],
                        },
                      },
                      colors: ["#3B82F6"],
                      xaxis: {
                        categories: data.weeklySales.map((item) => item.day),
                        labels: {
                          style: {
                            fontSize: "12px",
                          },
                        },
                      },
                      yaxis: {
                        title: {
                          text: "Nombre de ventes",
                        },
                        labels: {
                          style: {
                            fontSize: "12px",
                          },
                        },
                      },
                      grid: {
                        borderColor: "#f1f5f9",
                        strokeDashArray: 3,
                      },
                      tooltip: {
                        y: {
                          formatter: function (val: number) {
                            return val + " ventes";
                          },
                        },
                      },
                    }}
                    series={[
                      {
                        name: "Ventes",
                        data: data.weeklySales.map((item) => item.sales),
                      },
                    ]}
                    type="area"
                    height={350}
                  />
                </CardContent>
              </Card>

              {/* Ventes par mois */}
              <Card>
                <CardHeader>
                  <CardTitle>Ventes mensuelles</CardTitle>
                  <CardDescription>
                    Évolution des ventes sur l'année
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ReactApexChart
                    options={{
                      chart: {
                        type: "area",
                        height: 350,
                        zoom: {
                          enabled: false,
                        },
                        toolbar: {
                          show: false,
                        },
                      },
                      dataLabels: {
                        enabled: false,
                      },
                      stroke: {
                        curve: "smooth",
                        width: 2,
                      },
                      fill: {
                        type: "gradient",
                        gradient: {
                          shadeIntensity: 1,
                          opacityFrom: 0.7,
                          opacityTo: 0.3,
                          stops: [0, 90, 100],
                        },
                      },
                      colors: ["#10B981"],
                      xaxis: {
                        categories: data.monthlySales.map((item) => item.month),
                        labels: {
                          style: {
                            fontSize: "12px",
                          },
                        },
                      },
                      yaxis: {
                        title: {
                          text: "Nombre de ventes",
                        },
                        labels: {
                          style: {
                            fontSize: "12px",
                          },
                        },
                      },
                      grid: {
                        borderColor: "#f1f5f9",
                        strokeDashArray: 3,
                      },
                      tooltip: {
                        y: {
                          formatter: function (val: number) {
                            return val + " ventes";
                          },
                        },
                      },
                    }}
                    series={[
                      {
                        name: "Ventes",
                        data: data.monthlySales.map((item) => item.sales),
                      },
                    ]}
                    type="area"
                    height={350}
                  />
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Commandes récentes */}
              <Card>
                <CardHeader>
                  <CardTitle>Commandes récentes</CardTitle>
                  <CardDescription>
                    Les dernières commandes passées
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {data.recentOrders.map((order, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-center space-x-4">
                          {getStatusIcon(order.status)}
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className="font-medium text-gray-900">
                                {order.orderNumber}
                              </span>
                              <Badge
                                className={`text-xs ${getStatusColor(
                                  order.status
                                )}`}
                              >
                                {getStatusLabel(order.status)}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600">
                              {order.customerName || order.customerEmail} •{" "}
                              {order.items.map((item) => item.name).join(", ")}
                            </p>
                            <p className="text-xs text-gray-400">
                              {formatRelativeTime(order.createdAt)}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900">
                            {formatAmount(order.totalAmount)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Produits les plus vendus */}
              <Card>
                <CardHeader>
                  <CardTitle>Produits les plus vendus</CardTitle>
                  <CardDescription>
                    Top 5 des plats les plus populaires
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {data.topProducts.map((product, index) => (
                      <div
                        key={product.id}
                        className="flex items-center justify-between p-3 border rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                            <span className="text-sm font-bold text-blue-600">
                              #{index + 1}
                            </span>
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">
                              {product.name}
                            </p>
                            <p className="text-sm text-gray-600">
                              {product.sales} ventes
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900">
                            {formatAmount(product.revenue)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Transactions récentes */}
              {/* <Card>
            <CardHeader>
              <CardTitle>Transactions récentes</CardTitle>
              <CardDescription>Les derniers paiements effectués</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {data.recentTransactions.map((transaction, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <CreditCard className="h-4 w-4 text-gray-400" />
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-medium text-gray-900">
                            {transaction.orderNumber}
                          </span>
                          <Badge
                            className={`text-xs ${
                              transaction.status === "completed"
                                ? "bg-green-100 text-green-800"
                                : transaction.status === "pending"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                            }`}
                          >
                            {transaction.status === "completed"
                              ? "Réussie"
                              : transaction.status === "pending"
                              ? "En attente"
                              : "Échouée"}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600">
                          {transaction.customerName} • {transaction.method}
                        </p>
                        <p className="text-xs text-gray-400">
                          {formatRelativeTime(transaction.createdAt)}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900">
                        {formatAmount(transaction.amount)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card> */}

              {/* Activité récente */}
              {/* <Card>
              <CardHeader>
                <CardTitle>Activité récente</CardTitle>
                <CardDescription>Les dernières actions sur la plateforme</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <div>
                      <p className="text-sm text-gray-900">Nouveau plat ajouté au menu</p>
                      <p className="text-xs text-gray-500">Il y a 2 heures</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                    <div>
                      <p className="text-sm text-gray-900">Mise à jour des prix</p>
                      <p className="text-xs text-gray-500">Il y a 4 heures</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
                    <div>
                      <p className="text-sm text-gray-900">Nouvelle promotion créée</p>
                      <p className="text-xs text-gray-500">Il y a 6 heures</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2"></div>
                    <div>
                      <p className="text-sm text-gray-900">Nouvel utilisateur inscrit</p>
                      <p className="text-xs text-gray-500">Il y a 8 heures</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card> */}
            </div>
          </>
        )}
      </div>
    </AdminWrapper>
  );
}
