"use client";

import { useEffect } from "react";
import { ProtectedRoute } from "@/components/admin/ProtectedRoute";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { ErrorDisplay } from "@/components/ui/error-display";
import { FadeIn } from "@/components/ui/fade-in";
import { TableSkeleton } from "@/components/ui/table-skeleton";
import { useCompaniesStore } from "@/stores/companiesStore";
import { useToast } from "@/components/ui/use-toast";
import { Search, Eye, Edit, Trash2 } from "lucide-react";

import { CompanyAdd } from "@/components/admin/companies/CompanyAdd";
import { CompanyEdit } from "@/components/admin/companies/CompanyEdit";
import { CompanyDelete } from "@/components/admin/companies/CompanyDelete";
import { CompanyView } from "@/components/admin/companies/CompanyView";

export default function CompaniesPage() {
  const {
    companies,
    loading,
    error,
    operationLoading,
    filters,
    pagination,
    fetchCompanies,
    openAddDialog,
    openEditDialog,
    openViewDialog,
    openDeleteDialog,
    setFilters,
    goToNextPage,
    goToPrevPage,
    cleanup,
    setSearchFilter: debouncedSearch,
  } = useCompaniesStore();

  const { toast } = useToast();

  useEffect(() => {
    fetchCompanies();
    return () => cleanup();
  }, [fetchCompanies, cleanup]);

  const handleRetry = async () => {
    await fetchCompanies();
  };

  const handleSearchChange = (value: string) => {
    debouncedSearch(value);
  };

  const handleStatusFilterChange = (value: string) => {
    setFilters({ isActive: value as any });
  };

  const isTableLoading = loading && operationLoading.fetchCompanies;

  return (
    <ProtectedRoute>
      <AdminLayout>
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Entreprises</h1>
              <p className="text-muted-foreground">Gérez les entreprises et leurs limites par catégorie</p>
            </div>
            <CompanyAdd />
          </div>

          {error && (
            <FadeIn>
              <ErrorDisplay error={error} onRetry={handleRetry} retryText="Recharger les données" />
            </FadeIn>
          )}

          <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-end">
            <div className="flex-1">
              <label className="text-sm font-medium">Recherche</label>
              <div className="relative mt-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Rechercher par nom ou email"
                  className="pl-9"
                  defaultValue={filters.search}
                  onChange={(e) => handleSearchChange(e.target.value)}
                />
              </div>
            </div>
            <div className="w-full sm:w-64">
              <label className="text-sm font-medium">Statut</label>
              <Select defaultValue={filters.isActive} onValueChange={handleStatusFilterChange}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Statut" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous</SelectItem>
                  <SelectItem value="true">Actives</SelectItem>
                  <SelectItem value="false">Suspendues</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="bg-white rounded-lg border">
            {isTableLoading ? (
              <TableSkeleton rows={5} columns={6} />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nom</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Statut</TableHead>
                    <TableHead>Employés</TableHead>
                    <TableHead>Limites</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {companies.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-sm text-muted-foreground py-10">
                        Aucune entreprise trouvée
                      </TableCell>
                    </TableRow>
                  )}
                  {companies.map((company) => (
                    <TableRow key={company.id}>
                      <TableCell className="font-medium">{company.name}</TableCell>
                      <TableCell>{company.contactEmail || "—"}</TableCell>
                      <TableCell>
                        <Badge className={company.isActive ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                          {company.isActive ? "Active" : "Suspendue"}
                        </Badge>
                      </TableCell>
                      <TableCell>{company.stats?.userCount ?? (company.users?.length ?? 0)}</TableCell>
                      <TableCell>{company.stats?.limitsCount ?? (company.limits?.length ?? 0)}</TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button variant="outline" size="sm" onClick={() => openViewDialog(company)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => openEditDialog(company)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="destructive" size="sm" onClick={() => openDeleteDialog(company)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>

          <div className="flex items-center justify-between gap-2">
            <div className="text-sm text-muted-foreground">
              Page {pagination.page} / {Math.max(1, pagination.totalPages || 1)} — {pagination.total} entreprises
            </div>
            <div className="space-x-2">
              <Button variant="outline" size="sm" onClick={goToPrevPage} disabled={pagination.page <= 1 || loading}>
                Précédent
              </Button>
              <Button variant="outline" size="sm" onClick={goToNextPage} disabled={pagination.page >= (pagination.totalPages || 1) || loading}>
                Suivant
              </Button>
            </div>
          </div>

          <CompanyEdit />
          <CompanyDelete />
          <CompanyView />
        </div>
      </AdminLayout>
    </ProtectedRoute>
  );
}