"use client";

import React, { useEffect, useState } from 'react';
import { ProtectedRoute } from '@/components/admin/ProtectedRoute';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Save,
  RotateCcw,
  Settings,
  ShoppingCart,
  Bell,
  Shield,
  Palette,
  CheckCircle,
  AlertCircle,
  Loader2
} from 'lucide-react';
import { useConfigurationsStore } from '@/stores/configurationsStore';
import { ConfigurationSection } from '@/components/admin/configurations/ConfigurationSection';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

// Métadonnées des sections pour la navigation
const sectionMetadata = {
  general: {
    id: 'general',
    title: 'Général',
    description: 'Paramètres généraux de l\'application',
    icon: Settings,
    color: 'text-blue-600'
  },
  orders: {
    id: 'orders',
    title: 'Commandes',
    description: 'Configuration des commandes et heures d\'ouverture',
    icon: ShoppingCart,
    color: 'text-green-600'
  },
  notifications: {
    id: 'notifications',
    title: 'Notifications',
    description: 'Paramètres des notifications WhatsApp et email',
    icon: Bell,
    color: 'text-yellow-600'
  },
  security: {
    id: 'security',
    title: 'Sécurité',
    description: 'Paramètres de sécurité et authentification',
    icon: Shield,
    color: 'text-red-600'
  },
  appearance: {
    id: 'appearance',
    title: 'Apparence',
    description: 'Personnalisation de l\'interface utilisateur',
    icon: Palette,
    color: 'text-purple-600'
  }
} as const;

export default function SettingsPage() {
  const { toast } = useToast();
  const [activeSection, setActiveSection] = useState('general');
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  const {
    configurations,
    values,
    loading,
    error,
    operationLoading,
    validationErrors,
    fetchConfigurations,
    updateValue,
    saveChanges,
    resetChanges,
    hasChanges,
    getConfigurationsBySection,
    getAllSections,
    hasValidationErrors
  } = useConfigurationsStore();

  // Détecter si on est sur mobile avec debounce pour les performances
  useEffect(() => {
    let timeoutId: NodeJS.Timeout;

    const checkMobile = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        setIsMobile(window.innerWidth < 768);
      }, 100);
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => {
      window.removeEventListener('resize', checkMobile);
      clearTimeout(timeoutId);
    };
  }, []);

  // Charger les configurations au montage
  useEffect(() => {
    fetchConfigurations();
  }, [fetchConfigurations]);

  // Obtenir les sections disponibles
  const availableSections = getAllSections().filter(section =>
    Object.keys(sectionMetadata).includes(section)
  );

  // Gérer la sauvegarde
  const handleSave = async () => {
    if (hasValidationErrors()) {
      toast({
        title: "Erreurs de validation",
        description: "Veuillez corriger les erreurs avant de sauvegarder.",
        variant: "destructive",
      });
      return;
    }

    const success = await saveChanges();
    if (success) {
      toast({
        title: "Configurations sauvegardées",
        description: "Toutes les modifications ont été appliquées avec succès.",
        variant: "default",
      });
    } else {
      toast({
        title: "Erreur de sauvegarde",
        description: "Une erreur est survenue lors de la sauvegarde.",
        variant: "destructive",
      });
    }
  };

  // Gérer l'annulation avec confirmation
  const handleReset = () => {
    if (hasChanges()) {
      setShowResetDialog(true);
    }
  };

  const confirmReset = () => {
    resetChanges();
    setShowResetDialog(false);
    toast({
      title: "Modifications annulées",
      description: "Toutes les modifications ont été annulées.",
      variant: "default",
    });
  };

  // Compter les erreurs par section
  const getErrorCountForSection = (section: string) => {
    const sectionConfigs = getConfigurationsBySection(section);
    return sectionConfigs.filter(config => validationErrors[config.key]).length;
  };



  return (
    <ProtectedRoute>
      <AdminLayout>
        <div className="relative flex flex-col justify-between h-full">
          <div className="space-y-6 pb-20">
            {/* En-tête */}
            <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Configuration</h1>
                <p className="text-gray-600 mt-1">
                  Gérez les paramètres système de votre application
                </p>
              </div>

              {/* Indicateurs d'état */}
              <div className="flex items-center space-x-2">
                {hasChanges() && (
                  <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    Modifications en attente
                  </Badge>
                )}

                {hasValidationErrors() && (
                  <Badge variant="destructive">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    {Object.keys(validationErrors).length} erreur{Object.keys(validationErrors).length > 1 ? 's' : ''}
                  </Badge>
                )}

                {configurations.length > 0 && (
                  <Badge variant="outline">
                    {configurations.length} configuration{configurations.length > 1 ? 's' : ''}
                  </Badge>
                )}
              </div>
            </div>

            {/* Navigation et contenu */}
            {isMobile ? (
              // Version mobile avec navigation optimisée
              <div className="space-y-4">
                {/* Navigation mobile avec scroll horizontal */}
                <div className="overflow-x-auto pb-2">
                  <div className="flex space-x-2 min-w-max px-1">
                    {availableSections.map(section => {
                      const metadata = sectionMetadata[section as keyof typeof sectionMetadata];
                      const errorCount = getErrorCountForSection(section);
                      const IconComponent = metadata.icon;
                      const isActive = activeSection === section;

                      return (
                        <button
                          key={section}
                          onClick={() => setActiveSection(section)}
                          className={`flex items-center space-x-2 px-4 py-3 rounded-lg whitespace-nowrap transition-all duration-200 min-w-[120px] ${isActive
                            ? 'bg-primary text-white shadow-md'
                            : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50 active:bg-gray-100'
                            }`}
                        >
                          <IconComponent className={`h-4 w-4 flex-shrink-0 ${isActive ? 'text-white' : metadata.color}`} />
                          <span className="text-sm font-medium">{metadata.title}</span>
                          {errorCount > 0 && (
                            <Badge variant="destructive" className="h-5 w-5 p-0 text-xs flex-shrink-0">
                              {errorCount}
                            </Badge>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Indicateur de section active */}
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="flex items-center space-x-2">
                    {(() => {
                      const metadata = sectionMetadata[activeSection as keyof typeof sectionMetadata];
                      const IconComponent = metadata.icon;
                      return (
                        <>
                          <IconComponent className={`h-5 w-5 ${metadata.color}`} />
                          <div>
                            <h2 className="font-semibold text-gray-900">{metadata.title}</h2>
                            <p className="text-sm text-gray-600">{metadata.description}</p>
                          </div>
                        </>
                      );
                    })()}
                  </div>
                </div>

                {/* Contenu de la section active */}
                <div className="space-y-4">
                  <ConfigurationSection
                    section={activeSection}
                    configurations={getConfigurationsBySection(activeSection)}
                    values={values}
                    onChange={updateValue}
                    errors={validationErrors}
                  />
                </div>
              </div>
            ) : (
              // Version desktop avec sidebar
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* Navigation sidebar */}
                <div className="lg:col-span-1">
                  <Card className="sticky top-6">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg">Sections</CardTitle>
                      <CardDescription className="text-sm">
                        Naviguez entre les différentes catégories de configuration
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {availableSections.map(section => {
                        const metadata = sectionMetadata[section as keyof typeof sectionMetadata];
                        const errorCount = getErrorCountForSection(section);
                        const IconComponent = metadata.icon;
                        const isActive = activeSection === section;

                        return (
                          <button
                            key={section}
                            onClick={() => setActiveSection(section)}
                            className={`w-full flex items-center justify-between p-3 rounded-lg text-left transition-colors ${isActive
                              ? 'bg-primary text-white'
                              : 'hover:bg-gray-50 text-gray-700'
                              }`}
                          >
                            <div className="flex items-center space-x-3">
                              <IconComponent className={`h-4 w-4 ${isActive ? 'text-white' : metadata.color}`} />
                              <div>
                                <div className="font-medium text-sm">{metadata.title}</div>
                                <div className={`text-xs ${isActive ? 'text-white/80' : 'text-gray-500'}`}>
                                  {getConfigurationsBySection(section).length} config{getConfigurationsBySection(section).length > 1 ? 's' : ''}
                                </div>
                              </div>
                            </div>

                            {errorCount > 0 && (
                              <Badge variant="destructive" className="h-5 w-5 p-0 text-xs">
                                {errorCount}
                              </Badge>
                            )}
                          </button>
                        );
                      })}
                    </CardContent>
                  </Card>
                </div>

                {/* Contenu principal */}
                <div className="lg:col-span-3">
                  <ConfigurationSection
                    section={activeSection}
                    configurations={getConfigurationsBySection(activeSection)}
                    values={values}
                    onChange={updateValue}
                    errors={validationErrors}
                  />
                </div>
              </div>
            )}

          </div>

          {/* Boutons d'action fixes - optimisés pour mobile */}
          <div className="sticky bottom-0 bg-white border-t border-gray-200 p-4 shadow-lg z-50 rounded-2xl">
            <div className="w-full">
              {isMobile ? (
                // Version mobile avec boutons empilés
                <div className="space-y-3">
                  {/* Indicateur d'état */}
                  <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
                    {hasChanges() ? (
                      <>
                        <AlertCircle className="h-4 w-4 text-orange-500" />
                        <span className="text-center">Modifications non sauvegardées</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-center">Tout est sauvegardé</span>
                      </>
                    )}
                  </div>

                  {/* Boutons d'action */}
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      variant="outline"
                      onClick={handleReset}
                      disabled={!hasChanges() || operationLoading.save}
                      className="h-12 text-base"
                    >
                      <RotateCcw className="h-5 w-5 mr-2" />
                      Annuler
                    </Button>

                    <Button
                      onClick={handleSave}
                      disabled={!hasChanges() || hasValidationErrors() || operationLoading.save}
                      className="h-12 text-base"
                    >
                      {operationLoading.save ? (
                        <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                      ) : (
                        <Save className="h-5 w-5 mr-2" />
                      )}
                      Sauvegarder
                    </Button>
                  </div>
                </div>
              ) : (
                // Version desktop
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    {hasChanges() ? (
                      <>
                        <AlertCircle className="h-4 w-4 text-orange-500" />
                        <span>Vous avez des modifications non sauvegardées</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span>Toutes les modifications sont sauvegardées</span>
                      </>
                    )}
                  </div>

                  <div className="flex items-center space-x-3">
                    <Button
                      variant="outline"
                      onClick={handleReset}
                      disabled={!hasChanges() || operationLoading.save}
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Annuler
                    </Button>

                    <Button
                      onClick={handleSave}
                      disabled={!hasChanges() || hasValidationErrors() || operationLoading.save}
                    >
                      {operationLoading.save ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Save className="h-4 w-4 mr-2" />
                      )}
                      Sauvegarder
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Dialog de confirmation pour l'annulation */}
        <AlertDialog open={showResetDialog} onOpenChange={setShowResetDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Annuler les modifications ?</AlertDialogTitle>
              <AlertDialogDescription>
                Vous avez des modifications non sauvegardées. Êtes-vous sûr de vouloir les annuler ?
                Cette action ne peut pas être annulée.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Garder les modifications</AlertDialogCancel>
              <AlertDialogAction onClick={confirmReset} className="bg-red-600 hover:bg-red-700">
                Oui, annuler
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </AdminLayout>
    </ProtectedRoute>
  );
}